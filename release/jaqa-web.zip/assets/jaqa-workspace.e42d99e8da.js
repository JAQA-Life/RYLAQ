/* ---- modules/core.js ---- */
/*
JAQA Global Risk, Finance, Insurance & Procurement Intelligence Workspace
Built for jaqa.life or enterprise intranet deployment.
JAQA™ is a trademark of JAQA.
Educational and enterprise information-discovery use only.
Not legal, compliance, credit, investment, treasury, insurance, reinsurance,
underwriting, claims, sanctions, AML, procurement, bid, award, tax, or
supply-chain assurance advice.
Covers global risk domains, finance/counterparty risk, market/macro indicators,
insurance/reinsurance counterparties, procurement, bids, tenders, awards,
grants, PPPs, concessions, regulations, events, cyber, climate, ESG, trade,
sanctions, supply chain, and third-party signals where public APIs or official
link-outs are available.
Powered by selected public APIs and official link-outs including GLEIF,
World Bank, IMF, OECD, UN, ILO, ReliefWeb, USGS, Open-Meteo, NOAA/NWS,
NASA FIRMS, CISA KEV, NVD, CPSC, NHTSA, USAspending, Federal Register,
SEC EDGAR/XBRL, TED, SAM.gov, OFAC, EU/UK/UN/BIS sanctions link-outs, EPA,
CourtListener, OpenStreetMap, Wikidata, UN Comtrade, FRED, ECB, BIS,
ACLED, GDELT, OpenCorporates, Companies House, IAIS, EIOPA, NAIC/state DOI,
FCA/PRA, BaFin, APRA, OSFI, NFRA/CBIRC, IRDAI, rating agency link-outs,
Swiss Re/Munich Re/broker market report link-outs, Lloyd’s public resources,
ILS/cat bond public sources, captive registries, UNGM, World Bank/ADB/AfDB/
IDB/EBRD/IsDB/DFC procurement, EU Funding & Tenders, IATI/AidData, WTO GPA,
OECD procurement, and national/subnational procurement portal link-outs
where available and CORS-verified.
No stored searches. No backend. No proxy. No scraping of paid/confidential sources.
No credit rating. No investment advice. No treasury advice. No insurance advice.
No sanctions clearance. No AML determination. No procurement bid advice.
© {current year} JAQA™. All rights reserved.
*/

/*
 * core.js — namespace, in-memory state, event bus, DOM helpers, icons,
 * legal text, input hygiene guards, and the request manager.
 *
 * PRIVACY ENFORCEMENT (read this before changing anything):
 *  - All state lives in the JS heap only (R.state). There is no persistence
 *    layer at all: no cookies, no browser storage, no service worker. A page
 *    refresh therefore clears everything. scripts/check-static-safety.mjs fails
 *    the build if any storage API name appears in dist/.
 *  - Search terms are never written to the URL, never logged to the console,
 *    and never included in export filenames.
 *  - Every network call goes through R.net.request(), which uses
 *    cache:"no-store", credentials:"omit", referrerPolicy:"no-referrer", and
 *    refuses to contact a source unless it is live (verified) for this session.
 *
 * LEGAL / TRADEMARK TEXT lives in R.legal below. JAQA™ must only appear in
 * legal, copyright, privacy, disclaimer, ownership, and export-metadata text.
 * Normal UI branding is "JAQA" without the symbol.
 */
(function (global) {
  'use strict';

  const R = (global.JAQAWorkspace = global.JAQAWorkspace || {});
  R.version = '1.0.0';
  R.productName = 'JAQA Global Risk, Finance, Insurance & Procurement Intelligence Workspace';
  R.host = 'jaqa.life';
  R.config = R.config || {};

  /* ------------------------------------------------------------------ *
   * Legal & branding text (brandingLegalHelpers)
   * ------------------------------------------------------------------ */
  const YEAR = new Date().getFullYear();
  const ADVICE_LIST =
    'legal, compliance, credit, investment, treasury, insurance, reinsurance, underwriting, claims, sanctions, AML, procurement, bid, award, tax, or supply-chain assurance advice';
  R.legal = {
    year: YEAR,
    trademark: 'JAQA™',
    copyright: `© ${YEAR} JAQA™. All rights reserved.`,
    trademarkNotice: 'JAQA™ is a trademark of JAQA.',
    shortDisclaimer: `Educational and enterprise information-discovery use only. Not ${ADVICE_LIST}.`,
    privacyLegalSentence: `JAQA™ is a trademark of JAQA. This tool is provided for educational, research, and enterprise information-discovery purposes only. It does not provide ${ADVICE_LIST}.`,
    longDisclaimer: [
      'This tool is provided for educational, research, and enterprise information-discovery purposes only.',
      'Do not use for supplier approval, insurer/reinsurer/broker selection, underwriting, claims, coverage determinations, sanctions clearance, credit decisions, legal determinations, procurement bid/no-bid decisions, award decisions, grant applications, investment decisions, treasury hedging, tax decisions, or supply-chain assurance without qualified professional review.',
      'Public records may be incomplete, delayed, ambiguous, mistranslated, restated, or incorrectly matched.',
      'No public match found does not mean cleared, safe, authorized, solvent, eligible, insured, covered, or low risk.',
      'JAQA is not a sanctions screening system of record.',
      'JAQA is not a credit rating agency.',
      'JAQA is not an insurance broker, underwriter, actuary, claims adjuster, or coverage interpreter.',
      'JAQA is not a procurement advisor, bid manager, contract evaluator, or award authority.',
      'JAQA is not a real-time supply chain control tower.',
      'JAQA does not scan live systems or access private asset inventories.',
      'JAQA does not reproduce paid data or scrape paywalled sources.',
      'JAQA does not assist bid rigging, collusion, market allocation, corruption, sanctions evasion, export-control evasion, tax evasion, or anti-competitive conduct.',
      `JAQA™ does not provide ${ADVICE_LIST}.`,
      'JAQA™ is not responsible for decisions made using this interface.',
      'JAQA™ is an independent interface and is not affiliated with or endorsed by these providers unless expressly stated.',
      `© ${YEAR} JAQA™. All rights reserved.`
    ],
    privacyStatement:
      'JAQA does not store, proxy, log, persist, or analyze user searches. Searches are sent directly from the user’s browser to selected public data providers. Hosting providers and data providers may maintain their own infrastructure logs according to their own policies.',
    privacyBadge:
      'JAQA Privacy: Your searches are sent directly from your browser to selected public data providers and are not stored by JAQA.',
    commercialWarning:
      'Do not enter confidential contract terms, pricing, bid documents, underwriting files, claims files, policy numbers, insured names, claimant names, bank details, payment card data, loan applications, KYC documents, internal risk ratings, hedge positions, trading positions, invoice-level customer data, personal financial data, personal health data, M&A information, or protected commercial information.',
    sensitiveWarning:
      'Do not enter confidential commercial, financial, insurance, claims, procurement, personal, health, bank, payment, or protected information. This tool is not for PHI or protected commercial data.',
    noHitNotClear: 'No public match found does not mean cleared, safe, authorized, solvent, eligible, insured, covered, or low risk.',
    determinations: 'JAQA does not provide clearance, coverage, credit, bid, award, or legal determinations.'
  };

  /** Legal metadata block attached to every JSON export. */
  R.legal.exportBlock = function exportBlock(dataSources) {
    return {
      generatedBy: R.productName,
      host: R.host,
      generatedAt: new Date().toISOString(),
      dataSources: dataSources || [],
      legal: {
        trademark: 'JAQA™',
        copyright: R.legal.copyright,
        trademarkNotice: R.legal.trademarkNotice,
        disclaimer: R.legal.shortDisclaimer,
        noHitNotClear: R.legal.noHitNotClear,
        privacy: R.legal.privacyStatement,
        affiliation: 'JAQA™ is an independent interface and is not affiliated with or endorsed by these providers unless expressly stated.'
      }
    };
  };

  /* ------------------------------------------------------------------ *
   * Event bus (in-memory cross-module handoff; never touches the URL)
   * ------------------------------------------------------------------ */
  const listeners = new Map();
  R.events = {
    on(name, fn) {
      if (!listeners.has(name)) listeners.set(name, new Set());
      listeners.get(name).add(fn);
      return () => listeners.get(name).delete(fn);
    },
    emit(name, payload) {
      const set = listeners.get(name);
      if (!set) return;
      for (const fn of [...set]) {
        try {
          fn(payload);
        } catch (e) {
          // Never log payloads (they may contain search terms); log only the event name.
          console.error('[JAQA] handler error for event', name);
        }
      }
    }
  };

  /* ------------------------------------------------------------------ *
   * In-memory state. R.state.reset() is the single "Clear Session" path.
   * ------------------------------------------------------------------ */
  function freshPrefs() {
    return {
      theme: 'ops', // 'ops' (situation-room HUD) | 'dark' | 'light' | 'system'
      density: 'comfortable', // 'comfortable' | 'compact'
      hiddenGroups: new Set(),
      hiddenSources: new Set(),
      warningsCompact: false,
      marketCompact: false,
      highlightGaps: true,
      officialLinkOnly: false, // when true, link-outs never carry the query term
      viewMode: 'cards' // 'cards' | 'table'
    };
  }
  R.state = {
    generation: 0,
    session: null,
    prefs: freshPrefs(),
    watchlist: [],
    keys: {}, // optional user-entered API keys, memory only, never logged/exported
    currentModule: 'overview',
    helpDismissed: false,
    // Situation Room feeds: fixed, non-personal queries that survive new
    // searches but are wiped by Clear Session / refresh like everything else.
    feedTasks: new Map(),
    feedGen: 0,
    globeView: null,
    reset() {
      this.generation += 1;
      this.feedGen += 1;
      this.feedTasks = new Map();
      this.globeView = null;
      if (this.session && this.session.controller) this.session.controller.abort();
      this.session = null;
      this.prefs = freshPrefs();
      this.watchlist = [];
      this.keys = {};
      this.currentModule = 'overview';
      this.helpDismissed = false;
      if (R.net) R.net.resetCache();
      if (R.runtime) R.runtime.reset();
      R.events.emit('session:cleared');
    }
  };

  /* ------------------------------------------------------------------ *
   * DOM helpers. All text goes through textContent / createTextNode, so API
   * strings can never inject markup. innerHTML is never used with data.
   * ------------------------------------------------------------------ */
  // https, mailto, in-page anchors, the 3D globe (/globe/…) and the licences page on this site.
  const SAFE_URL = /^(https:\/\/|mailto:|#|\/globe\/|\/licenses\/$)/i;
  function safeUrl(u) {
    if (typeof u !== 'string') return null;
    const t = u.trim();
    if (!SAFE_URL.test(t)) return null;
    return t;
  }

  function h(tag, props, ...children) {
    const el = document.createElement(tag);
    if (props) {
      for (const [k, v] of Object.entries(props)) {
        if (v === null || v === undefined || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'text') el.textContent = String(v);
        else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
        else if (k === 'dataset') Object.assign(el.dataset, v);
        else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
        else if (k === 'href') {
          const s = safeUrl(v);
          if (s) el.setAttribute('href', s);
        } else if (v === true) el.setAttribute(k, '');
        else el.setAttribute(k, String(v));
      }
    }
    append(el, children);
    return el;
  }
  function append(el, children) {
    for (const c of children) {
      if (c === null || c === undefined || c === false) continue;
      if (Array.isArray(c)) append(el, c);
      else if (c instanceof Node) el.appendChild(c);
      else el.appendChild(document.createTextNode(String(c)));
    }
    return el;
  }
  function clear(el) {
    while (el && el.firstChild) el.removeChild(el.firstChild);
    return el;
  }

  /* Inline SVG icons (static, trusted path data only). */
  const ICONS = {
    search: 'M10.5 3a7.5 7.5 0 015.9 12.1l4.2 4.2-1.4 1.4-4.2-4.2A7.5 7.5 0 1110.5 3zm0 2a5.5 5.5 0 100 11 5.5 5.5 0 000-11z',
    shield: 'M12 2l8 3v6c0 5-3.4 9.3-8 11-4.6-1.7-8-6-8-11V5l8-3zm0 2.1L6 6.4V11c0 3.9 2.5 7.4 6 8.9 3.5-1.5 6-5 6-8.9V6.4l-6-2.3z',
    lock: 'M7 10V7a5 5 0 0110 0v3h1a2 2 0 012 2v8a2 2 0 01-2 2H6a2 2 0 01-2-2v-8a2 2 0 012-2h1zm2 0h6V7a3 3 0 00-6 0v3z',
    external: 'M14 3h7v7h-2V6.4l-9.3 9.3-1.4-1.4L17.6 5H14V3zM5 5h6v2H5v12h12v-6h2v6a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2z',
    close: 'M6.4 5L12 10.6 17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4 6.4 19 5 17.6 10.6 12 5 6.4z',
    info: 'M11 7h2v2h-2V7zm0 4h2v6h-2v-6zm1-9a10 10 0 110 20 10 10 0 010-20zm0 2a8 8 0 100 16 8 8 0 000-16z',
    warn: 'M12 2l10 18H2L12 2zm0 4.2L5.4 18h13.2L12 6.2zM11 10h2v4h-2v-4zm0 5h2v2h-2v-2z',
    trash: 'M9 3h6l1 2h4v2H4V5h4l1-2zm-3 6h12l-1 12H7L6 9zm4 2v8h2v-8h-2zm4 0v8h2v-8h-2z',
    download: 'M11 3h2v9.6l3.3-3.3 1.4 1.4L12 16.4l-5.7-5.7 1.4-1.4 3.3 3.3V3zM4 18h16v2H4v-2z',
    pin: 'M14 2l8 8-2 1-3-1-4 4 1 5-2 2-4-5-5 5-1-1 5-5-5-4 2-2 5 1 4-4-1-3 1-2z',
    globe: 'M12 2a10 10 0 110 20 10 10 0 010-20zm6.9 9a7 7 0 00-4.2-5.6c.6 1.5 1 3.4 1.2 5.6h3zm-5 0c-.3-3-1.2-5-1.9-5.6-.7.6-1.6 2.6-1.9 5.6h3.8zm-5.8 0c.1-2.2.6-4.1 1.2-5.6A7 7 0 005.1 11h3zm-3 2a7 7 0 004.2 5.6c-.6-1.5-1-3.4-1.2-5.6h-3zm5 0c.3 3 1.2 5 1.9 5.6.7-.6 1.6-2.6 1.9-5.6h-3.8zm5.8 0c-.1 2.2-.6 4.1-1.2 5.6a7 7 0 004.2-5.6h-3z',
    building: 'M4 21V3h11v6h5v12H4zm2-2h3v-3h2v3h2V5H6v14zm9 0h3v-8h-3v8zM8 7h2v2H8V7zm0 4h2v2H8v-2z',
    chart: 'M4 20V4h2v14h14v2H4zm4-4V10h2v6H8zm4 0V7h2v9h-2zm4 0v-4h2v4h-2z',
    coin: 'M12 3c4.4 0 8 1.8 8 4v10c0 2.2-3.6 4-8 4s-8-1.8-8-4V7c0-2.2 3.6-4 8-4zm0 2C8.4 5 6 6.3 6 7s2.4 2 6 2 6-1.3 6-2-2.4-2-6-2zm6 5c-1.5.9-3.6 1-6 1s-4.5-.1-6-1v2c0 .7 2.4 2 6 2s6-1.3 6-2v-2zm0 5c-1.5.9-3.6 1-6 1s-4.5-.1-6-1v2c0 .7 2.4 2 6 2s6-1.3 6-2v-2z',
    umbrella: 'M11 2h2v1.1A9 9 0 0121 12h-8v7a3 3 0 01-6 0h2a1 1 0 002 0v-7H3a9 9 0 018-8.9V2zm1 3a7 7 0 00-6.7 5h13.4A7 7 0 0012 5z',
    gavel: 'M13.8 2.4l7.8 7.8-2.8 2.8-1.4-1.4-2.1 2.1 5.7 5.7-2.1 2.1-5.7-5.7-2.1 2.1 1.4 1.4-2.8 2.8-7.8-7.8L4.7 11l1.4 1.4 5-5L9.6 6l2.8-2.8 1.4-.8z',
    doc: 'M6 2h8l6 6v14H6V2zm2 2v16h10V9h-5V4H8zm7 .8V7h2.2L15 4.8zM10 12h6v2h-6v-2zm0 4h6v2h-6v-2z',
    bug: 'M9 3l1.3 2h3.4L15 3h2l-1.6 2.6A5 5 0 0117 9h3v2h-3v2h3v2h-3a5 5 0 01-10 0H4v-2h3v-2H4V9h3a5 5 0 011.6-3.4L7 3h2zm3 4a3 3 0 00-3 3v5a3 3 0 006 0v-5a3 3 0 00-3-3z',
    cloud: 'M7 19a5 5 0 01-.9-9.9A6 6 0 0117.7 8 5.5 5.5 0 0117.5 19H7zm0-2h10.5a3.5 3.5 0 00.1-7l-1.4-.1-.3-1.3a4 4 0 00-7.7-.4l-.4 1.1-1.2.2A3 3 0 007 17z',
    leaf: 'M20 3c0 9-4 15-11 15-1.2 0-2.3-.2-3.2-.6L4.4 20 3 18.6l2.1-2.1A7 7 0 014 13C4 6 11 3 20 3zm-2.1 2.1C12 5.6 6 8 6 13c0 .8.1 1.5.4 2.1l6.9-6.9 1.4 1.4-6.9 6.9c.6.3 1.3.4 2.1.4 5 0 7.5-4.7 8-11.8z',
    ship: 'M11 2h2v3h4v6l3 1-3 8a5 5 0 01-5-2 5 5 0 01-5 2l-3-8 3-1V5h4V2zm-2 5v3.3l3-1 3 1V7H9z',
    link: 'M10.6 13.4a1 1 0 010-1.4l3-3a1 1 0 011.4 1.4l-3 3a1 1 0 01-1.4 0zM8 17a3 3 0 01-2.1-5.1l2.8-2.8 1.4 1.4-2.8 2.8a1 1 0 001.4 1.4l2.8-2.8 1.4 1.4-2.8 2.8A3 3 0 018 17zm8-2.3l-1.4-1.4 2.8-2.8a1 1 0 00-1.4-1.4l-2.8 2.8-1.4-1.4 2.8-2.8a3 3 0 014.2 4.2L16 14.7z',
    layers: 'M12 2l10 5-10 5L2 7l10-5zm0 2.2L6.5 7 12 9.8 17.5 7 12 4.2zM2 12l2-1 8 4 8-4 2 1-10 5-10-5zm0 5l2-1 8 4 8-4 2 1-10 5-10-5z',
    tree: 'M10 3h4v4h-1v3h6v4h1v4h-4v-4h1v-2h-4v2h1v4h-4v-4h1v-2H7v2h1v4H4v-4h1v-4h6V7h-1V3z',
    flask: 'M9 2h6v2h-1v5.3l5.6 9.3A2 2 0 0117.9 22H6.1a2 2 0 01-1.7-3.4L10 9.3V4H9V2zm3 8.4L8.4 16h7.2L12 10.4z',
    list: 'M4 5h2v2H4V5zm4 0h12v2H8V5zM4 11h2v2H4v-2zm4 0h12v2H8v-2zm-4 6h2v2H4v-2zm4 0h12v2H8v-2z',
    sliders: 'M4 5h10v2H4V5zm14 0h2v2h-2v1h-2V4h2v1zM4 11h4v2H4v-2zm6-1h2v4h-2v-1H8v-2h2v-1zm4 1h6v2h-6v-2zM4 17h12v2H4v-2zm14-1h2v4h-2v-1h-2v-2h2v-1z',
    gauge: 'M12 4a10 10 0 019.4 13.5l-.3.5H2.9l-.3-.5A10 10 0 0112 4zm0 2a8 8 0 00-7.7 10h15.4A8 8 0 0012 6zm4.2 2.4l1.4 1.4-4.2 4.2a1.5 1.5 0 11-1.4-1.4l4.2-4.2z',
    moon: 'M12.1 3a7 7 0 008.9 8.9A9 9 0 1112.1 3z',
    command: 'M7 3a4 4 0 014 4v1h2V7a4 4 0 114 4h-1v2h1a4 4 0 11-4 4v-1h-2v1a4 4 0 11-4-4h1v-2H7a4 4 0 010-8zm0 2a2 2 0 000 4h2V7a2 2 0 00-2-2zm10 0a2 2 0 00-2 2v2h2a2 2 0 000-4zm-6 6v2h2v-2h-2zm-4 4a2 2 0 102 2v-2H7zm8 0v2a2 2 0 102-2h-2z',
    help: 'M12 2a10 10 0 110 20 10 10 0 010-20zm0 2a8 8 0 100 16 8 8 0 000-16zm-1 11h2v2h-2v-2zm1-9a4 4 0 012 7.5c-.7.4-1 .8-1 1.5h-2c0-1.5.8-2.5 2-3.2A2 2 0 1010 10H8a4 4 0 014-4z',
    menu: 'M3 6h18v2H3V6zm0 5h18v2H3v-2zm0 5h18v2H3v-2z',
    refresh: 'M12 4a8 8 0 017.4 5H17v2h6V5h-2v2.3A10 10 0 002 12h2a8 8 0 018-8zm8 8a8 8 0 01-14.8 3H7v-2H1v6h2v-2.3A10 10 0 0022 12h-2z',
    copy: 'M8 3h11v13h-2V5H8V3zM4 7h11v14H4V7zm2 2v10h7V9H6z',
    print: 'M6 2h12v5h2a2 2 0 012 2v8h-4v5H6v-5H2V9a2 2 0 012-2h2V2zm2 2v3h8V4H8zm0 11v5h8v-5H8z',
    check: 'M9 16.2l-4.2-4.2-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z',
    chevron: 'M9 6l6 6-6 6-1.4-1.4 4.6-4.6-4.6-4.6L9 6z',
    grid: 'M3 3h8v8H3V3zm2 2v4h4V5H5zm8-2h8v8h-8V3zm2 2v4h4V5h-4zM3 13h8v8H3v-8zm2 2v4h4v-4H5zm8-2h8v8h-8v-8zm2 2v4h4v-4h-4z',
    calendar: 'M7 2h2v2h6V2h2v2h3v18H4V4h3V2zM6 10v10h12V10H6zm0-4v2h12V6H6z',
    key: 'M7 10a5 5 0 019.6-2H22v4h-2v3h-3v-3h-.4A5 5 0 017 10zm5-3a3 3 0 100 6 3 3 0 000-6z'
  };
  const SVGNS = 'http://www.w3.org/2000/svg';
  function icon(name, cls) {
    const svg = document.createElementNS(SVGNS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    svg.setAttribute('class', 'rq-icon' + (cls ? ' ' + cls : ''));
    const p = document.createElementNS(SVGNS, 'path');
    p.setAttribute('d', ICONS[name] || ICONS.info);
    p.setAttribute('fill', 'currentColor');
    svg.appendChild(p);
    return svg;
  }

  /**
   * External link helper. EVERY outbound link in the app is created here so
   * that target="_blank" is always paired with rel="noopener noreferrer".
   */
  function extLink(href, label, opts) {
    const o = opts || {};
    const url = safeUrl(href);
    if (!url) return h('span', { class: 'rq-muted' }, label, ' (link unavailable)');
    const a = h('a', { class: 'rq-ext' + (o.cls ? ' ' + o.cls : ''), href: url, target: '_blank', rel: 'noopener noreferrer' });
    append(a, [label, icon('external', 'rq-icon-xs'), h('span', { class: 'rq-sr' }, ' (opens official source in a new tab)')]);
    return a;
  }

  const fmt = {
    date(v) {
      if (!v) return 'Not reported by source';
      const d = new Date(v);
      if (isNaN(d.getTime())) return String(v);
      return d.toISOString().slice(0, 10);
    },
    time(d) {
      const x = d instanceof Date ? d : new Date(d);
      return isNaN(x.getTime()) ? '' : x.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    },
    num(v, digits) {
      if (v === null || v === undefined || v === '' || isNaN(Number(v))) return 'Not reported by source';
      return Number(v).toLocaleString('en-US', { maximumFractionDigits: digits === undefined ? 2 : digits });
    },
    money(v, cur) {
      if (v === null || v === undefined || v === '' || isNaN(Number(v))) return 'Not reported by source';
      const n = Number(v);
      const abs = Math.abs(n);
      const s = abs >= 1e9 ? (n / 1e9).toFixed(2) + 'B' : abs >= 1e6 ? (n / 1e6).toFixed(2) + 'M' : abs >= 1e3 ? (n / 1e3).toFixed(1) + 'K' : n.toFixed(0);
      return (cur || 'USD') + ' ' + s;
    },
    val(v) {
      if (v === null || v === undefined || v === '') return 'Not reported by source';
      if (Array.isArray(v)) return v.length ? v.join(', ') : 'Not reported by source';
      return String(v);
    },
    truncate(s, n) {
      const t = String(s || '');
      return t.length > n ? t.slice(0, n - 1) + '…' : t;
    }
  };

  let uidCounter = 0;
  const uid = (p) => (p || 'rq') + '-' + (++uidCounter).toString(36);

  /* Polite live region for loading / error / status announcements. */
  function announce(msg) {
    const el = document.getElementById('rq-live');
    if (!el) return;
    el.textContent = '';
    setTimeout(() => {
      el.textContent = msg;
    }, 30);
  }

  R.util = { h, append, clear, icon, extLink, safeUrl, fmt, uid, announce, ICONS };

  /* ------------------------------------------------------------------ *
   * Input hygiene (commercialConfidentialityGuard, personalFinancialDataGuard,
   * narrativeGuard). Rejected input is neither stored nor logged; the UI
   * shows only a generic message.
   * ------------------------------------------------------------------ */
  const MAX_LEN = 140;
  const GENERIC_REJECT =
    'This input appears too broad or may contain sensitive information. Please search a company, insurer, reinsurer, broker, LEI, ticker, CIK, country, port, HS code, CVE, tender, award, grant, PPP, recall, regulation, finance risk type, or procurement concept.';

  function mod97(str) {
    let rem = 0;
    for (const ch of str) {
      const code = /[A-Z]/.test(ch) ? String(ch.charCodeAt(0) - 55) : ch;
      for (const d of code) rem = (rem * 10 + Number(d)) % 97;
    }
    return rem;
  }
  const isValidLei = (s) => /^[A-Z0-9]{18}[0-9]{2}$/.test(s) && mod97(s) === 1;
  const isValidIban = (s) => {
    const t = s.replace(/\s+/g, '').toUpperCase();
    if (!/^[A-Z]{2}\d{2}[A-Z0-9]{10,30}$/.test(t)) return false;
    return mod97(t.slice(4) + t.slice(0, 4)) === 1;
  };
  const luhn = (digits) => {
    let sum = 0;
    let alt = false;
    for (let i = digits.length - 1; i >= 0; i--) {
      let n = Number(digits[i]);
      if (alt) {
        n *= 2;
        if (n > 9) n -= 9;
      }
      sum += n;
      alt = !alt;
    }
    return sum % 10 === 0;
  };

  // Known public identifier formats are allowed before the sensitive-data heuristics run.
  const PUBLIC_ID_PATTERNS = [
    /^CVE-\d{4}-\d{4,}$/i,
    /^CWE-\d{1,5}$/i,
    /^(CIK\s*)?\d{1,10}$/i,
    /^(HS\s*)?\d{4}([.\s]?\d{2}){0,3}$/i,
    /^\d{2}[VETC]\d{6}$/i,
    /^\d{4}-\d{5}$/,
    /^\d{1,8}-\d{4}$/,
    /^\d{4}\/S \d{3}-\d{6}$/i
  ];

  const SENSITIVE_KEYWORDS = [
    'policy no', 'policy number', 'policy #', 'claim no', 'claim number', 'claim #', 'claim id', 'claimant', 'insured name', 'member id',
    'patient', 'diagnosis', 'mrn', 'medical record', 'date of birth', 'dob', 'born on', 'ssn', 'social security', 'national insurance number',
    'passport', 'driver licen', 'account no', 'account number', 'acct', 'sort code', 'routing number', 'swift code', 'iban', 'bic code', 'card number', 'cvv',
    'password', 'salary', 'payroll', 'employee id', 'bid price', 'our price', 'our bid', 'pricing sheet', 'cost breakdown', 'margin', 'discount',
    'confidential', 'internal only', 'strictly private', 'not for distribution', 'term sheet', 'covenant', 'hedge position', 'trading position',
    'invoice #', 'invoice no', 'kyc', 'loan application', 'credit limit', 'treaty terms', 'retrocession chain', 'collateral detail',
    'negotiation', 'm&a', 'merger target', 'valuation model', 'classified', 'export-controlled', 'itar data', 'workaround', 'evade', 'evasion', 'bypass sanctions', 'rig the bid', 'bid rigging'
  ];

  R.privacy = {
    GENERIC_REJECT,
    isValidLei,
    /**
     * Returns { ok, value, reason }. `reason` is always the generic message —
     * the specific trigger is intentionally not surfaced or recorded.
     */
    checkInput(raw) {
      if (typeof raw !== 'string') return { ok: false, reason: GENERIC_REJECT };
      if (/[\r\n\t]/.test(raw.trim())) return { ok: false, reason: GENERIC_REJECT };
      // eslint-disable-next-line no-control-regex
      if (/[\u0000-\u001f<>{}]/.test(raw)) return { ok: false, reason: GENERIC_REJECT };
      const value = raw.replace(/\s+/g, ' ').trim();
      if (!value) return { ok: false, reason: 'Enter a company, insurer, LEI, country, port, HS code, CVE, tender, regulation, or risk concept to begin.' };
      if (value.length > MAX_LEN) return { ok: false, reason: GENERIC_REJECT };
      const upper = value.toUpperCase();
      if (isValidLei(upper)) return { ok: true, value: upper };
      if (PUBLIC_ID_PATTERNS.some((re) => re.test(value))) return { ok: true, value };
      const lower = value.toLowerCase();
      if (SENSITIVE_KEYWORDS.some((k) => (k.length <= 4 ? new RegExp('\\b' + k.replace(/[.*+?^${}()|[\]\\#&]/g, '\\$&') + '\\b').test(lower) : lower.includes(k))))
        return { ok: false, reason: GENERIC_REJECT };
      if (/[^\s@]+@[^\s@]+\.[^\s@]+/.test(value)) return { ok: false, reason: GENERIC_REJECT }; // email
      if (/\b\d{3}-\d{2}-\d{4}\b/.test(value)) return { ok: false, reason: GENERIC_REJECT }; // SSN-like
      if (/\b\d{1,2}[/.]\d{1,2}[/.]\d{2,4}\b/.test(value)) return { ok: false, reason: GENERIC_REJECT }; // DOB-like date
      if (isValidIban(value)) return { ok: false, reason: GENERIC_REJECT };
      const digitRuns = value.replace(/[\s-]/g, '').match(/\d{12,}/g) || [];
      if (digitRuns.length) return { ok: false, reason: GENERIC_REJECT }; // card/account-like
      const cardLike = value.match(/(?:\d[ -]?){13,19}/g) || [];
      if (cardLike.some((c) => luhn(c.replace(/\D/g, '')))) return { ok: false, reason: GENERIC_REJECT };
      const phoneDigits = (value.match(/\+?[\d\s().-]{9,}/g) || []).map((p) => p.replace(/\D/g, ''));
      if (phoneDigits.some((d) => d.length >= 9 && d.length <= 15) && /[+()\s.-]/.test(value)) return { ok: false, reason: GENERIC_REJECT };
      if (/\b(MRN|PT|CLM|POL)[-#:\s]?\d{5,}\b/i.test(value)) return { ok: false, reason: GENERIC_REJECT };
      if (value.split(' ').length > 10) return { ok: false, reason: GENERIC_REJECT }; // narrative-like
      return { ok: true, value };
    }
  };

  /* ------------------------------------------------------------------ *
   * Module registry
   * ------------------------------------------------------------------ */
  const moduleList = [];
  R.modules = {
    register(def) {
      if (!def || !def.id) throw new Error('module id required');
      const i = moduleList.findIndex((m) => m.id === def.id);
      if (i >= 0) moduleList[i] = def;
      else moduleList.push(def);
      moduleList.sort((a, b) => (a.order || 0) - (b.order || 0));
    },
    get: (id) => moduleList.find((m) => m.id === id),
    all: () => moduleList.slice(),
    GROUPS: [
      { id: 'risk', label: 'Risk' },
      { id: 'finance', label: 'Finance' },
      { id: 'insurance', label: 'Insurance & Reinsurance' },
      { id: 'procurement', label: 'Procurement & Bids' },
      { id: 'evidence', label: 'Evidence' }
    ]
  };
})(window);

/* ---- modules/corsConfig.js ---- */
/*
 * corsConfig.js — GENERATED by scripts/build.mjs from config/cors-verification.json.
 * Do not edit by hand. Re-run scripts/verify-cors.mjs, commit the JSON, then build.
 * Only sources with verified:true may be promoted to live and allowed by CSP.
 */
(function (R) {
  'use strict';
  R.config = R.config || {};
  R.config.corsVerification = {
    "origin": "https://jaqa.life",
    "verifiedAt": "2026-09-30T10:35:10.089Z",
    "runner": "github-actions:36703177628",
    "method": "Server-side request with Origin header + CORS preflight emulation + response-shape validation. Confirm from the deployed origin with the Coverage Console.",
    "sources": {
      "gleif": {
        "verified": true,
        "passingEndpoints": [
          "gleif-fulltext",
          "gleif-record",
          "gleif-children",
          "gleif-direct-parent",
          "gleif-ultimate-parent",
          "gleif-fuzzy"
        ],
        "checks": [
          {
            "id": "gleif-fulltext",
            "ok": true,
            "status": 200
          },
          {
            "id": "gleif-record",
            "ok": true,
            "status": 200
          },
          {
            "id": "gleif-children",
            "ok": true,
            "status": 200
          },
          {
            "id": "gleif-direct-parent",
            "ok": true,
            "status": 200
          },
          {
            "id": "gleif-ultimate-parent",
            "ok": true,
            "status": 200
          },
          {
            "id": "gleif-fuzzy",
            "ok": true,
            "status": 200
          }
        ]
      },
      "worldbank": {
        "verified": true,
        "passingEndpoints": [
          "wb-country",
          "wb-lpi",
          "wb-wgi-gov",
          "wb-inflation"
        ],
        "checks": [
          {
            "id": "wb-country",
            "ok": true,
            "status": 200
          },
          {
            "id": "wb-lpi",
            "ok": true,
            "status": 200
          },
          {
            "id": "wb-wgi-legacy",
            "ok": false,
            "status": 200
          },
          {
            "id": "wb-wgi-source3",
            "ok": false,
            "status": 200
          },
          {
            "id": "wb-wgi-gov",
            "ok": true,
            "status": 200
          },
          {
            "id": "wb-inflation",
            "ok": true,
            "status": 200
          }
        ]
      },
      "imf": {
        "verified": false,
        "passingEndpoints": [],
        "checks": [
          {
            "id": "imf-datamapper",
            "ok": false,
            "status": 403
          }
        ]
      },
      "usgs": {
        "verified": true,
        "passingEndpoints": [
          "usgs-query"
        ],
        "checks": [
          {
            "id": "usgs-query",
            "ok": true,
            "status": 200
          }
        ]
      },
      "openmeteo": {
        "verified": true,
        "passingEndpoints": [
          "om-forecast",
          "om-geocode"
        ],
        "checks": [
          {
            "id": "om-forecast",
            "ok": true,
            "status": 200
          },
          {
            "id": "om-geocode",
            "ok": true,
            "status": 200
          }
        ]
      },
      "nws": {
        "verified": true,
        "passingEndpoints": [
          "nws-alerts-point"
        ],
        "checks": [
          {
            "id": "nws-alerts-point",
            "ok": true,
            "status": 200
          }
        ]
      },
      "reliefweb": {
        "verified": false,
        "passingEndpoints": [],
        "checks": [
          {
            "id": "rw-v2-reports",
            "ok": false,
            "status": 403
          },
          {
            "id": "rw-v1-reports",
            "ok": false,
            "status": 410
          }
        ]
      },
      "cisaKev": {
        "verified": true,
        "passingEndpoints": [
          "kev-cisagov-github"
        ],
        "checks": [
          {
            "id": "kev-cisa-gov",
            "ok": false,
            "status": 200
          },
          {
            "id": "kev-cisagov-github",
            "ok": true,
            "status": 200
          }
        ]
      },
      "nvd": {
        "verified": true,
        "passingEndpoints": [
          "nvd-cve",
          "nvd-keyword"
        ],
        "checks": [
          {
            "id": "nvd-cve",
            "ok": true,
            "status": 200
          },
          {
            "id": "nvd-keyword",
            "ok": true,
            "status": 200
          },
          {
            "id": "nvd-apikey-preflight",
            "ok": false,
            "status": null
          }
        ]
      },
      "cpsc": {
        "verified": true,
        "passingEndpoints": [
          "cpsc-recall-number",
          "cpsc-recall"
        ],
        "checks": [
          {
            "id": "cpsc-recall-number",
            "ok": true,
            "status": 200
          },
          {
            "id": "cpsc-recall",
            "ok": true,
            "status": 200
          }
        ]
      },
      "nhtsa": {
        "verified": true,
        "passingEndpoints": [
          "nhtsa-campaign",
          "nhtsa-vehicle"
        ],
        "checks": [
          {
            "id": "nhtsa-campaign",
            "ok": true,
            "status": 200
          },
          {
            "id": "nhtsa-vehicle",
            "ok": true,
            "status": 200
          }
        ]
      },
      "usaspending": {
        "verified": true,
        "passingEndpoints": [
          "usa-autocomplete-recipient",
          "usa-awards",
          "usa-award-detail",
          "usa-grants"
        ],
        "checks": [
          {
            "id": "usa-autocomplete-recipient",
            "ok": true,
            "status": 200
          },
          {
            "id": "usa-awards",
            "ok": true,
            "status": 200
          },
          {
            "id": "usa-award-detail",
            "ok": true,
            "status": 200
          },
          {
            "id": "usa-grants",
            "ok": true,
            "status": 200
          }
        ]
      },
      "federalRegister": {
        "verified": true,
        "passingEndpoints": [
          "fr-agency",
          "fr-search"
        ],
        "checks": [
          {
            "id": "fr-agency",
            "ok": true,
            "status": 200
          },
          {
            "id": "fr-search",
            "ok": true,
            "status": 200
          }
        ]
      },
      "sec": {
        "verified": true,
        "passingEndpoints": [
          "sec-submissions"
        ],
        "checks": [
          {
            "id": "sec-submissions",
            "ok": true,
            "status": 200
          }
        ]
      },
      "secXbrl": {
        "verified": false,
        "passingEndpoints": [],
        "checks": [
          {
            "id": "sec-companyfacts",
            "ok": false,
            "status": 200
          },
          {
            "id": "sec-companyconcept",
            "ok": false,
            "status": 200
          }
        ]
      },
      "secTickers": {
        "verified": false,
        "passingEndpoints": [],
        "checks": [
          {
            "id": "sec-tickers",
            "ok": false,
            "status": 403
          }
        ]
      },
      "secFullText": {
        "verified": false,
        "passingEndpoints": [],
        "checks": [
          {
            "id": "sec-efts",
            "ok": false,
            "status": 200
          }
        ]
      },
      "ted": {
        "verified": false,
        "passingEndpoints": [],
        "checks": [
          {
            "id": "ted-search",
            "ok": false,
            "status": 200
          }
        ]
      },
      "courtlistener": {
        "verified": true,
        "passingEndpoints": [
          "cl-v4-search",
          "cl-v4-opinions"
        ],
        "checks": [
          {
            "id": "cl-v4-search",
            "ok": true,
            "status": 200
          },
          {
            "id": "cl-v4-opinions",
            "ok": true,
            "status": 200
          }
        ]
      },
      "wikidata": {
        "verified": true,
        "passingEndpoints": [
          "wd-search",
          "wd-entities"
        ],
        "checks": [
          {
            "id": "wd-search",
            "ok": true,
            "status": 200
          },
          {
            "id": "wd-entities",
            "ok": true,
            "status": 200
          }
        ]
      },
      "wikipedia": {
        "verified": true,
        "passingEndpoints": [
          "wp-summary"
        ],
        "checks": [
          {
            "id": "wp-summary",
            "ok": true,
            "status": 200
          }
        ]
      },
      "overpass": {
        "verified": true,
        "passingEndpoints": [
          "overpass-around"
        ],
        "checks": [
          {
            "id": "overpass-around",
            "ok": true,
            "status": 200
          }
        ]
      },
      "ecb": {
        "verified": true,
        "passingEndpoints": [
          "ecb-exr"
        ],
        "checks": [
          {
            "id": "ecb-exr",
            "ok": true,
            "status": 200
          }
        ]
      },
      "gdelt": {
        "verified": true,
        "passingEndpoints": [
          "gdelt-doc"
        ],
        "checks": [
          {
            "id": "gdelt-doc",
            "ok": true,
            "status": 200
          }
        ]
      },
      "epa": {
        "verified": true,
        "passingEndpoints": [
          "echo-facility-info"
        ],
        "checks": [
          {
            "id": "echo-facility-info",
            "ok": true,
            "status": 200
          }
        ]
      },
      "comtrade": {
        "verified": false,
        "passingEndpoints": [],
        "checks": [
          {
            "id": "comtrade-preview",
            "ok": false,
            "status": 200
          }
        ]
      },
      "fred": {
        "verified": false,
        "passingEndpoints": [],
        "checks": [
          {
            "id": "fred-nokey",
            "ok": false,
            "status": 400
          }
        ]
      },
      "companiesHouse": {
        "verified": false,
        "passingEndpoints": [
          "ch-preflight"
        ],
        "checks": [
          {
            "id": "ch-preflight",
            "ok": true,
            "status": null
          }
        ]
      },
      "opencorporates": {
        "verified": false,
        "passingEndpoints": [],
        "checks": [
          {
            "id": "oc-search",
            "ok": false,
            "status": 401
          }
        ]
      }
    }
  };
  // Global Monitor: only feeds verified by scripts/verify-monitor.mjs (served by the JAQA server).
  R.config.monitor = {
    "verifiedAt": "2026-09-30T18:15:34.995Z",
    "runner": "github-actions:36757264566",
    "categories": [
      [
        "world",
        "World & diplomacy"
      ],
      [
        "hazards",
        "Disasters & hazards"
      ],
      [
        "health",
        "Health"
      ],
      [
        "security",
        "Security & cyber"
      ],
      [
        "finance",
        "Finance & regulators"
      ],
      [
        "travel",
        "Travel & trade"
      ]
    ],
    "candidates": [
      {
        "id": "un-news",
        "name": "UN News — all stories",
        "publisher": "United Nations",
        "category": "world",
        "home": "https://news.un.org/"
      },
      {
        "id": "un-peace",
        "name": "UN News — peace and security",
        "publisher": "United Nations",
        "category": "world",
        "home": "https://news.un.org/"
      },
      {
        "id": "wto-news",
        "name": "WTO news",
        "publisher": "World Trade Organization",
        "category": "travel",
        "home": "https://www.wto.org/"
      },
      {
        "id": "gdacs",
        "name": "GDACS disaster alerts",
        "publisher": "GDACS (UN / European Commission)",
        "category": "hazards",
        "home": "https://www.gdacs.org/"
      },
      {
        "id": "eonet",
        "name": "NASA EONET open natural events",
        "publisher": "NASA Earth Observatory",
        "category": "hazards",
        "home": "https://eonet.gsfc.nasa.gov/"
      },
      {
        "id": "usgs-significant",
        "name": "USGS significant earthquakes — 30 days",
        "publisher": "U.S. Geological Survey",
        "category": "hazards",
        "home": "https://earthquake.usgs.gov/"
      },
      {
        "id": "nhc-atlantic",
        "name": "NHC Atlantic tropical cyclones",
        "publisher": "NOAA National Hurricane Center",
        "category": "hazards",
        "home": "https://www.nhc.noaa.gov/"
      },
      {
        "id": "nhc-epacific",
        "name": "NHC Eastern Pacific tropical cyclones",
        "publisher": "NOAA National Hurricane Center",
        "category": "hazards",
        "home": "https://www.nhc.noaa.gov/"
      },
      {
        "id": "reliefweb-updates",
        "name": "ReliefWeb humanitarian updates",
        "publisher": "UN OCHA ReliefWeb",
        "category": "hazards",
        "home": "https://reliefweb.int/"
      },
      {
        "id": "reliefweb-disasters",
        "name": "ReliefWeb disasters",
        "publisher": "UN OCHA ReliefWeb",
        "category": "hazards",
        "home": "https://reliefweb.int/"
      },
      {
        "id": "who-news",
        "name": "WHO news releases",
        "publisher": "World Health Organization",
        "category": "health",
        "home": "https://www.who.int/"
      },
      {
        "id": "cisa-advisories",
        "name": "CISA cybersecurity advisories",
        "publisher": "U.S. CISA",
        "category": "security",
        "home": "https://www.cisa.gov/"
      },
      {
        "id": "ncsc-uk",
        "name": "UK NCSC news and advisories",
        "publisher": "UK National Cyber Security Centre",
        "category": "security",
        "home": "https://www.ncsc.gov.uk/"
      },
      {
        "id": "ecb-press",
        "name": "ECB press releases",
        "publisher": "European Central Bank",
        "category": "finance",
        "home": "https://www.ecb.europa.eu/"
      },
      {
        "id": "fed-press",
        "name": "Federal Reserve press releases",
        "publisher": "U.S. Federal Reserve Board",
        "category": "finance",
        "home": "https://www.federalreserve.gov/"
      },
      {
        "id": "sec-press",
        "name": "SEC press releases",
        "publisher": "U.S. Securities and Exchange Commission",
        "category": "finance",
        "home": "https://www.sec.gov/"
      },
      {
        "id": "boe-news",
        "name": "Bank of England news",
        "publisher": "Bank of England",
        "category": "finance",
        "home": "https://www.bankofengland.co.uk/"
      },
      {
        "id": "bis-press",
        "name": "BIS press releases",
        "publisher": "Bank for International Settlements",
        "category": "finance",
        "home": "https://www.bis.org/"
      },
      {
        "id": "imf-news",
        "name": "IMF news",
        "publisher": "International Monetary Fund",
        "category": "finance",
        "home": "https://www.imf.org/"
      },
      {
        "id": "us-travel",
        "name": "U.S. travel advisories",
        "publisher": "U.S. Department of State",
        "category": "travel",
        "home": "https://travel.state.gov/"
      },
      {
        "id": "uk-travel",
        "name": "UK foreign travel advice",
        "publisher": "UK FCDO (GOV.UK)",
        "category": "travel",
        "home": "https://www.gov.uk/foreign-travel-advice"
      }
    ],
    "feeds": [
      {
        "id": "un-news",
        "name": "UN News — all stories",
        "publisher": "United Nations",
        "category": "world",
        "home": "https://news.un.org/"
      },
      {
        "id": "un-peace",
        "name": "UN News — peace and security",
        "publisher": "United Nations",
        "category": "world",
        "home": "https://news.un.org/"
      },
      {
        "id": "wto-news",
        "name": "WTO news",
        "publisher": "World Trade Organization",
        "category": "travel",
        "home": "https://www.wto.org/"
      },
      {
        "id": "gdacs",
        "name": "GDACS disaster alerts",
        "publisher": "GDACS (UN / European Commission)",
        "category": "hazards",
        "home": "https://www.gdacs.org/"
      },
      {
        "id": "eonet",
        "name": "NASA EONET open natural events",
        "publisher": "NASA Earth Observatory",
        "category": "hazards",
        "home": "https://eonet.gsfc.nasa.gov/"
      },
      {
        "id": "usgs-significant",
        "name": "USGS significant earthquakes — 30 days",
        "publisher": "U.S. Geological Survey",
        "category": "hazards",
        "home": "https://earthquake.usgs.gov/"
      },
      {
        "id": "nhc-atlantic",
        "name": "NHC Atlantic tropical cyclones",
        "publisher": "NOAA National Hurricane Center",
        "category": "hazards",
        "home": "https://www.nhc.noaa.gov/"
      },
      {
        "id": "nhc-epacific",
        "name": "NHC Eastern Pacific tropical cyclones",
        "publisher": "NOAA National Hurricane Center",
        "category": "hazards",
        "home": "https://www.nhc.noaa.gov/"
      },
      {
        "id": "who-news",
        "name": "WHO news releases",
        "publisher": "World Health Organization",
        "category": "health",
        "home": "https://www.who.int/"
      },
      {
        "id": "cisa-advisories",
        "name": "CISA cybersecurity advisories",
        "publisher": "U.S. CISA",
        "category": "security",
        "home": "https://www.cisa.gov/"
      },
      {
        "id": "ncsc-uk",
        "name": "UK NCSC news and advisories",
        "publisher": "UK National Cyber Security Centre",
        "category": "security",
        "home": "https://www.ncsc.gov.uk/"
      },
      {
        "id": "ecb-press",
        "name": "ECB press releases",
        "publisher": "European Central Bank",
        "category": "finance",
        "home": "https://www.ecb.europa.eu/"
      },
      {
        "id": "fed-press",
        "name": "Federal Reserve press releases",
        "publisher": "U.S. Federal Reserve Board",
        "category": "finance",
        "home": "https://www.federalreserve.gov/"
      },
      {
        "id": "sec-press",
        "name": "SEC press releases",
        "publisher": "U.S. Securities and Exchange Commission",
        "category": "finance",
        "home": "https://www.sec.gov/"
      },
      {
        "id": "boe-news",
        "name": "Bank of England news",
        "publisher": "Bank of England",
        "category": "finance",
        "home": "https://www.bankofengland.co.uk/"
      },
      {
        "id": "bis-press",
        "name": "BIS press releases",
        "publisher": "Bank for International Settlements",
        "category": "finance",
        "home": "https://www.bis.org/"
      },
      {
        "id": "us-travel",
        "name": "U.S. travel advisories",
        "publisher": "U.S. Department of State",
        "category": "travel",
        "home": "https://travel.state.gov/"
      },
      {
        "id": "uk-travel",
        "name": "UK foreign travel advice",
        "publisher": "UK FCDO (GOV.UK)",
        "category": "travel",
        "home": "https://www.gov.uk/foreign-travel-advice"
      }
    ]
  };
})(window.JAQAWorkspace);

/* ---- modules/sourceRegistry.js ---- */
/*
 * sourceRegistry.js — Source Capability Registry, endpoint registry and
 * official link-out directories.
 *
 * HOW TO ADD A NEW SOURCE
 *   1. Add an entry with S('id', 'Display name', { ...fields }) below.
 *   2. If it has a documented public read-only API, set liveCapable:true,
 *      apiBase, endpoints and a `probe` URL (fixed, no user data).
 *   3. Add matching checks to scripts/verify-cors.mjs and run it (locally or
 *      via the "Verify public sources" GitHub workflow).
 *   4. Commit config/cors-verification.json and run `npm run build`.
 *
 * HOW LINK-OUT → LIVE PROMOTION WORKS
 *   A source becomes defaultMode "live" ONLY when config/cors-verification.json
 *   (compiled into corsConfig.js) marks it verified for the production origin.
 *   The build also derives CSP connect-src from that same list, so an
 *   unverified host cannot be contacted in production even by mistake.
 *   Unverified live-capable sources show status "verify" and link-outs.
 *   Paid, login-protected, regulator, rating-agency, market-report and
 *   procurement-portal sources are link-out only by policy and are never
 *   promoted or scraped.
 */
(function (R) {
  'use strict';

  const verification = (R.config.corsVerification && R.config.corsVerification.sources) || {};

  const DEFAULTS = {
    region: 'Global',
    kind: 'api',
    tier: 'C',
    liveCapable: false,
    apiBase: null,
    endpoints: [],
    linkoutSearchUrlTemplate: null,
    linkoutDetailUrlTemplate: null,
    officialDocsUrl: null,
    officialSiteUrl: null,
    attribution: '',
    privacyNote: 'Opened directly by your browser. The provider may log requests under its own policy.',
    safetyNote: '',
    rateLimitPolicy: 'Be conservative; user-triggered requests only.',
    concurrencyLimit: 2,
    timeoutMs: 12000,
    lastVerifiedNote: 'Not verified for live browser access. Link-out only.',
    featureFlag: null,
    mayLagOfficialDb: false,
    publicDataOnly: true,
    controlledAccessProhibited: true,
    paidSourceLinkOutOnly: false,
    regulatorLinkOutOnly: false,
    ratingAgencyLinkOutOnly: false,
    marketReportLinkOutOnly: false,
    procurementPortalLinkOutOnly: false,
    insolvencyRegistryLinkOutOnly: false,
    lienRegistryLinkOutOnly: false,
    sanctionsLinkOutOnly: false,
    guidelineLinkOutOnly: false,
    translationRisk: false,
    deadlineRisk: false,
    officialSourceAuthoritative: false,
    coverageGapWarning: '',
    falseNegativeRisk: false,
    legalReviewRequired: false,
    insuranceSensitive: false,
    financeSensitive: false,
    procurementSensitive: false,
    commercialConfidentialitySensitive: false,
    personalDataSensitive: false,
    keyOptional: false,
    probe: null
  };

  const SOURCES = [];
  function S(id, displayName, props) {
    const v = verification[id];
    const s = Object.assign({ id, displayName }, DEFAULTS, props);
    s.corsVerified = !!(v && v.verified && s.liveCapable);
    s.verificationDetail = v || null;
    s.defaultMode = s.corsVerified ? 'live' : props.download ? 'download' : 'linkout';
    s.status = s.corsVerified ? 'live' : s.liveCapable ? 'verify' : 'linkout';
    if (s.corsVerified) {
      const when = R.config.corsVerification.verifiedAt ? R.config.corsVerification.verifiedAt.slice(0, 10) : 'unknown date';
      s.lastVerifiedNote = `CORS + response shape verified for origin ${R.config.corsVerification.origin} on ${when} (${(v.passingEndpoints || []).join(', ')}). Re-confirm from the deployed origin in the Coverage Console.`;
    } else if (s.liveCapable) {
      s.lastVerifiedNote = v
        ? `Verification did not pass (${(v.checks || []).filter((c) => !c.ok).map((c) => c.id + (c.status ? ' → HTTP ' + c.status : '')).join('; ') || 'no passing checks'}). Link-out only until re-verified.`
        : 'Documented API, not yet verified for browser CORS from the JAQA origin. Link-out only.';
    }
    if (props.serverBacked) {
      // Same-origin feeds fetched by the JAQA server (no browser CORS involved):
      // live only when scripts/verify-monitor.mjs verified at least one feed.
      const mc = R.config.monitor || { feeds: [] };
      const n = (mc.feeds || []).length;
      s.defaultMode = n ? 'live' : 'linkout';
      s.status = n ? 'live' : 'verify';
      s.lastVerifiedNote = n
        ? `${n} official feed(s) verified by server-side fetch on ${(mc.verifiedAt || '').slice(0, 10) || 'unknown date'}. Needs the JAQA server; on static-only hosting this source is unavailable.`
        : 'No monitor feed verified yet. Link-out to the publishers only.';
    }
    SOURCES.push(s);
    return s;
  }

  /* ---------------------------- Tier A ---------------------------- */
  S('gleif', 'GLEIF LEI API', {
    tier: 'A', liveCapable: true, apiBase: 'https://api.gleif.org/api/v1',
    endpoints: ['/lei-records?filter[fulltext]=', '/lei-records/{lei}', '/lei-records/{lei}/direct-parent', '/lei-records/{lei}/ultimate-parent', '/lei-records/{lei}/direct-children'],
    linkoutSearchUrlTemplate: 'https://search.gleif.org/#/search/simpleSearch={q}', linkoutDetailUrlTemplate: 'https://search.gleif.org/#/record/{id}',
    officialDocsUrl: 'https://www.gleif.org/en/lei-data/gleif-api', officialSiteUrl: 'https://www.gleif.org/',
    attribution: 'LEI data provided by GLEIF.', rateLimitPolicy: 'GLEIF fair use (~60 requests/minute). Max 3 concurrent.', concurrencyLimit: 3,
    officialSourceAuthoritative: true, falseNegativeRisk: true,
    coverageGapWarning: 'Many private companies, SMEs and some insurers/brokers have no LEI. Missing LEI does not mean an invalid entity. Parent/child relationships are only as reported to GLEIF.',
    probe: 'https://api.gleif.org/api/v1/lei-records?page%5Bsize%5D=1'
  });
  S('worldbank', 'World Bank Indicators API', {
    tier: 'A', liveCapable: true, apiBase: 'https://api.worldbank.org/v2',
    endpoints: ['/country/{iso}', '/country/{iso}/indicator/{code}'],
    linkoutSearchUrlTemplate: 'https://data.worldbank.org/country/{id}', officialDocsUrl: 'https://datahelpdesk.worldbank.org/knowledgebase/topics/125589', officialSiteUrl: 'https://data.worldbank.org/',
    attribution: 'World Bank data provided by the World Bank Group.', mayLagOfficialDb: true,
    coverageGapWarning: 'Indicators are annual and often lag 1–3 years. Some countries/years are not reported.',
    probe: 'https://api.worldbank.org/v2/country/WLD?format=json'
  });
  S('usgs', 'USGS Earthquake Catalog (FDSN)', {
    tier: 'A', region: 'Global', liveCapable: true, apiBase: 'https://earthquake.usgs.gov/fdsnws/event/1', endpoints: ['/query?format=geojson'],
    officialDocsUrl: 'https://earthquake.usgs.gov/fdsnws/event/1/', officialSiteUrl: 'https://earthquake.usgs.gov/earthquakes/map/',
    attribution: 'Earthquake data provided by USGS.', insuranceSensitive: true,
    coverageGapWarning: 'Seismic events do not confirm facility damage, insured loss or supplier disruption.',
    probe: 'https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&limit=1&minmagnitude=6'
  });
  S('openmeteo', 'Open-Meteo (forecast + geocoding)', {
    tier: 'A', liveCapable: true, apiBase: 'https://api.open-meteo.com/v1', endpoints: ['/forecast', 'https://geocoding-api.open-meteo.com/v1/search'],
    officialDocsUrl: 'https://open-meteo.com/en/docs', officialSiteUrl: 'https://open-meteo.com/',
    attribution: 'Weather data provided by Open-Meteo and underlying meteorological sources. Geocoding based on GeoNames.',
    rateLimitPolicy: 'Non-commercial fair use (<10,000 calls/day).',
    coverageGapWarning: 'Model forecasts are not official warnings. Geocoding may match the wrong place — verify.',
    probe: 'https://api.open-meteo.com/v1/forecast?latitude=0&longitude=0&daily=precipitation_sum&forecast_days=1'
  });
  S('nws', 'NOAA / National Weather Service API', {
    tier: 'A', region: 'United States', liveCapable: true, apiBase: 'https://api.weather.gov', endpoints: ['/alerts/active?point={lat},{lon}'],
    officialDocsUrl: 'https://www.weather.gov/documentation/services-web-api', officialSiteUrl: 'https://www.weather.gov/',
    attribution: 'Weather alert data provided by NOAA/NWS.', officialSourceAuthoritative: true,
    coverageGapWarning: 'US and territories only.', probe: 'https://api.weather.gov/alerts/active?area=DC'
  });
  S('reliefweb', 'ReliefWeb API (OCHA)', {
    tier: 'A', liveCapable: true, apiBase: 'https://api.reliefweb.int/v2', endpoints: ['/reports', '/disasters'],
    linkoutSearchUrlTemplate: 'https://reliefweb.int/updates?search={q}', linkoutDetailUrlTemplate: 'https://reliefweb.int/country/{id}',
    officialDocsUrl: 'https://apidoc.reliefweb.int/', officialSiteUrl: 'https://reliefweb.int/',
    attribution: 'Humanitarian event data provided by ReliefWeb / OCHA.',
    coverageGapWarning: 'API v2 requires a ReliefWeb-approved appname. Until JAQA’s appname is approved and verified, ReliefWeb is link-out only.'
  });
  S('cisaKev', 'CISA Known Exploited Vulnerabilities', {
    tier: 'A', region: 'Global (US agency)', liveCapable: true,
    apiBase: 'https://raw.githubusercontent.com/cisagov/kev-data/develop',
    endpoints: ['/known_exploited_vulnerabilities.json (official cisagov GitHub mirror of https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json)'],
    linkoutSearchUrlTemplate: 'https://www.cisa.gov/known-exploited-vulnerabilities-catalog', officialDocsUrl: 'https://www.cisa.gov/known-exploited-vulnerabilities-catalog', officialSiteUrl: 'https://www.cisa.gov/',
    attribution: 'KEV data provided by CISA (official cisagov/kev-data repository).', concurrencyLimit: 1, timeoutMs: 20000,
    coverageGapWarning: 'The cisa.gov feed does not send CORS headers; JAQA uses CISA’s official GitHub mirror. A KEV entry does not prove any supplier uses the affected product/version.',
    rateLimitPolicy: 'Catalog (~1–2 MB) downloaded at most once per session, only when a cyber lookup is triggered.',
    probe: 'https://raw.githubusercontent.com/cisagov/kev-data/develop/known_exploited_vulnerabilities.json'
  });
  S('cpsc', 'CPSC Recalls API', {
    tier: 'A', region: 'United States', liveCapable: true, apiBase: 'https://www.saferproducts.gov/RestWebServices', endpoints: ['/Recall?format=json&RecallTitle=', '/Recall?format=json&RecallNumber='],
    linkoutSearchUrlTemplate: 'https://www.cpsc.gov/Recalls', officialDocsUrl: 'https://www.cpsc.gov/Recalls/CPSC-Recalls-Application-Program-Interface-API-Information', officialSiteUrl: 'https://www.cpsc.gov/Recalls',
    attribution: 'Recall data provided by U.S. Consumer Product Safety Commission.', officialSourceAuthoritative: true, timeoutMs: 15000,
    coverageGapWarning: 'US consumer products only. Name matching is keyword-based and may miss or over-match.',
    probe: 'https://www.saferproducts.gov/RestWebServices/Recall?format=json&RecallNumber=26639'
  });
  S('nhtsa', 'NHTSA Recalls API', {
    tier: 'A', region: 'United States', liveCapable: true, apiBase: 'https://api.nhtsa.gov/recalls', endpoints: ['/campaignNumber?campaignNumber=', '/recallsByVehicle?make=&model=&modelYear='],
    linkoutSearchUrlTemplate: 'https://www.nhtsa.gov/recalls', officialDocsUrl: 'https://www.nhtsa.gov/nhtsa-datasets-and-apis', officialSiteUrl: 'https://www.nhtsa.gov/recalls',
    attribution: 'Recall data provided by NHTSA.', officialSourceAuthoritative: true,
    probe: 'https://api.nhtsa.gov/recalls/campaignNumber?campaignNumber=20V314000'
  });
  S('usaspending', 'USAspending API', {
    tier: 'A', region: 'United States', liveCapable: true, apiBase: 'https://api.usaspending.gov/api/v2', endpoints: ['POST /search/spending_by_award/', 'POST /autocomplete/recipient/', 'GET /awards/{generated_award_id}/'],
    linkoutSearchUrlTemplate: 'https://www.usaspending.gov/search', linkoutDetailUrlTemplate: 'https://www.usaspending.gov/award/{id}',
    officialDocsUrl: 'https://api.usaspending.gov/docs/endpoints', officialSiteUrl: 'https://www.usaspending.gov/',
    attribution: 'Federal spending data provided by USAspending.gov.', procurementSensitive: true, mayLagOfficialDb: true, officialSourceAuthoritative: true,
    coverageGapWarning: 'US federal awards only. Recipient names can be ambiguous across parent/subsidiary entities; verify the legal entity (UEI) and contract number.',
    probe: 'https://api.usaspending.gov/api/v2/references/toptier_agencies/'
  });
  S('federalRegister', 'Federal Register API', {
    tier: 'A', region: 'United States', liveCapable: true, apiBase: 'https://www.federalregister.gov/api/v1', endpoints: ['/documents.json?conditions[term]=', '/documents/{number}.json'],
    linkoutSearchUrlTemplate: 'https://www.federalregister.gov/documents/search?conditions%5Bterm%5D={q}', officialDocsUrl: 'https://www.federalregister.gov/developers/documentation/api/v1', officialSiteUrl: 'https://www.federalregister.gov/',
    attribution: 'Regulatory documents provided by Federal Register / GovInfo.', legalReviewRequired: true, officialSourceAuthoritative: true,
    probe: 'https://www.federalregister.gov/api/v1/documents.json?per_page=1'
  });
  S('sec', 'SEC EDGAR submissions', {
    tier: 'A', region: 'United States', liveCapable: true, apiBase: 'https://data.sec.gov', endpoints: ['/submissions/CIK##########.json'],
    linkoutSearchUrlTemplate: 'https://www.sec.gov/cgi-bin/browse-edgar?company={q}&owner=exclude&action=getcompany', linkoutDetailUrlTemplate: 'https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK={id}&owner=exclude',
    officialDocsUrl: 'https://www.sec.gov/search-filings/edgar-application-programming-interfaces', officialSiteUrl: 'https://www.sec.gov/edgar/search/',
    attribution: 'Public company filings provided by U.S. SEC EDGAR.', financeSensitive: true, officialSourceAuthoritative: true, concurrencyLimit: 1,
    rateLimitPolicy: 'SEC fair access: max 10 requests/second; JAQA sends at most 1 at a time, user-triggered.',
    coverageGapWarning: 'SEC registrants only. Private companies and most non-US insurers are not covered.',
    probe: 'https://data.sec.gov/submissions/CIK0000320193.json'
  });
  S('secXbrl', 'SEC EDGAR XBRL company facts', {
    tier: 'A', region: 'United States', liveCapable: true, apiBase: 'https://data.sec.gov/api/xbrl', endpoints: ['/companyfacts/CIK##########.json'],
    linkoutDetailUrlTemplate: 'https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK={id}&type=10-K&owner=exclude', officialDocsUrl: 'https://www.sec.gov/search-filings/edgar-application-programming-interfaces',
    attribution: 'XBRL financial data provided by U.S. SEC EDGAR.', financeSensitive: true, concurrencyLimit: 1, timeoutMs: 20000,
    coverageGapWarning: 'The companyfacts endpoint returned no CORS header in verification, so XBRL facts and derived metrics are link-out only (filing index remains live).',
    probe: 'https://data.sec.gov/api/xbrl/companyfacts/CIK0000320193.json'
  });
  S('secFullText', 'SEC EDGAR full-text search', {
    tier: 'B', region: 'United States', liveCapable: true, apiBase: 'https://efts.sec.gov/LATEST', endpoints: ['/search-index?q='],
    linkoutSearchUrlTemplate: 'https://www.sec.gov/edgar/search/#/q=%22{q}%22', attribution: 'Filing text search provided by U.S. SEC EDGAR.', financeSensitive: true,
    coverageGapWarning: 'No CORS header returned in verification; link-out only.'
  });
  S('ted', 'TED — Tenders Electronic Daily API', {
    tier: 'A', region: 'European Union / EEA', liveCapable: true, apiBase: 'https://api.ted.europa.eu/v3', endpoints: ['POST /notices/search'],
    linkoutSearchUrlTemplate: 'https://ted.europa.eu/en/search/result?FT={q}', linkoutDetailUrlTemplate: 'https://ted.europa.eu/en/notice/-/detail/{id}',
    officialDocsUrl: 'https://docs.ted.europa.eu/api/latest/index.html', officialSiteUrl: 'https://ted.europa.eu/',
    attribution: 'EU tender data provided by TED / Publications Office of the European Union.',
    procurementSensitive: true, translationRisk: true, deadlineRisk: true, officialSourceAuthoritative: true,
    coverageGapWarning: 'Only above-threshold EU/EEA notices. The search API currently does not return CORS headers for browser POSTs, so TED is link-out only.'
  });
  S('sam', 'SAM.gov opportunities & exclusions', {
    tier: 'A', region: 'United States', linkoutSearchUrlTemplate: 'https://sam.gov/search/?index=ex', officialSiteUrl: 'https://sam.gov/', officialDocsUrl: 'https://open.gsa.gov/api/',
    attribution: 'Federal exclusion/opportunity data provided by SAM.gov / GSA.', procurementSensitive: true, sanctionsLinkOutOnly: true, falseNegativeRisk: true, officialSourceAuthoritative: true, deadlineRisk: true,
    coverageGapWarning: 'API requires a registered key; link-out only. An exclusion search is not sanctions clearance.'
  });
  S('ofac', 'OFAC Sanctions List Search', {
    tier: 'A', region: 'United States', linkoutSearchUrlTemplate: 'https://sanctionssearch.ofac.treas.gov/', officialSiteUrl: 'https://ofac.treasury.gov/',
    attribution: 'Sanctions information provided by OFAC / U.S. Department of the Treasury.', sanctionsLinkOutOnly: true, falseNegativeRisk: true, legalReviewRequired: true, officialSourceAuthoritative: true,
    coverageGapWarning: 'No hit ≠ clear. Name screening requires a sanctions screening system of record and compliance review.'
  });
  S('epa', 'EPA ECHO facility search', {
    tier: 'A', region: 'United States', liveCapable: true, apiBase: 'https://echodata.epa.gov/echo', endpoints: ['/echo_rest_services.get_facility_info?output=JSON&p_fn='],
    linkoutSearchUrlTemplate: 'https://echo.epa.gov/facilities/facility-search', officialDocsUrl: 'https://echo.epa.gov/tools/web-services', officialSiteUrl: 'https://echo.epa.gov/',
    attribution: 'Environmental compliance data provided by U.S. EPA ECHO.', timeoutMs: 20000, concurrencyLimit: 1, mayLagOfficialDb: true,
    coverageGapWarning: 'US regulated facilities only. Facility-name matches are not legal-entity matches.',
    probe: 'https://echodata.epa.gov/echo/echo_rest_services.get_facility_info?output=JSON&p_fn=ZZZZJAQAPROBE'
  });
  S('courtlistener', 'CourtListener (Free Law Project)', {
    tier: 'A', region: 'United States', liveCapable: true, apiBase: 'https://www.courtlistener.com/api/rest/v4', endpoints: ['/search/?type=r', '/search/?type=o'],
    linkoutSearchUrlTemplate: 'https://www.courtlistener.com/?q={q}', officialDocsUrl: 'https://www.courtlistener.com/help/api/rest/', officialSiteUrl: 'https://www.courtlistener.com/',
    attribution: 'Court records/metadata provided by CourtListener / RECAP (Free Law Project).', legalReviewRequired: true, falseNegativeRisk: true, concurrencyLimit: 1, timeoutMs: 15000,
    coverageGapWarning: 'Partial US federal coverage (RECAP is crowd-sourced). Not a complete litigation history. PACER is fee-based and is not bypassed.',
    probe: 'https://www.courtlistener.com/api/rest/v4/search/?q=%22reinsurance%22&type=o'
  });
  S('overpass', 'OpenStreetMap Overpass API', {
    tier: 'A', liveCapable: true, apiBase: 'https://overpass-api.de/api', endpoints: ['/interpreter?data='],
    officialDocsUrl: 'https://wiki.openstreetmap.org/wiki/Overpass_API', officialSiteUrl: 'https://www.openstreetmap.org/',
    attribution: 'Geographic data © OpenStreetMap contributors (ODbL).', concurrencyLimit: 1, timeoutMs: 25000,
    rateLimitPolicy: 'Shared community server: one small user-triggered query at a time. No map tiles.',
    coverageGapWarning: 'Community-mapped; completeness varies. Not a facility register.'
  });
  S('wikidata', 'Wikidata', {
    tier: 'A', liveCapable: true, apiBase: 'https://www.wikidata.org/w/api.php', endpoints: ['?action=wbsearchentities', '?action=wbgetentities'],
    linkoutDetailUrlTemplate: 'https://www.wikidata.org/wiki/{id}', officialDocsUrl: 'https://www.wikidata.org/wiki/Wikidata:Data_access', officialSiteUrl: 'https://www.wikidata.org/',
    attribution: 'Entity background data provided by Wikidata (CC0).',
    coverageGapWarning: 'Community-edited and not authoritative for legal, insurance, sanctions, credit, procurement, or financial status.',
    probe: 'https://www.wikidata.org/w/api.php?action=wbsearchentities&search=GLEIF&language=en&format=json&limit=1&origin=*'
  });
  S('wikipedia', 'Wikipedia REST API', {
    tier: 'A', liveCapable: true, apiBase: 'https://en.wikipedia.org/api/rest_v1', endpoints: ['/page/summary/{title}'],
    linkoutSearchUrlTemplate: 'https://en.wikipedia.org/wiki/Special:Search?search={q}', officialSiteUrl: 'https://en.wikipedia.org/',
    attribution: 'Background summaries from Wikipedia (CC BY-SA).',
    coverageGapWarning: 'Encyclopedic background only; not authoritative.', probe: 'https://en.wikipedia.org/api/rest_v1/page/summary/Legal_Entity_Identifier'
  });

  /* ---------------------------- Tier B ---------------------------- */
  S('nvd', 'NIST National Vulnerability Database', {
    tier: 'B', liveCapable: true, apiBase: 'https://services.nvd.nist.gov/rest/json/cves/2.0', endpoints: ['?cveId=', '?keywordSearch='],
    linkoutDetailUrlTemplate: 'https://nvd.nist.gov/vuln/detail/{id}', officialDocsUrl: 'https://nvd.nist.gov/developers/vulnerabilities', officialSiteUrl: 'https://nvd.nist.gov/',
    attribution: 'CVE data provided by NVD. This product uses the NVD API but is not endorsed or certified by the NVD.',
    rateLimitPolicy: 'Without a key: 5 requests per rolling 30 seconds. JAQA sends one at a time, user-triggered.', concurrencyLimit: 1, timeoutMs: 20000,
    coverageGapWarning: 'CVE records do not prove a supplier uses the affected product/version.',
    probe: 'https://services.nvd.nist.gov/rest/json/cves/2.0?cveId=CVE-2021-44228'
  });
  S('ecb', 'ECB Data Portal API', {
    tier: 'B', region: 'Euro area', liveCapable: true, apiBase: 'https://data-api.ecb.europa.eu/service', endpoints: ['/data/EXR/D.{CUR}.EUR.SP00.A?format=jsondata'],
    officialDocsUrl: 'https://data.ecb.europa.eu/help/api/overview', officialSiteUrl: 'https://data.ecb.europa.eu/',
    attribution: 'ECB data provided by the European Central Bank.', financeSensitive: true, officialSourceAuthoritative: true,
    coverageGapWarning: 'Euro foreign exchange reference rates are for information only; they are not tradable prices.',
    probe: 'https://data-api.ecb.europa.eu/service/data/EXR/D.USD.EUR.SP00.A?format=jsondata&lastNObservations=1'
  });
  S('fred', 'FRED (Federal Reserve Bank of St. Louis)', {
    tier: 'B', region: 'United States / Global', linkoutSearchUrlTemplate: 'https://fred.stlouisfed.org/searchresults/?st={q}', officialSiteUrl: 'https://fred.stlouisfed.org/', officialDocsUrl: 'https://fred.stlouisfed.org/docs/api/fred/',
    attribution: 'Economic data provided by FRED / Federal Reserve Bank of St. Louis where used.', financeSensitive: true,
    coverageGapWarning: 'API requires a key and does not return browser CORS headers; link-out only.'
  });
  S('imf', 'IMF data & country resources', {
    tier: 'B', linkoutDetailUrlTemplate: 'https://www.imf.org/en/Countries/{id}', officialSiteUrl: 'https://www.imf.org/en/Data', attribution: 'IMF data/resources provided by the International Monetary Fund where used.', financeSensitive: true,
    coverageGapWarning: 'DataMapper API refused automated verification requests; link-out only. WEO series include projections.'
  });
  S('oecd', 'OECD data & resources', { tier: 'B', officialSiteUrl: 'https://www.oecd.org/', linkoutSearchUrlTemplate: 'https://data-explorer.oecd.org/', attribution: 'OECD data/resources provided by the OECD where used.' });
  S('bis', 'BIS statistics', { tier: 'B', officialSiteUrl: 'https://data.bis.org/', attribution: 'BIS data provided by the Bank for International Settlements where used.', financeSensitive: true });
  S('un', 'United Nations resources (UNGM, UN Stats, UN sanctions)', { tier: 'B', officialSiteUrl: 'https://www.un.org/', attribution: 'UN data/resources provided by the United Nations where used.' });
  S('ilo', 'International Labour Organization', { tier: 'B', officialSiteUrl: 'https://www.ilo.org/', attribution: 'ILO data/resources provided by the International Labour Organization where used.', guidelineLinkOutOnly: true });
  S('firms', 'NASA FIRMS active fire data', { tier: 'B', officialSiteUrl: 'https://firms.modaps.eosdis.nasa.gov/map/', attribution: 'NASA FIRMS data provided by NASA where used.', coverageGapWarning: 'API requires a MAP_KEY; link-out only.' });
  S('comtrade', 'UN Comtrade', { tier: 'B', officialSiteUrl: 'https://comtradeplus.un.org/', attribution: 'Trade data provided by UN Comtrade where used.', mayLagOfficialDb: true, coverageGapWarning: 'Keyed API without browser CORS; link-out only. Aggregated, lagging data; no shipment-level visibility.' });
  S('acled', 'ACLED conflict data', { tier: 'B', officialSiteUrl: 'https://acleddata.com/', attribution: 'Event data provided by ACLED where used.', coverageGapWarning: 'Registration/key and licence terms required; link-out only.' });
  S('gdelt', 'GDELT DOC 2.0 API', {
    tier: 'B', liveCapable: true, apiBase: 'https://api.gdeltproject.org/api/v2', endpoints: ['/doc/doc?mode=artlist&format=json'],
    officialDocsUrl: 'https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/', officialSiteUrl: 'https://www.gdeltproject.org/',
    attribution: 'Media event data provided by the GDELT Project where used.', concurrencyLimit: 1, timeoutMs: 15000,
    rateLimitPolicy: 'GDELT asks for at most one request every 5 seconds; JAQA sends user-triggered requests only.',
    coverageGapWarning: 'Noisy media signals, not truth, and not adverse-media screening. Rate-limit responses omit CORS headers, so a throttled request appears as unavailable for the session.',
    probe: 'https://api.gdeltproject.org/api/v2/doc/doc?query=%22port%20congestion%22&mode=artlist&format=json&maxrecords=1'
  });
  S('opencorporates', 'OpenCorporates', { tier: 'B', linkoutSearchUrlTemplate: 'https://opencorporates.com/companies?q={q}', officialSiteUrl: 'https://opencorporates.com/', attribution: 'Company registry data provided by OpenCorporates where used.', coverageGapWarning: 'API requires a token; link-out only.' });
  S('companiesHouse', 'UK Companies House', {
    tier: 'B', region: 'United Kingdom', linkoutSearchUrlTemplate: 'https://find-and-update.company-information.service.gov.uk/search?q={q}', linkoutDetailUrlTemplate: 'https://find-and-update.company-information.service.gov.uk/company/{id}',
    officialSiteUrl: 'https://find-and-update.company-information.service.gov.uk/', officialDocsUrl: 'https://developer.company-information.service.gov.uk/',
    attribution: 'UK company data provided by Companies House where used.', officialSourceAuthoritative: true, insolvencyRegistryLinkOutOnly: true, lienRegistryLinkOutOnly: true,
    coverageGapWarning: 'API requires a key; link-out only in this release (extension point: in-memory browser key).'
  });

  /* ------------- Server-backed (same-origin JAQA server) ------------- */
  S('jaqaMonitor', 'JAQA Global Monitor — official public feeds (via the JAQA server)', {
    tier: 'B', region: 'Global', liveCapable: true, serverBacked: true, apiBase: '/api/jaqa/monitor', endpoints: ['/feed?id={feed}'],
    officialSiteUrl: 'https://jaqa.life/', attribution: 'Headlines and links from the listed official publishers, fetched by the JAQA server. Content and copyright remain with each publisher.',
    coverageGapWarning: 'A selected set of official feeds. Headlines are not the full story and are not verified, ranked or summarized by JAQA.',
    rateLimitPolicy: 'Server-side cache of 10 minutes per feed. Max 4 concurrent.', concurrencyLimit: 4, officialSourceAuthoritative: true
  });

  /* ------------------ Tier C (link-out only by policy) ------------------ */
  S('insuranceRegulators', 'Insurance regulators (IAIS, EIOPA, NAIC, FCA/PRA, BaFin, APRA, OSFI, NFRA, IRDAI…)', { kind: 'directory', regulatorLinkOutOnly: true, insuranceSensitive: true, officialSourceAuthoritative: true, legalReviewRequired: true, attribution: 'Regulatory information provided by the respective supervisory authorities.' });
  S('ratingAgencies', 'Rating agencies (AM Best, S&P, Moody’s, Fitch, KBRA)', { kind: 'directory', ratingAgencyLinkOutOnly: true, paidSourceLinkOutOnly: true, insuranceSensitive: true, financeSensitive: true, safetyNote: 'Ratings are never scraped, reproduced or derived.' });
  S('marketReports', 'Insurance / reinsurance market reports', { kind: 'directory', marketReportLinkOutOnly: true, paidSourceLinkOutOnly: true, insuranceSensitive: true, safetyNote: 'Reports are never scraped or reproduced.' });
  S('procurementPortals', 'Global procurement portals & development banks', { kind: 'directory', procurementPortalLinkOutOnly: true, procurementSensitive: true, translationRisk: true, deadlineRisk: true, officialSourceAuthoritative: true, safetyNote: 'Portals are never scraped. Login-protected portals are link-out only.' });
  S('sanctionsLists', 'Sanctions, debarment & export-control lists', { kind: 'directory', sanctionsLinkOutOnly: true, falseNegativeRisk: true, legalReviewRequired: true, officialSourceAuthoritative: true });
  S('insolvencyRegistries', 'Insolvency & bankruptcy registries', { kind: 'directory', insolvencyRegistryLinkOutOnly: true, falseNegativeRisk: true, legalReviewRequired: true, financeSensitive: true });
  S('lienRegistries', 'Lien, UCC, charges & judgment registries', { kind: 'directory', lienRegistryLinkOutOnly: true, falseNegativeRisk: true, legalReviewRequired: true, financeSensitive: true });
  S('standards', 'Standards & frameworks publishers', { kind: 'directory', guidelineLinkOutOnly: true, safetyNote: 'References, not certifications.' });
  S('paidCommercial', 'Paid / commercial data providers', { kind: 'directory', paidSourceLinkOutOnly: true, publicDataOnly: false, safetyNote: 'Never scraped, reproduced or bypassed. Listed for orientation only; no affiliation.' });
  S('internalSystems', 'Internal enterprise systems (ERP, vendor master, claims, treasury…)', { kind: 'unavailable', publicDataOnly: false, commercialConfidentialitySensitive: true, personalDataSensitive: true, safetyNote: 'Unavailable by design. JAQA never accepts internal or confidential data.' });
  // Internal systems are unavailable by design (never link-out, never live).
  SOURCES[SOURCES.length - 1].defaultMode = 'unavailable';
  SOURCES[SOURCES.length - 1].status = 'unavailable';

  R.sources = {
    list: SOURCES,
    get: (id) => SOURCES.find((s) => s.id === id),
    liveHosts() {
      const hosts = new Set();
      SOURCES.filter((s) => s.corsVerified).forEach((s) => {
        [s.apiBase, ...(s.endpoints || [])].forEach((e) => {
          const m = /^https:\/\/[^/\s]+/.exec(e || '');
          if (m) hosts.add(m[0]);
        });
      });
      return [...hosts];
    }
  };

  /* ------------------------------------------------------------------ *
   * Official link-out directories. Every entry is opened by the USER’S
   * browser in a new tab; nothing is fetched or scraped by JAQA.
   * `search` templates carry the query only when the user has not enabled
   * “official-link-only mode”.
   * ------------------------------------------------------------------ */
  const L = (name, url, extra) => Object.assign({ name, url }, extra || {});
  R.directories = {
    entity: [
      L('GLEIF LEI Search', 'https://search.gleif.org/', { search: 'https://search.gleif.org/#/search/simpleSearch={q}', region: 'Global', kind: 'official' }),
      L('SEC EDGAR company search', 'https://www.sec.gov/edgar/searchedgar/companysearch', { search: 'https://www.sec.gov/cgi-bin/browse-edgar?company={q}&owner=exclude&action=getcompany', region: 'United States', kind: 'official' }),
      L('UK Companies House', 'https://find-and-update.company-information.service.gov.uk/', { search: 'https://find-and-update.company-information.service.gov.uk/search?q={q}', region: 'United Kingdom', kind: 'official' }),
      L('EU business registers (e-Justice / BRIS)', 'https://e-justice.europa.eu/topics/registers-business-insolvency-land/business-registers-search-company-eu_en', { region: 'European Union', kind: 'official' }),
      L('OpenCorporates', 'https://opencorporates.com/', { search: 'https://opencorporates.com/companies?q={q}', region: 'Global', kind: 'reference' }),
      L('Wikipedia search', 'https://en.wikipedia.org/', { search: 'https://en.wikipedia.org/wiki/Special:Search?search={q}', kind: 'reference', note: 'Non-authoritative background.' })
    ],
    sanctions: [
      L('OFAC Sanctions List Search', 'https://sanctionssearch.ofac.treas.gov/', { region: 'United States', kind: 'sanctions' }),
      L('OFAC SDN List', 'https://ofac.treasury.gov/specially-designated-nationals-and-blocked-persons-list-sdn-human-readable-lists', { region: 'United States', kind: 'sanctions' }),
      L('EU Sanctions Map', 'https://www.sanctionsmap.eu/', { region: 'European Union', kind: 'sanctions' }),
      L('EU consolidated financial sanctions list', 'https://data.europa.eu/data/datasets/consolidated-list-of-persons-groups-and-entities-subject-to-eu-financial-sanctions', { region: 'European Union', kind: 'sanctions' }),
      L('UK sanctions list (FCDO / OFSI)', 'https://www.gov.uk/government/publications/the-uk-sanctions-list', { region: 'United Kingdom', kind: 'sanctions' }),
      L('UN Security Council Consolidated List', 'https://main.un.org/securitycouncil/en/content/un-sc-consolidated-list', { region: 'Global', kind: 'sanctions' }),
      L('US Consolidated Screening List (trade.gov)', 'https://www.trade.gov/consolidated-screening-list', { region: 'United States', kind: 'export-control', note: 'Includes BIS Entity List, Denied Persons, Unverified List and others.' }),
      L('BIS Entity List', 'https://www.bis.gov/entity-list', { region: 'United States', kind: 'export-control' }),
      L('SAM.gov exclusions', 'https://sam.gov/search/?index=ex', { region: 'United States', kind: 'debarment' }),
      L('World Bank debarred firms & individuals', 'https://www.worldbank.org/en/projects-operations/procurement/debarred-firms', { region: 'Global (IFI)', kind: 'debarment' }),
      L('ADB Office of Anticorruption and Integrity (sanctions)', 'https://www.adb.org/who-we-are/integrity', { region: 'Asia-Pacific (IFI)', kind: 'debarment' }),
      L('AfDB debarment list', 'https://www.afdb.org/en/projects-and-operations/procurement/debarment-and-sanctions-procedures', { region: 'Africa (IFI)', kind: 'debarment' }),
      L('IDB sanctioned firms & individuals', 'https://www.iadb.org/en/who-we-are/topics/transparency/integrity-at-the-idb-group/sanctioned-firms-and-individuals', { region: 'Latin America (IFI)', kind: 'debarment' }),
      L('EBRD ineligible entities', 'https://www.ebrd.com/ineligible-entities.html', { region: 'Europe/Central Asia (IFI)', kind: 'debarment' }),
      L('UFLPA Entity List (DHS)', 'https://www.dhs.gov/uflpa-entity-list', { region: 'United States', kind: 'export-control' })
    ],
    enforcement: [
      L('SEC litigation releases', 'https://www.sec.gov/enforcement-litigation/litigation-releases', { region: 'United States' }),
      L('US DOJ news & press releases', 'https://www.justice.gov/news', { region: 'United States' }),
      L('FTC cases & proceedings', 'https://www.ftc.gov/legal-library/browse/cases-proceedings', { region: 'United States' }),
      L('FinCEN enforcement actions', 'https://www.fincen.gov/news-room/enforcement-actions', { region: 'United States' }),
      L('UK FCA enforcement', 'https://www.fca.org.uk/about/enforcement', { region: 'United Kingdom' }),
      L('UK Serious Fraud Office cases', 'https://www.sfo.gov.uk/our-cases/', { region: 'United Kingdom' }),
      L('FATF high-risk jurisdictions', 'https://www.fatf-gafi.org/en/topics/high-risk-and-other-monitored-jurisdictions.html', { region: 'Global' }),
      L('OpenSanctions (reference, no auto-screening)', 'https://www.opensanctions.org/', { region: 'Global', kind: 'reference', note: 'Third-party aggregation; link-out only, no clearance.' })
    ],
    insolvency: [
      L('UK Gazette insolvency notices', 'https://www.thegazette.co.uk/insolvency', { region: 'United Kingdom' }),
      L('UK Insolvency Service', 'https://www.gov.uk/government/organisations/insolvency-service', { region: 'United Kingdom' }),
      L('EU bankruptcy & insolvency registers (e-Justice)', 'https://e-justice.europa.eu/topics/registers-business-insolvency-land/bankruptcy-insolvency-registers_en', { region: 'European Union' }),
      L('US Bankruptcy Courts (uscourts.gov)', 'https://www.uscourts.gov/court-programs/bankruptcy', { region: 'United States' }),
      L('PACER (fee-based; no bypass)', 'https://pacer.uscourts.gov/', { region: 'United States', kind: 'paid' }),
      L('ASIC published notices', 'https://publishednotices.asic.gov.au/', { region: 'Australia' }),
      L('Canada Office of the Superintendent of Bankruptcy', 'https://ised-isde.canada.ca/site/office-superintendent-bankruptcy/en', { region: 'Canada' }),
      L('Insolvency and Bankruptcy Board of India', 'https://ibbi.gov.in/', { region: 'India' }),
      L('New Zealand Insolvency & Trustee Service', 'https://www.insolvency.govt.nz/', { region: 'New Zealand' }),
      L('Singapore Insolvency Office (MinLaw)', 'https://www.mlaw.gov.sg/', { region: 'Singapore' })
    ],
    lien: [
      L('US state UCC filing offices (NASS directory)', 'https://www.nass.org/', { region: 'United States', note: 'UCC filings are searched per state Secretary of State.' }),
      L('UK Companies House charges (per company)', 'https://find-and-update.company-information.service.gov.uk/', { region: 'United Kingdom' }),
      L('Australia PPSR', 'https://www.ppsr.gov.au/', { region: 'Australia' }),
      L('New Zealand PPSR', 'https://www.ppsr.govt.nz/', { region: 'New Zealand' }),
      L('CourtListener judgments (US, partial)', 'https://www.courtlistener.com/', { search: 'https://www.courtlistener.com/?q={q}', region: 'United States' })
    ],
    insuranceRegulators: [
      L('IAIS — International Association of Insurance Supervisors', 'https://www.iaisweb.org/', { region: 'Global' }),
      L('IAIS member directory', 'https://www.iaisweb.org/about-the-iais/iais-members/', { region: 'Global', note: 'Directory of national insurance supervisors.' }),
      L('EIOPA register of insurance undertakings', 'https://register.eiopa.europa.eu/', { region: 'European Union' }),
      L('EIOPA', 'https://www.eiopa.europa.eu/', { region: 'European Union' }),
      L('NAIC — state insurance departments', 'https://content.naic.org/state-insurance-departments', { region: 'United States' }),
      L('NAIC Consumer Insurance Search', 'https://content.naic.org/cis_consumer_information.htm', { region: 'United States' }),
      L('UK FCA Financial Services Register', 'https://register.fca.org.uk/s/', { region: 'United Kingdom' }),
      L('UK PRA (Bank of England)', 'https://www.bankofengland.co.uk/prudential-regulation', { region: 'United Kingdom' }),
      L('BaFin company database', 'https://portal.mvp.bafin.de/database/InstInfo/', { region: 'Germany' }),
      L('APRA (Australia)', 'https://www.apra.gov.au/', { region: 'Australia' }),
      L('OSFI (Canada)', 'https://www.osfi-bsif.gc.ca/', { region: 'Canada' }),
      L('NFRA (China, former CBIRC)', 'https://www.nfra.gov.cn/', { region: 'China', lang: 'zh', translationRisk: true }),
      L('IRDAI (India)', 'https://irdai.gov.in/', { region: 'India' }),
      L('MAS financial institutions directory (Singapore)', 'https://eservices.mas.gov.sg/fid', { region: 'Singapore' }),
      L('FINMA (Switzerland)', 'https://www.finma.ch/en/', { region: 'Switzerland' }),
      L('Bermuda Monetary Authority (insurance, captives, ILS)', 'https://www.bma.bm/', { region: 'Bermuda' }),
      L('Cayman Islands Monetary Authority', 'https://www.cima.ky/', { region: 'Cayman Islands' }),
      L('Guernsey Financial Services Commission', 'https://www.gfsc.gg/', { region: 'Guernsey' }),
      L('Vermont captive insurance (DFR)', 'https://dfr.vermont.gov/industry/insurance/captive-insurance', { region: 'United States (Vermont)' })
    ],
    ratingAgencies: [
      L('AM Best', 'https://web.ambest.com/', { kind: 'rating-agency' }),
      L('S&P Global Ratings', 'https://www.spglobal.com/ratings/en/', { kind: 'rating-agency' }),
      L('Moody’s Ratings', 'https://ratings.moodys.com/', { kind: 'rating-agency' }),
      L('Fitch Ratings', 'https://www.fitchratings.com/', { kind: 'rating-agency' }),
      L('KBRA', 'https://www.kbra.com/', { kind: 'rating-agency' })
    ],
    marketReports: [
      L('Swiss Re Institute (sigma)', 'https://www.swissre.com/institute/', { kind: 'market-report' }),
      L('Munich Re natural catastrophe resources', 'https://www.munichre.com/en/risks/natural-disasters.html', { kind: 'market-report' }),
      L('Gallagher Re', 'https://www.ajg.com/gallagherre/', { kind: 'market-report' }),
      L('Aon reinsurance insights', 'https://www.aon.com/en/insights', { kind: 'market-report' }),
      L('Marsh global insurance market index', 'https://www.marsh.com/en/services/international-placement-services/insights/global-insurance-market-index.html', { kind: 'market-report' }),
      L('Guy Carpenter', 'https://www.guycarp.com/', { kind: 'market-report' }),
      L('Lloyd’s of London', 'https://www.lloyds.com/', { kind: 'market-report', note: 'Public market and syndicate information.' }),
      L('Artemis ILS / cat bond deal directory', 'https://www.artemis.bm/deal-directory/', { kind: 'market-report', note: 'Industry news directory; not investment advice.' })
    ],
    procurement: [
      L('TED — Tenders Electronic Daily', 'https://ted.europa.eu/', { search: 'https://ted.europa.eu/en/search/result?FT={q}', region: 'European Union', lang: 'multi', translationRisk: true }),
      L('EU Funding & Tenders Portal', 'https://ec.europa.eu/info/funding-tenders/opportunities/portal/', { region: 'European Union', grant: true }),
      L('UK Find a Tender', 'https://www.find-tender.service.gov.uk/', { region: 'United Kingdom' }),
      L('UK Contracts Finder', 'https://www.contractsfinder.service.gov.uk/', { region: 'United Kingdom' }),
      L('SAM.gov contract opportunities', 'https://sam.gov/search/?index=opp', { region: 'United States' }),
      L('USAspending award search', 'https://www.usaspending.gov/search', { region: 'United States' }),
      L('CanadaBuys', 'https://canadabuys.canada.ca/', { region: 'Canada', lang: 'en/fr' }),
      L('AusTender', 'https://www.tenders.gov.au/', { region: 'Australia' }),
      L('New Zealand GETS', 'https://www.gets.govt.nz/', { region: 'New Zealand' }),
      L('Singapore GeBIZ', 'https://www.gebiz.gov.sg/', { region: 'Singapore' }),
      L('India CPPP (eProcure)', 'https://eprocure.gov.in/', { region: 'India' }),
      L('India GeM', 'https://gem.gov.in/', { region: 'India' }),
      L('Brazil gov.br Compras', 'https://www.gov.br/compras/', { region: 'Brazil', lang: 'pt', translationRisk: true }),
      L('Mexico federal procurement (ComprasMX)', 'https://comprasmx.buengobierno.gob.mx/', { region: 'Mexico', lang: 'es', translationRisk: true }),
      L('Switzerland simap', 'https://www.simap.ch/', { region: 'Switzerland', lang: 'de/fr/it', translationRisk: true }),
      L('Norway Doffin', 'https://doffin.no/', { region: 'Norway', lang: 'no', translationRisk: true }),
      L('Denmark udbud.dk', 'https://udbud.dk/', { region: 'Denmark', lang: 'da', translationRisk: true }),
      L('Finland Hilma', 'https://www.hankintailmoitukset.fi/', { region: 'Finland', lang: 'fi/sv', translationRisk: true }),
      L('Japan government procurement (JETRO)', 'https://www.jetro.go.jp/en/database/procurement/', { region: 'Japan' }),
      L('Korea KONEPS', 'https://www.g2b.go.kr/', { region: 'South Korea', lang: 'ko', translationRisk: true }),
      L('China Government Procurement (CCGP)', 'https://www.ccgp.gov.cn/', { region: 'China', lang: 'zh', translationRisk: true }),
      L('UNGM — UN Global Marketplace', 'https://www.ungm.org/Public/Notice', { region: 'Global (UN)' }),
      L('UNDP procurement notices', 'https://procurement-notices.undp.org/', { region: 'Global (UN)' }),
      L('WTO Government Procurement Agreement', 'https://www.wto.org/english/tratop_e/gproc_e/gp_gpa_e.htm', { region: 'Global', kind: 'guideline' }),
      L('OECD public procurement', 'https://www.oecd.org/en/topics/public-procurement.html', { region: 'Global', kind: 'guideline' })
    ],
    devBanks: [
      L('World Bank procurement notices', 'https://projects.worldbank.org/en/projects-operations/procurement', { region: 'Global' }),
      L('World Bank projects & operations', 'https://projects.worldbank.org/en/projects-operations/projects-home', { region: 'Global', grant: true }),
      L('Asian Development Bank tenders', 'https://www.adb.org/projects/tenders', { region: 'Asia-Pacific' }),
      L('African Development Bank procurement', 'https://www.afdb.org/en/projects-and-operations/procurement', { region: 'Africa' }),
      L('Inter-American Development Bank procurement', 'https://projectprocurement.iadb.org/', { region: 'Latin America & Caribbean' }),
      L('EBRD procurement (ECEPP)', 'https://ecepp.ebrd.com/', { region: 'Europe & Central Asia' }),
      L('Islamic Development Bank procurement', 'https://www.isdb.org/project-procurement', { region: 'OIC member countries' }),
      L('US DFC', 'https://www.dfc.gov/', { region: 'Global', grant: true }),
      L('IATI d-portal (aid activity data)', 'https://d-portal.org/', { region: 'Global', grant: true }),
      L('AidData', 'https://www.aiddata.org/', { region: 'Global', grant: true }),
      L('UK FCDO Development Tracker', 'https://devtracker.fcdo.gov.uk/', { region: 'Global', grant: true }),
      L('GIZ tenders', 'https://www.giz.de/en/workingwithgiz/tenders.html', { region: 'Global' }),
      L('KfW Development Bank', 'https://www.kfw-entwicklungsbank.de/', { region: 'Global', grant: true }),
      L('JICA procurement', 'https://www.jica.go.jp/english/about/procurement/index.html', { region: 'Global' }),
      L('AFD (Agence Française de Développement)', 'https://www.afd.fr/en', { region: 'Global', grant: true })
    ],
    ppp: [
      L('World Bank PPP Resource Center', 'https://ppp.worldbank.org/', { region: 'Global' }),
      L('World Bank PPI Database', 'https://ppi.worldbank.org/', { region: 'Global' }),
      L('Global Infrastructure Hub', 'https://www.gihub.org/', { region: 'Global' }),
      L('EPEC — European PPP Expertise Centre (EIB)', 'https://www.eib.org/en/about/partners/cooperation/epec', { region: 'Europe' }),
      L('UK Infrastructure and Projects Authority', 'https://www.gov.uk/government/organisations/infrastructure-and-projects-authority', { region: 'United Kingdom' })
    ],
    macro: [
      L('World Bank Open Data', 'https://data.worldbank.org/', { region: 'Global' }),
      L('IMF Data', 'https://www.imf.org/en/Data', { region: 'Global' }),
      L('IMF World Economic Outlook', 'https://www.imf.org/en/Publications/WEO', { region: 'Global' }),
      L('OECD Data Explorer', 'https://data-explorer.oecd.org/', { region: 'OECD' }),
      L('BIS Data Portal', 'https://data.bis.org/', { region: 'Global' }),
      L('BIS central bank directory', 'https://www.bis.org/cbanks.htm', { region: 'Global' }),
      L('ECB Data Portal', 'https://data.ecb.europa.eu/', { region: 'Euro area' }),
      L('ECB euro reference exchange rates', 'https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html', { region: 'Euro area' }),
      L('FRED', 'https://fred.stlouisfed.org/', { search: 'https://fred.stlouisfed.org/searchresults/?st={q}', region: 'United States / Global' }),
      L('US Treasury interest rate statistics', 'https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics', { region: 'United States' }),
      L('World Bank commodity prices (Pink Sheet)', 'https://www.worldbank.org/en/research/commodity-markets', { region: 'Global' }),
      L('IMF AREAER (exchange arrangements & restrictions)', 'https://www.elibrary-areaer.imf.org/', { region: 'Global', note: 'Currency-control context.' })
    ],
    trade: [
      L('UN Comtrade', 'https://comtradeplus.un.org/', { region: 'Global' }),
      L('World Bank WITS', 'https://wits.worldbank.org/', { region: 'Global' }),
      L('USITC Harmonized Tariff Schedule', 'https://hts.usitc.gov/', { region: 'United States' }),
      L('EU TARIC', 'https://ec.europa.eu/taxation_customs/dds2/taric/taric_consultation.jsp', { region: 'European Union' }),
      L('UK Trade Tariff', 'https://www.trade-tariff.service.gov.uk/find_commodity', { region: 'United Kingdom' }),
      L('WTO Tariff & Trade Data', 'https://ttd.wto.org/', { region: 'Global' }),
      L('ITC Market Access Map', 'https://www.macmap.org/', { region: 'Global' }),
      L('WTO trade remedies (anti-dumping, countervailing)', 'https://www.wto.org/english/tratop_e/adp_e/adp_e.htm', { region: 'Global' }),
      L('UN/LOCODE code list', 'https://unece.org/trade/cefact/unlocode-code-list-country-and-territory', { region: 'Global' }),
      L('World Bank Logistics Performance Index', 'https://lpi.worldbank.org/', { region: 'Global' })
    ],
    cyber: [
      L('CISA KEV catalog', 'https://www.cisa.gov/known-exploited-vulnerabilities-catalog', { region: 'Global' }),
      L('CISA cybersecurity advisories', 'https://www.cisa.gov/news-events/cybersecurity-advisories', { region: 'Global' }),
      L('NVD', 'https://nvd.nist.gov/', { region: 'Global' }),
      L('CVE.org', 'https://www.cve.org/', { region: 'Global' }),
      L('GitHub Advisory Database', 'https://github.com/advisories', { region: 'Global' }),
      L('MITRE ATT&CK', 'https://attack.mitre.org/', { region: 'Global', kind: 'reference' }),
      L('MITRE CWE', 'https://cwe.mitre.org/', { region: 'Global', kind: 'reference' }),
      L('OpenSSF Scorecard', 'https://scorecard.dev/', { region: 'Global', kind: 'reference', note: 'Repository hygiene signal; not supplier approval.' }),
      L('CycloneDX (SBOM standard)', 'https://cyclonedx.org/', { region: 'Global', kind: 'standard' }),
      L('EDPB (EU data protection)', 'https://www.edpb.europa.eu/', { region: 'European Union' }),
      L('UK ICO', 'https://ico.org.uk/', { region: 'United Kingdom' }),
      L('NIST AI Risk Management Framework', 'https://www.nist.gov/itl/ai-risk-management-framework', { region: 'Global', kind: 'standard' })
    ],
    scannersLinkOutOnly: [
      L('Shodan', 'https://www.shodan.io/', { kind: 'reference', note: 'Link-out only. No live scanning from JAQA.' }),
      L('Censys', 'https://search.censys.io/', { kind: 'reference', note: 'Link-out only. No live scanning from JAQA.' }),
      L('VirusTotal', 'https://www.virustotal.com/', { kind: 'reference', note: 'Link-out only. Do not upload confidential files.' }),
      L('urlscan.io', 'https://urlscan.io/', { kind: 'reference', note: 'Link-out only. Submissions may be public.' })
    ],
    climate: [
      L('USGS earthquake map', 'https://earthquake.usgs.gov/earthquakes/map/', { region: 'Global' }),
      L('NASA FIRMS fire map', 'https://firms.modaps.eosdis.nasa.gov/map/', { region: 'Global' }),
      L('Copernicus Emergency Management Service', 'https://emergency.copernicus.eu/', { region: 'Global' }),
      L('EM-DAT disaster database', 'https://www.emdat.be/', { region: 'Global' }),
      L('ND-GAIN country index', 'https://gain.nd.edu/our-work/country-index/', { region: 'Global' }),
      L('World Bank Climate Change Knowledge Portal', 'https://climateknowledgeportal.worldbank.org/', { region: 'Global' }),
      L('NOAA National Hurricane Center', 'https://www.nhc.noaa.gov/', { region: 'Atlantic / Eastern Pacific' }),
      L('WMO', 'https://wmo.int/', { region: 'Global', note: 'Gateway to national meteorological services.' }),
      L('ReliefWeb', 'https://reliefweb.int/', { search: 'https://reliefweb.int/updates?search={q}', region: 'Global' }),
      L('Swiss Re Institute catastrophe reports', 'https://www.swissre.com/institute/research/sigma-research.html', { region: 'Global', kind: 'market-report' })
    ],
    esg: [
      L('EPA ECHO', 'https://echo.epa.gov/', { region: 'United States' }),
      L('ILO NORMLEX (labour standards)', 'https://normlex.ilo.org/', { region: 'Global' }),
      L('OECD Due Diligence Guidance for Responsible Business Conduct', 'https://mneguidelines.oecd.org/duediligence/', { region: 'Global' }),
      L('UN Guiding Principles on Business and Human Rights', 'https://www.ohchr.org/en/publications/reference-publications/guiding-principles-business-and-human-rights', { region: 'Global' }),
      L('UK modern slavery statement registry', 'https://modern-slavery-statement-registry.service.gov.uk/', { region: 'United Kingdom' }),
      L('Australia modern slavery register', 'https://modernslaveryregister.gov.au/', { region: 'Australia' }),
      L('US DOL list of goods produced by child or forced labor', 'https://www.dol.gov/agencies/ilab/reports/child-labor/list-of-goods', { region: 'Global' }),
      L('CBP withhold release orders & findings', 'https://www.cbp.gov/trade/forced-labor/withhold-release-orders-and-findings', { region: 'United States' }),
      L('OECD minerals due diligence', 'https://mneguidelines.oecd.org/mining.htm', { region: 'Global' }),
      L('Responsible Minerals Initiative', 'https://www.responsiblemineralsinitiative.org/', { region: 'Global' }),
      L('TNFD (nature-related disclosures)', 'https://tnfd.global/', { region: 'Global' }),
      L('World Bank Worldwide Governance Indicators', 'https://www.worldbank.org/en/publication/worldwide-governance-indicators', { region: 'Global' }),
      L('Transparency International CPI', 'https://www.transparency.org/en/cpi', { region: 'Global' })
    ],
    regulatory: [
      L('Federal Register', 'https://www.federalregister.gov/', { search: 'https://www.federalregister.gov/documents/search?conditions%5Bterm%5D={q}', region: 'United States' }),
      L('Regulations.gov', 'https://www.regulations.gov/', { search: 'https://www.regulations.gov/search?filter={q}', region: 'United States' }),
      L('EUR-Lex', 'https://eur-lex.europa.eu/', { search: 'https://eur-lex.europa.eu/search.html?scope=EURLEX&text={q}&lang=en&type=quick', region: 'European Union', lang: 'multi' }),
      L('UK legislation.gov.uk', 'https://www.legislation.gov.uk/', { region: 'United Kingdom' }),
      L('EU sanctions (Council of the EU)', 'https://www.consilium.europa.eu/en/policies/sanctions-against-russia/', { region: 'European Union' }),
      L('US BIS export administration regulations', 'https://www.bis.gov/regulations', { region: 'United States' }),
      L('IOSCO', 'https://www.iosco.org/', { region: 'Global' }),
      L('Financial Stability Board', 'https://www.fsb.org/', { region: 'Global' })
    ],
    standards: [
      L('ISO 31000 — Risk management', 'https://www.iso.org/iso-31000-risk-management.html', { publisher: 'ISO' }),
      L('ISO 22301 — Business continuity', 'https://www.iso.org/standard/75106.html', { publisher: 'ISO' }),
      L('ISO/IEC 27001 — Information security', 'https://www.iso.org/standard/27001', { publisher: 'ISO/IEC' }),
      L('ISO/IEC 27031 — ICT readiness for business continuity', 'https://www.iso.org/search.html?q=27031', { publisher: 'ISO/IEC' }),
      L('ISO/IEC 27035 — Incident management', 'https://www.iso.org/search.html?q=27035', { publisher: 'ISO/IEC' }),
      L('AICPA SOC 2 resources', 'https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-2', { publisher: 'AICPA & CIMA' }),
      L('NIST Cybersecurity Framework', 'https://www.nist.gov/cyberframework', { publisher: 'NIST' }),
      L('NIST SSDF (SP 800-218)', 'https://csrc.nist.gov/projects/ssdf', { publisher: 'NIST' }),
      L('NIST AI RMF', 'https://www.nist.gov/itl/ai-risk-management-framework', { publisher: 'NIST' }),
      L('OECD Due Diligence Guidance', 'https://mneguidelines.oecd.org/duediligence/', { publisher: 'OECD' }),
      L('UN Guiding Principles on Business and Human Rights', 'https://www.ohchr.org/en/publications/reference-publications/guiding-principles-business-and-human-rights', { publisher: 'UN OHCHR' }),
      L('ILO conventions & recommendations', 'https://normlex.ilo.org/', { publisher: 'ILO' }),
      L('FIDIC contracts', 'https://fidic.org/', { publisher: 'FIDIC' }),
      L('NEC contracts', 'https://www.neccontract.com/', { publisher: 'NEC' }),
      L('World Bank Procurement Framework', 'https://www.worldbank.org/en/projects-operations/products-and-services/brief/procurement-new-framework', { publisher: 'World Bank' }),
      L('IAIS Insurance Core Principles', 'https://www.iaisweb.org/icp-online-tool/', { publisher: 'IAIS' }),
      L('Solvency II (EIOPA)', 'https://www.eiopa.europa.eu/browse/regulation-and-policy/solvency-ii_en', { publisher: 'EIOPA' }),
      L('WTO Government Procurement Agreement', 'https://www.wto.org/english/tratop_e/gproc_e/gp_gpa_e.htm', { publisher: 'WTO' }),
      L('UN Convention against Corruption', 'https://www.unodc.org/unodc/en/corruption/uncac.html', { publisher: 'UNODC' }),
      L('FATF Recommendations', 'https://www.fatf-gafi.org/en/topics/fatf-recommendations.html', { publisher: 'FATF' }),
      L('CMMC (US DoD)', 'https://dodcio.defense.gov/CMMC/', { publisher: 'US DoD CIO' }),
      L('ISO certificate check (IAF CertSearch)', 'https://www.iafcertsearch.org/', { publisher: 'IAF', note: 'Certification register; verify certificates there, not in JAQA.', kind: 'certification-register' })
    ],
    digitalAssets: [
      L('ESMA MiCA resources', 'https://www.esma.europa.eu/esmas-activities/digital-finance-and-innovation/markets-crypto-assets-regulation-mica', { region: 'European Union' }),
      L('SEC crypto assets', 'https://www.sec.gov/securities-topics/crypto-assets', { region: 'United States' }),
      L('OFAC recent actions', 'https://ofac.treasury.gov/recent-actions', { region: 'United States' }),
      L('FATF virtual assets', 'https://www.fatf-gafi.org/en/topics/virtual-assets.html', { region: 'Global' })
    ],
    logistics: [
      L('Port of Rotterdam', 'https://www.portofrotterdam.com/', { region: 'Netherlands' }),
      L('Maritime and Port Authority of Singapore', 'https://www.mpa.gov.sg/', { region: 'Singapore' }),
      L('UN/LOCODE', 'https://unece.org/trade/cefact/unlocode-code-list-country-and-territory', { region: 'Global' }),
      L('World Bank LPI', 'https://lpi.worldbank.org/', { region: 'Global' }),
      L('IMO GISIS (public ship data)', 'https://gisis.imo.org/', { region: 'Global', note: 'Registration required for some modules.' }),
      L('MarineTraffic (commercial AIS)', 'https://www.marinetraffic.com/', { region: 'Global', kind: 'paid' })
    ],
    paid: [
      ['Dun & Bradstreet', 'https://www.dnb.com/'], ['Experian Business', 'https://www.experian.com/business'], ['Creditsafe', 'https://www.creditsafe.com/'],
      ['EcoVadis', 'https://ecovadis.com/'], ['Interos', 'https://www.interos.ai/'], ['Resilinc', 'https://www.resilinc.com/'], ['Everstream', 'https://www.everstream.ai/'],
      ['Exiger', 'https://www.exiger.com/'], ['Sphera', 'https://sphera.com/'], ['Assent', 'https://www.assent.com/'], ['S&P Global Market Intelligence', 'https://www.spglobal.com/market-intelligence/'],
      ['Moody’s (incl. Orbis / Bureau van Dijk)', 'https://www.moodys.com/'], ['Fitch Solutions', 'https://www.fitchsolutions.com/'], ['AM Best', 'https://web.ambest.com/'], ['KBRA', 'https://www.kbra.com/'],
      ['Bloomberg Professional', 'https://www.bloomberg.com/professional/'], ['LSEG (Refinitiv, World-Check)', 'https://www.lseg.com/'], ['PitchBook', 'https://pitchbook.com/'], ['FactSet', 'https://www.factset.com/'],
      ['Dow Jones Risk & Compliance', 'https://www.dowjones.com/professional/risk/'], ['Accuity (LexisNexis Risk)', 'https://risk.lexisnexis.com/'], ['MarineTraffic', 'https://www.marinetraffic.com/'], ['Spire Maritime', 'https://spire.com/maritime/']
    ].map(([n, u]) => L(n, u, { kind: 'paid', note: 'Paid/commercial. Link-out only; never scraped or reproduced. No affiliation.' })),
    thirdPartyRepos: [
      L('OWASP Dependency-Track', 'https://github.com/DependencyTrack/dependency-track', { kind: 'third-party-repo', license: 'Apache-2.0', mode: 'reference', note: 'Software supply-chain platform reference; not a backend fork.' }),
      L('Trivy', 'https://github.com/aquasecurity/trivy', { kind: 'third-party-repo', license: 'Apache-2.0', mode: 'reference', note: 'Scanner/SBOM reference; not integrated.' }),
      L('Grype', 'https://github.com/anchore/grype', { kind: 'third-party-repo', license: 'Apache-2.0', mode: 'reference', note: 'Scanner reference; not integrated.' }),
      L('Syft', 'https://github.com/anchore/syft', { kind: 'third-party-repo', license: 'Apache-2.0', mode: 'reference', note: 'SBOM generator reference; not integrated.' }),
      L('MITRE CTI (ATT&CK STIX data)', 'https://github.com/mitre/cti', { kind: 'third-party-repo', license: 'See repository', mode: 'reference', note: 'Cyber taxonomy reference.' }),
      L('MITRE ATT&CK Navigator', 'https://github.com/mitre-attack/attack-navigator', { kind: 'third-party-repo', license: 'Apache-2.0', mode: 'link-out', note: 'Not embedded (would require audit for storage/CDN/telemetry).' }),
      L('CVEProject cvelistV5', 'https://github.com/CVEProject/cvelistV5', { kind: 'third-party-repo', license: 'See repository', mode: 'reference', note: 'Not bulk-fetched into the browser.' }),
      L('CycloneDX', 'https://github.com/CycloneDX', { kind: 'third-party-repo', license: 'Apache-2.0', mode: 'link-out', note: 'SBOM standard.' }),
      L('OpenSSF Scorecard', 'https://github.com/ossf/scorecard', { kind: 'third-party-repo', license: 'Apache-2.0', mode: 'link-out', note: 'Repository hygiene; not supplier approval.' }),
      L('OpenSanctions', 'https://github.com/opensanctions/opensanctions', { kind: 'third-party-repo', license: 'See repository (data licence differs)', mode: 'link-out', note: 'No auto-screening; no clearance language.' })
    ]
  };

  /** Build a link-out URL. The query is included only when a template exists and official-link-only mode is off. */
  R.linkout = function linkout(entry, q) {
    if (!entry) return null;
    const officialOnly = R.state.prefs.officialLinkOnly;
    if (q && entry.search && !officialOnly) return { href: entry.search.replace('{q}', encodeURIComponent(q)), withQuery: true };
    return { href: entry.url, withQuery: false };
  };
  R.linkoutFromTemplate = function (tpl, value, fallback) {
    if (!tpl) return fallback || null;
    if (/\{q\}/.test(tpl) && R.state.prefs.officialLinkOnly) return fallback || tpl.replace(/[?#].*$/, '');
    return tpl.replace('{q}', encodeURIComponent(value)).replace('{id}', encodeURIComponent(value));
  };

  /* ------------------------------------------------------------------ *
   * Country reference data: ISO2|ISO3|name (ISO 3166-1). Used for local
   * detection only; all country facts are fetched live or linked out.
   * ------------------------------------------------------------------ */
  const COUNTRY_DATA =
    'AF|AFG|Afghanistan;AL|ALB|Albania;DZ|DZA|Algeria;AD|AND|Andorra;AO|AGO|Angola;AG|ATG|Antigua and Barbuda;AR|ARG|Argentina;AM|ARM|Armenia;AU|AUS|Australia;AT|AUT|Austria;AZ|AZE|Azerbaijan;BS|BHS|Bahamas;BH|BHR|Bahrain;BD|BGD|Bangladesh;BB|BRB|Barbados;BY|BLR|Belarus;BE|BEL|Belgium;BZ|BLZ|Belize;BJ|BEN|Benin;BM|BMU|Bermuda;BT|BTN|Bhutan;BO|BOL|Bolivia;BA|BIH|Bosnia and Herzegovina;BW|BWA|Botswana;BR|BRA|Brazil;BN|BRN|Brunei Darussalam;BG|BGR|Bulgaria;BF|BFA|Burkina Faso;BI|BDI|Burundi;CV|CPV|Cabo Verde;KH|KHM|Cambodia;CM|CMR|Cameroon;CA|CAN|Canada;KY|CYM|Cayman Islands;CF|CAF|Central African Republic;TD|TCD|Chad;CL|CHL|Chile;CN|CHN|China;CO|COL|Colombia;KM|COM|Comoros;CD|COD|Congo, Democratic Republic;CG|COG|Congo, Republic;CR|CRI|Costa Rica;CI|CIV|Cote d’Ivoire;HR|HRV|Croatia;CU|CUB|Cuba;CY|CYP|Cyprus;CZ|CZE|Czechia;DK|DNK|Denmark;DJ|DJI|Djibouti;DM|DMA|Dominica;DO|DOM|Dominican Republic;EC|ECU|Ecuador;EG|EGY|Egypt;SV|SLV|El Salvador;GQ|GNQ|Equatorial Guinea;ER|ERI|Eritrea;EE|EST|Estonia;SZ|SWZ|Eswatini;ET|ETH|Ethiopia;FJ|FJI|Fiji;FI|FIN|Finland;FR|FRA|France;GA|GAB|Gabon;GM|GMB|Gambia;GE|GEO|Georgia;DE|DEU|Germany;GH|GHA|Ghana;GR|GRC|Greece;GD|GRD|Grenada;GT|GTM|Guatemala;GG|GGY|Guernsey;GN|GIN|Guinea;GW|GNB|Guinea-Bissau;GY|GUY|Guyana;HT|HTI|Haiti;HN|HND|Honduras;HK|HKG|Hong Kong SAR, China;HU|HUN|Hungary;IS|ISL|Iceland;IN|IND|India;ID|IDN|Indonesia;IR|IRN|Iran;IQ|IRQ|Iraq;IE|IRL|Ireland;IM|IMN|Isle of Man;IL|ISR|Israel;IT|ITA|Italy;JM|JAM|Jamaica;JP|JPN|Japan;JE|JEY|Jersey;JO|JOR|Jordan;KZ|KAZ|Kazakhstan;KE|KEN|Kenya;KI|KIR|Kiribati;KP|PRK|Korea, North;KR|KOR|Korea, South;XK|XKX|Kosovo;KW|KWT|Kuwait;KG|KGZ|Kyrgyz Republic;LA|LAO|Lao PDR;LV|LVA|Latvia;LB|LBN|Lebanon;LS|LSO|Lesotho;LR|LBR|Liberia;LY|LBY|Libya;LI|LIE|Liechtenstein;LT|LTU|Lithuania;LU|LUX|Luxembourg;MO|MAC|Macao SAR, China;MG|MDG|Madagascar;MW|MWI|Malawi;MY|MYS|Malaysia;MV|MDV|Maldives;ML|MLI|Mali;MT|MLT|Malta;MH|MHL|Marshall Islands;MR|MRT|Mauritania;MU|MUS|Mauritius;MX|MEX|Mexico;FM|FSM|Micronesia;MD|MDA|Moldova;MC|MCO|Monaco;MN|MNG|Mongolia;ME|MNE|Montenegro;MA|MAR|Morocco;MZ|MOZ|Mozambique;MM|MMR|Myanmar;NA|NAM|Namibia;NR|NRU|Nauru;NP|NPL|Nepal;NL|NLD|Netherlands;NZ|NZL|New Zealand;NI|NIC|Nicaragua;NE|NER|Niger;NG|NGA|Nigeria;MK|MKD|North Macedonia;NO|NOR|Norway;OM|OMN|Oman;PK|PAK|Pakistan;PW|PLW|Palau;PS|PSE|West Bank and Gaza;PA|PAN|Panama;PG|PNG|Papua New Guinea;PY|PRY|Paraguay;PE|PER|Peru;PH|PHL|Philippines;PL|POL|Poland;PT|PRT|Portugal;PR|PRI|Puerto Rico;QA|QAT|Qatar;RO|ROU|Romania;RU|RUS|Russian Federation;RW|RWA|Rwanda;WS|WSM|Samoa;SM|SMR|San Marino;ST|STP|Sao Tome and Principe;SA|SAU|Saudi Arabia;SN|SEN|Senegal;RS|SRB|Serbia;SC|SYC|Seychelles;SL|SLE|Sierra Leone;SG|SGP|Singapore;SK|SVK|Slovak Republic;SI|SVN|Slovenia;SB|SLB|Solomon Islands;SO|SOM|Somalia;ZA|ZAF|South Africa;SS|SSD|South Sudan;ES|ESP|Spain;LK|LKA|Sri Lanka;KN|KNA|St. Kitts and Nevis;LC|LCA|St. Lucia;VC|VCT|St. Vincent and the Grenadines;SD|SDN|Sudan;SR|SUR|Suriname;SE|SWE|Sweden;CH|CHE|Switzerland;SY|SYR|Syrian Arab Republic;TW|TWN|Taiwan, China;TJ|TJK|Tajikistan;TZ|TZA|Tanzania;TH|THA|Thailand;TL|TLS|Timor-Leste;TG|TGO|Togo;TO|TON|Tonga;TT|TTO|Trinidad and Tobago;TN|TUN|Tunisia;TR|TUR|Turkiye;TM|TKM|Turkmenistan;TV|TUV|Tuvalu;UG|UGA|Uganda;UA|UKR|Ukraine;AE|ARE|United Arab Emirates;GB|GBR|United Kingdom;US|USA|United States;UY|URY|Uruguay;UZ|UZB|Uzbekistan;VU|VUT|Vanuatu;VE|VEN|Venezuela;VN|VNM|Viet Nam;YE|YEM|Yemen;ZM|ZMB|Zambia;ZW|ZWE|Zimbabwe';
  const COUNTRIES = COUNTRY_DATA.split(';').map((r) => {
    const [iso2, iso3, name] = r.split('|');
    return { iso2, iso3, name };
  });
  const ALIASES = {
    usa: 'US', 'united states of america': 'US', america: 'US', 'u.s.': 'US', 'u.s.a.': 'US', uk: 'GB', britain: 'GB', 'great britain': 'GB', england: 'GB',
    russia: 'RU', 'south korea': 'KR', korea: 'KR', 'north korea': 'KP', vietnam: 'VN', turkey: 'TR', 'hong kong': 'HK', macau: 'MO', macao: 'MO', taiwan: 'TW',
    iran: 'IR', syria: 'SY', laos: 'LA', 'ivory coast': 'CI', "cote d'ivoire": 'CI', 'czech republic': 'CZ', slovakia: 'SK', drc: 'CD', 'democratic republic of the congo': 'CD',
    uae: 'AE', emirates: 'AE', holland: 'NL', 'the netherlands': 'NL', burma: 'MM', swaziland: 'SZ', 'cape verde': 'CV', brunei: 'BN', kyrgyzstan: 'KG', palestine: 'PS', 'east timor': 'TL'
  };
  // Currencies published by the ECB reference-rate series (EXR). Euro-area members map to EUR.
  const EURO = ['AT', 'BE', 'HR', 'CY', 'EE', 'FI', 'FR', 'DE', 'GR', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PT', 'SK', 'SI', 'ES', 'BG'];
  const ECB_CCY = { US: 'USD', JP: 'JPY', CZ: 'CZK', DK: 'DKK', GB: 'GBP', HU: 'HUF', PL: 'PLN', RO: 'RON', SE: 'SEK', CH: 'CHF', IS: 'ISK', NO: 'NOK', TR: 'TRY', AU: 'AUD', BR: 'BRL', CA: 'CAD', CN: 'CNY', HK: 'HKD', ID: 'IDR', IL: 'ILS', IN: 'INR', KR: 'KRW', MX: 'MXN', MY: 'MYR', NZ: 'NZD', PH: 'PHP', SG: 'SGD', TH: 'THB', ZA: 'ZAR' };

  R.geo = {
    countries: COUNTRIES,
    EU_MEMBERS: ['AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE'],
    findCountry(q) {
      if (!q) return null;
      const t = q.trim();
      const lower = t.toLowerCase().replace(/^the\s+/, '');
      if (ALIASES[lower]) return COUNTRIES.find((c) => c.iso2 === ALIASES[lower]) || null;
      const up = t.toUpperCase();
      return (
        COUNTRIES.find((c) => c.name.toLowerCase() === lower) ||
        (t.length === 2 && t === up ? COUNTRIES.find((c) => c.iso2 === up) : null) ||
        (t.length === 3 && t === up ? COUNTRIES.find((c) => c.iso3 === up) : null) ||
        null
      );
    },
    byIso2: (iso2) => COUNTRIES.find((c) => c.iso2 === String(iso2 || '').toUpperCase()) || null,
    currencyFor(iso2) {
      if (EURO.includes(iso2)) return 'EUR';
      return ECB_CCY[iso2] || null;
    },
    ECB_CCY: Object.values(ECB_CCY)
  };
})(window.JAQAWorkspace);

/* ---- modules/net.js ---- */
/*
 * net.js — request manager, runtime source status and task store.
 *
 * - Every request: cache "no-store", credentials "omit", referrerPolicy
 *   "no-referrer", mode "cors". No cookies are ever sent or received.
 * - Global concurrency cap (6) + per-source caps from the registry.
 * - In-session de-duplication of identical requests (memory only; cleared
 *   by Clear Session / refresh).
 * - AbortController per request, chained to the session controller so a new
 *   search cancels stale requests.
 * - Partial failure handling: callers use Promise.allSettled and each
 *   failure is classified (cors_or_network, timeout, rate_limited, http_4xx,
 *   http_5xx, bad_json, bad_shape, offline, linkout, aborted).
 * - A CORS/network failure during normal use marks that source unavailable
 *   for the current session and the UI falls back to official link-outs.
 * - Search terms, URLs containing them and response bodies are never logged.
 */
(function (R) {
  'use strict';

  /* ------------------------- runtime status ------------------------- */
  const status = new Map();
  function st(id) {
    if (!status.has(id)) status.set(id, { mode: null, reason: '', ok: 0, fail: 0, rateLimited: 0, skipped: 0, lastStatus: null, lastFetch: null, rateLimitedUntil: 0, sessionVerified: false, lastErrorKind: null });
    return status.get(id);
  }
  R.runtime = {
    get: st,
    all: () => status,
    reset() {
      status.clear();
      R.events.emit('net:update');
    },
    /** Effective mode for this session: runtime override, else registry default. */
    mode(id) {
      const s = R.sources.get(id);
      if (!s) return 'unavailable';
      const r = st(id);
      if (R.state.prefs.hiddenSources.has(id)) return 'hidden';
      if (r.mode) return r.mode;
      return s.defaultMode;
    },
    isLive(id) {
      return this.mode(id) === 'live';
    },
    markUnavailable(id, reason) {
      const r = st(id);
      r.mode = 'unavailable';
      r.reason = reason;
      R.events.emit('net:update');
    },
    markLive(id) {
      const r = st(id);
      r.mode = 'live';
      r.reason = '';
      r.sessionVerified = true;
      R.events.emit('net:update');
    },
    totals() {
      let ok = 0, fail = 0, rl = 0, last = null;
      for (const r of status.values()) {
        ok += r.ok;
        fail += r.fail;
        rl += r.rateLimited;
        if (r.lastFetch && (!last || r.lastFetch > last)) last = r.lastFetch;
      }
      return { ok, fail, rateLimited: rl, last };
    }
  };

  /* --------------------------- request queue ------------------------- */
  const GLOBAL_MAX = 6;
  let active = 0;
  const perSource = new Map();
  const queue = [];
  const cache = new Map(); // key -> resolved result (success only)
  const inflight = new Map(); // key -> promise

  function pump() {
    for (let i = 0; i < queue.length && active < GLOBAL_MAX; ) {
      const job = queue[i];
      const src = R.sources.get(job.sourceId);
      const cur = perSource.get(job.sourceId) || 0;
      if (cur >= (src ? src.concurrencyLimit : 1)) {
        i++;
        continue;
      }
      queue.splice(i, 1);
      active++;
      perSource.set(job.sourceId, cur + 1);
      job.start().finally(() => {
        active--;
        perSource.set(job.sourceId, (perSource.get(job.sourceId) || 1) - 1);
        pump();
      });
    }
  }

  function sessionSignal() {
    const s = R.state.session;
    return s && s.controller ? s.controller.signal : null;
  }

  /**
   * request(sourceId, url, opts) -> Promise<{ok, data, status, errorKind, retryAt}>
   * opts: { method, body (object), headers, validate(json) -> bool, allow404, probe, dedupe }
   */
  function request(sourceId, url, opts) {
    const o = opts || {};
    const src = R.sources.get(sourceId);
    const rs = st(sourceId);
    if (!src) return Promise.resolve({ ok: false, errorKind: 'unknown_source' });
    if (!o.probe && !R.runtime.isLive(sourceId)) {
      rs.skipped++;
      R.events.emit('net:update');
      return Promise.resolve({ ok: false, errorKind: 'linkout' });
    }
    if (rs.rateLimitedUntil > Date.now()) {
      rs.skipped++;
      R.events.emit('net:update');
      return Promise.resolve({ ok: false, errorKind: 'rate_limited', retryAt: rs.rateLimitedUntil });
    }
    const method = o.method || 'GET';
    const bodyStr = o.body ? JSON.stringify(o.body) : undefined;
    const key = method + ' ' + url + ' ' + (bodyStr || '');
    if (!o.probe && cache.has(key)) return Promise.resolve(cache.get(key));
    if (!o.probe && inflight.has(key)) return inflight.get(key);

    const genNow = () => (o.persistent ? R.state.feedGen : R.state.generation);
    const generation = genNow();
    const p = new Promise((resolve) => {
      queue.push({
        sourceId,
        start: () => run(src, url, method, bodyStr, o, generation).then((res) => {
          if (res.ok && !o.probe && generation === genNow()) cache.set(key, res);
          resolve(res);
        })
      });
      pump();
    });
    if (!o.probe) {
      inflight.set(key, p);
      p.finally(() => inflight.delete(key));
    }
    return p;
  }

  async function run(src, url, method, bodyStr, o, generation) {
    const rs = st(src.id);
    const ctrl = new AbortController();
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      ctrl.abort();
    }, src.timeoutMs || 12000);
    // Persistent feed requests are not cancelled by a new search (they carry no search term).
    const outer = o.probe || o.persistent ? null : sessionSignal();
    const onOuter = () => ctrl.abort();
    if (outer) {
      if (outer.aborted) ctrl.abort();
      else outer.addEventListener('abort', onOuter, { once: true });
    }
    const headers = Object.assign({ Accept: 'application/json' }, o.headers || {});
    if (bodyStr) headers['Content-Type'] = 'application/json';
    const finish = (res) => {
      clearTimeout(timer);
      if (outer) outer.removeEventListener('abort', onOuter);
      if (!o.probe && generation !== (o.persistent ? R.state.feedGen : R.state.generation)) return { ok: false, errorKind: 'aborted' };
      rs.lastFetch = new Date();
      if (res.ok) rs.ok++;
      else if (res.errorKind !== 'aborted') rs.fail++;
      rs.lastStatus = res.status || res.errorKind;
      rs.lastErrorKind = res.ok ? null : res.errorKind;
      R.events.emit('net:update');
      return res;
    };
    let resp;
    try {
      resp = await fetch(url, {
        method,
        headers,
        body: bodyStr,
        mode: 'cors',
        cache: 'no-store',
        credentials: 'omit',
        referrerPolicy: 'no-referrer',
        redirect: 'follow',
        signal: ctrl.signal
      });
    } catch (e) {
      if (timedOut) return finish({ ok: false, errorKind: 'timeout' });
      if (ctrl.signal.aborted) return finish({ ok: false, errorKind: 'aborted' });
      if (typeof navigator !== 'undefined' && navigator.onLine === false) return finish({ ok: false, errorKind: 'offline' });
      // Browsers report CORS blocks and network failures identically (TypeError).
      if (!o.probe) R.runtime.markUnavailable(src.id, 'Live request blocked or failed from this browser (CORS/network).');
      return finish({ ok: false, errorKind: 'cors_or_network' });
    }
    const code = resp.status;
    if (code === 429) {
      const ra = Number(resp.headers.get('Retry-After'));
      rs.rateLimited++;
      rs.rateLimitedUntil = Date.now() + (isFinite(ra) && ra > 0 ? ra * 1000 : 30000);
      return finish({ ok: false, status: code, errorKind: 'rate_limited', retryAt: rs.rateLimitedUntil });
    }
    if (code === 404 && o.allow404) return finish({ ok: true, status: code, data: null });
    if (code >= 500) return finish({ ok: false, status: code, errorKind: 'http_5xx' });
    if (code >= 400) return finish({ ok: false, status: code, errorKind: code === 404 ? 'not_found' : 'http_4xx' });
    let text;
    try {
      text = await resp.text();
    } catch (e) {
      return finish({ ok: false, status: code, errorKind: timedOut ? 'timeout' : 'aborted' });
    }
    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      return finish({ ok: false, status: code, errorKind: 'bad_json' });
    }
    if (o.validate) {
      let valid = false;
      try {
        valid = !!o.validate(data);
      } catch (e) {
        valid = false;
      }
      if (!valid) return finish({ ok: false, status: code, errorKind: 'bad_shape' });
    }
    return finish({ ok: true, status: code, data });
  }

  const ERROR_TEXT = {
    linkout: 'Live request unavailable from this browser. Open the source directly.',
    cors_or_network: 'This source may not support live browser access. Use the official link.',
    timeout: 'This source is temporarily unavailable. You can open the official source instead.',
    rate_limited: 'Request limit reached. Please wait a moment and retry.',
    http_5xx: 'This source is temporarily unavailable. You can open the official source instead.',
    http_4xx: 'Unavailable in the current public API response.',
    not_found: 'This query returned no public records from the selected sources.',
    bad_json: 'This source returned an unexpected response. Open the official source instead.',
    bad_shape: 'This source returned an unexpected response. Open the official source instead.',
    offline: 'You appear to be offline. Reconnect and retry.',
    aborted: 'Request cancelled.',
    unknown_source: 'Unavailable in the current public API response.'
  };

  R.net = {
    request,
    errorText: (k) => ERROR_TEXT[k] || ERROR_TEXT.http_5xx,
    resetCache() {
      cache.clear();
      inflight.clear();
      queue.length = 0;
    },
    stats: () => ({ active, queued: queue.length })
  };

  /* ------------------------------------------------------------------ *
   * Task store. A task is one logical lookup (e.g. "GLEIF search for X")
   * producing normalized records. Tasks are keyed and de-duplicated per
   * session so modules can share results; nothing survives Clear Session.
   * ------------------------------------------------------------------ */
  const isFeed = (key) => String(key).startsWith('feed:');
  function store(key) {
    if (isFeed(key)) return R.state.feedTasks;
    return R.state.session ? R.state.session.tasks : null;
  }
  const genOf = (key) => (isFeed(key) ? R.state.feedGen : R.state.generation);

  R.tasks = {
    isFeed,
    /** def: { key, sourceId, label, run: async () => records[] } */
    ensure(def) {
      const st = store(def.key);
      if (!st) return null;
      let t = st.get(def.key);
      if (t && t.status !== 'error') return t;
      t = { key: def.key, sourceId: def.sourceId, label: def.label, status: 'idle', records: [], errorKind: null, def };
      st.set(def.key, t);
      return t;
    },
    get(key) {
      const st = store(key);
      return st ? st.get(key) : null;
    },
    async start(key) {
      const st = store(key);
      if (!st) return null;
      const t = st.get(key);
      if (!t || t.status === 'loading' || t.status === 'done' || t.status === 'empty') return t;
      if (!R.runtime.isLive(t.sourceId)) {
        t.status = 'linkout';
        R.events.emit('task:update', t);
        return t;
      }
      const gen = genOf(key);
      t.status = 'loading';
      t.errorKind = null;
      R.events.emit('task:update', t);
      try {
        const out = await t.def.run();
        if (gen !== genOf(key)) return t;
        if (out && out.error) {
          t.status = out.error === 'linkout' ? 'linkout' : 'error';
          t.errorKind = out.error;
          t.retryAt = out.retryAt;
        } else {
          t.records = (out && out.records) || [];
          t.meta = (out && out.meta) || null;
          t.status = t.records.length ? 'done' : 'empty';
          t.retrievedAt = new Date();
        }
      } catch (e) {
        if (gen !== genOf(key)) return t;
        t.status = 'error';
        t.errorKind = 'bad_shape';
        console.error('[JAQA] task failed:', t.sourceId); // no query / payload in logs
      }
      R.events.emit('task:update', t);
      return t;
    },
    /** Run several tasks with Promise.allSettled so one failure never blocks the rest. */
    runAll(keys) {
      return Promise.allSettled(keys.map((k) => this.start(k)));
    },
    retryFailed() {
      const s = R.state.session;
      if (!s) return;
      const keys = [];
      for (const t of s.tasks.values()) {
        if (t.status === 'error') {
          if (t.errorKind === 'cors_or_network') continue; // source unavailable this session
          t.status = 'idle';
          keys.push(t.key);
        }
      }
      return this.runAll(keys);
    },
    /** Session tasks only (feeds are listed separately via feeds()). */
    all() {
      const s = R.state.session;
      return s ? [...s.tasks.values()] : [];
    },
    feeds() {
      return [...R.state.feedTasks.values()];
    },
    records() {
      return this.all().flatMap((t) => t.records || []);
    }
  };
})(window.JAQAWorkspace);

/* ---- modules/clients.js ---- */
/*
 * clients.js — API clients for verified public sources.
 *
 * Every client returns { records, meta } or { error }. Records are normalized:
 *   { uid, kind, title, subtitle, fields: [[label, value]], badges, ids,
 *     links: [{label, href}], prov: { sourceId, sourceName, endpoint,
 *     retrievedAt, recordId, url, category, confidence }, data }
 *
 * Provenance is attached here, at the point of normalization, so every
 * rendered fact can be traced back to its source record. Missing fields are
 * rendered as "Not reported by source" — never guessed.
 *
 * Endpoints and response shapes used here were validated by
 * scripts/verify-cors.mjs (see config/cors-verification.json).
 */
(function (R) {
  'use strict';
  const { fmt } = R.util;
  const enc = encodeURIComponent;
  const isArr = Array.isArray;
  const obj = (v) => v && typeof v === 'object';

  let n = 0;
  function rec(sourceId, kind, p) {
    const src = R.sources.get(sourceId);
    return {
      uid: 'r' + ++n,
      kind,
      title: p.title || 'Untitled record',
      subtitle: p.subtitle || '',
      fields: (p.fields || []).filter((f) => f && f[1] !== undefined),
      badges: p.badges || [],
      ids: p.ids || {},
      links: p.links || [],
      summary: p.summary || '',
      data: p.data || {},
      flags: p.flags || {},
      prov: {
        sourceId,
        sourceName: src ? src.displayName : sourceId,
        endpoint: p.endpoint || '',
        retrievedAt: new Date(),
        recordId: p.recordId || '',
        url: p.url || (src && src.officialSiteUrl) || '',
        category: p.category || 'public-record',
        confidence: p.confidence || null,
        attribution: src ? src.attribution : ''
      }
    };
  }
  R.rec = rec;

  async function call(sourceId, url, opts) {
    const res = await R.net.request(sourceId, url, opts);
    if (!res.ok) return { error: res.errorKind, retryAt: res.retryAt };
    return { data: res.data };
  }

  /* ------------------------- name matching ------------------------- */
  const SUFFIX = /\b(incorporated|inc|corporation|corp|company|co|limited|ltd|plc|llc|llp|lp|ag|se|sa|s\.a|nv|bv|gmbh|kgaa|kg|spa|s\.p\.a|srl|sarl|oyj|ab|asa|as|pte|bhd|berhad|kk|pty|holdings?|group|the)\b/g;
  function normName(s) {
    return String(s || '')
      .toLowerCase()
      .normalize('NFKD')
      .replace(/[̀-ͯ]/g, '')
      .replace(/&/g, ' and ')
      .replace(/[.,'’()\-/]/g, ' ')
      .replace(SUFFIX, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }
  function matchConfidence(query, name) {
    const a = normName(query);
    const b = normName(name);
    if (!a || !b) return 'Unresolved';
    if (a === b) return 'Exact';
    if (b.startsWith(a + ' ') || a.startsWith(b + ' ')) return 'Likely';
    const ta = new Set(a.split(' '));
    const tb = b.split(' ');
    const overlap = tb.filter((t) => ta.has(t)).length;
    if (overlap && overlap >= Math.min(ta.size, tb.length)) return 'Likely';
    return 'Possible';
  }
  R.match = { normName, matchConfidence };

  function haversineKm(lat1, lon1, lat2, lon2) {
    const toR = (d) => (d * Math.PI) / 180;
    const dLat = toR(lat2 - lat1);
    const dLon = toR(lon2 - lon1);
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(toR(lat1)) * Math.cos(toR(lat2)) * Math.sin(dLon / 2) ** 2;
    return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }
  R.util.haversineKm = haversineKm;

  const C = (R.clients = {});

  /* ------------------------------ GLEIF ------------------------------ */
  const GL = 'https://api.gleif.org/api/v1';
  function gleifRecord(d, query) {
    const a = (d && d.attributes) || {};
    const e = a.entity || {};
    const reg = a.registration || {};
    const addr = (x) => (x ? [...(x.addressLines || []), x.city, x.region, x.postalCode, x.country].filter(Boolean).join(', ') : null);
    const name = (e.legalName && e.legalName.name) || a.lei;
    const other = (e.otherNames || []).map((o) => o.name).filter(Boolean);
    const conf = query ? matchConfidence(query, name) : 'Exact';
    const badges = [{ text: 'Legal entity (LEI)', tone: 'org' }];
    if (e.status && e.status !== 'ACTIVE') badges.push({ text: 'Entity status: ' + e.status, tone: 'warn' });
    if (reg.status && reg.status !== 'ISSUED') badges.push({ text: 'LEI registration: ' + reg.status, tone: 'warn' });
    return rec('gleif', 'legal-entity', {
      title: name,
      subtitle: [e.jurisdiction, e.legalAddress && e.legalAddress.city].filter(Boolean).join(' · '),
      recordId: a.lei,
      url: 'https://search.gleif.org/#/record/' + a.lei,
      endpoint: 'lei-records',
      category: 'public-record',
      confidence: conf,
      ids: { lei: a.lei, country: e.jurisdiction ? String(e.jurisdiction).slice(0, 2) : (e.legalAddress && e.legalAddress.country) || null },
      badges,
      fields: [
        ['LEI', a.lei],
        ['Legal name', name],
        ['Other names', other.length ? other.join('; ') : null],
        ['Jurisdiction', e.jurisdiction],
        ['Legal form (ELF code)', e.legalForm && e.legalForm.id],
        ['Entity category', e.category],
        ['Entity status', e.status],
        ['Legal address', addr(e.legalAddress)],
        ['Headquarters address', addr(e.headquartersAddress)],
        ['Registered as', e.registeredAs],
        ['Registration authority ID', e.registeredAt && e.registeredAt.id],
        ['LEI registration status', reg.status],
        ['Initial registration', reg.initialRegistrationDate ? fmt.date(reg.initialRegistrationDate) : null],
        ['Last update', reg.lastUpdateDate ? fmt.date(reg.lastUpdateDate) : null],
        ['Next renewal', reg.nextRenewalDate ? fmt.date(reg.nextRenewalDate) : null],
        ['Corroboration level', reg.corroborationLevel],
        ['BIC (as reported)', isArr(a.bic) && a.bic.length ? a.bic.join(', ') : null]
      ],
      data: { name, lei: a.lei, jurisdiction: e.jurisdiction, country: (e.legalAddress && e.legalAddress.country) || null, status: e.status, otherNames: other }
    });
  }
  C.gleif = {
    async search(q, size) {
      const r = await call('gleif', `${GL}/lei-records?filter%5Bfulltext%5D=${enc(q)}&page%5Bsize%5D=${size || 10}`, { validate: (j) => isArr(j.data) });
      if (r.error) return r;
      const records = r.data.data.map((d) => gleifRecord(d, q));
      const order = { Exact: 0, Likely: 1, Possible: 2, Unresolved: 3 };
      records.sort((x, y) => order[x.prov.confidence] - order[y.prov.confidence]);
      const total = r.data.meta && r.data.meta.pagination ? r.data.meta.pagination.total : records.length;
      return { records, meta: { total } };
    },
    async byLei(lei) {
      const r = await call('gleif', `${GL}/lei-records/${enc(lei)}`, { allow404: true, validate: (j) => j === null || obj(j.data) });
      if (r.error) return r;
      return { records: r.data ? [gleifRecord(r.data.data)] : [] };
    },
    async parent(lei, which) {
      const path = which === 'ultimate' ? 'ultimate-parent' : 'direct-parent';
      const r = await call('gleif', `${GL}/lei-records/${enc(lei)}/${path}`, { allow404: true, validate: (j) => j === null || obj(j.data) });
      if (r.error) return r;
      if (!r.data) return { records: [], meta: { note: 'No ' + (which === 'ultimate' ? 'ultimate' : 'direct') + ' parent reported to GLEIF (the entity may be top-level, or may have filed a reporting exception).' } };
      const x = gleifRecord(r.data.data);
      x.prov.endpoint = path;
      x.prov.category = 'public-record';
      x.badges.push({ text: which === 'ultimate' ? 'Ultimate parent (GLEIF Level 2)' : 'Direct parent (GLEIF Level 2)', tone: 'org' });
      return { records: [x] };
    },
    async children(lei, size) {
      const r = await call('gleif', `${GL}/lei-records/${enc(lei)}/direct-children?page%5Bsize%5D=${size || 20}`, { allow404: true, validate: (j) => j === null || isArr(j.data) });
      if (r.error) return r;
      if (!r.data) return { records: [], meta: { total: 0 } };
      return { records: r.data.data.map((d) => gleifRecord(d)), meta: { total: r.data.meta && r.data.meta.pagination ? r.data.meta.pagination.total : r.data.data.length } };
    }
  };

  /* ---------------------------- World Bank ---------------------------- */
  const WB = 'https://api.worldbank.org/v2';
  C.worldbank = {
    INDICATORS: {
      lpi: ['LP.LPI.OVRL.XQ', 'Logistics Performance Index: overall (1=low to 5=high)'],
      gdpGrowth: ['NY.GDP.MKTP.KD.ZG', 'GDP growth (annual %)'],
      inflation: ['FP.CPI.TOTL.ZG', 'Inflation, consumer prices (annual %)'],
      fx: ['PA.NUS.FCRF', 'Official exchange rate (LCU per US$, period average)'],
      lending: ['FR.INR.LEND', 'Lending interest rate (%)'],
      realRate: ['FR.INR.RINR', 'Real interest rate (%)'],
      govDebt: ['GC.DOD.TOTL.GD.ZS', 'Central government debt, total (% of GDP)'],
      currentAccount: ['BN.CAB.XOKA.GD.ZS', 'Current account balance (% of GDP)'],
      reserves: ['FI.RES.TOTL.MO', 'Total reserves in months of imports'],
      extDebt: ['DT.DOD.DECT.GN.ZS', 'External debt stocks (% of GNI)'],
      npl: ['FB.AST.NPER.ZS', 'Bank nonperforming loans to total gross loans (%)'],
      bankCapital: ['FB.BNK.CAPA.ZS', 'Bank capital to assets ratio (%)'],
      privCredit: ['FS.AST.PRVT.GD.ZS', 'Domestic credit to private sector (% of GDP)'],
      trade: ['NE.TRD.GNFS.ZS', 'Trade (% of GDP)'],
      hightech: ['TX.VAL.TECH.MF.ZS', 'High-technology exports (% of manufactured exports)'],
      wgiCC: ['GOV_WGI_CC.EST', 'Control of Corruption: estimate (approx. -2.5 to +2.5)'],
      wgiGE: ['GOV_WGI_GE.EST', 'Government Effectiveness: estimate'],
      wgiPV: ['GOV_WGI_PV.EST', 'Political Stability and Absence of Violence/Terrorism: estimate'],
      wgiRQ: ['GOV_WGI_RQ.EST', 'Regulatory Quality: estimate'],
      wgiRL: ['GOV_WGI_RL.EST', 'Rule of Law: estimate'],
      wgiVA: ['GOV_WGI_VA.EST', 'Voice and Accountability: estimate']
    },
    async country(iso) {
      const r = await call('worldbank', `${WB}/country/${enc(iso)}?format=json`, { validate: (j) => isArr(j) });
      if (r.error) return r;
      const c = isArr(r.data[1]) ? r.data[1][0] : null;
      if (!c) return { records: [] };
      return {
        records: [
          rec('worldbank', 'country', {
            title: c.name,
            subtitle: [c.region && c.region.value, c.incomeLevel && c.incomeLevel.value].filter(Boolean).join(' · '),
            recordId: c.id,
            url: 'https://data.worldbank.org/country/' + c.iso2Code,
            endpoint: 'country',
            category: 'public-record',
            confidence: 'Exact',
            ids: { iso2: c.iso2Code, iso3: c.id },
            badges: [{ text: 'Country / sovereign', tone: 'risk' }],
            fields: [
              ['ISO codes', c.iso2Code + ' / ' + c.id],
              ['Region', c.region && c.region.value],
              ['Income level', c.incomeLevel && c.incomeLevel.value],
              ['Lending type', c.lendingType && c.lendingType.value],
              ['Capital city', c.capitalCity || null],
              ['Capital coordinates', c.latitude && c.longitude ? `${Number(c.latitude).toFixed(3)}, ${Number(c.longitude).toFixed(3)}` : null]
            ],
            data: { iso2: c.iso2Code, iso3: c.id, name: c.name, lat: Number(c.latitude) || null, lon: Number(c.longitude) || null, capital: c.capitalCity }
          })
        ]
      };
    },
    async indicator(iso, key) {
      const [code, label] = this.INDICATORS[key] || [key, key];
      const r = await call('worldbank', `${WB}/country/${enc(iso)}/indicator/${enc(code)}?format=json&mrv=6`, { validate: (j) => isArr(j) });
      if (r.error) return r;
      const rows = isArr(r.data[1]) ? r.data[1].filter((x) => x.value !== null) : [];
      if (!rows.length) return { records: [] };
      const latest = rows[0];
      const series = rows.map((x) => [x.date, x.value]).reverse();
      return {
        records: [
          rec('worldbank', 'indicator', {
            title: label,
            subtitle: `${latest.country && latest.country.value} · ${latest.date}`,
            recordId: code,
            url: `https://data.worldbank.org/indicator/${code}?locations=${latest.country ? latest.country.id : ''}`,
            endpoint: 'indicator/' + code,
            category: 'public-market-indicator',
            ids: { indicator: code },
            badges: [{ text: 'Annual indicator', tone: 'fin' }],
            fields: [
              ['Latest value', fmt.num(latest.value, 3)],
              ['Period', latest.date],
              ['Series (as reported)', series.map(([y, v]) => `${y}: ${fmt.num(v, 2)}`).join(' · ')],
              ['Source last updated', (r.data[0] && r.data[0].lastupdated) || null],
              ['Frequency / latency', 'Annual; typically lags 1–3 years']
            ],
            data: { code, value: latest.value, year: latest.date, series }
          })
        ]
      };
    }
  };

  /* ------------------------------- USGS ------------------------------- */
  function quakeRecord(f, ref) {
    const p = f.properties || {};
    const [lo, la, depth] = (f.geometry && f.geometry.coordinates) || [];
    const dist = ref && isFinite(la) ? haversineKm(ref.lat, ref.lon, la, lo) : null;
    const badges = [{ text: 'Seismic event', tone: 'warn' }];
    if (p.alert) badges.push({ text: 'USGS PAGER alert: ' + p.alert, tone: p.alert === 'green' ? 'neutral' : 'serious' });
    if (p.tsunami) badges.push({ text: 'Tsunami flag (source-reported)', tone: 'serious' });
    return rec('usgs', 'earthquake', {
      title: `M${fmt.num(p.mag, 1)} — ${p.place || 'location not reported'}`,
      subtitle: new Date(p.time).toISOString().replace('T', ' ').slice(0, 16) + ' UTC',
      recordId: f.id,
      url: p.url,
      endpoint: 'fdsnws/event/1/query',
      category: 'public-event',
      badges,
      fields: [
        ['Magnitude', fmt.num(p.mag, 1) + (p.magType ? ' ' + p.magType : '')],
        ['Time (UTC)', new Date(p.time).toISOString()],
        ['Depth (km)', fmt.num(depth, 1)],
        ['Coordinates', isFinite(la) ? `${Number(la).toFixed(3)}, ${Number(lo).toFixed(3)}` : null],
        ref ? ['Distance from reference point (km, derived by JAQA)', dist !== null ? fmt.num(dist, 0) : null] : null,
        ['Review status', p.status],
        ['Significance (USGS sig)', p.sig]
      ].filter(Boolean),
      data: { mag: p.mag, dist, alert: p.alert, time: p.time, lat: la, lon: lo }
    });
  }
  C.usgs = {
    async near(lat, lon, radiusKm, days, minMag) {
      const start = new Date(Date.now() - (days || 30) * 86400000).toISOString().slice(0, 10);
      const url = `https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&latitude=${lat}&longitude=${lon}&maxradiuskm=${radiusKm || 500}&minmagnitude=${minMag || 4.5}&starttime=${start}&orderby=magnitude&limit=20`;
      const r = await call('usgs', url, { validate: (j) => isArr(j.features) });
      if (r.error) return r;
      return { records: r.data.features.map((f) => quakeRecord(f, { lat, lon })), meta: { query: { radiusKm, days, minMag } } };
    },
    /** Global feed (fixed query, no user data): M≥minMag worldwide over the last N days. */
    async global(days, minMag, opts) {
      const start = new Date(Date.now() - (days || 7) * 86400000).toISOString().slice(0, 10);
      const url = `https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&minmagnitude=${minMag || 4.5}&starttime=${start}&orderby=time&limit=150`;
      const r = await call('usgs', url, Object.assign({ validate: (j) => isArr(j.features) }, opts || {}));
      if (r.error) return r;
      return { records: r.data.features.map((f) => quakeRecord(f, null)), meta: { total: r.data.features.length } };
    }
  };

  /* ---------------------------- Open-Meteo ---------------------------- */
  C.openmeteo = {
    async geocode(name) {
      const r = await call('openmeteo', `https://geocoding-api.open-meteo.com/v1/search?name=${enc(name)}&count=5&language=en&format=json`, { validate: (j) => obj(j) });
      if (r.error) return r;
      const rows = isArr(r.data.results) ? r.data.results : [];
      return {
        records: rows.map((p, i) =>
          rec('openmeteo', 'place', {
            title: [p.name, p.admin1, p.country].filter(Boolean).join(', '),
            subtitle: `${fmt.num(p.latitude, 3)}, ${fmt.num(p.longitude, 3)}`,
            recordId: String(p.id),
            url: `https://www.openstreetmap.org/?mlat=${p.latitude}&mlon=${p.longitude}#map=10/${p.latitude}/${p.longitude}`,
            endpoint: 'geocoding/search',
            category: 'public-record',
            confidence: i === 0 && rows.length === 1 ? 'Likely' : 'Possible',
            ids: { country: p.country_code },
            badges: [{ text: 'Geographic location', tone: 'neutral' }],
            fields: [
              ['Country', p.country],
              ['Admin region', p.admin1],
              ['Coordinates', `${p.latitude}, ${p.longitude}`],
              ['Feature code (GeoNames)', p.feature_code],
              ['Population (as reported)', p.population ? fmt.num(p.population, 0) : null],
              ['Timezone', p.timezone]
            ],
            data: { lat: p.latitude, lon: p.longitude, country: p.country_code, name: p.name }
          })
        )
      };
    },
    async forecast(lat, lon, label) {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=weather_code,temperature_2m_max,precipitation_sum,wind_speed_10m_max,wind_gusts_10m_max&forecast_days=7&timezone=auto`;
      const r = await call('openmeteo', url, { validate: (j) => obj(j.daily) && isArr(j.daily.time) });
      if (r.error) return r;
      const d = r.data.daily;
      const T = { gust: 75, rain: 50, heat: 40 };
      const flags = [];
      d.time.forEach((day, i) => {
        if (d.wind_gusts_10m_max[i] >= T.gust) flags.push(`${day}: gusts ${d.wind_gusts_10m_max[i]} km/h`);
        if (d.precipitation_sum[i] >= T.rain) flags.push(`${day}: precipitation ${d.precipitation_sum[i]} mm`);
        if (d.temperature_2m_max[i] >= T.heat) flags.push(`${day}: max temperature ${d.temperature_2m_max[i]} °C`);
      });
      const max = (a) => Math.max(...a.filter((x) => x !== null));
      const sum = (a) => a.reduce((s, x) => s + (x || 0), 0);
      return {
        records: [
          rec('openmeteo', 'forecast', {
            title: '7-day weather forecast' + (label ? ' — ' + label : ''),
            subtitle: `${d.time[0]} to ${d.time[d.time.length - 1]} (${r.data.timezone || 'local'})`,
            recordId: `${lat},${lon}`,
            url: 'https://open-meteo.com/',
            endpoint: 'v1/forecast',
            category: 'public-event',
            badges: [{ text: 'Model forecast (not an official warning)', tone: 'neutral' }, ...(flags.length ? [{ text: flags.length + ' threshold signal(s)', tone: 'warn' }] : [])],
            fields: [
              ['Max wind gust (km/h)', fmt.num(max(d.wind_gusts_10m_max), 0)],
              ['Total precipitation (mm)', fmt.num(sum(d.precipitation_sum), 1)],
              ['Max temperature (°C)', fmt.num(max(d.temperature_2m_max), 1)],
              ['Threshold signals (derived by JAQA)', flags.length ? flags.join('; ') : 'None at the displayed thresholds'],
              ['Thresholds used', `gust ≥ ${T.gust} km/h, daily precipitation ≥ ${T.rain} mm, max temperature ≥ ${T.heat} °C`]
            ],
            data: { flags, lat, lon }
          })
        ]
      };
    }
  };

  /* -------------------------------- NWS -------------------------------- */
  C.nws = {
    async alertsAt(lat, lon) {
      const r = await call('nws', `https://api.weather.gov/alerts/active?point=${Number(lat).toFixed(4)},${Number(lon).toFixed(4)}`, { validate: (j) => isArr(j.features), headers: { Accept: 'application/geo+json' } });
      if (r.error) return r;
      return {
        records: r.data.features.map((f) => {
          const p = f.properties || {};
          const serious = ['Extreme', 'Severe'].includes(p.severity);
          return rec('nws', 'weather-alert', {
            title: p.event || 'Weather alert',
            subtitle: p.areaDesc || '',
            recordId: p.id || f.id,
            url: 'https://alerts.weather.gov/',
            endpoint: 'alerts/active',
            category: 'public-event',
            badges: [{ text: 'Official NWS alert', tone: serious ? 'serious' : 'warn' }, { text: 'Severity: ' + (p.severity || 'not reported'), tone: 'neutral' }],
            fields: [
              ['Headline', p.headline],
              ['Severity', p.severity],
              ['Urgency', p.urgency],
              ['Certainty', p.certainty],
              ['Effective', p.effective],
              ['Expires', p.expires],
              ['Issued by', p.senderName]
            ],
            data: { severity: p.severity }
          });
        })
      };
    }
  };

  /* ------------------------------ CISA KEV ------------------------------ */
  let kevCatalog = null;
  R.events.on('session:cleared', () => {
    kevCatalog = null;
  });
  async function loadKev(opts) {
    if (kevCatalog) return { data: kevCatalog };
    const r = await call('cisaKev', 'https://raw.githubusercontent.com/cisagov/kev-data/develop/known_exploited_vulnerabilities.json', Object.assign({ validate: (j) => isArr(j.vulnerabilities) }, opts || {}));
    if (r.error) return r;
    kevCatalog = r.data;
    return r;
  }
  function kevRecord(v, catalogVersion) {
    return rec('cisaKev', 'vulnerability', {
      title: `${v.cveID} — ${v.vulnerabilityName || ''}`.trim(),
      subtitle: `${v.vendorProject || ''} · ${v.product || ''}`,
      recordId: v.cveID,
      url: 'https://nvd.nist.gov/vuln/detail/' + v.cveID,
      endpoint: 'known_exploited_vulnerabilities.json',
      category: 'public-record',
      ids: { cve: v.cveID },
      badges: [{ text: 'In CISA KEV (known exploited)', tone: 'serious' }, ...(v.knownRansomwareCampaignUse === 'Known' ? [{ text: 'Ransomware use: Known (source-reported)', tone: 'serious' }] : [])],
      fields: [
        ['CVE', v.cveID],
        ['Vendor / project', v.vendorProject],
        ['Product', v.product],
        ['Date added to KEV', v.dateAdded],
        ['Federal remediation due date', v.dueDate],
        ['Known ransomware campaign use', v.knownRansomwareCampaignUse],
        ['Required action (CISA)', v.requiredAction],
        ['Description', v.shortDescription],
        ['CWE', isArr(v.cwes) ? v.cwes.join(', ') : null],
        ['KEV catalog version', catalogVersion]
      ],
      links: [{ label: 'CISA KEV catalog', href: 'https://www.cisa.gov/known-exploited-vulnerabilities-catalog' }],
      data: { vendor: v.vendorProject, product: v.product }
    });
  }
  C.kev = {
    async byCve(cve) {
      const r = await loadKev();
      if (r.error) return r;
      const v = r.data.vulnerabilities.find((x) => String(x.cveID).toUpperCase() === cve.toUpperCase());
      return { records: v ? [kevRecord(v, r.data.catalogVersion)] : [], meta: { catalogVersion: r.data.catalogVersion, count: r.data.count } };
    },
    async recent(n, opts) {
      const r = await loadKev(opts);
      if (r.error) return r;
      const rows = r.data.vulnerabilities.slice().sort((a, b) => String(b.dateAdded).localeCompare(String(a.dateAdded)));
      return { records: rows.slice(0, n || 15).map((v) => kevRecord(v, r.data.catalogVersion)), meta: { total: r.data.count, catalogVersion: r.data.catalogVersion } };
    },
    async mentions(term) {
      const t = String(term || '').toLowerCase().trim();
      if (t.length < 3) return { records: [] };
      const r = await loadKev();
      if (r.error) return r;
      const hits = r.data.vulnerabilities.filter((v) => `${v.vendorProject} ${v.product}`.toLowerCase().includes(t));
      hits.sort((a, b) => String(b.dateAdded).localeCompare(String(a.dateAdded)));
      return { records: hits.slice(0, 25).map((v) => kevRecord(v, r.data.catalogVersion)), meta: { total: hits.length, catalogVersion: r.data.catalogVersion } };
    }
  };

  /* -------------------------------- NVD -------------------------------- */
  function nvdRecord(c) {
    const desc = (c.descriptions || []).find((d) => d.lang === 'en');
    const m = c.metrics || {};
    const pick = (m.cvssMetricV40 || m.cvssMetricV31 || m.cvssMetricV30 || m.cvssMetricV2 || [])[0];
    const cvss = pick && pick.cvssData ? pick.cvssData : null;
    const sev = cvss ? cvss.baseSeverity || (pick && pick.baseSeverity) : null;
    const cwes = (c.weaknesses || []).flatMap((w) => (w.description || []).map((d) => d.value)).filter((x) => /^CWE-/.test(x));
    return rec('nvd', 'vulnerability', {
      title: c.id,
      subtitle: `Published ${fmt.date(c.published)} · ${c.vulnStatus || ''}`,
      recordId: c.id,
      url: 'https://nvd.nist.gov/vuln/detail/' + c.id,
      endpoint: 'cves/2.0',
      category: 'public-record',
      ids: { cve: c.id },
      badges: [{ text: 'CVE record', tone: 'cyber' }, ...(sev ? [{ text: 'CVSS severity (source-reported): ' + sev, tone: 'neutral' }] : [])],
      summary: desc ? desc.value : '',
      fields: [
        ['CVE', c.id],
        ['Status', c.vulnStatus],
        ['Published', fmt.date(c.published)],
        ['Last modified', fmt.date(c.lastModified)],
        ['CVSS version / base score', cvss ? `${cvss.version || ''} / ${cvss.baseScore}` : null],
        ['CVSS vector', cvss ? cvss.vectorString : null],
        ['Weaknesses', cwes.length ? [...new Set(cwes)].join(', ') : null],
        ['References', isArr(c.references) ? c.references.length + ' (open NVD record)' : null],
        ['CISA KEV date added (per NVD)', c.cisaExploitAdd || null]
      ],
      data: { cwes }
    });
  }
  C.nvd = {
    async cve(id) {
      const r = await call('nvd', `https://services.nvd.nist.gov/rest/json/cves/2.0?cveId=${enc(id)}`, { validate: (j) => isArr(j.vulnerabilities) });
      if (r.error) return r;
      return { records: r.data.vulnerabilities.map((v) => nvdRecord(v.cve)) };
    },
    async keyword(term) {
      const r = await call('nvd', `https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch=${enc(term)}&resultsPerPage=10`, { validate: (j) => isArr(j.vulnerabilities) });
      if (r.error) return r;
      return { records: r.data.vulnerabilities.map((v) => nvdRecord(v.cve)), meta: { total: r.data.totalResults } };
    }
  };

  /* ------------------------------- CPSC ------------------------------- */
  function cpscRecord(x) {
    const names = (arr, k) => (isArr(arr) ? arr.map((a) => a[k || 'Name']).filter(Boolean).join('; ') : null);
    return rec('cpsc', 'recall', {
      title: x.Title || 'CPSC recall ' + x.RecallNumber,
      subtitle: `Recall ${x.RecallNumber} · ${fmt.date(x.RecallDate)}`,
      recordId: String(x.RecallNumber),
      url: x.URL,
      endpoint: 'RestWebServices/Recall',
      category: 'public-record',
      ids: { recall: String(x.RecallNumber) },
      badges: [{ text: 'Product recall (US CPSC)', tone: 'serious' }],
      fields: [
        ['Recall number', x.RecallNumber],
        ['Recall date', fmt.date(x.RecallDate)],
        ['Products', names(x.Products)],
        ['Hazards', names(x.Hazards)],
        ['Manufacturers', names(x.Manufacturers)],
        ['Retailers', names(x.Retailers)],
        ['Manufacturer countries', names(x.ManufacturerCountries, 'Country')],
        ['Remedies', names(x.Remedies)],
        ['Units (as reported)', names(x.Products, 'NumberOfUnits')]
      ],
      summary: x.Description || '',
      data: {}
    });
  }
  C.cpsc = {
    async search(title) {
      const r = await call('cpsc', `https://www.saferproducts.gov/RestWebServices/Recall?format=json&RecallTitle=${enc(title)}`, { validate: (j) => isArr(j) });
      if (r.error) return r;
      const rows = r.data.slice().sort((a, b) => String(b.RecallDate).localeCompare(String(a.RecallDate)));
      return { records: rows.slice(0, 20).map(cpscRecord), meta: { total: rows.length } };
    },
    async byNumber(num) {
      const r = await call('cpsc', `https://www.saferproducts.gov/RestWebServices/Recall?format=json&RecallNumber=${enc(num)}`, { validate: (j) => isArr(j) });
      if (r.error) return r;
      return { records: r.data.slice(0, 5).map(cpscRecord) };
    }
  };

  /* ------------------------------- NHTSA ------------------------------- */
  function nhtsaRecord(x) {
    return rec('nhtsa', 'recall', {
      title: `${x.NHTSACampaignNumber} — ${x.Component || 'Vehicle recall'}`,
      subtitle: `${x.Manufacturer || ''}${x.ModelYear ? ' · ' + [x.Make, x.Model, x.ModelYear].filter(Boolean).join(' ') : ''}`,
      recordId: x.NHTSACampaignNumber,
      url: 'https://www.nhtsa.gov/recalls',
      endpoint: 'recalls',
      category: 'public-record',
      ids: { recall: x.NHTSACampaignNumber },
      badges: [{ text: 'Vehicle recall (US NHTSA)', tone: 'serious' }],
      summary: x.Summary || '',
      fields: [
        ['Campaign number', x.NHTSACampaignNumber],
        ['Manufacturer', x.Manufacturer],
        ['Report received (as published)', x.ReportReceivedDate],
        ['Component', x.Component],
        ['Potential units affected', x.PotentialNumberofUnitsAffected ? fmt.num(x.PotentialNumberofUnitsAffected, 0) : null],
        ['Consequence', x.Consequence],
        ['Remedy', x.Remedy],
        ['Vehicle (make/model/year)', [x.Make, x.Model, x.ModelYear].filter(Boolean).join(' ') || null]
      ]
    });
  }
  C.nhtsa = {
    async campaign(id) {
      const r = await call('nhtsa', `https://api.nhtsa.gov/recalls/campaignNumber?campaignNumber=${enc(id)}`, { validate: (j) => isArr(j.results) });
      if (r.error) return r;
      return { records: r.data.results.slice(0, 20).map(nhtsaRecord), meta: { total: r.data.Count } };
    },
    async vehicle(make, model, year) {
      const r = await call('nhtsa', `https://api.nhtsa.gov/recalls/recallsByVehicle?make=${enc(make)}&model=${enc(model)}&modelYear=${enc(year)}`, { validate: (j) => isArr(j.results) });
      if (r.error) return r;
      return { records: r.data.results.slice(0, 25).map(nhtsaRecord), meta: { total: r.data.Count } };
    }
  };

  /* ---------------------------- USAspending ---------------------------- */
  const USA = 'https://api.usaspending.gov/api/v2';
  const CONTRACT_CODES = ['A', 'B', 'C', 'D'];
  const GRANT_CODES = ['02', '03', '04', '05'];
  C.usaspending = {
    async awards(opts) {
      const o = opts || {};
      const filters = { award_type_codes: o.kind === 'grants' ? GRANT_CODES : o.kind === 'idvs' ? ['IDV_A', 'IDV_B', 'IDV_B_A', 'IDV_B_B', 'IDV_B_C', 'IDV_C', 'IDV_D', 'IDV_E'] : CONTRACT_CODES };
      if (o.recipient) filters.recipient_search_text = [o.recipient];
      if (o.keyword) filters.keywords = [o.keyword];
      if (o.from || o.to) filters.time_period = [{ start_date: o.from || '2007-10-01', end_date: o.to || new Date().toISOString().slice(0, 10) }];
      const body = {
        filters,
        fields: ['Award ID', 'Recipient Name', 'Start Date', 'End Date', 'Award Amount', 'Awarding Agency', 'Awarding Sub Agency', 'Description', 'Recipient UEI'],
        limit: o.limit || 10,
        page: o.page || 1,
        sort: o.sort || 'Award Amount',
        order: 'desc'
      };
      const r = await call('usaspending', `${USA}/search/spending_by_award/`, { method: 'POST', body, validate: (j) => isArr(j.results) });
      if (r.error) return r;
      const isGrant = o.kind === 'grants';
      return {
        records: r.data.results.map((x) =>
          rec('usaspending', isGrant ? 'grant' : 'award', {
            title: `${x['Award ID'] || 'Award'} — ${x['Recipient Name'] || 'Recipient not reported'}`,
            subtitle: [x['Awarding Agency'], x['Awarding Sub Agency']].filter(Boolean).join(' · '),
            recordId: x.generated_internal_id || x['Award ID'],
            url: x.generated_internal_id ? 'https://www.usaspending.gov/award/' + x.generated_internal_id : 'https://www.usaspending.gov/search',
            endpoint: 'search/spending_by_award',
            category: isGrant ? 'grant-notice' : 'award-notice',
            confidence: o.recipient ? matchConfidence(o.recipient, x['Recipient Name']) : null,
            ids: { award: x['Award ID'], uei: x['Recipient UEI'] || null },
            badges: [{ text: isGrant ? 'US federal grant/assistance award' : 'US federal contract award', tone: 'proc' }],
            summary: x.Description || '',
            fields: [
              ['Award ID', x['Award ID']],
              ['Recipient (as reported)', x['Recipient Name']],
              ['Recipient UEI', x['Recipient UEI']],
              ['Awarding agency', x['Awarding Agency']],
              ['Awarding sub-agency', x['Awarding Sub Agency']],
              ['Period of performance', `${x['Start Date'] || '?'} → ${x['End Date'] || '?'}`],
              ['Award amount (USD, as reported)', fmt.money(x['Award Amount'], 'USD')]
            ],
            data: { amount: x['Award Amount'], start: x['Start Date'], end: x['End Date'], generatedId: x.generated_internal_id }
          })
        ),
        meta: { hasNext: r.data.page_metadata ? !!r.data.page_metadata.hasNext : false }
      };
    },
    async awardDetail(generatedId) {
      const r = await call('usaspending', `${USA}/awards/${enc(generatedId)}/`, { validate: (j) => obj(j) });
      if (r.error) return r;
      const x = r.data;
      const lt = x.latest_transaction_contract_data || {};
      return {
        records: [
          rec('usaspending', 'award', {
            title: `${x.piid || x.fain || x.uri || generatedId} — ${(x.recipient && x.recipient.recipient_name) || ''}`,
            subtitle: x.type_description || x.category,
            recordId: x.generated_unique_award_id,
            url: 'https://www.usaspending.gov/award/' + x.generated_unique_award_id,
            endpoint: 'awards/{id}',
            category: 'award-notice',
            ids: { award: x.piid || x.fain },
            badges: [{ text: 'Award detail', tone: 'proc' }],
            summary: x.description || '',
            fields: [
              ['Type', x.type_description],
              ['Date signed', x.date_signed],
              ['Total obligation (USD)', fmt.money(x.total_obligation)],
              ['Base and all options (USD)', fmt.money(x.base_and_all_options)],
              ['Subaward count', x.subaward_count],
              ['Parent award', x.parent_award && (x.parent_award.piid || x.parent_award.generated_unique_award_id)],
              ['Solicitation identifier', lt.solicitation_identifier],
              ['Extent competed', lt.extent_competed_description],
              ['Number of offers received', lt.number_of_offers_received],
              ['Recipient parent (as reported)', x.recipient && x.recipient.parent_recipient_name],
              ['Period of performance', x.period_of_performance ? `${x.period_of_performance.start_date} → ${x.period_of_performance.end_date}` : null]
            ]
          })
        ]
      };
    }
  };

  /* -------------------------- Federal Register -------------------------- */
  const FR_FIELDS = ['title', 'type', 'abstract', 'document_number', 'html_url', 'publication_date', 'agencies', 'comments_close_on', 'effective_on', 'docket_ids', 'topics'];
  function frRecord(d) {
    const agencies = isArr(d.agencies) ? d.agencies.map((a) => a.name || a.raw_name).filter(Boolean) : [];
    const badges = [{ text: 'US regulatory document: ' + (d.type || 'document'), tone: 'reg' }];
    if (d.comments_close_on && d.comments_close_on >= new Date().toISOString().slice(0, 10)) badges.push({ text: 'Comment period open (verify)', tone: 'warn' });
    return rec('federalRegister', 'regulatory-document', {
      title: d.title,
      subtitle: `${agencies.join('; ')} · ${d.publication_date || ''}`,
      recordId: d.document_number,
      url: d.html_url,
      endpoint: 'documents',
      category: 'official-source-authoritative',
      ids: { frDoc: d.document_number },
      badges,
      summary: d.abstract || '',
      fields: [
        ['Document number', d.document_number],
        ['Action type', d.type],
        ['Agencies', agencies.length ? agencies.join('; ') : null],
        ['Publication date', d.publication_date],
        ['Comment deadline', d.comments_close_on || null],
        ['Effective date', d.effective_on || null],
        ['Dockets', isArr(d.docket_ids) && d.docket_ids.length ? d.docket_ids.join(', ') : null],
        ['Topics', isArr(d.topics) && d.topics.length ? d.topics.join(', ') : null]
      ],
      flags: { legalReviewRequired: true, deadlineRisk: !!d.comments_close_on }
    });
  }
  C.federalRegister = {
    async search(term, opts) {
      const o = opts || {};
      let url = `https://www.federalregister.gov/api/v1/documents.json?conditions%5Bterm%5D=${enc(term)}&per_page=${o.perPage || 10}&order=${o.order || 'relevance'}`;
      FR_FIELDS.forEach((f) => (url += '&fields%5B%5D=' + f));
      if (o.type) url += '&conditions%5Btype%5D%5B%5D=' + enc(o.type);
      if (o.agency) url += '&conditions%5Bagencies%5D%5B%5D=' + enc(o.agency);
      if (o.from) url += '&conditions%5Bpublication_date%5D%5Bgte%5D=' + enc(o.from);
      if (o.to) url += '&conditions%5Bpublication_date%5D%5Blte%5D=' + enc(o.to);
      const r = await call('federalRegister', url, { validate: (j) => obj(j), persistent: !!o.persistent });
      if (r.error) return r;
      return { records: (r.data.results || []).map(frRecord), meta: { total: r.data.count || 0 } };
    },
    async doc(num) {
      let url = `https://www.federalregister.gov/api/v1/documents/${enc(num)}.json?`;
      FR_FIELDS.forEach((f) => (url += 'fields%5B%5D=' + f + '&'));
      const r = await call('federalRegister', url, { allow404: true, validate: (j) => j === null || obj(j) });
      if (r.error) return r;
      return { records: r.data && r.data.document_number ? [frRecord(r.data)] : [] };
    }
  };

  /* ------------------------------ SEC EDGAR ------------------------------ */
  // 8-K item codes that correspond to publicly disclosed financial-stress,
  // audit or governance events. Presence is a source-reported filing fact —
  // not a prediction, score or conclusion.
  const EIGHT_K_ITEMS = {
    '1.03': 'Bankruptcy or Receivership',
    '1.05': 'Material Cybersecurity Incidents',
    '2.04': 'Triggering Events That Accelerate or Increase a Direct Financial Obligation',
    '2.05': 'Costs Associated with Exit or Disposal Activities',
    '2.06': 'Material Impairments',
    '3.01': 'Notice of Delisting or Failure to Satisfy a Continued Listing Rule',
    '4.01': 'Changes in Registrant’s Certifying Accountant',
    '4.02': 'Non-Reliance on Previously Issued Financial Statements (restatement)',
    '5.02': 'Departure/Appointment of Directors or Certain Officers'
  };
  C.sec = {
    EIGHT_K_ITEMS,
    padCik: (c) => String(c).replace(/\D/g, '').padStart(10, '0'),
    async submissions(cik) {
      const padded = this.padCik(cik);
      const r = await call('sec', `https://data.sec.gov/submissions/CIK${padded}.json`, { allow404: true, validate: (j) => j === null || obj(j.filings) });
      if (r.error) return r;
      if (!r.data) return { records: [] };
      const d = r.data;
      const rc = (d.filings && d.filings.recent) || {};
      const cikInt = String(Number(padded));
      const filings = [];
      const signals = [];
      const forms = rc.form || [];
      for (let i = 0; i < forms.length && filings.length < 400; i++) {
        const acc = rc.accessionNumber[i];
        const url = `https://www.sec.gov/Archives/edgar/data/${cikInt}/${String(acc).replace(/-/g, '')}/${rc.primaryDocument[i] || ''}`;
        const f = { form: forms[i], date: rc.filingDate[i], accession: acc, report: rc.reportDate ? rc.reportDate[i] : null, items: rc.items ? rc.items[i] : '', url };
        filings.push(f);
        if (/^NT /.test(f.form)) signals.push({ date: f.date, text: `${f.form} filed (notification of late filing)`, url, form: f.form });
        if (/^8-K/.test(f.form) && f.items) {
          String(f.items)
            .split(',')
            .map((s) => s.trim())
            .filter((it) => EIGHT_K_ITEMS[it])
            .forEach((it) => signals.push({ date: f.date, text: `8-K item ${it}: ${EIGHT_K_ITEMS[it]}`, url, form: f.form, item: it }));
        }
      }
      const latest = (re) => filings.find((f) => re.test(f.form));
      const k = latest(/^(10-K|20-F|40-F)$/);
      const q = latest(/^10-Q$/);
      const entity = rec('sec', 'filer', {
        title: d.name,
        subtitle: `CIK ${padded}${d.tickers && d.tickers.length ? ' · ' + d.tickers.join(', ') : ''}`,
        recordId: padded,
        url: `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=${padded}&owner=exclude`,
        endpoint: 'submissions',
        category: 'public-filing',
        confidence: 'Exact',
        ids: { cik: padded, ticker: (d.tickers || [])[0] || null, lei: d.lei || null },
        badges: [{ text: 'SEC registrant', tone: 'fin' }, ...(signals.length ? [{ text: signals.length + ' filing event(s) to review', tone: 'warn' }] : [])],
        fields: [
          ['Name', d.name],
          ['CIK', padded],
          ['Tickers', (d.tickers || []).join(', ') || null],
          ['Exchanges', (d.exchanges || []).join(', ') || null],
          ['SIC', d.sic ? `${d.sic} — ${d.sicDescription || ''}` : null],
          ['Entity type', d.entityType],
          ['Filer category', d.category],
          ['State of incorporation', d.stateOfIncorporationDescription || d.stateOfIncorporation],
          ['Fiscal year end (MMDD)', d.fiscalYearEnd],
          ['LEI (as reported to SEC)', d.lei || null],
          ['Latest annual report', k ? `${k.form} filed ${k.date}` : null],
          ['Latest quarterly report', q ? `${q.form} filed ${q.date}` : null],
          ['Former names', isArr(d.formerNames) && d.formerNames.length ? d.formerNames.map((x) => x.name).join('; ') : null]
        ],
        data: { filings, signals, name: d.name }
      });
      return { records: [entity], meta: { filings, signals } };
    }
  };

  /* ---------------------------- CourtListener ---------------------------- */
  C.courtlistener = {
    async search(q, type) {
      const t = type === 'o' ? 'o' : 'r';
      const r = await call('courtlistener', `https://www.courtlistener.com/api/rest/v4/search/?q=${enc('"' + q.replace(/"/g, '') + '"')}&type=${t}&order_by=score%20desc`, { validate: (j) => isArr(j.results) });
      if (r.error) return r;
      return {
        records: r.data.results.slice(0, 15).map((x) =>
          rec('courtlistener', 'court-record', {
            title: x.caseName || x.caseNameFull || 'Case',
            subtitle: `${x.court || ''} · filed ${x.dateFiled || '?'}`,
            recordId: String(x.docket_id || x.cluster_id || ''),
            url: 'https://www.courtlistener.com' + (x.docket_absolute_url || x.absolute_url || '/'),
            endpoint: 'search (' + (t === 'o' ? 'opinions' : 'RECAP dockets') + ')',
            category: 'litigation-record',
            confidence: 'Possible',
            badges: [{ text: t === 'o' ? 'Court opinion' : 'Court docket (RECAP)', tone: 'legal' }, ...(x.chapter ? [{ text: 'Bankruptcy chapter ' + x.chapter + ' (source-reported)', tone: 'warn' }] : [])],
            fields: [
              ['Case name', x.caseName],
              ['Court', x.court],
              ['Docket number', x.docketNumber],
              ['Date filed', x.dateFiled],
              ['Date terminated', x.dateTerminated || null],
              ['Bankruptcy chapter', x.chapter || null],
              ['Cause / nature', x.cause || x.suitNature || null],
              ['Match basis', 'Name/keyword text match only — manual review recommended']
            ],
            flags: { legalReviewRequired: true }
          })
        ),
        meta: { total: r.data.count }
      };
    }
  };

  /* ------------------------ Wikidata / Wikipedia ------------------------ */
  const WD = 'https://www.wikidata.org/w/api.php';
  const claim = (claims, p) => (claims && claims[p] ? claims[p].map((c) => c.mainsnak && c.mainsnak.datavalue && c.mainsnak.datavalue.value).filter((v) => v !== undefined && v !== null) : []);
  C.wikidata = {
    async search(q) {
      const r = await call('wikidata', `${WD}?action=wbsearchentities&search=${enc(q)}&language=en&uselang=en&type=item&format=json&limit=6&origin=*`, { validate: (j) => isArr(j.search) });
      if (r.error) return r;
      return {
        records: r.data.search.map((x) =>
          rec('wikidata', 'background', {
            title: x.label || x.id,
            subtitle: x.description || '',
            recordId: x.id,
            url: 'https://www.wikidata.org/wiki/' + x.id,
            endpoint: 'wbsearchentities',
            category: 'public-record',
            confidence: matchConfidence(q, x.label) === 'Exact' ? 'Likely' : 'Possible',
            ids: { wikidata: x.id },
            badges: [{ text: 'Background (non-authoritative)', tone: 'neutral' }],
            fields: [
              ['Wikidata ID', x.id],
              ['Description', x.description || null]
            ],
            data: { qid: x.id, label: x.label }
          })
        )
      };
    },
    async identifiers(qid) {
      const r = await call('wikidata', `${WD}?action=wbgetentities&ids=${enc(qid)}&props=claims%7Clabels%7Cdescriptions%7Caliases%7Csitelinks&sitefilter=enwiki&languages=en&format=json&origin=*`, { validate: (j) => obj(j.entities) });
      if (r.error) return r;
      const e = r.data.entities[qid];
      if (!e) return { records: [] };
      const cl = e.claims || {};
      const tickers = [];
      (cl.P414 || []).forEach((c) => ((c.qualifiers && c.qualifiers.P249) || []).forEach((q) => q.datavalue && tickers.push(q.datavalue.value)));
      const lei = claim(cl, 'P1278')[0] || null;
      const cik = claim(cl, 'P5531')[0] || null;
      const website = claim(cl, 'P856')[0] || null;
      const isin = claim(cl, 'P946');
      const ukco = claim(cl, 'P2622')[0] || null;
      const oc = claim(cl, 'P1320')[0] || null;
      const inception = claim(cl, 'P571')[0];
      const label = e.labels && e.labels.en ? e.labels.en.value : qid;
      const aliases = e.aliases && e.aliases.en ? e.aliases.en.map((a) => a.value) : [];
      const enwiki = e.sitelinks && e.sitelinks.enwiki ? e.sitelinks.enwiki.title : null;
      return {
        records: [
          rec('wikidata', 'background', {
            title: label,
            subtitle: e.descriptions && e.descriptions.en ? e.descriptions.en.value : '',
            recordId: qid,
            url: 'https://www.wikidata.org/wiki/' + qid,
            endpoint: 'wbgetentities',
            category: 'public-record',
            confidence: 'Possible',
            ids: { wikidata: qid, lei, cik, ticker: tickers[0] || null, ukCompany: ukco },
            badges: [{ text: 'Identifier cross-links (non-authoritative)', tone: 'neutral' }],
            fields: [
              ['Aliases', aliases.length ? aliases.slice(0, 8).join('; ') : null],
              ['LEI (claimed on Wikidata)', lei],
              ['SEC CIK (claimed on Wikidata)', cik],
              ['Ticker(s)', tickers.length ? [...new Set(tickers)].join(', ') : null],
              ['ISIN(s)', isin.length ? isin.slice(0, 5).join(', ') : null],
              ['UK company number', ukco],
              ['OpenCorporates ID', oc],
              ['Official website (as listed)', website],
              ['Inception', inception && inception.time ? String(inception.time).replace(/^\+/, '').slice(0, 10) : null]
            ],
            links: [website ? { label: 'Official website (as listed on Wikidata)', href: website } : null, enwiki ? { label: 'Wikipedia article', href: 'https://en.wikipedia.org/wiki/' + encodeURIComponent(enwiki.replace(/ /g, '_')) } : null].filter(Boolean),
            data: { lei, cik, tickers, website, enwiki, label, aliases }
          })
        ]
      };
    }
  };
  C.wikipedia = {
    async summary(title) {
      const r = await call('wikipedia', `https://en.wikipedia.org/api/rest_v1/page/summary/${enc(title.replace(/ /g, '_'))}`, { allow404: true, validate: (j) => j === null || obj(j) });
      if (r.error) return r;
      const d = r.data;
      if (!d || d.type === 'disambiguation' || !d.extract) return { records: [] };
      return {
        records: [
          rec('wikipedia', 'background', {
            title: d.title,
            subtitle: d.description || '',
            recordId: String(d.pageid || d.title),
            url: d.content_urls && d.content_urls.desktop ? d.content_urls.desktop.page : 'https://en.wikipedia.org/',
            endpoint: 'page/summary',
            category: 'public-record',
            confidence: 'Possible',
            badges: [{ text: 'Encyclopedic background (non-authoritative)', tone: 'neutral' }],
            summary: d.extract,
            fields: [['Last edited', d.timestamp ? fmt.date(d.timestamp) : null]]
          })
        ]
      };
    }
  };

  /* ------------------------------ Overpass ------------------------------ */
  C.overpass = {
    async portsNear(lat, lon, radiusM) {
      const rad = Math.min(radiusM || 15000, 30000);
      const q = `[out:json][timeout:20];(nwr["landuse"="port"](around:${rad},${lat},${lon});nwr["industrial"="port"](around:${rad},${lat},${lon});nwr["harbour"="yes"]["name"](around:${rad},${lat},${lon}););out center tags 25;`;
      const r = await call('overpass', 'https://overpass-api.de/api/interpreter?data=' + enc(q), { validate: (j) => isArr(j.elements) });
      if (r.error) return r;
      return {
        records: r.data.elements.map((e) => {
          const t = e.tags || {};
          const la = e.lat || (e.center && e.center.lat);
          const lo = e.lon || (e.center && e.center.lon);
          return rec('overpass', 'facility', {
            title: t.name || t['name:en'] || 'Unnamed port feature',
            subtitle: [t.operator, t.landuse || t.industrial || (t.harbour ? 'harbour' : '')].filter(Boolean).join(' · '),
            recordId: `${e.type}/${e.id}`,
            url: `https://www.openstreetmap.org/${e.type}/${e.id}`,
            endpoint: 'interpreter',
            category: 'public-record',
            confidence: 'Possible',
            badges: [{ text: 'Mapped port feature (OSM)', tone: 'neutral' }],
            fields: [
              ['Name', t.name],
              ['Operator (as mapped)', t.operator],
              ['Tag', t.landuse ? 'landuse=' + t.landuse : t.industrial ? 'industrial=' + t.industrial : 'harbour=yes'],
              ['Coordinates', la && lo ? `${Number(la).toFixed(4)}, ${Number(lo).toFixed(4)}` : null],
              ['Distance from reference (km, derived by JAQA)', la && lo ? fmt.num(haversineKm(lat, lon, la, lo), 1) : null]
            ]
          });
        })
      };
    }
  };

  /* -------------------------------- ECB -------------------------------- */
  C.ecb = {
    async exr(ccy, n, opts) {
      const r = await call('ecb', `https://data-api.ecb.europa.eu/service/data/EXR/D.${enc(ccy)}.EUR.SP00.A?format=jsondata&lastNObservations=${n || 30}`, Object.assign({ allow404: true, validate: (j) => j === null || isArr(j.dataSets) }, opts || {}));
      if (r.error) return r;
      if (!r.data) return { records: [] };
      const ds = r.data.dataSets[0] || {};
      const key = Object.keys(ds.series || {})[0];
      if (!key) return { records: [] };
      const obs = ds.series[key].observations || {};
      const dims = (r.data.structure && r.data.structure.dimensions && r.data.structure.dimensions.observation && r.data.structure.dimensions.observation[0] && r.data.structure.dimensions.observation[0].values) || [];
      const pts = Object.keys(obs)
        .map((k) => [dims[Number(k)] ? dims[Number(k)].id : k, obs[k][0]])
        .filter((p) => p[1] !== null)
        .sort((a, b) => String(a[0]).localeCompare(String(b[0])));
      if (!pts.length) return { records: [] };
      const last = pts[pts.length - 1];
      const first = pts[0];
      const chg = first[1] ? ((last[1] - first[1]) / first[1]) * 100 : null;
      return {
        records: [
          rec('ecb', 'fx-rate', {
            title: `EUR/${ccy} euro foreign exchange reference rate`,
            subtitle: `Latest ${last[0]}`,
            recordId: `EXR.D.${ccy}.EUR.SP00.A`,
            url: `https://data.ecb.europa.eu/data/datasets/EXR/EXR.D.${ccy}.EUR.SP00.A`,
            endpoint: 'data/EXR',
            category: 'public-market-indicator',
            badges: [{ text: 'Reference rate (not a tradable price)', tone: 'fin' }],
            fields: [
              ['Latest (units of ' + ccy + ' per EUR)', fmt.num(last[1], 4)],
              ['Observation date', last[0]],
              ['Observations shown', `${pts.length} business days (${first[0]} → ${last[0]})`],
              ['Change over window (%, derived by JAQA)', chg !== null ? fmt.num(chg, 2) : null],
              ['Formula', '(latest − first) ÷ first × 100 over the displayed window'],
              ['Frequency / latency', 'Daily reference rate, published ~16:00 CET on TARGET business days']
            ],
            data: { series: pts, ccy }
          })
        ]
      };
    }
  };

  /* ------------------------------- GDELT ------------------------------- */
  C.gdelt = {
    async articles(q) {
      const r = await call('gdelt', `https://api.gdeltproject.org/api/v2/doc/doc?query=${enc('"' + q.replace(/"/g, '') + '"')}&mode=artlist&format=json&maxrecords=15&sort=datedesc&timespan=3months`, { validate: (j) => obj(j) });
      if (r.error) return r;
      const arts = isArr(r.data.articles) ? r.data.articles : [];
      return {
        records: arts.map((a) =>
          rec('gdelt', 'news-signal', {
            title: a.title || a.url,
            subtitle: `${a.domain || ''} · ${a.sourcecountry || ''} · ${a.language || ''}`,
            recordId: a.url,
            url: a.url,
            endpoint: 'doc/doc artlist',
            category: 'public-event',
            confidence: 'Possible',
            badges: [{ text: 'Media signal (noisy, unverified)', tone: 'neutral' }, ...(a.language && a.language !== 'English' ? [{ text: 'Translation risk', tone: 'warn' }] : [])],
            fields: [
              ['Seen (UTC, as reported)', a.seendate ? String(a.seendate).replace(/^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2}).*/, '$1-$2-$3 $4:$5') : null],
              ['Outlet domain', a.domain],
              ['Language', a.language],
              ['Source country', a.sourcecountry]
            ],
            flags: { translationRisk: a.language && a.language !== 'English' }
          })
        )
      };
    }
  };

  /* ------------------------------ EPA ECHO ------------------------------ */
  /* ---------------- JAQA Global Monitor (same-origin JAQA server) ---------------- */
  C.monitor = {
    /** Latest headlines of one verified official feed. Fixed feed id; no search terms are sent. */
    async feed(feed, opts) {
      const endpoint = '/api/jaqa/monitor/feed?id=' + enc(feed.id);
      const r = await call('jaqaMonitor', endpoint, Object.assign({ validate: (j) => !!j && j.ok === true && isArr(j.items) }, opts || {}));
      // Only verified feed ids are requested, so a 404 means there is no JAQA
      // server here (static-only hosting): switch the source to link-out.
      if (r.error === 'not_found') {
        R.runtime.markUnavailable('jaqaMonitor', 'The JAQA server is not available on this deployment (static hosting).');
        return { error: 'linkout' };
      }
      if (r.error) return r;
      return {
        records: r.data.items.map((it) =>
          rec('jaqaMonitor', 'monitor', {
            title: it.title,
            subtitle: feed.publisher + (it.published ? ' · ' + it.published.slice(0, 16).replace('T', ' ') + ' UTC' : ''),
            fields: [['Publisher', feed.publisher], ['Feed', feed.name], ['Published', it.published ? it.published.replace('T', ' ').slice(0, 19) + ' UTC' : 'not stated'], ['Coordinates', isFinite(it.lat) ? it.lat.toFixed(2) + ', ' + it.lon.toFixed(2) + ' (publisher-supplied)' : undefined]],
            links: [{ label: 'Read at ' + feed.publisher, href: it.link }],
            data: { feedId: feed.id, category: feed.category, publisher: feed.publisher, published: it.published || null, lat: isFinite(it.lat) ? it.lat : undefined, lon: isFinite(it.lon) ? it.lon : undefined },
            url: it.link, recordId: it.link, endpoint, category: 'official-feed-headline', confidence: 'Source-reported'
          })
        ),
        meta: { fetchedAt: r.data.fetchedAt }
      };
    }
  };

  C.epa = {
    async facilities(name) {
      const r = await call('epa', `https://echodata.epa.gov/echo/echo_rest_services.get_facility_info?output=JSON&p_fn=${enc(name)}`, { validate: (j) => obj(j) && obj(j.Results) });
      if (r.error) return r;
      const rows = isArr(r.data.Results.Facilities) ? r.data.Results.Facilities : [];
      const g = (x, ...keys) => {
        for (const k of keys) if (x[k] !== undefined && x[k] !== null && x[k] !== '') return x[k];
        return null;
      };
      return {
        records: rows.slice(0, 25).map((x) =>
          rec('epa', 'facility', {
            title: x.FacName || 'Facility',
            subtitle: [x.FacCity, x.FacState].filter(Boolean).join(', '),
            recordId: x.RegistryID,
            url: x.RegistryID ? 'https://echo.epa.gov/detailed-facility-report?fid=' + x.RegistryID : 'https://echo.epa.gov/',
            endpoint: 'get_facility_info',
            category: 'public-record',
            confidence: 'Possible',
            badges: [{ text: 'EPA-regulated facility (name match)', tone: 'esg' }],
            fields: [
              ['Registry ID', x.RegistryID],
              ['Address', [x.FacStreet, x.FacCity, x.FacState, x.FacZip].filter(Boolean).join(', ') || null],
              ['County', x.FacCounty],
              ['Compliance status (as reported)', g(x, 'FacComplianceStatus', 'FacCurrCompStatus')],
              ['Quarters with violation (as reported)', g(x, 'FacQtrsWithNC')],
              ['Significant noncompliance flag', g(x, 'FacSNCFlg')],
              ['Inspections (5 yr, as reported)', g(x, 'FacInspectionCount')],
              ['Formal actions (5 yr, as reported)', g(x, 'FacFormalActionCount')],
              ['Penalties (as reported)', g(x, 'FacTotalPenalties')],
              ['Last inspection', g(x, 'FacDateLastInspection', 'FacLastInspectionDate')],
              ['Match basis', 'Facility-name text match — not a legal-entity match']
            ]
          })
        ),
        meta: { total: Number(r.data.Results.QueryRows) || rows.length }
      };
    }
  };

  /** Coverage Console availability check (user-triggered, fixed probe URL, no user data). */
  R.probeSource = async function probeSource(id) {
    const s = R.sources.get(id);
    if (!s || !s.probe) return { ok: false, errorKind: 'unknown_source' };
    const res = await R.net.request(id, s.probe, { probe: true });
    if (res.ok) R.runtime.markLive(id);
    else if (res.errorKind === 'cors_or_network') R.runtime.markUnavailable(id, 'Availability check failed from this browser (CORS, network, or site security policy).');
    return res;
  };
})(window.JAQAWorkspace);

/* ---- modules/taxonomies.js ---- */
/*
 * taxonomies.js — Global Risk Universe, Finance Risk Universe, insurance
 * lines and procurement categories.
 *
 * HOW DOMAINS MAP TO PUBLIC SOURCES
 *   Each domain inherits defaults from its group (live source ids, link-out
 *   directory keys, regulators, standards, gaps) and may override them.
 *   `src` lists registry ids that have live clients relevant to the domain;
 *   whether they are actually live is decided at runtime by the registry.
 *   `dirs` lists R.directories keys used for official link-outs.
 *
 * IMPORTANT: this is a map of public evidence, not a risk measurement system.
 * Nothing here scores, ranks or rates any entity, country or domain.
 */
(function (R) {
  'use strict';

  const G = {
    strategy: { label: 'Strategic, reputational & governance', src: ['secXbrl', 'sec', 'gdelt', 'wikidata'], dirs: ['enforcement', 'entity'], reg: ['Securities regulators (SEC, FCA, ESMA)'], std: ['ISO 31000', 'COSO ERM'], gaps: 'Board-level strategy, internal decisions and reputational sentiment are largely non-public; media signals are noisy.', regions: ['Global'], sectors: ['All'] },
    integrity: { label: 'Fraud, bribery, AML & sanctions', src: ['federalRegister', 'courtlistener'], dirs: ['sanctions', 'enforcement'], reg: ['OFAC', 'OFSI', 'EU Council', 'UN Security Council', 'FinCEN', 'FATF'], std: ['FATF Recommendations', 'UNCAC', 'ISO 37001'], gaps: 'Sanctions/PEP screening requires a system of record; no public hit ≠ clear. SAR/CTR and transaction data are never accessible.', regions: ['Global'], sectors: ['All'] },
    legal: { label: 'Legal, regulatory, compliance & tax', src: ['federalRegister', 'courtlistener'], dirs: ['regulatory', 'enforcement'], reg: ['Sector regulators', 'Tax authorities', 'Courts'], std: ['ISO 37301 (compliance management)'], gaps: 'Litigation coverage is partial (US-centric, RECAP crowd-sourced). Most jurisdictions have no open court API. Tax positions are confidential.', regions: ['US (live)', 'EU/UK (link-out)'], sectors: ['All'] },
    financial: { label: 'Financial & market', src: ['sec', 'worldbank', 'ecb'], dirs: ['macro', 'insolvency', 'lien'], reg: ['Central banks', 'Securities regulators', 'Banking supervisors'], std: ['Basel framework', 'IFRS 9 / CECL'], gaps: 'Private-company financials, lender data, credit bureau files and trading positions are not public. Market data may be delayed.', regions: ['Global (macro)', 'US (filings)'], sectors: ['All'] },
    insurance: { label: 'Insurance, reinsurance & pensions', src: ['gleif', 'sec', 'federalRegister', 'usgs'], dirs: ['insuranceRegulators', 'ratingAgencies', 'marketReports'], reg: ['IAIS', 'EIOPA', 'NAIC / state DOIs', 'PRA/FCA', 'BaFin', 'APRA', 'OSFI', 'NFRA', 'IRDAI', 'BMA'], std: ['IAIS ICPs', 'Solvency II', 'IFRS 17'], gaps: 'Treaty terms, recoverables, collateral, retrocession chains and underwriting files are confidential. Ratings are paid/licensed and link-out only.', regions: ['Global'], sectors: ['Insurance', 'Reinsurance'] },
    operational: { label: 'Operational & resilience', src: ['cpsc', 'nhtsa', 'federalRegister'], dirs: ['standards'], reg: ['OSHA / HSE', 'Consumer product regulators', 'Operational resilience supervisors'], std: ['ISO 22301', 'ISO 45001', 'ISO 31000'], gaps: 'Internal incidents, process failures, staffing and BCP test results are internal data.', regions: ['US (recalls live)', 'Global (link-out)'], sectors: ['All'] },
    technology: { label: 'Technology, cyber, data & AI', src: ['cisaKev', 'nvd', 'federalRegister'], dirs: ['cyber'], reg: ['CISA', 'ENISA', 'Data protection authorities (EDPB, ICO)', 'SEC (cyber disclosure)'], std: ['NIST CSF', 'ISO/IEC 27001', 'NIST SSDF', 'NIST AI RMF', 'CycloneDX/SPDX SBOM'], gaps: 'CVE records do not prove a supplier runs the affected version. Asset inventories and SBOMs are private. No live scanning.', regions: ['Global'], sectors: ['Technology', 'All'] },
    thirdparty: { label: 'Third-party & supply chain', src: ['gleif', 'usaspending', 'cpsc', 'cisaKev', 'worldbank'], dirs: ['entity', 'sanctions', 'trade', 'logistics'], reg: ['Sector regulators (outsourcing rules)', 'Customs authorities'], std: ['ISO 28000', 'ISO 31000', 'OECD Due Diligence Guidance'], gaps: 'Tier-N supplier maps, contracts, questionnaires and audits are internal. Public data rarely reveals customer–supplier relationships.', regions: ['Global'], sectors: ['All'] },
    trade: { label: 'Trade, customs & export control', src: ['federalRegister', 'worldbank'], dirs: ['trade', 'sanctions'], reg: ['Customs authorities', 'US BIS', 'EU DG TRADE', 'UK ECJU'], std: ['WCO HS nomenclature', 'Wassenaar Arrangement'], gaps: 'Trade data is aggregated and lags; no shipment-level visibility. HS classification is not customs advice.', regions: ['Global'], sectors: ['Goods'] },
    projects: { label: 'Procurement, contracts & projects', src: ['usaspending', 'federalRegister'], dirs: ['procurement', 'devBanks', 'ppp'], reg: ['Public procurement authorities', 'Audit offices', 'Competition authorities'], std: ['WTO GPA', 'World Bank Procurement Framework', 'FIDIC', 'NEC', 'ISO 21500'], gaps: 'Bids, pricing, evaluations and contract terms are confidential. Many portals are not open APIs; deadlines and amendments must be verified officially.', regions: ['US (awards live)', 'Global (link-out)'], sectors: ['Public sector', 'Construction', 'All'] },
    infrastructure: { label: 'Infrastructure & transport', src: ['usgs', 'openmeteo', 'nws', 'overpass', 'worldbank'], dirs: ['logistics', 'ppp', 'climate'], reg: ['Transport & energy regulators', 'Port authorities', 'Aviation authorities'], std: ['ISO 55000', 'ISO 22301'], gaps: 'Asset condition, maintenance and throughput data are mostly private. OSM features are community-mapped.', regions: ['Global'], sectors: ['Infrastructure', 'Energy', 'Transport'] },
    climate: { label: 'Climate & nature', src: ['usgs', 'openmeteo', 'nws', 'worldbank'], dirs: ['climate', 'esg'], reg: ['Financial supervisors (climate disclosure)', 'Environmental agencies'], std: ['ISSB IFRS S2', 'TCFD', 'TNFD'], gaps: 'Asset-level exposure requires verified locations; transition-risk data is largely modelled or paid.', regions: ['Global'], sectors: ['All'] },
    esg: { label: 'ESG & human rights', src: ['epa', 'worldbank', 'federalRegister'], dirs: ['esg', 'standards'], reg: ['Environmental agencies', 'Labour inspectorates', 'Customs (forced-labour enforcement)'], std: ['OECD Due Diligence Guidance', 'UNGPs', 'ILO conventions', 'GRI', 'ISSB'], gaps: 'ESG ratings are paid and not reproduced. Public records neither prove nor disprove misconduct.', regions: ['Global'], sectors: ['All'] },
    political: { label: 'Political & geopolitical', src: ['worldbank', 'gdelt', 'federalRegister'], dirs: ['sanctions', 'macro', 'regulatory'], reg: ['Foreign ministries', 'Sanctions authorities', 'Investment screening bodies'], std: ['OECD Guidelines for MNEs'], gaps: 'Conflict datasets (e.g. ACLED) require licences; media signals are noisy; no forecasts of political events.', regions: ['Global'], sectors: ['All'] },
    catastrophe: { label: 'Health disruption & catastrophe', src: ['usgs', 'openmeteo', 'nws'], dirs: ['climate', 'marketReports'], reg: ['Civil protection agencies', 'Meteorological services', 'Insurance supervisors'], std: ['Sendai Framework', 'ISO 22301'], gaps: 'Public event data does not confirm insured loss, supplier disruption, force majeure or claims liability.', regions: ['Global'], sectors: ['All'] }
  };

  const D = [];
  function d(id, name, group, def, why, o) {
    const g = G[group];
    D.push(
      Object.assign(
        { id, name, group, groupLabel: g.label, def, why, sub: [], ev: [], ins: [], proc: [], aliases: [] },
        { src: g.src, dirs: g.dirs, reg: g.reg, std: g.std, gaps: g.gaps, regions: g.regions, sectors: g.sectors },
        o || {}
      )
    );
  }

  // 1–4 Strategic & governance
  d('strategic', 'Strategic risk', 'strategy', 'Risk that business model, market position or major decisions fail to deliver objectives.', 'Frames counterparty viability, concentration and long-term supplier/insurer relationships.', { sub: ['Business model', 'Competitive disruption', 'M&A integration', 'Concentration'], ev: ['Annual reports', 'Material 8-K events', 'Segment disclosures'], ins: ['D&O'], proc: ['Strategic sourcing'] });
  d('reputational', 'Reputational risk', 'strategy', 'Risk of loss of trust among customers, regulators, investors or the public.', 'Adverse public events at suppliers, insurers or partners can transfer to your organization.', { sub: ['Adverse media', 'Stakeholder activism', 'Association risk'], ev: ['Media signals (noisy)', 'Enforcement releases', 'Litigation'], ins: ['Media liability', 'D&O'], aliases: ['adverse media', 'reputation'] });
  d('governance', 'Governance risk', 'strategy', 'Risk arising from weak board oversight, controls, ownership transparency or accountability.', 'Opaque ownership and weak controls are early indicators for fraud, sanctions and credit issues.', { sub: ['Beneficial ownership opacity', 'Board independence', 'Auditor changes', 'Related parties'], ev: ['GLEIF parent/child data', '8-K item 4.01/4.02', 'Proxy statements'], ins: ['D&O'], std: ['OECD Principles of Corporate Governance', 'ISO 37000'], src: ['gleif', 'sec', 'wikidata'] });
  d('conduct', 'Conduct risk', 'strategy', 'Risk that behaviour by firms or staff causes poor customer outcomes or market harm.', 'Key for financial counterparties, brokers and insurers regulated on conduct.', { sub: ['Mis-selling', 'Market abuse', 'Unfair treatment'], ev: ['FCA/SEC enforcement', 'Market conduct exams'], ins: ['Professional indemnity / E&O'], dirs: ['enforcement', 'insuranceRegulators'] });
  // 5–6 Integrity
  d('fraud', 'Fraud risk', 'integrity', 'Risk of intentional deception for gain, internally or by third parties.', 'Supplier, invoice, procurement and insurance fraud all rely on weak counterparty verification.', { sub: ['Procurement fraud', 'Invoice fraud', 'Claims fraud', 'Financial statement fraud'], ev: ['DOJ/SEC releases', 'Court records', 'Debarment lists'], ins: ['Crime / fidelity', 'D&O'], proc: ['Supplier onboarding'] });
  d('bribery-aml-sanctions', 'Bribery, corruption, AML & sanctions risk', 'integrity', 'Risk of involvement in bribery, money laundering, terrorist financing or sanctions breaches.', 'Strict-liability regimes make counterparty and jurisdiction screening essential; JAQA only links to official lists.', { sub: ['Sanctions exposure', 'PEP exposure', 'Bribery', 'Money laundering', 'Debarment'], ev: ['Official sanctions lists (link-out)', 'Debarment lists', 'Enforcement releases', 'WGI control-of-corruption'], ins: ['Political risk', 'Trade credit'], proc: ['Due diligence', 'Integrity pacts'], src: ['federalRegister', 'worldbank', 'courtlistener'], aliases: ['sanctions risk', 'aml risk', 'bribery risk', 'corruption risk', 'money laundering', 'debarment', 'sanctions'] });
  // 7–13 Legal/regulatory/compliance/tax
  d('legal', 'Legal risk', 'legal', 'Risk of loss from litigation, unenforceable contracts or legal liability.', 'Counterparty litigation and judgments signal disputes, liabilities and solvency pressure.', { sub: ['Litigation', 'Contract enforceability', 'IP disputes'], ev: ['Court dockets', 'Opinions', 'Judgments'], ins: ['General liability', 'Professional indemnity', 'D&O'], aliases: ['litigation risk'] });
  d('regulatory', 'Regulatory risk', 'legal', 'Risk that new or changed regulation affects operations, costs or permissions.', 'Regulatory change drives procurement specifications, insurance wordings and compliance costs.', { sub: ['New rules', 'Enforcement priorities', 'Licensing changes'], ev: ['Federal Register documents', 'EUR-Lex acts', 'Consultations'], ins: ['Regulatory fines cover (where insurable)'], aliases: ['regulatory change'] });
  d('compliance', 'Compliance risk', 'legal', 'Risk of failing to meet legal, regulatory or internal-policy obligations.', 'Supplier and insurer non-compliance can create second-order liability.', { sub: ['Regulatory breaches', 'Policy breaches', 'Reporting failures'], ev: ['Enforcement actions', 'EPA ECHO records'], std: ['ISO 37301'], src: ['federalRegister', 'epa'] });
  d('licensing', 'Licensing risk', 'legal', 'Risk that required licences, authorizations or registrations are missing, lapsed or revoked.', 'Insurers, brokers, MGAs and many suppliers must be authorized; registers are authoritative.', { sub: ['Insurance authorization', 'Financial services permissions', 'Operating permits'], ev: ['Regulator registers (FCA, EIOPA, NAIC)'], dirs: ['insuranceRegulators', 'regulatory'], ins: ['Broker/MGA authorization'] });
  d('tax', 'Tax risk', 'legal', 'Risk from tax disputes, changes in tax law or aggressive tax positions.', 'Tax disputes can weaken counterparties; JAQA does not provide tax advice.', { sub: ['Tax disputes', 'Tax law change', 'Withholding'], ev: ['Public filings (tax contingencies)', 'Regulatory documents'], dirs: ['regulatory'] });
  d('transfer-pricing', 'Transfer-pricing risk', 'legal', 'Risk that intra-group pricing is challenged by tax authorities.', 'Relevant to group structures and intercompany supply arrangements.', { sub: ['Intercompany pricing', 'Permanent establishment'], ev: ['Filing disclosures', 'OECD guidance (link-out)'], std: ['OECD Transfer Pricing Guidelines'] });
  d('customs-valuation', 'Customs-valuation risk', 'legal', 'Risk that declared customs values, origin or classification are challenged.', 'Affects landed cost, duties and penalties across supply chains.', { sub: ['Valuation', 'Origin', 'Classification'], ev: ['Tariff schedules', 'Customs rulings'], dirs: ['trade'], std: ['WTO Customs Valuation Agreement'] });
  // 14–24 Financial
  d('financial', 'Financial risk', 'financial', 'Umbrella for risks to earnings, capital and cash flows from financial exposures.', 'Counterparty financial health underpins supply continuity, claims-paying ability and contract performance.', { sub: ['Credit', 'Market', 'Liquidity'], ev: ['Public filings', 'Macro indicators'], ins: ['Trade credit', 'Surety'] });
  d('credit', 'Credit risk', 'financial', 'Risk that a counterparty fails to meet payment or performance obligations.', 'Core for receivables, supplier prepayments, reinsurance recoverables and guarantees.', { sub: ['Default', 'Downgrade (link-out)', 'Payment delays'], ev: ['8-K 1.03 / 2.04 items', 'Insolvency notices', 'Court records'], ins: ['Trade credit', 'Credit & surety'], src: ['sec', 'courtlistener'], aliases: ['credit risk', 'default risk'] });
  d('market', 'Market risk', 'financial', 'Risk of loss from movements in market prices and rates.', 'Drives input costs, collateral values and investment portfolios of insurers.', { sub: ['Equity', 'Rates', 'FX', 'Commodities', 'Spreads'], ev: ['Reference rates', 'Macro indicators'], src: ['ecb', 'worldbank'] });
  d('liquidity', 'Liquidity risk', 'financial', 'Risk of being unable to meet obligations as they fall due without unacceptable loss.', 'Liquidity stress at suppliers and brokers can precede disruption.', { sub: ['Funding liquidity', 'Market liquidity'], ev: ['Filings (current assets/liabilities)', 'Going-concern disclosures (link-out)'] });
  d('funding', 'Funding risk', 'financial', 'Risk that funding becomes unavailable or materially more expensive.', 'Affects project finance, PPP sponsors and highly leveraged counterparties.', { sub: ['Refinancing', 'Covenant pressure (public disclosures only)'], ev: ['8-K 2.04 items', 'Debt disclosures'] });
  d('fx', 'Currency / FX risk', 'financial', 'Risk from exchange-rate movements on costs, revenues, assets and liabilities.', 'Cross-border sourcing, premiums and claims in foreign currency.', { sub: ['Transaction', 'Translation', 'Economic'], ev: ['ECB reference rates', 'World Bank official exchange rate'], aliases: ['fx risk', 'currency risk', 'foreign exchange'] });
  d('interest-rate', 'Interest-rate risk', 'financial', 'Risk from changes in interest rates on value, income or funding costs.', 'Affects financing costs, discounting of liabilities and insurer asset values.', { sub: ['Repricing', 'Yield curve', 'Basis'], ev: ['Lending/real interest rates (World Bank)', 'Central bank link-outs'], aliases: ['interest rate risk', 'rates risk'] });
  d('commodity', 'Commodity risk', 'financial', 'Risk from price or availability changes in raw materials and energy.', 'Direct driver for category management, indexation clauses and hedging.', { sub: ['Energy', 'Metals', 'Agriculture'], ev: ['World Bank commodity price data (link-out)'], dirs: ['macro', 'trade'], aliases: ['commodity risk', 'raw material price'] });
  d('sovereign', 'Sovereign risk', 'financial', 'Risk that a government defaults, restructures or imposes measures affecting obligations.', 'Country exposure for suppliers, public buyers, PPPs and political-risk insurance.', { sub: ['Default', 'Restructuring', 'Transfer & convertibility'], ev: ['Government debt, reserves, current account (World Bank)', 'IMF country pages'], ins: ['Political risk', 'Trade credit'], aliases: ['sovereign risk', 'country risk'] });
  d('subnational-fiscal', 'Subnational fiscal risk', 'financial', 'Risk from fiscal stress at state, provincial or municipal level.', 'Public-sector buyers and PPP counterparties may be subnational.', { sub: ['Municipal payment delays', 'Budget stress'], ev: ['Official budget disclosures (link-out)'], gaps: 'Subnational fiscal data is fragmented and rarely machine-readable.' });
  d('counterparty', 'Counterparty risk', 'financial', 'Risk that the other party to a contract fails to perform.', 'Unifies credit, operational and legal exposure to a named counterparty.', { sub: ['Performance', 'Settlement', 'Pre-settlement'], ev: ['LEI records', 'Filings', 'Sanctions link-outs', 'Litigation'], src: ['gleif', 'sec', 'courtlistener', 'usaspending'], aliases: ['counterparty risk'] });
  // 25–27 + 82 Insurance
  d('insurance', 'Insurance risk', 'insurance', 'Risk that insurance protection is unavailable, inadequate or unrecoverable, and underwriting risk for insurers.', 'Informs placement strategy discussions with qualified brokers — JAQA gives no coverage advice.', { sub: ['Coverage gaps (advice needed)', 'Insurer financial strength (link-out)', 'Claims disputes'], ev: ['Regulator registers', 'Public filings', 'Market reports (link-out)'], ins: ['All lines'], aliases: ['insurance risk'] });
  d('reinsurance', 'Reinsurance risk', 'insurance', 'Risk that reinsurance is unavailable, mispriced or not recoverable.', 'Reinsurance security and recoverables are critical for cedants; much is confidential.', { sub: ['Recoverability', 'Counterparty concentration', 'Retrocession'], ev: ['Reinsurer filings', 'Regulator links', 'Rating link-outs'], ins: ['Treaty', 'Facultative', 'Retrocession'], aliases: ['reinsurance risk', 'reinsurance counterparty'] });
  d('pension', 'Pension / retirement risk', 'insurance', 'Risk from defined-benefit obligations, longevity and asset-liability mismatch (enterprise context only).', 'Large pension deficits can weigh on counterparty financial strength.', { sub: ['Funding deficits', 'Longevity', 'Buy-out/buy-in'], ev: ['Filing pension notes', 'Regulator (e.g. TPR, PBGC) link-outs'], src: ['sec'] });
  // 28–37 Operational
  d('operational', 'Operational risk', 'operational', 'Risk of loss from inadequate or failed processes, people, systems or external events.', 'Supplier and service-provider failures surface as operational events.', { sub: ['Process', 'People', 'Systems', 'External events'], ev: ['Recalls', 'Enforcement', 'Incident disclosures'] });
  d('process', 'Process risk', 'operational', 'Risk from poorly designed or executed business processes.', 'Quality failures at suppliers show up in recalls and warning letters.', { sub: ['Quality', 'Execution errors'], ev: ['Recalls', 'Regulatory notices'] });
  d('people', 'People risk', 'operational', 'Risk from workforce availability, capability, conduct or labour relations.', 'Strikes, labour shortages and safety incidents drive supply disruption.', { sub: ['Labour disputes', 'Key-person', 'Skills'], ev: ['Media signals', 'ILO resources'], dirs: ['esg'], ins: ['Employers liability', 'Workers compensation'], src: ['gdelt'] });
  d('systems', 'Systems risk', 'operational', 'Risk from failure or inadequacy of IT and operational systems.', 'Outages at critical vendors cascade to customers.', { sub: ['Outages', 'Capacity', 'Legacy systems'], ev: ['CISA advisories', 'Incident disclosures (8-K 1.05)'], src: ['cisaKev', 'sec'], ins: ['Cyber', 'Business interruption'] });
  d('change-management', 'Change-management risk', 'operational', 'Risk from poorly managed transformations, migrations or reorganizations.', 'Large programmes at vendors can degrade service levels.', { sub: ['Migration', 'Reorganization'], ev: ['8-K 2.05 (exit/disposal costs)'], src: ['sec'] });
  d('business-continuity', 'Business-continuity risk', 'operational', 'Risk that critical activities cannot continue during disruption.', 'Central to supplier resilience reviews and BI insurance.', { sub: ['Single points of failure', 'Recovery capability'], ev: ['Event signals near facilities', 'BCP standards'], std: ['ISO 22301'], ins: ['Business interruption', 'Contingent BI'], src: ['usgs', 'openmeteo', 'nws'], aliases: ['business continuity', 'bcp'] });
  d('disaster-recovery', 'Disaster-recovery risk', 'operational', 'Risk that IT and data cannot be restored within tolerance after disruption.', 'Vendor DR capability matters for critical outsourcing.', { sub: ['RTO/RPO failure', 'Backup failure'], ev: ['Standards link-outs'], std: ['ISO/IEC 27031', 'ISO 22301'], ins: ['Cyber', 'Business interruption'], aliases: ['disaster recovery', 'dr'] });
  d('health-safety', 'Health-and-safety risk', 'operational', 'Risk of injury or ill-health to workers, contractors or the public.', 'Safety failures create liability, stoppages and reputational damage.', { sub: ['Workplace injury', 'Process safety', 'Contractor safety'], ev: ['OSHA/HSE records (link-out)', 'Recalls'], std: ['ISO 45001'], ins: ['Employers liability', 'Workers compensation', 'General liability'] });
  d('product-safety', 'Product-safety risk', 'operational', 'Risk that products cause harm, leading to recalls, liability and regulatory action.', 'Recalls affect supplier selection, product liability and recall insurance.', { sub: ['Consumer products', 'Vehicles', 'Components'], ev: ['CPSC recalls', 'NHTSA recalls'], ins: ['Product liability', 'Product recall'], proc: ['Quality assurance'], src: ['cpsc', 'nhtsa'], aliases: ['product safety', 'recall risk', 'product recall'] });
  d('service-disruption', 'Service-disruption risk', 'operational', 'Risk that a critical service becomes unavailable.', 'Links operational resilience rules to third-party dependencies.', { sub: ['Outage', 'Capacity shortfall'], ev: ['Incident disclosures', 'Event signals'], ins: ['Business interruption', 'Cyber'] });
  // 38–42 Technology
  d('technology', 'Technology risk', 'technology', 'Risk from technology failure, obsolescence or poor technology management.', 'Vendor technology choices influence your attack surface and resilience.', { sub: ['Obsolescence', 'Vendor lock-in'], ev: ['Vendor advisories', 'KEV entries'] });
  d('cyber', 'Cyber risk', 'technology', 'Risk of loss from malicious or accidental compromise of systems and data.', 'Supplier and platform vulnerabilities are a major third-party loss driver.', { sub: ['Exploited vulnerabilities', 'Ransomware', 'Supply-chain compromise'], ev: ['CISA KEV', 'NVD CVE records', '8-K item 1.05 disclosures'], ins: ['Cyber'], proc: ['IT / software / cloud'], src: ['cisaKev', 'nvd', 'sec'], aliases: ['cyber risk', 'cybersecurity', 'ransomware'] });
  d('data-privacy', 'Data-privacy risk', 'technology', 'Risk of unlawful processing or breach of personal data.', 'Processors and sub-processors carry regulatory exposure you inherit.', { sub: ['Breach', 'Unlawful processing', 'Cross-border transfer'], ev: ['DPA decisions (link-out)'], ins: ['Cyber'], std: ['GDPR', 'ISO/IEC 27701'], aliases: ['privacy risk', 'gdpr'] });
  d('ai-model', 'AI / algorithmic / model risk', 'technology', 'Risk from errors, bias or misuse of models and AI systems.', 'Vendors increasingly embed AI; governance frameworks are emerging.', { sub: ['Model error', 'Bias', 'AI regulation'], ev: ['NIST AI RMF', 'EU AI Act (link-out)', 'Federal Register documents'], std: ['NIST AI RMF', 'ISO/IEC 42001'], ins: ['Technology E&O'], aliases: ['ai risk', 'model risk', 'algorithmic risk'] });
  d('software-supply-chain', 'Software supply-chain risk', 'technology', 'Risk from compromised or vulnerable third-party software and dependencies.', 'Open-source and vendor components propagate vulnerabilities (e.g. CVE-2024-3094).', { sub: ['Dependency compromise', 'Build pipeline', 'SBOM gaps'], ev: ['KEV', 'NVD', 'GitHub advisories (link-out)'], std: ['NIST SSDF', 'CycloneDX', 'SPDX', 'OpenSSF Scorecard'], ins: ['Cyber'], src: ['cisaKev', 'nvd'], aliases: ['software supply chain', 'sbom'] });
  // 43–47 Third party & supply chain
  d('third-party', 'Third-party risk', 'thirdparty', 'Risk arising from any external party your organization relies on or interacts with.', 'Umbrella for vendor, supplier, broker, insurer and partner exposure.', { sub: ['Onboarding', 'Ongoing monitoring', 'Offboarding'], ev: ['Entity resolution', 'Sanctions link-outs', 'Filings', 'Awards'], aliases: ['third party risk', 'tprm'] });
  d('vendor', 'Vendor risk', 'thirdparty', 'Risk from providers of services and technology.', 'Critical vendors (cloud, claims platforms, TPAs) need layered evidence.', { sub: ['Concentration', 'Performance', 'Security'], ev: ['KEV/NVD', 'Awards', 'Filings'], src: ['gleif', 'cisaKev', 'usaspending'], aliases: ['vendor risk'] });
  d('supplier', 'Supplier risk', 'thirdparty', 'Risk from providers of goods and materials.', 'Supplier failure drives shortages, quality issues and cost spikes.', { sub: ['Financial', 'Quality', 'Geographic concentration'], ev: ['LEI', 'Recalls', 'Country context'], src: ['gleif', 'cpsc', 'worldbank'], aliases: ['supplier risk'] });
  d('supply-chain', 'Supply-chain risk', 'thirdparty', 'Risk of disruption anywhere from raw materials to delivery.', 'Connects geography, logistics, trade and counterparty evidence.', { sub: ['Disruption', 'Single sourcing', 'Tier-N opacity'], ev: ['Events near ports/facilities', 'Trade context', 'LPI'], src: ['usgs', 'openmeteo', 'worldbank', 'gleif'], aliases: ['supply chain risk', 'supply chain disruption'] });
  d('logistics', 'Logistics risk', 'thirdparty', 'Risk from transport, warehousing and distribution failures.', 'Port congestion, weather and strikes delay flows.', { sub: ['Port disruption', 'Carrier failure', 'Route closure'], ev: ['LPI', 'Weather alerts', 'Seismic events', 'OSM port features'], ins: ['Cargo', 'Marine'], src: ['worldbank', 'usgs', 'openmeteo', 'nws', 'overpass'], aliases: ['logistics risk', 'port risk', 'shipping risk'] });
  // 48–50 Trade
  d('trade', 'Trade risk', 'trade', 'Risk from changes in trade flows, policy and market access.', 'Tariffs and trade measures reshape category strategy.', { sub: ['Market access', 'Trade remedies'], ev: ['Trade % of GDP', 'Tariff schedules'], ins: ['Trade credit', 'Political risk'] });
  d('customs-tariff', 'Customs / tariff risk', 'trade', 'Risk from tariff changes, duties and customs procedures.', 'Direct landed-cost and compliance impact.', { sub: ['Tariff changes', 'Anti-dumping', 'Customs holds'], ev: ['Federal Register tariff notices', 'TARIC/HTS link-outs'], aliases: ['tariff risk', 'customs risk', 'tariffs'] });
  d('export-control', 'Export-control risk', 'trade', 'Risk of breaching controls on dual-use/military items, end users or destinations.', 'Entity List and end-use controls affect suppliers and customers.', { sub: ['Entity List', 'Dual-use', 'End-use'], ev: ['BIS rules (Federal Register)', 'Consolidated Screening List (link-out)'], aliases: ['export control', 'entity list', 'dual-use'] });
  // 51–54 Projects
  d('procurement', 'Procurement risk', 'projects', 'Risk in sourcing processes: integrity, competition, supplier selection and compliance.', 'Public procurement is heavily regulated; integrity failures carry debarment.', { sub: ['Integrity', 'Competition', 'Specification'], ev: ['Award records', 'Debarment lists', 'Procurement rules'], proc: ['All categories'], aliases: ['procurement risk'] });
  d('contract', 'Contract risk', 'projects', 'Risk from contract terms, performance and enforceability.', 'Contract terms are confidential; public awards show only metadata.', { sub: ['Performance', 'Variations', 'Termination'], ev: ['Award modifications (USAspending)', 'Court records'], src: ['usaspending', 'courtlistener'] });
  d('project-program', 'Project / program / portfolio risk', 'projects', 'Risk that projects miss scope, schedule, cost or benefit targets.', 'Large programmes rely on contractor performance and funding.', { sub: ['Schedule', 'Cost overrun', 'Benefits'], ev: ['Award periods & modifications'], std: ['ISO 21500', 'ISO 21502'] });
  d('construction', 'Construction / capital-project risk', 'projects', 'Risk from design, construction and commissioning of physical assets.', 'Contractor insolvency, ground conditions and weather drive losses.', { sub: ['Contractor failure', 'Delay', 'Defects'], ev: ['Awards', 'Weather/seismic', 'Litigation'], ins: ['Construction all risks', 'Engineering', 'Surety'], std: ['FIDIC', 'NEC'], src: ['usaspending', 'usgs', 'openmeteo'] });
  // 55–60 Infrastructure
  d('infrastructure', 'Infrastructure risk', 'infrastructure', 'Risk of failure or disruption of critical physical infrastructure.', 'Shared infrastructure failures cascade across many counterparties.', { sub: ['Grid', 'Telecoms', 'Transport networks'], ev: ['Event signals', 'PPP databases'], ins: ['Property', 'Business interruption'] });
  d('energy', 'Energy risk', 'infrastructure', 'Risk from energy supply, price and transition.', 'Energy-intensive suppliers are exposed to price spikes and outages.', { sub: ['Supply', 'Price', 'Transition'], ev: ['Commodity link-outs', 'Regulatory notices'], ins: ['Energy onshore/offshore'], aliases: ['energy risk'] });
  d('water', 'Water risk', 'infrastructure', 'Risk from water scarcity, quality or flooding affecting operations.', 'Semiconductors, food and chemicals are water-intensive.', { sub: ['Scarcity', 'Quality', 'Flooding'], ev: ['Precipitation forecasts', 'Climate portals'], dirs: ['climate'] });
  d('transport', 'Transport risk', 'infrastructure', 'Risk of disruption to road, rail and multimodal transport.', 'Inland logistics links ports to plants.', { sub: ['Road', 'Rail', 'Intermodal'], ev: ['Weather alerts', 'Recalls (vehicles)'], src: ['nws', 'openmeteo', 'nhtsa'] });
  d('aviation', 'Aviation risk', 'infrastructure', 'Risk affecting air transport, airports and aircraft.', 'Air freight for high-value goods and staff travel.', { sub: ['Airport disruption', 'Airworthiness'], ev: ['Weather', 'Regulatory notices (FAA via Federal Register)'], ins: ['Aviation'], src: ['openmeteo', 'federalRegister'] });
  d('maritime', 'Maritime risk', 'infrastructure', 'Risk affecting ships, ports, canals and sea routes.', 'Most global trade moves by sea; chokepoints matter.', { sub: ['Port congestion', 'Chokepoints', 'Piracy', 'Vessel casualty'], ev: ['OSM port features', 'Seismic/weather signals', 'Media signals'], ins: ['Marine', 'Cargo', 'Hull'], src: ['overpass', 'usgs', 'openmeteo', 'gdelt'], aliases: ['maritime risk', 'marine risk'] });
  // 61–63 Climate & nature
  d('climate-physical', 'Climate physical risk', 'climate', 'Risk from acute and chronic physical climate hazards.', 'Drives facility, supplier and insured-loss exposure.', { sub: ['Acute hazards', 'Chronic shifts'], ev: ['Forecasts', 'Seismic/weather events', 'Climate portals'], ins: ['Property', 'Parametric', 'Business interruption'], aliases: ['climate physical risk', 'physical climate risk', 'climate risk'] });
  d('climate-transition', 'Climate transition risk', 'climate', 'Risk from policy, technology, market and legal shifts toward a low-carbon economy.', 'Carbon pricing and disclosure rules reshape suppliers and portfolios.', { sub: ['Carbon pricing', 'Disclosure', 'Stranded assets'], ev: ['Regulatory documents', 'Disclosure standards'], src: ['federalRegister'], aliases: ['transition risk'] });
  d('nature', 'Nature / biodiversity risk', 'climate', 'Risk from dependencies and impacts on nature and ecosystems.', 'Agricultural and extractive supply chains depend on ecosystem services.', { sub: ['Deforestation', 'Water ecosystems', 'Biodiversity loss'], ev: ['TNFD resources', 'Environmental records'], std: ['TNFD'], src: ['epa'], aliases: ['biodiversity risk', 'nature risk', 'deforestation'] });
  // 64–66 ESG
  d('esg', 'ESG risk', 'esg', 'Environmental, social and governance risks affecting value or stakeholders.', 'Customers, lenders and insurers increasingly require ESG due diligence.', { sub: ['Environmental', 'Social', 'Governance'], ev: ['EPA ECHO', 'WGI', 'Modern slavery registers'], aliases: ['esg risk'] });
  d('human-rights', 'Human-rights risk', 'esg', 'Risk of causing, contributing to or being linked to human-rights harms.', 'Mandatory due-diligence laws are expanding.', { sub: ['Labour rights', 'Community impacts', 'Security forces'], ev: ['UNGPs', 'OECD guidance', 'CBP WROs'], aliases: ['human rights risk'] });
  d('modern-slavery', 'Modern-slavery risk', 'esg', 'Risk of forced labour, trafficking or child labour in operations or supply chains.', 'Import bans and statements regimes create legal exposure.', { sub: ['Forced labour', 'Child labour', 'Trafficking'], ev: ['UK/Australia registers', 'DOL goods list', 'UFLPA Entity List'], proc: ['Supplier due diligence'], aliases: ['modern slavery risk', 'modern slavery', 'forced labour', 'forced labor', 'child labour'] });
  // 67–72 Political
  d('political', 'Political risk', 'political', 'Risk from government actions or political instability affecting operations.', 'Country exposure for suppliers, projects and investments.', { sub: ['Policy change', 'Instability'], ev: ['WGI political stability', 'Sanctions'], ins: ['Political risk'], aliases: ['political risk'] });
  d('geopolitical', 'Geopolitical risk', 'political', 'Risk from inter-state tensions, sanctions and conflict.', 'Sanctions and trade measures shift quickly.', { sub: ['Sanctions escalation', 'Trade blocs', 'Chokepoints'], ev: ['Federal Register sanctions rules', 'Media signals'], aliases: ['geopolitical risk', 'geopolitics'] });
  d('conflict-protest', 'Conflict / protest risk', 'political', 'Risk from armed conflict, civil unrest and protests.', 'Physical security, logistics and staff safety.', { sub: ['Armed conflict', 'Civil unrest', 'Strikes'], ev: ['Media signals', 'ACLED (link-out)'], ins: ['Political violence', 'Terrorism'], aliases: ['conflict risk', 'unrest', 'protest'] });
  d('election', 'Election / regime-change risk', 'political', 'Risk of policy discontinuity around elections or regime change.', 'Contract, licence and tax regime continuity.', { sub: ['Policy discontinuity', 'Contested outcomes'], ev: ['WGI voice & accountability', 'Media signals'] });
  d('expropriation', 'Expropriation / nationalization risk', 'political', 'Risk of seizure of assets or forced transfer by the state.', 'Relevant for PPPs, concessions and foreign investment.', { sub: ['Direct expropriation', 'Creeping expropriation'], ev: ['WGI rule of law', 'Investment treaty resources'], ins: ['Political risk'] });
  d('currency-control', 'Currency-control risk', 'political', 'Risk of restrictions on currency convertibility or transfer.', 'Can block payments to suppliers and repatriation.', { sub: ['Convertibility', 'Transfer'], ev: ['IMF AREAER (link-out)', 'Reserves in months of imports'], ins: ['Political risk (CI/transfer)'], dirs: ['macro'], aliases: ['currency controls', 'capital controls'] });
  // 73–81 Catastrophe
  d('pandemic', 'Pandemic / epidemic disruption risk', 'catastrophe', 'Enterprise disruption from outbreaks (operational context only; not health advice).', 'Workforce, demand and logistics disruption.', { sub: ['Workforce absence', 'Border closures'], ev: ['Official public-health notices (link-out)'], gaps: 'JAQA is not a health tool and processes no health data.', aliases: ['pandemic', 'epidemic'] });
  d('catastrophe', 'Catastrophe risk', 'catastrophe', 'Risk of large, low-frequency loss events, natural or man-made.', 'Drives property, BI and reinsurance programme needs.', { sub: ['Natural catastrophe', 'Man-made catastrophe'], ev: ['Seismic/weather events', 'Cat loss reports (link-out)'], ins: ['Property cat', 'Reinsurance', 'Cat bonds'], aliases: ['cat risk', 'nat cat', 'catastrophe'] });
  d('earthquake', 'Earthquake risk', 'catastrophe', 'Risk of loss from seismic shaking, liquefaction and tsunami.', 'Concentrated manufacturing regions are seismically exposed.', { sub: ['Shaking', 'Tsunami'], ev: ['USGS events'], ins: ['Property (earthquake)'], src: ['usgs'], aliases: ['earthquake', 'seismic'] });
  d('flood', 'Flood risk', 'catastrophe', 'Risk of loss from riverine, pluvial or coastal flooding.', 'Most common natural hazard affecting facilities.', { sub: ['Riverine', 'Pluvial', 'Coastal'], ev: ['Precipitation forecasts', 'NWS alerts'], ins: ['Property (flood)'], src: ['openmeteo', 'nws'], aliases: ['flood', 'flooding'] });
  d('storm', 'Storm risk', 'catastrophe', 'Risk from tropical cyclones, windstorms and severe convective storms.', 'Ports and coastal plants are highly exposed.', { sub: ['Tropical cyclone', 'Windstorm', 'Hail'], ev: ['Wind-gust forecasts', 'NWS alerts', 'NHC (link-out)'], ins: ['Property (windstorm)', 'Marine'], src: ['openmeteo', 'nws'], aliases: ['storm', 'hurricane', 'typhoon', 'cyclone'] });
  d('wildfire', 'Wildfire risk', 'catastrophe', 'Risk of loss from wildfires and smoke.', 'Affects facilities, power grids and air quality.', { sub: ['Fire spread', 'Smoke', 'Power shutoffs'], ev: ['NASA FIRMS (link-out)', 'NWS fire weather alerts'], ins: ['Property (wildfire)'], src: ['nws'], aliases: ['wildfire', 'bushfire'] });
  d('heat', 'Heat risk', 'catastrophe', 'Risk from extreme heat on people, equipment and processes.', 'Worker safety and energy demand.', { sub: ['Heatwaves', 'Cooling failure'], ev: ['Temperature forecasts', 'NWS heat alerts'], src: ['openmeteo', 'nws'], aliases: ['heatwave', 'extreme heat'] });
  d('drought', 'Drought risk', 'catastrophe', 'Risk from prolonged water deficit.', 'Agriculture, hydropower and river transport.', { sub: ['Agricultural', 'Hydrological'], ev: ['Climate portals (link-out)'], aliases: ['drought'] });
  d('sea-level', 'Sea-level-rise risk', 'catastrophe', 'Chronic risk from rising sea levels and coastal erosion.', 'Long-dated port and coastal asset exposure.', { sub: ['Coastal inundation', 'Erosion'], ev: ['Climate portals (link-out)'], aliases: ['sea level rise'] });
  d('insurance-market', 'Insurance-market capacity / pricing / solvency risk', 'insurance', 'Risk that insurance/reinsurance capacity shrinks, pricing hardens or carriers weaken (public-source evidence only).', 'Affects renewal strategy; decisions require qualified brokers and carriers.', { sub: ['Capacity', 'Pricing cycle', 'Carrier solvency (link-out)'], ev: ['Market reports (link-out)', 'Regulator registers', 'Public filings'], ins: ['All lines'], aliases: ['insurance solvency risk', 'insurance market', 'hard market', 'insurance capacity', 'insurer solvency'] });

  /* ------------------------ Finance Risk Universe ------------------------ */
  const F = [];
  function f(id, name, def, rel, o) {
    F.push(Object.assign({ id, name, def, rel, sub: [], src: ['sec', 'gleif'], dirs: ['macro'], ev: [], gaps: 'Private and confidential financial data is not public.', ins: [], proc: [], reg: ['Securities & banking regulators'], std: [], regions: ['Global'], sectors: ['All'], aliases: [] }, o || {}));
  }
  f('fin-fragility', 'Counterparty financial fragility', 'Public evidence that a counterparty may be under financial stress.', 'Credit, procurement and insurance teams use it to prioritize human review.', { sub: ['Late filings', 'Restatements', 'Going-concern language', 'Accelerated obligations'], ev: ['8-K items 1.03/2.04/4.02', 'NT 10-K/Q', 'Insolvency notices', 'Court records'], src: ['sec', 'gleif', 'courtlistener'], dirs: ['insolvency', 'lien'], ins: ['Trade credit', 'Surety'], aliases: ['counterparty financial fragility', 'financial fragility', 'financial distress', 'public filing stress'] });
  f('fin-credit', 'Credit risk', 'Risk that obligations are not paid or performed.', 'Receivables, prepayments, guarantees, recoverables.', { sub: ['Default', 'Downgrade (link-out)'], ev: ['Filings', 'Rating link-outs'], dirs: ['insolvency', 'macro'], ins: ['Trade credit'] });
  f('fin-bond', 'Public debt / bond issuer risk', 'Risk associated with issuers of publicly traded debt.', 'Treasury and investment teams monitor issuer disclosures.', { sub: ['Issuer events', 'Covenant disclosures'], ev: ['8-K', '10-K/20-F'], dirs: ['macro'] });
  f('fin-opacity', 'Private-company financial opacity', 'Lack of public financial information for private entities.', 'Most suppliers and many brokers/MGAs are private; gaps must be closed with direct requests.', { sub: ['No filings', 'Limited registry data'], ev: ['LEI records', 'Registry link-outs'], src: ['gleif'], dirs: ['entity'], gaps: 'Private-company financial statements are often unavailable or paid. Missing data does not indicate health or distress.', aliases: ['private company'] });
  f('fin-insolvency', 'Insolvency / restructuring risk', 'Risk of formal insolvency, administration or restructuring.', 'Critical for supplier continuity and contract enforcement.', { sub: ['Bankruptcy', 'Administration', 'Schemes of arrangement'], ev: ['Bankruptcy dockets', 'Gazette notices', '8-K 1.03'], src: ['courtlistener', 'sec'], dirs: ['insolvency'], aliases: ['insolvency', 'bankruptcy', 'receivership', 'liquidation', 'administration', 'insolvency registry'] });
  f('fin-liens', 'Lien / judgment / secured creditor risk', 'Risk from secured claims, liens and judgments on counterparty assets.', 'Signals encumbrance and creditor pressure.', { sub: ['UCC filings', 'Charges', 'Tax liens', 'Judgments'], ev: ['UCC/charges registers (link-out)', 'Court records'], src: ['courtlistener'], dirs: ['lien'], gaps: 'Lien registries are jurisdiction-specific, often fee-based and delayed; name matching is ambiguous.', aliases: ['lien', 'ucc', 'judgment', 'lien judgment', 'tax lien'] });
  f('fin-market', 'Market risk', 'Risk from market price movements.', 'Input costs, portfolio values, collateral.', { ev: ['Reference rates', 'Indicators'], src: ['ecb', 'worldbank'] });
  f('fin-rates', 'Interest-rate risk', 'Risk from changes in interest rates.', 'Financing costs and liability discounting.', { ev: ['Lending & real interest rates', 'Central bank link-outs'], src: ['worldbank'], aliases: ['interest rate risk'] });
  f('fin-fx', 'FX risk', 'Risk from exchange-rate movements.', 'Cross-border contracts, premiums, claims.', { ev: ['ECB reference rates', 'Official exchange rates'], src: ['ecb', 'worldbank'], aliases: ['fx risk', 'currency risk'] });
  f('fin-commodity', 'Commodity risk', 'Risk from commodity price and availability.', 'Category management and indexation.', { ev: ['Commodity price link-outs'], src: ['worldbank'], dirs: ['macro', 'trade'], aliases: ['commodity risk'] });
  f('fin-equity', 'Equity market stress context', 'Context on equity market conditions (link-out).', 'Listed counterparties and insurer asset portfolios.', { ev: ['Exchange / index link-outs'], src: [], gaps: 'Real-time market data is licensed; link-out only.' });
  f('fin-cds', 'Credit spread / default swap context', 'Market-implied credit context (link-out only).', 'Used by treasury and credit teams; data is licensed.', { src: [], ev: ['Licensed data (link-out only)'], dirs: ['macro'], gaps: 'CDS and spread data are licensed; never reproduced.' });
  f('fin-liquidity', 'Liquidity risk', 'Risk of being unable to meet short-term obligations.', 'Supplier payment ability and broker client-money handling.', { ev: ['Current assets/liabilities (filings)'] });
  f('fin-funding', 'Funding risk', 'Risk that funding is unavailable or costly.', 'Project sponsors and leveraged counterparties.', { ev: ['8-K 2.04', 'Debt disclosures'] });
  f('fin-treasury', 'Treasury exposure context', 'Context for exposures managed by treasury (public data only).', 'Actual exposure requires internal data JAQA never accepts.', { src: ['ecb', 'worldbank'], gaps: 'Actual exposure requires internal contracts, debt schedules, payables/receivables and hedge data.' });
  f('fin-sovereign', 'Sovereign financial risk', 'Risk from a sovereign’s fiscal and external position.', 'Country exposure for trade, PPPs and insurance.', { ev: ['Debt, reserves, current account (World Bank)', 'IMF link-outs'], src: ['worldbank'], ins: ['Political risk'], aliases: ['sovereign risk'] });
  f('fin-subnational', 'Subnational fiscal risk', 'Fiscal stress at state/municipal level.', 'Public-sector buyers and concession grantors.', { src: [], ev: ['Official budget disclosures (link-out)'] });
  f('fin-banking', 'Banking sector stability context', 'Context on banking-system health.', 'Counterparty banks, guarantees and letters of credit.', { ev: ['NPL ratio, bank capital (World Bank)', 'BIS/FSB link-outs'], src: ['worldbank'] });
  f('fin-payments', 'Payment / settlement system risk context', 'Context on payment and settlement infrastructure.', 'Cross-border payments to suppliers.', { src: [], ev: ['BIS CPMI resources (link-out)'] });
  f('fin-crime', 'Financial crime risk', 'Risk of fraud, money laundering or terrorist financing.', 'AML/CTF programmes rely on systems of record, not JAQA.', { src: ['federalRegister', 'courtlistener'], dirs: ['enforcement', 'sanctions'], ev: ['Enforcement releases', 'FATF lists'], aliases: ['financial crime', 'aml'] });
  f('fin-sanctions', 'Sanctions / debarment risk', 'Risk of dealing with sanctioned or debarred parties.', 'No hit ≠ clear; screening systems of record required.', { src: ['federalRegister'], dirs: ['sanctions'], ev: ['Official lists (link-out)'], aliases: ['sanctions list search', 'debarment risk'] });
  f('fin-enforcement', 'AML / fraud / enforcement link-outs', 'Official enforcement sources for financial misconduct.', 'Evidence assembly for compliance review.', { src: ['courtlistener'], dirs: ['enforcement'] });
  f('fin-ins-strength', 'Insurance financial strength risk', 'Risk that an insurer cannot meet obligations to policyholders.', 'Insurer selection is for qualified brokers; JAQA links regulators and ratings.', { src: ['gleif', 'sec'], dirs: ['insuranceRegulators', 'ratingAgencies'], ins: ['All lines'], aliases: ['insurance financial strength', 'insurer financial strength'] });
  f('fin-reins-cpty', 'Reinsurance counterparty risk', 'Risk that a reinsurer cannot pay recoverables.', 'Recoverables and collateral are confidential; public signals only.', { src: ['gleif', 'sec'], dirs: ['insuranceRegulators', 'ratingAgencies', 'marketReports'], aliases: ['reinsurance counterparty risk'] });
  f('fin-broker', 'Broker / MGA / TPA financial & regulatory risk', 'Risk from intermediaries handling premiums, claims or authority.', 'Client money and delegated authority exposures.', { src: ['gleif'], dirs: ['insuranceRegulators'] });
  f('fin-captive', 'Captive / protected cell public registry context', 'Public registry context for captives and cells.', 'Captive managers and risk managers verifying domicile status.', { src: ['gleif'], dirs: ['insuranceRegulators'], gaps: 'Captive financials and cell/member data are confidential.' });
  f('fin-ils', 'ILS / cat bond public document context', 'Public documents for insurance-linked securities.', 'Investors and cedants — no investment advice or trigger interpretation.', { src: ['gleif'], dirs: ['marketReports', 'insuranceRegulators'], aliases: ['ils', 'cat bond'] });
  f('fin-pension', 'Pension / asset-liability public context', 'Public disclosures on pension obligations.', 'Large deficits can weigh on counterparty strength.', { src: ['sec'] });
  f('fin-trade-finance', 'Trade finance exposure context', 'Public context for letters of credit, guarantees and receivables finance.', 'No shipment-level or transaction data.', { src: ['worldbank', 'ecb'], dirs: ['trade', 'macro'], ins: ['Trade credit'], aliases: ['trade finance exposure', 'trade finance'] });
  f('fin-project', 'Project / PPP / infrastructure finance context', 'Public context on project finance and PPP arrangements.', 'No bankability or covenant determinations.', { src: ['usaspending', 'worldbank'], dirs: ['ppp', 'devBanks'], aliases: ['project finance risk', 'project finance'] });
  f('fin-digital', 'Digital asset / crypto market context', 'Regulatory and market context for digital assets (link-out only).', 'Highly volatile; no investment advice.', { src: [], dirs: ['digitalAssets'], aliases: ['crypto', 'digital asset', 'stablecoin'] });
  f('fin-accounting', 'Accounting / restatement / audit-risk signals', 'Public signals of accounting or audit issues.', 'Restatements and auditor changes are strong review triggers.', { sub: ['8-K 4.01 auditor change', '8-K 4.02 non-reliance', 'Late filings'], src: ['sec'], ev: ['8-K items', 'NT filings'], aliases: ['restatement', 'auditor change', 'going concern'] });

  /* ----------------------------- insurance ----------------------------- */
  const INSURANCE_LINES = [
    ['property', 'Property', ['catastrophe', 'flood', 'storm', 'earthquake', 'wildfire']], ['casualty', 'Casualty', ['legal']], ['general-liability', 'General liability', ['legal', 'health-safety']],
    ['product-liability', 'Product liability', ['product-safety']], ['employers-liability', 'Employers liability', ['health-safety', 'people']], ['workers-comp', 'Workers compensation', ['health-safety']],
    ['motor', 'Motor / auto', ['transport']], ['marine', 'Marine', ['maritime', 'logistics']], ['cargo', 'Cargo', ['logistics', 'maritime']], ['hull', 'Hull', ['maritime']], ['aviation', 'Aviation', ['aviation']],
    ['engineering', 'Engineering', ['construction']], ['construction', 'Construction', ['construction']], ['energy', 'Energy onshore / offshore', ['energy']], ['credit-surety', 'Credit and surety', ['credit', 'counterparty']],
    ['political-risk', 'Political risk', ['political', 'expropriation', 'currency-control']], ['terrorism', 'Terrorism', ['conflict-protest']], ['cyber', 'Cyber', ['cyber', 'data-privacy', 'software-supply-chain']],
    ['pi-eo', 'Professional indemnity / E&O', ['conduct', 'legal']], ['do', 'Directors and officers (D&O)', ['governance', 'strategic']], ['media', 'Media / piracy', ['reputational']],
    ['environmental', 'Environmental impairment', ['esg', 'nature']], ['recall', 'Product recall', ['product-safety']], ['trade-credit', 'Trade credit', ['credit', 'sovereign']], ['bond', 'Bond / guarantee', ['contract']],
    ['life', 'Life', []], ['health', 'Health (enterprise context only)', ['pandemic']], ['annuities', 'Annuities', ['pension']], ['pension', 'Pension / retirement (enterprise context)', ['pension']], ['travel', 'Travel', ['aviation']],
    ['parametric', 'Parametric insurance', ['catastrophe', 'climate-physical']], ['ils', 'Insurance-linked securities / cat bonds', ['catastrophe', 'reinsurance']], ['reinsurance', 'Reinsurance (treaty / facultative / retrocession)', ['reinsurance', 'insurance-market']]
  ].map(([id, name, risks]) => ({ id, name, risks }));

  const INSURANCE_ENTITY_TYPES = [
    ['insurer', 'Insurer', /\b(insurance|assurance|insurer|underwriters?|versicherung|assurances|seguros|assicurazioni|mutual)\b/i],
    ['reinsurer', 'Reinsurer', /\b(reinsurance|reinsurer|re\b|rück|ruck|réassurance|retrocession(aire)?)\b/i],
    ['broker', 'Broker', /\b(broker(s|age)?|intermediar(y|ies))\b/i],
    ['mga', 'MGA', /\b(mga|managing general (agent|underwriter))\b/i],
    ['captive', 'Captive / protected cell / RRG', /\b(captive|protected cell|pcc|risk retention group|rrg)\b/i],
    ['ils', 'ILS / cat bond vehicle', /\b(ils|cat(astrophe)? bonds?|sidecar|insurance[- ]linked)\b/i],
    ['tpa', 'TPA / claims administrator', /\b(tpa|third[- ]party administrator|claims administrat(or|ion))\b/i],
    ['syndicate', 'Lloyd’s syndicate', /\b(syndicate|lloyd'?s)\b/i]
  ].map(([id, name, re]) => ({ id, name, re }));

  /* ---------------------------- procurement ---------------------------- */
  const PROCUREMENT_TYPES = ['Open tender', 'Restricted tender', 'RFP', 'RFQ', 'ITT', 'EOI', 'PQQ', 'Competitive dialogue', 'Innovation partnership', 'Framework agreement', 'Dynamic purchasing system', 'Electronic / reverse auction', 'Design contest', 'Direct award (published)', 'Contract notice', 'Award notice', 'Modification notice', 'Cancellation notice', 'Prior information notice', 'Grant notice', 'Concession notice', 'PPP notice'];
  const PROCUREMENT_CATEGORIES = [
    ['goods', 'Goods'], ['services', 'Services'], ['works', 'Works / construction'], ['consultancy', 'Consultancy'], ['it', 'IT / software / cloud'], ['healthcare', 'Healthcare (procurement only)'],
    ['energy', 'Energy / mining / commodities'], ['transport', 'Transport / logistics'], ['insurance', 'Insurance-related (broker panels, claims platforms, actuarial, captive management)'], ['defense', 'Defense / security (lawfully published only)'], ['utilities', 'Utilities']
  ].map(([id, name]) => ({ id, name }));

  R.taxonomy = {
    groups: G,
    global: D,
    finance: F,
    insuranceLines: INSURANCE_LINES,
    insuranceEntityTypes: INSURANCE_ENTITY_TYPES,
    procurementTypes: PROCUREMENT_TYPES,
    procurementCategories: PROCUREMENT_CATEGORIES,
    /** Find taxonomy entries whose name or alias appears in the query. */
    matchDomains(q) {
      const t = ' ' + String(q || '').toLowerCase() + ' ';
      const hit = (x) => {
        const names = [x.name.toLowerCase(), ...(x.aliases || [])];
        return names.some((n) => n.length > 3 && t.includes(' ' + n + ' ')) || names.some((n) => n.length > 5 && t.trim() === n);
      };
      return { global: D.filter(hit), finance: F.filter(hit) };
    },
    matchInsuranceLine(q) {
      const t = String(q || '').toLowerCase();
      return INSURANCE_LINES.filter((l) => {
        const n = l.name.toLowerCase().replace(/\s*\(.*\)/, '');
        return t.includes(n) || (l.id === 'do' && /\bd&o\b/.test(t)) || (l.id === 'pi-eo' && /\b(e&o|professional indemnity)\b/.test(t));
      });
    }
  };
})(window.JAQAWorkspace);

/* ---- modules/worldLand.js ---- */
/*
 * worldLand.js — GENERATED by scripts/gen-land.mjs. Do not edit by hand.
 * Coastline polylines (5120 points) for the Situation Room globe.
 * Source: Natural Earth 1:110m land (public domain), redistributed as TopoJSON
 * by the world-atlas package, whose licence notice follows:
 *
 * Copyright 2013-2019 Michael Bostock
 * 
 * Permission to use, copy, modify, and/or distribute this software for any purpose
 * with or without fee is hereby granted, provided that the above copyright notice
 * and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
 * INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF
 * THIS SOFTWARE.
 */
(function (R) {
  'use strict';
  const RAW = '-596,-800,-3,-5,-3,-5,-21,1,-22,0,-12,3,0,1,-6,2,23,0,21,-1,8,4,5,4,10,-4;-1592,-795,-19,-1,-13,3,-6,4,-1,0,-6,3,6,4,19,-2,10,-3,7,-3,3,-5;-452,-780,13,-5,4,-6,1,-4,1,-5,-16,-3,-16,-3,-19,-2,-21,-2,-24,0,-13,4,2,4,21,3,9,3,6,4,5,4,6,3,6,5,5,0,15,2,15,-2;-1212,-735,13,-2,12,2,-6,-3,-9,-3,-14,1,-10,3,2,4,12,-2;-1256,-735,16,-4,-6,1,-13,1,-14,2,7,3,10,-3;-990,-719,11,-2,11,1,6,-5,-8,1,-12,-1,-12,1,-14,-1,-10,2,-5,4,6,2,13,-2,14,0;-685,-710,2,-4,-2,-4,-3,-4,-12,-1,-11,-2,-13,0,5,4,-12,-1,-11,-2,-8,3,0,4,11,4,7,1,11,0,3,5,1,4,0,8,5,5,9,1,6,-4,2,-3,4,-5,4,-4,2,-5;-1800,-847,1,0,8,6,18,-4,2,1,2,1,4,1,3,1,1,0,2,0,1,0,14,-4,13,4,2,0,29,2,10,-2,5,-1,15,-4,28,-2,23,-3,38,-3,29,3,43,-2,24,-3,26,3,28,3,2,4,-39,1,-33,2,-8,4,-27,2,2,5,4,4,3,3,-2,5,-16,2,-8,4,-15,3,24,-1,23,2,15,-3,17,3,17,3,8,4,-4,4,-13,2,-14,3,-21,1,-18,1,-19,1,-7,4,-13,3,-8,4,-3,11,5,-1,9,-3,17,1,16,1,8,-4,16,1,13,2,13,3,11,3,15,1,0,4,-4,4,3,3,13,2,6,-3,15,2,12,2,14,0,13,1,14,3,11,2,12,2,8,-1,7,0,14,1,14,-2,13,0,14,2,13,-1,15,-1,14,0,14,0,15,0,14,0,10,3,12,2,13,-2,12,1,11,4,6,-3,4,-4,6,-3,10,3,12,-4,14,-1,11,-3,15,1,12,2,15,-1,14,-1,14,-2,5,4,-7,4,-5,3,-12,1,-6,4,-2,3,-4,8,8,-2,13,0,13,0,12,-1,10,-3,4,-4,14,0,13,1,13,2,13,1,10,-2,13,1,9,7,8,-4,11,-2,13,1,8,-4,13,0,12,-1,12,-3,8,4,4,4,10,-4,14,1,10,-2,7,-4,13,1,10,2,11,3,12,1,14,2,13,1,9,2,6,3,3,5,-2,4,-3,4,-3,3,-3,4,-3,4,0,4,1,4,4,3,4,5,2,3,-2,5,-1,4,4,4,6,3,6,4,7,3,8,3,4,4,6,3,6,3,10,0,6,3,7,2,8,1,7,3,6,3,8,1,6,-2,-4,-4,-10,-3,-4,-2,-8,2,-8,-1,-7,-2,-7,-3,-5,-3,-1,-4,0,-4,5,-3,-7,-2,-9,-1,-6,-3,-6,-3,-6,-5,-2,-4,4,-4,5,-3,8,-2,8,-3,4,-4,2,-4,3,-4,5,-3,3,-4,1,-9,3,-4,1,-4,3,-4,-1,-5,-6,-4,-6,-3,-13,-2,-4,-3,-7,-4,-15,-3,-13,-2,-12,-2,-14,-2,-8,-4,-16,-1,-18,1,-16,-1,-16,0,3,-4,15,-2,11,-3,6,-3,-11,-3,-17,1,-14,-3,-1,-4,0,-4,12,-3,2,-4,12,-4,22,-1,18,-3,14,-3,18,-3,25,-2,24,-2,17,-3,19,-4,10,-4,5,-4,12,3,16,3,18,3,21,3,17,3,25,0,25,-1,20,-3,6,4,14,3,26,1,19,2,19,2,21,1,22,2,15,3,-7,3,-4,4,0,3,-19,0,-21,-2,-19,0,-3,4,1,8,5,2,14,2,17,2,12,3,12,3,9,4,14,2,13,1,7,1,16,1,14,1,13,2,12,2,11,3,14,3,9,3,9,3,3,4,-11,2,4,4,7,4,10,1,11,3,10,3,8,4,5,5,7,2,12,0,5,-4,12,0,0,4,5,4,11,-1,3,-4,12,-1,13,2,12,1,11,0,5,-4,11,3,10,2,11,1,11,1,11,3,11,1,8,3,6,3,8,-2,10,1,8,-5,5,-3,12,2,4,4,10,2,13,0,4,-4,8,4,11,1,12,0,11,0,11,-1,11,-1,4,-3,7,-3,11,2,11,0,12,0,11,0,10,2,11,1,8,3,10,1,10,1,8,3,5,6,6,3,10,-2,4,-3,9,-2,10,0,7,-3,7,-3,11,3,3,4,9,2,11,3,9,1,12,2,8,2,8,3,8,2,9,-1,9,3,7,3,9,0,9,2,1,4,9,3,8,1,10,2,9,1,9,-1,10,-1,8,-2,1,-5,8,-3,6,-3,12,-1,7,-3,8,-3,10,0,8,2,9,4,9,-2,10,-1,9,-2,10,0,10,0,8,-11,0,-2,-1,-5,-10,-2,-8,-4,1,-4,12,0,-2,-4,-5,-3,-5,-5,8,-3,12,-1,11,2,6,4,3,4,6,3,6,3,2,3,6,5,6,1,11,1,10,1,10,1,5,4,3,4,7,4,10,2,8,2,6,4,6,1,7,2,10,-1,9,1,10,1,11,0,7,2,5,7,4,-3,4,-5,9,-1,9,-1,10,1,10,-1,9,0,7,1,8,-1,8,-2,9,2,11,0,9,1,10,-1,7,3,5,3,7,3,12,7,7,-1,7,-3,7,-3,13,-6,10,-1,9,0,11,2,10,1,9,3,6,3,12,0,7,2,8,-2,5,-3,7,-3,11,0,7,-2,12,-3,12,-1,11,1,8,3,6,3,9,1,9,-1,11,-1,9,1,9,0,9,-1,9,-1,9,2,11,2,10,0,11,0,10,1,9,1,2,5,1,4,6,-3,2,-4,3,-4,4,-4,9,-2,11,1,13,0,9,1,13,0,10,0,13,0,11,-1,7,-3,-2,-4,6,-3,11,-2,11,-3,13,-2,14,-1,10,-2,11,0,7,3,9,-2,7,-3,9,-3,12,-1,12,-1,5,-4,11,-2,8,-4,11,-1,11,0,11,-1,12,0,12,0,11,-2,11,-2,10,-2,7,-3,-1,-4,-5,-3,-5,-5,-3,-3,-5,-5,-13,-1,-6,-4,-13,-2,-5,-4,-6,-3,-8,-4,-4,-4,-2,-3,-1,-5,0,-4,6,-4,2,-3,4,-4,19,-1,4,-5,-18,-1,-15,-2,-19,-1,-9,-5,-2,-5,-4,-4,-5,-3,13,-4,5,-4,9,-4,12,-3,14,-3,15,-3,23,-3,5,-5,29,-2,2,-1,7,-3,28,2,23,-3,-3583,-2;-678,-538,13,-7,14,-2,-4,-5,-10,0,-5,3,-3,-4,-8,-3,-11,1,-8,3,-10,1,-13,6,-10,5,-14,12,9,-2,14,-7,13,-4,5,5,3,7,10,4,7,-1,3,-5,5,-7;-585,-511,8,-4,-3,-4,-14,-3,-4,4,-9,-5,-5,5,12,5,8,-2,7,4;703,-497,-16,-1,0,6,2,4,0,2,7,-3,9,-2,1,-2,-3,-4;1454,-408,10,-3,5,1,8,2,6,-1,1,-12,-4,-3,-1,-8,-3,3,-7,-7,-2,0,-7,1,-6,8,-1,7,-6,8,0,5,7,-1;1730,-409,2,-4,8,4,2,-4,0,-5,-3,-4,-7,-8,-5,-4,4,-5,-8,0,-8,-3,-3,-7,-6,-10,-8,-5,-5,-2,-9,0,-6,3,-11,1,-2,3,5,8,13,10,6,2,8,3,8,6,6,5,5,7,4,3,1,5,7,5,2,-4;1746,-362,7,-10,1,7,4,-3,2,-8,8,-3,6,-1,6,4,5,-1,-2,-9,-3,-6,-8,1,-3,-3,1,-5,-1,-2,-4,-5,-5,-7,-8,-4,-1,3,-4,1,5,8,-3,6,-11,4,1,4,7,3,1,8,0,6,-4,7,0,2,-5,4,-7,9,-5,7,4,0,6,-5,7,-3,3,-9;1671,-222,-4,-2,-5,3,-7,4,-7,6,-6,7,-2,3,5,0,5,-4,5,-3,3,-3,8,-6,5,-5;1784,-173,3,-3,-1,-6,-7,-1,-5,1,-1,5,4,3,4,-1,3,2;-1800,-166,3594,-2,-7,-2,-1,4,5,2,3,0,-3594,3;-1800,-161,0,-5;-1800,-161,2,1,-1,-5,-1,-1;1678,-165,-3,-1,-3,4,0,3,6,-6;1671,-149,2,-8,-3,1,-2,-1,-1,3,-1,8,5,-3;501,-136,1,-12,3,-4,-1,-5,-2,-3,-3,6,-2,-3,2,-8,-1,-4,-3,-2,-1,-9,-4,-11,-5,-14,-6,-19,-4,-14,-4,-11,-8,-3,-9,-4,-6,3,-8,3,-2,5,-1,9,-4,8,0,7,1,8,5,1,0,4,5,7,1,7,-3,4,-2,7,0,9,3,5,1,7,5,0,6,2,4,2,4,0,6,6,8,6,3,5,-1,4,4,-1,5,7,1,6,3,5,3,-5,3,-4,3,-7;1436,-138,3,-7,7,3,3,-4,5,-4,-1,-4,2,-9,1,-5,3,-1,3,-9,-1,-5,3,-7,11,-5,7,-5,6,-4,-1,-2,6,-7,4,-10,4,2,4,-5,2,2,2,-11,7,-6,5,-4,8,-8,2,-8,1,-5,-1,-7,5,-8,-1,-9,-2,-5,-2,-9,0,-5,-2,-7,-5,-10,-7,-4,-4,-8,-3,-5,-3,-9,-4,-5,-2,-7,-2,-7,1,-3,-6,-4,-11,0,-9,-4,-5,-4,-6,-4,-8,4,-6,2,1,5,-5,-2,-9,-7,-9,3,-5,1,-6,1,-10,3,-6,6,-2,8,-2,5,-5,4,-10,1,3,5,-2,7,-5,-7,-9,-2,6,6,1,6,4,5,-1,7,-8,-9,-6,-3,-4,-8,-8,4,0,6,-6,7,-5,4,2,2,-13,6,-7,0,-10,5,-18,-1,-13,-3,-11,-4,-10,1,-10,-5,-9,-3,-2,-5,-3,-4,-9,0,-6,-1,-9,2,-7,-1,-7,-1,-6,-5,-3,0,-5,-2,-5,-4,-7,1,-7,0,-10,6,-6,2,0,6,5,1,2,2,0,4,1,7,-1,6,-5,10,-2,6,0,5,-4,7,0,3,-4,4,-2,8,-5,8,-2,4,5,-4,-4,9,5,-3,3,-4,0,5,-5,8,-1,3,-2,3,1,6,2,2,1,5,-1,6,4,7,1,-7,4,7,9,3,4,4,8,4,5,1,2,-1,8,3,6,1,2,3,3,0,5,0,11,3,5,5,3,5,5,5,1,4,0,5,7,9,4,-9,5,2,-4,5,3,5,5,-2,1,7,5,5,3,4,5,2,0,3,4,-1,0,2,5,1,5,2,7,-5,6,-6,6,0,6,-1,-2,6,5,8,4,2,-1,3,4,6,6,3,5,-1,9,2,0,5,-8,3,6,2,6,-3,6,-4,8,-2,3,1,6,-3,6,2,4,0,2,1,5,-5,-3,-5,-4,-4,-3,0,1,-4,-3,-5,-4,-5,1,-3,8,-6,8,-3,5,-3,7,-6,3,0,5,-3,2,-3,9,-3,7,3,2,6,2,4,1,6,3,8,-1,4,0,3,-1,6,2,8,1,2,-1,3,2,5,2,6,0,3,4,3,3,-5,1,-6,2,-1,1,-4,3,-5,1,-6,0,-4;1621,-105,3,-3,-7,0,-4,6,6,-2,2,-1;1207,-102,-4,-1,-13,7,9,2,5,-3,4,-3,-1,-2;1609,-99,-4,0,-6,1,-3,2,1,4,7,-2,3,-2,2,-3;1617,-96,-2,-2,-7,9,-2,6,3,0,4,-8,4,-5;1244,-101,-8,-3,-1,2,1,3,4,6,10,4,1,2,8,3,7,0,4,1,3,-1,-3,-3,-11,-4,-8,-3,-7,-7;1179,-81,4,-3,6,1,2,-4,-11,-2,-7,-1,-6,0,4,5,5,1,3,3;1229,-81,-1,-6,-15,-2,-14,1,0,4,8,2,6,-3,7,0,9,4;1599,-83,0,-2,-8,4,-5,3,-4,4,2,1,4,-3,8,-4,3,-3;1575,-73,-2,-1,-4,2,-4,4,0,2,6,-4,4,-3;1086,-68,19,-1,3,4,18,-4,4,-7,15,-2,12,-6,-11,-4,-11,5,-9,-1,-11,1,-9,2,-12,4,-7,1,-4,-2,-18,4,-2,5,-9,0,7,10,12,-1,8,-3,4,-1,1,-4;1347,-62,-5,-7,-1,8,2,3,2,4,2,-3,0,-5;1559,-68,-3,-1,-4,4,-5,6,-2,8,2,1,1,-3,3,-3,4,-6,5,-3,-1,-3;1520,-55,-5,-1,-2,-2,-5,-3,-6,-2,-5,0,-8,3,-6,3,1,3,9,-2,5,1,2,5,1,0,1,-5,6,0,3,4,5,3,-1,6,6,1,2,-2,0,-6,-3,-6;1272,-35,-3,-3,-7,2,-2,4,10,1,2,-4;1305,-31,3,-8,-8,5,-8,0,-6,0,-7,0,2,6,13,0,11,-3;1531,-45,-3,-3,-2,6,-2,4,-4,3,-6,5,-7,3,2,2,6,-3,3,-2,4,-2,4,-5,4,-3,1,-5;1341,-12,3,-16,11,-6,8,11,11,6,9,0,9,-4,7,-3,11,-2,17,-7,19,-6,7,-5,5,-5,2,-6,16,-6,3,-5,-9,-1,2,-7,9,-6,6,-11,6,0,0,-4,7,-2,-3,-2,11,-4,-1,-3,-7,-1,-2,3,-9,1,-10,2,-8,6,-5,6,-6,8,-13,5,-8,-3,-6,-3,1,-8,-8,-3,-5,1,-11,1,-9,8,-10,2,-2,-3,-13,0,4,8,7,3,-3,11,-5,8,-19,9,-8,0,-15,10,-3,-5,-4,-1,-2,4,0,4,-8,5,11,3,7,0,-1,3,-15,0,-4,6,-9,2,-4,5,14,2,5,3,16,-4,1,-4;1252,14,-8,-10,-7,-2,-10,2,-16,0,-9,-2,-2,-7,9,-9,6,4,18,4,0,-5,-5,2,-4,-6,-9,-4,10,-13,-2,-3,9,-12,0,-6,-6,-3,-4,3,5,8,-10,-4,-2,3,1,4,-7,6,1,10,-7,-3,1,-12,0,-14,-6,-2,-4,3,3,9,-2,10,-4,0,-3,7,4,7,1,7,5,16,2,4,9,7,8,-3,12,-1,12,0,10,7,1,-2;1287,11,-1,-8,-5,1,-1,-7,4,-5,-3,-1,-4,6,-3,13,2,8,3,4,1,-6,6,-1,1,-4;1058,-59,-11,0,-8,9,-13,8,-4,6,-8,8,-5,7,-8,14,-8,9,-3,8,-4,8,-9,7,-5,8,-8,6,-10,11,-1,5,6,-1,16,-2,9,-9,7,-7,6,-4,9,-11,11,0,8,-7,6,-8,7,-5,-4,-8,6,-4,4,0,1,-7,4,-5,7,-1,5,-7,-2,-12,-1,-16;1179,18,11,-9,-12,-1,-3,-7,0,-9,-9,-7,-1,-10,-4,-15,-1,3,-11,-4,-4,6,-7,1,-5,3,-12,-4,-4,5,-7,0,-8,1,-1,13,-5,3,-5,8,-1,9,1,9,6,7,7,-3,8,2,2,8,4,2,12,2,7,8,5,6,4,4,9,5,7,7,5,8,4,0,5,-5,1,-4,6,-3,9,-3,-1,-4,-7,0,2,-5,-7,-4,-6,-9,7,-9,-1,-5;1264,84,1,-6,0,-6,-3,-9,-4,10,-4,-5,3,-8,-3,-4,-12,6,-3,7,3,5,-6,4,-3,-4,-5,1,-7,-6,-2,3,4,8,6,3,6,4,3,-5,8,3,2,5,7,0,-1,8,8,-5,1,-5,1,-4;812,62,-9,-2,-4,8,-2,14,4,16,7,-5,5,-7,5,-11,-2,-10,-4,-3;-609,101,-9,-1,-2,1,3,3,0,4,6,1,2,0,0,-8;1240,103,-4,-4,-3,-6,-3,-3,-6,7,2,3,2,3,1,6,6,0,-2,-6,8,9,-1,-9;1185,93,-13,-9,5,7,7,6,6,7,5,10,2,-8,-7,-6,-5,-7;1219,119,6,-3,6,0,0,-4,-5,-5,-6,-3,0,5,0,5,-1,5;1255,122,3,-12,-8,3,0,-3,3,-6,-5,-3,0,7,-3,1,-2,6,6,-1,0,4,-6,8,9,-1,3,-3;1215,131,-2,-9,-5,5,-5,8,9,-1,3,-3;1213,185,6,-3,3,3,1,-3,-1,-4,3,-7,-2,-8,-6,-4,-2,-8,2,-8,6,-1,4,1,13,-5,-1,-6,3,-2,-1,-5,-8,5,-4,6,-2,-4,-7,6,-9,-2,-5,3,1,4,3,2,-3,3,-1,-4,-5,6,-2,4,0,10,4,-4,1,16,3,9,6,0;-656,182,-2,-2,-8,0,-6,-1,0,5,1,1,8,0,5,-1,2,-2;-769,179,-3,-2,-6,2,-5,3,1,3,4,0,2,0,7,-1,5,-2,2,-3,-7,0;-726,199,9,-2,1,2,8,0,6,-3,2,0,2,-3,6,0,-1,-3,5,0,5,-4,-4,-4,-5,2,-4,0,-4,0,-1,-2,-4,0,-2,2,-3,-1,-4,-7,-3,2,0,2,-7,2,-4,-1,-7,1,-4,-2,-6,3,1,4,10,-2,7,-1,4,3,-5,4,0,4,-6,1,2,3,6,0;1103,187,-8,-5,-8,3,-1,9,5,4,11,3,6,0,2,-4,-4,-4,-3,-6;-1555,191,-2,-2,-2,2,0,2,-2,4,1,1,1,2,0,2,0,1,1,-1,4,-1,2,-1,1,-1,3,-4,-4,-3,-3,-1;-1561,206,-3,0,-2,2,-1,1,1,1,3,-1,3,-1,-1,-2;-1568,212,0,-1,-5,0,0,1,5,0;-1577,213,-1,0,-3,0,-2,2,0,1,3,1,1,0,2,-4;-1593,220,-2,-1,-3,2,1,0,1,1,2,0,1,-2;-797,228,4,-4,10,1,3,-2,9,-6,6,-5,3,0,6,-2,-1,-3,8,0,7,-4,-1,-2,-7,-2,-6,0,-7,1,-15,-1,7,5,-4,3,-6,0,-4,3,-2,6,-6,0,-9,2,-3,2,-13,2,-4,2,4,2,-10,1,-7,-5,-4,0,-2,-3,-4,-1,-5,1,6,3,2,4,4,2,5,2,8,1,2,1,9,-1,8,0,9,-3;-775,238,-3,-1,-2,6,-4,3,2,6,3,0,4,-9,0,-5;1212,228,-5,-8,-5,8,-1,8,6,9,8,8,5,-3,-2,-6,-6,-16;-778,266,-11,-2,-1,4,5,1,7,-1,0,-2;-770,266,-2,-7,-2,1,1,5,-5,4,0,1,8,-4;1346,341,2,-3,-6,-6,-4,3,-5,-2,-3,-6,-6,3,0,5,5,6,6,-2,4,5,7,-3;346,357,-7,-5,1,-1,0,-1,-10,-4,-5,1,-2,4,4,0,1,0,1,3,8,0,9,3;237,357,5,-3,8,0,8,0,-1,-2,6,1,-1,-3,-15,-1,0,2,-12,2,2,4;155,382,-3,-8,1,-3,-2,-5,-8,4,-5,1,-14,5,2,5,11,-1,11,1,7,1;92,412,6,-7,-1,-13,-5,0,-4,-3,-4,3,0,12,-2,6,5,-1,5,3;1410,371,-4,-8,2,-5,-5,-7,-13,-4,-18,-1,-14,-11,-7,3,0,8,-18,-2,-11,-5,-12,0,10,-8,-7,-16,-6,-5,-5,4,2,9,-6,3,-4,7,10,3,5,6,10,6,7,6,20,3,11,-2,10,18,7,-5,15,10,5,4,7,12,-2,12,4,6,11,2,5,-14,0,-8,-9,-10,0,-11;96,422,-4,-8,-4,2,-3,7,2,3,7,4,2,-8;1439,442,7,-2,7,4,2,-11,-14,-3,-9,-10,-16,7,-5,-11,-11,0,-2,10,5,7,11,1,3,14,3,8,11,-11,8,-3;-637,465,8,-1,9,0,-5,-4,-4,0,-12,4,-3,3,4,3,3,-5;-618,491,-5,0,-13,3,-9,5,3,1,13,-3,11,-4,0,-2;-1235,485,-5,-1,-17,4,-3,4,-8,3,-2,3,-11,2,-3,5,0,3,11,-2,6,-2,9,-1,4,-4,5,-4,10,-4,4,-6;-561,507,-7,-9,7,3,6,-2,-3,-3,9,-3,4,3,10,-4,-3,-7,7,2,1,-5,4,-7,-5,-8,-4,-1,-7,2,2,8,-2,2,-12,-9,-6,0,7,5,-10,2,-10,0,-20,0,-1,3,6,4,-4,2,8,6,10,16,7,6,8,3,5,0,-2,-3,-5,-6;-1327,540,10,1,-4,-11,9,-8,-4,0,-6,4,-4,5,-5,3,-1,5,0,3,5,-2;1436,507,11,-17,-15,3,-6,-14,9,-11,0,-7,-8,6,-6,-7,-2,8,1,10,-1,11,2,7,1,14,-6,9,1,14,9,5,-4,4,5,2,2,-7,4,-10,-1,-9,4,-11;-68,523,-18,-6,-14,1,8,11,-5,10,14,8,7,4,9,1,10,-6,-5,-7,2,-7,-8,-9;127,556,-6,-8,-11,6,-1,4,15,3,3,-5;-1530,571,-10,-4,-5,3,-2,5,9,3,6,2,6,-1,5,-3,-9,-5;-30,586,-11,-10,10,1,11,0,-2,-8,-9,-9,10,-1,10,-13,7,-1,6,-12,3,-4,12,-2,-1,-6,-6,-3,4,-5,-9,-5,-13,0,-17,-3,-5,2,-6,-5,-9,1,-7,-3,-6,2,15,10,9,2,-16,2,-3,4,11,3,-6,5,2,7,15,-1,2,6,-7,6,-12,2,-3,3,4,4,-3,3,-6,-5,0,10,-6,5,4,10,8,8,8,0,12,0;-1656,599,-6,-1,-6,1,-7,3,10,2,8,-1,1,-4;-793,622,-4,-6,-4,1,-3,3,1,1,4,3,4,0,2,-2;-819,627,-12,-5,-7,0,-2,3,8,4,13,0,0,-2;-1717,638,6,-2,6,1,8,-3,10,-1,-1,-1,-7,-2,-8,2,-4,2,-9,-1,-2,1,1,4;-852,657,2,-5,5,2,6,-3,11,-3,12,-3,0,-5,8,1,7,-4,-9,-3,-15,3,-6,4,-10,-5,-14,-5,-4,5,-13,-1,8,5,2,8,3,9,7,0;-145,665,-2,-7,11,-7,-13,-7,-29,-7,-9,-2,-13,1,-28,4,10,4,-22,5,18,2,0,3,-21,2,6,7,16,1,15,-7,15,6,13,-3,16,5,17,0;-759,671,-11,0,-2,5,4,5,9,2,8,-3,0,-4,-1,-2,-7,-3;-1800,690,25,-8,26,-10,-1,-6,7,-3,-3,8,27,-2,20,-9,-10,-5,-16,-1,-1,-9,-4,-2,-9,0,-8,3,-13,3,-2,5,-10,1,-12,-1,-5,3,2,4,-12,-2,5,-5,-6,-4;-1800,650,0,40;-956,691,-7,-3,-13,3,-8,-1,-14,4,9,3,7,4,10,-2,6,-2,3,-2,7,-4;-1800,715,3600,-7,-11,0,-2,3,-3587,4;-1800,715,1,1,9,0,14,-3,-1,-2,-10,-2,-13,-1,0,7;-905,695,0,-10,13,8,12,-7,-3,-7,10,-7,10,7,7,9,1,11,14,-1,15,-1,13,-5,1,-5,-8,-6,7,-5,-1,-5,-19,-7,-14,-1,-11,3,-3,-5,-9,-9,-3,-4,-12,-7,-14,-1,-8,-4,-1,-6,-11,-2,-13,-8,-10,-11,-4,-8,-1,-12,15,-1,4,-10,5,-7,14,2,19,-4,10,-4,7,-5,12,-3,11,-4,16,-1,11,-1,-1,-8,3,-10,7,-11,15,-10,8,3,5,11,-5,15,-7,6,16,4,11,7,6,7,-1,7,-7,9,-12,7,12,11,-5,9,-3,15,7,3,17,-3,10,-1,9,2,9,-3,12,-6,3,-4,18,0,0,-9,3,-12,9,-2,7,-6,15,6,10,11,6,4,8,-9,13,-12,11,-12,-4,-7,13,-5,9,-6,16,-3,7,-3,4,-8,7,-2,4,-3,1,-12,-7,-3,-7,-4,-17,-3,-12,-9,-17,-1,-22,2,-15,0,-10,-1,-8,-7,-13,-4,-15,-14,-11,-9,8,2,16,13,21,8,15,1,9,-5,-9,-6,3,-11,3,-8,13,-5,17,2,10,11,0,-7,7,-4,-12,-6,-23,-6,-9,-4,-12,-8,-7,1,-1,9,18,8,-16,0,-11,-2,1,-3,-10,-5,-11,-3,-10,-3,-6,-7,-1,-1,0,-6,3,-5,4,0,-1,3,3,-2,-1,-3,-6,-1,-5,0,-8,-2,-4,0,-6,-1,-8,-3,15,2,3,-2,-14,-3,-7,0,0,2,-3,-3,3,-1,-2,-7,-7,-8,-1,3,-2,0,-3,3,2,-5,2,-2,0,-4,-3,-4,-5,-8,-1,1,3,6,-5,4,-2,8,-1,-4,2,-6,-7,1,7,-3,0,-9,3,-1,1,-3,2,-10,-7,-8,-10,-3,-7,-6,-5,0,-5,-4,-1,-3,-11,-7,-6,-5,-4,-6,-2,-7,2,-7,3,-8,5,-7,0,-5,4,-11,0,-7,0,-4,-3,-6,-3,-1,-5,1,-1,4,-4,3,-5,8,-5,8,-2,4,2,7,-2,5,-8,8,-4,2,-10,-5,-2,1,-5,5,-6,2,-11,-1,-9,1,-8,-1,-4,-1,2,-3,0,-4,2,-2,-2,-1,-4,1,-4,-2,-7,0,-7,6,-9,-1,-7,2,-6,-1,-9,-2,-9,-8,-10,-4,-5,-5,-3,-4,0,-7,1,-5,2,-3,-4,-9,-2,-7,-1,-14,-1,-5,2,-5,3,-5,2,-8,7,-7,2,-6,4,-5,11,-2,4,-5,9,3,7,1,8,2,6,2,6,4,3,6,0,8,2,3,7,3,11,2,8,0,6,0,3,-2,0,-5,-6,-5,-2,-7,2,-1,-2,-5,-2,-7,-3,2,-2,0,0,-1,2,-1,0,-2,-2,-5,1,-1,-1,-4,1,-1,-2,-5,-2,-2,-1,-1,-2,-3,3,-2,1,2,3,-2,1,0,2,2,3,0,1,-1,1,0,5,0,5,0,3,1,1,1,3,0,3,-1,2,0,2,1,5,-1,1,-1,3,-2,3,-2,4,-1,3,-3,-1,-1,-1,-2,1,-4,-2,-3,-1,-4,-1,-5,1,-2,0,-5,-1,-1,-1,-4,0,-3,-2,-2,1,-3,1,-2,3,-5,4,-4,5,-4,3,-4,0,-2,4,0,1,0,3,-2,5,1,4,2,6,2,3,3,6,0,-1,-1,6,-1,4,-2,4,-3,3,-2,6,-1,7,7,4,1,0,4,2,8,6,5,6,0,1,2,8,-1,8,5,4,3,4,4,4,0,3,-3,-2,-3,-1,-3,-5,-1,3,-4,0,-6,-5,-5,4,-8,4,0,3,8,-4,3,0,8,12,4,-1,4,4,4,3,-7,7,-1,7,-5,0,-3,9,-1,11,1,5,-4,8,-1,6,3,0,2,12,1,12,0,-8,-3,3,-5,8,0,8,-5,1,-8,5,0,4,-2,7,-4,6,-7,0,-5,4,0,6,-5,4,-3,12,-2,1,2,8,0,10,-2,4,-2,7,-2,11,-8,1,-4,4,0,2,-6,6,-17,5,-2,1,-7,-8,-8,3,-3,18,-1,0,-10,8,6,12,-3,17,-7,5,-5,-2,-6,12,3,19,-5,15,0,15,-8,13,-11,7,-3,9,0,4,-4,3,-12,2,-6,-4,-17,-5,-6,-14,-14,-7,-12,-7,-8,-3,-1,-3,-7,1,-19,-3,-15,-1,-7,-3,-4,-2,-13,-10,-13,-1,-10,-9,-5,-2,-6,-11,0,-15,-4,-8,-4,-11,-3,-11,-8,-9,-10,-1,-7,1,-6,-2,-10,-2,-5,-7,-5,-11,-18,-9,-8,-7,-4,-4,-10,-7,-6,-4,-6,-11,-6,-8,2,-5,-1,-9,5,-7,-1,-6,6,-1,-5,13,-9,-2,-7,7,-4,-1,-5,-9,-13,-15,-5,-20,-2,-11,1,2,-6,-2,-8,2,-5,-6,-3,-11,-2,-9,4,-4,-3,1,-10,7,-3,5,4,3,-6,-9,-3,-8,-6,-1,-10,-3,-5,-9,0,-8,-6,-3,-7,10,-7,10,-2,-4,-9,-12,-6,-6,-12,-9,-4,-4,-4,3,-11,6,-6,-4,1,-9,0,-4,-2,-9,-4,-2,-9,-4,-1,-12,4,-11,7,-12,5,-4,7,3,6,-5,6,-1,17,4,10,11,8,-15,3,9,8,3,17,12,-4,5,21,-7,3,-3,-13,-6,2,3,14,3,19,5,6,-3,10,-1,11,4,1,6,16,7,16,5,15,-3,15,3,8,-1,12,6,13,2,19,3,21,3,22,-1,16,-2,15,-10,5,-1,4,-19,10,-18,11,-8,7,-4,8,1,3,-8,13,-10,18,-9,20,-4,5,-4,7,-7,7,-8,4,4,4,-5,10,3,7,8,6,5,7,-2,5,-4,-5,-6,5,2,2,-1,9,3,2,2,6,4,7,-1,4,6,2,6,4,-1,3,4,1,-1,5,3,3,5,1,4,6,4,5,-4,3,2,6,-2,9,2,2,-2,9,-4,5,-3,3,-2,6,2,2,-2,1,-2,3,-5,3,-5,-1,-2,-3,-4,-3,-2,0,-1,-2,5,-6,-3,-1,-1,-1,-5,-1,-2,6,-1,-2,-3,1,-2,4,-4,1,-3,1,-4,0,0,-2,-2,1,-5,2,-2,3,1,1,0,3,-3,2,-4,2,-3,1,-1,3,-3,2,1,-3,-2,-2,-2,2,-4,1,-1,2,0,3,1,4,-2,1,2,2,-4,3,-4,4,-2,3,-5,4,-5,4,1,2,2,-2,1,1,-2,3,-3,1,-1,-3,-6,1,-3,1,-5,2,-5,0,-3,2,-5,2,-6,0,-5,2,-5,4,-12,11,-5,3,-8,3,-6,-1,-8,-3,-5,-1,-7,2,-7,2,-9,5,-8,1,-11,5,-9,4,-2,3,-6,1,-10,3,-4,4,-11,6,-5,6,-2,5,3,1,-1,3,2,3,0,3,-3,5,-1,4,-3,5,-9,10,-10,7,-5,7,-9,4,-1,2,1,6,-5,3,-6,5,-2,7,-6,0,-6,6,-4,5,-1,3,-5,7,-4,8,1,4,-8,4,-3,-1,-6,3,-1,-4,1,-5,1,-7,4,-4,7,-7,2,-3,1,0,2,-4,1,0,2,-6,3,-3,3,-3,6,-5,3,-10,3,-4,3,-5,0,-5,5,0,4,-5,4,-4,0,-2,-5,-4,-1,0,-3,6,-7,6,-7,5,-5,2,0,8,-1,5,-5,3,-7,5,-1,-2,-2,3,-7,2,-6,6,1,1,4,-1,4,4,0,5,-7,7,-6,3,-4,6,-4,6,-4,8,-4,9,-2,5,-6,6,-5,1,-1,3,-6,1,-3,2,-10,1,-2,2,-1,6,-10,10,-8,14,0,2,-5,3,-7,9,-2,8,-5,5,2,8,0,9,-3,8,4,9,2,18,-2,14,-3,8,-3,5,1,2,15,-4,5,-9,3,3,-2,8,-3,8,-2,0,-19,10,-7,4,-18,4,-6,9,2,6,-13,5,-2,8,-12,7,0,5,-6,4,-9,3,-2,9,-13,8,-6,9,-9,1,-16,0,-12,3,-21,10,-9,2,-18,4,-14,-1,-19,5,-12,4,-11,-2,2,-7,-6,-1,-11,-2,-9,-3,-11,-2,-2,5,5,10,11,3,-3,3,-13,-6,-7,-6,-14,-7,7,-5,-9,-8,-11,-4,-10,-3,-3,-4,-15,-5,-3,-5,-12,-4,-7,0,-9,-2,-10,-4,-9,-3,-17,-3,-1,2,11,4,9,3,11,6,12,1,5,4,14,6,2,2,8,4,1,7,6,6,-12,-3,-3,2,-6,-4,-6,5,-3,-3,-4,5,-10,-4,-6,0,-1,6,2,3,-6,4,-13,-2,-9,5,-6,2,-1,6,-7,4,4,6,8,5,3,5,8,1,7,-1,8,4,8,0,7,3,-2,4,-5,2,7,4,-6,0,-11,-2,-3,-3,-7,3,-15,-2,-14,3,-4,4,-13,6,14,4,22,5,8,0,-1,-5,21,0,-8,6,-12,4,-7,5,-10,4,-14,4,6,5,18,0,12,5,3,5,10,4,10,1,19,5,9,-1,15,6,15,-3,8,-4,4,2,17,-1,-1,-2,16,-2,10,1,21,-3,19,-1,8,-1,13,2,15,-3,11,-2,19,-2,16,-5,10,-1,9,4,12,3,15,-1,15,4,16,3,7,-4,7,2,3,5,7,-1,16,-9,14,7,1,-8,12,2,4,3,12,-1,16,-4,23,-4,14,-2,10,1,13,-5,-14,-5,18,-2,27,1,9,2,10,-6,11,5,-10,4,6,4,12,0,9,1,8,-2,10,-6,11,1,17,-5,16,2,15,0,-2,6,9,2,16,-4,0,-9,6,8,8,0,5,10,-11,6,-12,4,1,11,12,7,13,-1,10,-5,14,-11,-9,-5,19,-2;-1142,731,-5,-4,23,3,13,-5,12,5,9,-4,8,-9,5,4,-7,10,9,1,10,-1,11,-4,6,-10,3,-7,17,-5,18,-5,-1,-4,-16,-1,6,-4,-3,-3,-18,1,-18,3,-11,-1,-19,-3,-30,-2,-13,-1,-6,5,-13,3,-9,-1,-12,8,6,1,16,1,14,0,13,2,-19,2,-22,-1,-14,0,-5,4,23,4,-16,0,-17,3,8,7,7,4,27,6,10,-2;-1045,734,-9,-6,-15,7,3,1,13,0,8,-2;-763,731,0,-3,-10,1,-11,0,-11,-2,-3,1,-11,5,1,4,4,1,23,-1,18,-6;-866,732,8,-7,9,8,26,5,17,-11,-2,-6,20,3,10,4,22,-6,14,-4,1,-5,19,3,10,-7,24,-4,9,-4,9,-9,-18,-5,23,-6,16,-3,15,-9,15,0,-3,-7,-17,-12,-12,4,-16,10,-13,-1,-1,-6,10,-6,14,-5,4,-2,6,-10,-3,-7,-13,2,-25,8,14,-8,11,-6,1,-4,-27,4,-21,6,-12,5,3,3,-15,5,-14,5,0,-3,-29,-2,-9,4,7,7,19,0,20,2,-3,3,4,5,12,10,-2,4,-4,4,-15,5,-21,3,7,2,-11,7,-9,0,-8,4,-5,-3,-18,-2,-36,3,-22,3,-16,1,-8,4,10,4,-14,0,-3,10,8,9,10,4,26,3,-8,-6;-1004,738,12,-2,18,2,3,-3,-10,-5,16,-4,-2,-9,-17,-4,-9,1,-7,3,-25,8,0,3,21,-1,-11,7,11,4;1436,732,-15,0,-21,1,-1,1,9,4,13,1,14,-4,1,-3;-932,728,-11,-8,-11,1,-6,8,0,5,5,5,10,2,21,0,19,-2,-15,-9,-12,-2;-1205,714,-26,-5,-5,4,-23,6,3,3,8,8,9,7,-10,6,34,1,14,-2,25,0,10,-3,11,-4,-13,-3,-24,-7,-13,-7,0,-4;1507,751,-11,-4,-16,1,-19,4,3,3,18,-2,25,-2;-936,750,-6,-4,-14,1,-12,2,5,5,14,2,9,-3,4,-3;1451,756,-8,-8,-37,0,-16,-2,-20,7,5,6,13,2,27,0,36,-5;-985,767,8,-4,0,-6,-5,-7,-16,-1,-11,2,0,5,-16,0,-1,7,11,0,15,3,14,0,1,1;-1082,762,4,-4,9,2,10,0,2,-5,-6,-5,-34,-1,-25,-5,-15,0,-2,3,21,5,-45,-2,-14,2,14,10,9,3,28,-4,18,-6,17,0,-14,9,9,4,10,-1,4,-5;575,707,-6,-1,-32,2,-3,4,-18,3,-1,5,10,2,-1,6,20,8,-9,2,24,8,-3,5,23,5,33,7,33,1,17,4,20,1,7,-4,-7,-3,-36,-5,-30,-4,-31,-10,-15,-10,-16,-9,2,-9,19,-8;-947,771,11,-3,20,0,9,-3,-3,-4,12,-3,6,-2,14,0,14,-1,16,2,20,1,17,-1,10,-4,3,-4,-7,-2,-14,-3,-13,2,-29,-2,-20,0,-17,1,-26,3,-4,6,-1,5,-10,4,-21,1,-11,4,4,4,20,-1;-1162,776,-1,-7,-8,-4,-9,0,-19,-4,-16,-2,-14,2,17,8,21,6,15,0,14,1;491,413,5,-7,5,-1,3,-2,-8,-1,-2,-8,-2,-4,-3,-2,0,-5,3,-7,9,-2,7,-5,15,-2,15,3,1,2,-2,7,2,11,-8,3,3,7,-7,0,2,9,10,-3,8,4,-7,6,-3,5,-8,-2,-1,-8,-3,7,-1,2,3,4,-2,4,-12,3,-4,9,-6,3,0,3,10,-1,0,7,9,2,8,-1,2,9,-2,7,-10,-1,-8,2,-12,-4,-9,-2,-5,-6,-9,-2,-10,-10,9,-9,-1,-7,11,-12,5,-5;-1800,650,3600,0,-13,-5,-13,1,9,-5,6,-8,5,-3,1,-4,-3,-3,-18,2,-28,-7,-9,-1,-16,-8,-14,-6,-4,-4,-14,7,-26,-8,-5,4,-9,-5,-14,2,-3,-7,-12,-10,1,-4,11,-2,-1,-14,-10,-1,-4,-8,4,-4,-17,-6,-4,-11,-15,-2,-3,-11,-14,-9,-4,7,-4,15,-6,22,5,14,9,6,0,4,16,3,17,12,18,10,18,8,8,15,-12,-1,-6,-9,-26,-11,-8,13,-26,-4,-25,-16,8,-7,-22,-2,-15,-1,0,7,-15,2,-13,-5,-30,1,-33,-3,-32,-19,-39,-24,16,-1,5,-6,10,-2,6,5,11,-1,14,-11,1,-9,-8,-10,-1,-12,-4,-16,-15,-14,-4,-7,-13,-12,-14,-11,-6,-6,-14,-6,-6,0,-6,5,-14,-7,-1,-4,-4,1,-4,-4,-3,-3,0,-7,-5,-2,-2,-2,-4,-3,-6,-2,-5,-2,0,-5,-1,-1,4,-1,6,-5,8,-12,3,-6,0,-12,-4,-5,-9,-2,-8,-4,-9,-1,-1,5,2,8,-5,10,8,2,-7,8,-5,2,-1,-1,-3,-1,-1,2,-2,0,-3,2,3,4,2,2,-1,1,3,6,-1,2,-6,1,-4,2,-14,-3,-8,-4,-10,-3,5,5,-2,4,8,6,-6,5,-8,-3,-12,-7,-6,-6,-10,-1,-5,-5,6,-6,8,-2,0,-5,8,-2,11,7,9,-4,7,0,1,-6,-14,-2,-5,-6,-9,-5,-5,-7,10,-5,4,-10,6,-9,7,-8,0,-8,-6,-2,2,-6,6,-3,-2,-8,-2,-8,-6,-1,-7,-10,-8,-14,-9,-12,-14,-9,-14,-8,-11,-1,-6,-5,-4,3,-6,-4,-14,-5,-10,-2,-4,-11,-5,0,-3,7,3,4,-14,3,-5,-1,-13,-9,-8,-9,-2,-7,7,-11,10,-13,9,-6,6,-8,4,-19,-1,-17,-8,-7,-12,-6,-8,-9,-12,-9,-4,6,3,7,-8,6,-8,1,-4,6,-5,10,-9,4,-9,0,2,8,-9,0,-1,-11,-5,-15,-3,-8,0,-8,7,0,4,-9,2,-9,5,-5,6,-2,5,-5,3,-1,6,-6,4,-6,0,-7,-1,-5,1,-3,1,-6,4,-3,3,-9,0,-3,-7,-1,-9,8,-12,8,-1,5,-6,6,-1,9,-4,5,1,7,-2,5,-4,3,-2,5,-5,6,-5,5,-2,-6,-2,5,2,7,3,9,-1,8,3,7,-4,6,1,11,-4,5,-3,12,-2,13,-4,8,-7,-5,-11,-7,-6,1,-6,2,3,13,-2,9,-8,12,2,3,-6,2,-7,8,-3,5,-1,5,-2,5,-4,6,-9,0,1,-4,-3,-6,-5,2,-1,-1,-3,1,-4,1,-1,-4,-7,0,-12,-2,0,-8,-5,-5,-14,-7,-12,-12,-7,-6,-10,-7,0,-4,-5,-3,-9,-3,-5,-1,-3,-8,2,-13,1,-8,-4,-9,0,-17,-6,-1,-4,-8,3,-3,-9,-3,-4,-6,-4,-3,-9,9,-5,14,-4,10,-3,5,-5,9,-3,13,-2,6,-9,14,-4,19,-3,13,0,12,-2,10,-14,-6,-7,1,-13,12,4,4,-3,3,-11,9,-8,2,-3,8,-7,7,-19,-2,-16,0,-14,-1,-19,3,-11,2,-11,1,-4,13,-5,1,-8,-1,-10,-5,-12,3,-10,8,-10,3,-6,9,-8,13,-5,-1,-7,3,-3,-4,-6,1,2,-5,-1,-2,3,-7,4,-9,5,-2,2,-4,7,-4,0,-4,-1,-4,1,-3,3,-3,2,-3,1,-2,-1,7,3,5,3,1,3,-3,0,-6,-2,-6,2,-4,2,1,0,-3,8,2,8,0,6,-1,7,7,7,6,7,7,3,3,1,-1,-1,-4,-1,-2,1,-8,4,-7,6,-3,7,-2,6,-1,5,-6,2,-3,4,-2,0,-2,-4,-6,-1,-3,-4,-3,-4,-7,-5,1,-2,-3,-1,-5,1,-6,-1,-2,-5,0,-6,-3,-1,-5,-2,-2,-6,0,-4,-3,0,-4,-5,-3,-6,1,-6,-3,-5,0,-7,-3,-2,-5,0,-3,-10,-4,-16,-5,-9,-7,-5,-1,-3,1,-5,-4,-7,-2,-8,-1,-3,0,-2,-3,-3,0,-1,-3,-5,0,-3,-1,-7,0,-3,6,1,6,-2,3,-2,7,-3,4,2,1,-1,4,1,2,0,4,-1,5,-4,3,0,4,-5,3,-6,9,-3,8,-7,7,-4,1,-7,10,-1,7,1,6,-6,11,-5,4,-5,2,-3,6,0,2,-3,5,-3,2,-3,8,-7,8,-5,7,-5,0,2,5,0,4,2,4,-1,1,-3,-4,-2,-8,-2,-5,-3,-2,-3,4,-5,4,-7,15,-1,-1,4,-11,6,-10,8,-16,4,-5,3,-6,9,-11,-2,-1,0,-7,12,-9,2,-2,3,-10,-2,-2,1,-10,4,-12,4,-2,5,-4,6,-12,3,-9,5,-5,14,-9,5,-6,6,-6,3,-3,5,-3,2,-3,0,-4,-6,-3,4,-2,4,-2,2,-4,4,-5,5,0,10,3,10,1,9,3,5,1,4,2,5,0,4,0,4,2,6,1,4,3,4,0,0,-3,-1,-5,0,-6,-2,-3,-2,-11,-5,-11,-6,-13,-9,-15,-9,-11,-11,-13,-10,-9,-15,-9,-10,-8,-11,-12,-2,-5,-2,-3,-7,-4,-3,-4,-3,-1,-2,-7,-3,-4,-2,-6,-4,-4,-5,-12,1,-6,6,-3,1,-3,-3,-6,1,-3,-1,-5,3,-6,5,-10,3,-2,2,-5,-1,-10,2,-8,0,-16,2,-5,-3,-7,-4,-7,-6,-6,-10,-4,-11,-5,-11,-11,-4,-1,-7,-8,-4,-2,-1,-7,5,-8,2,-5,0,-3,2,0,-1,-10,-1,-4,2,-2,-1,-4,-5,-4,-8,-3,-12,-6,-4,-3,1,-4,2,-1,-1,-5,-2,-8,-1,-8,-3,-5,-7,-5,-2,-1,-4,-5,-3,-5,-5,-7,-12,-11,-7,-6,-7,-4,-11,-4,-5,-1,-1,-2,-6,1,-5,-2,-11,2,-6,-1,-4,0,-11,-4,-8,-1,-6,-4,-5,0,-4,3,-3,1,-5,4,0,-1,-2,2,1,6,-4,7,3,2,0,7,-6,10,-5,8,-8,13,-7,8,-4,7,-2,10,-3,7,-3,15,0,12,-1,6,-4,4,-5,8,-6,12,-2,7,-8,9,-1,8,-1,6,2,9,3,9,1,5,3,9,2,4,6,6,3,5,1,7,0,6,-3,3,-3,6,-2,6,0,2,3,4,-3,10,-2,7,-5,6,1,2,-1,3,-3,8,-8,10,-10,10,-7,9,-6,10,0,3,2,3,3,8,2,7,-2,2,3,11,2,8,-4,6,-5,2,-2,5,-2,1,0,3,-10,-4,-4,1,-4,-3,-8,1,-5,6,-4,7,-7,7,-7,0,-9,0,-8,-2,-8,-2,-16,-6,-6,-3,-9,-3,-9,3,-4,0,-7,2,-6,0,-12,-2,-7,-3,-10,-4,-2,1,-3,0,-10,4,-9,8,-9,5,-6,7,-3,1,-7,4,-5,5,-2,4,-1,7,-5,6,-4,4,-2,1,-3,2,-1,5,-1,2,-3,1,-6,5,-4,0,-2,3,0,2,-3,2,-1,2,-1,8,1,4,-4,8,-5,3,4,2,5,7,2,5,-1,6,3,5,2,9,-2,10,-1,5,1,5,-2,5,-6,4,1,4,0,5,4,3,3,5,0,3,3,7,6,7,3,1,3,6,0,5,4,7,6,3,7,10,5,4,9,1,8,7,5,3,8,8,-2,13,4,8,1,6,6,6,10,5,8,4,7,10,3,7,7,0,6,-5,10,1,10,-2,4,0,10,5,11,2,6,4,10,3,17,2,16,1,5,-2,10,4,10,0,4,-2,7,0,11,5,7,-2,0,-5,8,4,1,-2,-5,-5,0,-5,3,-2,-1,-9,-6,-5,1,-5,6,0,2,-5,4,-2,12,-3,4,1,8,-2,13,-4,5,-9,9,-2,14,-4,11,-5,5,2,5,5,-3,8,3,4,8,5,6,1,14,-2,3,-4,4,0,3,-2,10,-1,3,-3,13,0,10,-3,9,-3,5,-1,8,3,4,3,9,1,7,-2,3,-5,2,4,8,-3,8,0,5,2,3,3,-1,1,3,5,2,7,1,3,4,8,5,7,-1,8,2,4,-3,5,4,4,-6,-1,-9,2,-7,-6,-15,-1,-8,5,-11,1,-2,-4,-7,-2,-10,6,-11,0,-6,10,-7,5,5,8,-6,5,11,9,15,1,4,7,19,-1,12,6,12,3,17,0,17,-7,14,-4,12,2,9,-1,12,5,1,5,-2,6,-6,4,-6,1,-3,3,-13,9,-12,4,-8,5,7,2,8,8,-5,4,14,4,0,3,-9,-2,-8,-1,-6,-3,-10,-1,-8,-3,0,-6,5,-3,10,1,-2,-4,-11,-2,-13,-5,-6,2,2,4,-10,3,1,2,10,4,-3,2,-16,2,0,4,-10,-1,-3,-6,-8,-7,0,-3,-5,-2,-3,1,-2,-12,-6,-4,-3,-7,3,-6,1,-4,9,-3,-2,-2,-12,-1,-4,-3,-8,-5,-4,4,1,2,-7,1,-5,0,-12,-2,7,-6,-5,-1,-6,0,-5,5,-2,-2,3,-6,5,-5,-4,-2,5,-5,5,-3,0,-5,-9,2,3,-5,-6,-1,4,-9,-7,0,-8,4,-4,8,-2,7,-4,5,-5,5,0,3,-2,1,0,2,-6,4,-1,4,1,7,1,3,-1,2,-2,1,-3,3,-5,2,-9,3,-6,4,-9,3,-8,7,2,1,-5,4,0,4,-6,1,-3,-4,-3,3,0,4,2,1,-8,1,-8,-3,1,-5,-1,-3,3,-5,9,-5,5,-8,11,-8,8,0,3,-3,-3,-2,9,-3,7,-3,9,-5,1,-2,-2,-4,-6,5,-8,1,-4,-6,7,-4,-1,-5,-5,-1,-5,-8,-4,-1,0,3,2,6,2,2,-4,5,-3,5,-4,2,-3,4,-6,2,-5,4,-7,1,-8,4,-9,7,-7,5,-3,10,-5,1,-8,4,-5,-2,-6,-4,-4,-1,-9,-6,-19,3,-15,-3,-1,-6,0,-6,-9,-7,-13,-2,-1,-3,-6,-6,-4,-8,4,-6,-6,-4,-2,-7,-7,-2,-7,-7,-13,0,-10,0,-6,-4,-4,-4,-5,1,-3,4,-3,5,-10,2,-4,-3,-5,2,-5,-1,2,8,-1,6,-5,1,-2,3,1,7,4,4,0,4,2,6,0,4,-2,3,0,4,0,7,-4,4,14,7,12,-1,14,0,11,-2,8,1,16,-1,5,6,2,20,-10,11,-8,5,-15,4,-1,7,13,2,17,-3,-3,12,9,-5,23,8,3,8,9,2,8,2,5,3,9,15,14,4,8,0,2,2,8,0,2,-2,7,5,-2,4,-1,6,-4,5,0,10,2,3,2,3,9,1,4,2,8,3,-1,-5,-2,-3,1,-3,5,-1,-2,-4,-3,1,-8,-7,3,-5,0,-4,10,-2,0,-4,11,2,5,3,11,-4,5,-3,7,3,16,4,12,4,10,-2,1,-3,10,0,2,5,14,3,-2,8,0,8,5,6,9,4,8,-8,8,0,2,8,1,6,-3,-1,-7,3,-1,6,13,3,13,1,10,-2,11,1,11,5,-10,5,-18,-1,-18,-3,-16,-3,-6,6,-10,3,2,10,-4,9,4,6,9,6,23,11,7,2,-1,4,-14,5,-17,-3,-10,-7,2,-6,-16,-8,-20,-9,-7,-14,7,-7,10,-5,-9,-11,-11,-3,-4,-17,-5,-9,-12,1,-6,-8,-12,0,-3,9,-8,11,-8,15,-6,6,-20,-12,-13,-2,-14,5,-4,11,-3,23,9,6,27,9,19,10,19,14,24,19,16,8,28,12,22,5,16,-1,15,8,19,0,18,2,31,-7,-13,-3,11,-6,10,3,17,-6,27,-2,38,-12,8,-4,0,-7,-11,-5,-16,-3,-45,8,-7,-2,16,-7,1,-15,13,-3,8,-2,1,4,-6,5,7,3,24,-6,8,3,-6,7,23,10,9,-1,10,-3,5,7,-8,6,5,6,-7,6,28,-4,5,-5,-12,-1,0,-6,7,-3,16,2,2,6,21,5,35,9,8,-1,-10,-6,12,-1,7,3,19,1,15,4,11,-6,12,6,-11,6,6,4,29,-4,14,-3,36,-11,7,5,-10,5,-1,3,-12,1,4,4,-6,8,0,3,18,9,7,9,7,2,27,-2,2,-6,-10,-8,7,-3,3,-7,-2,-14,11,-6,-5,-7,-19,-14,11,-1,4,3,11,3,3,5,9,5,-6,5,4,7,-11,1,-2,5,8,10,-13,8,18,7,-2,7,5,1,5,-6,-4,-10,11,-1,-5,7,17,4,21,0,18,-6,-9,9,-1,10,18,3,24,-1,21,1,-8,6,12,6,11,0,20,5,26,2,3,2,27,1,8,-2,22,5,19,0,2,5,10,4,24,4,17,-3,-14,-3,23,-1,2,-5,10,2,29,0,22,-5,8,-4,-2,-5,-11,-3,-26,-5,-8,-3,12,-2,15,-2,9,2,5,-7,5,3,16,2,32,-2,2,-5,42,-1,1,7,21,-1,16,0,16,-6,5,-6,-6,-4,12,-8,16,-4,10,10,16,-4,17,3,19,-4,7,3,17,-1,-8,9,14,4,90,-6,9,-6,26,-8,40,2,20,-1,8,-4,-1,-8,12,-3,14,2,18,1,18,-2,19,1,18,-9,12,3,-8,7,5,4,31,-3,21,1,29,-5,-3586,-4;-938,775,-5,0,-19,1,-2,2,20,0,7,-2,-1,-1;-1102,777,-19,-3,-14,3,8,4,14,1,14,-2,-3,-3;247,779,-22,-5,-18,3,7,2,-6,4,21,2,4,-4,14,-2;-1097,786,-12,-2,-16,0,0,2,10,3,5,-1,13,-2;-958,781,-15,-3,-8,3,-5,4,0,4,13,-1,5,0,12,-4,-2,-3;-1001,783,4,-4,-16,1,-16,3,-23,1,10,3,-12,2,-1,4,20,-1,27,-4,7,-5;1051,783,-57,-4,19,13,8,1,7,0,26,-6,-3,-4;183,797,32,-7,-25,-4,-5,-8,-9,-2,-5,-8,-12,0,-21,6,9,3,-15,3,-20,9,-8,8,28,3,5,-3,14,0,4,3,15,1,13,-4;254,804,20,-3,-15,-6,-29,-1,-29,2,-2,2,-14,1,-11,4,31,3,14,-2,10,3,25,-3;511,805,-13,-1,-9,-1,-1,-1,-12,-2,-11,2,6,4,-23,0,20,2,15,0,2,-3,6,3,9,1,15,-2,-4,-2;999,789,-21,-1,-28,2,-17,4,-8,7,-13,2,26,7,21,3,20,-6,23,-9,-3,-9;-870,797,12,-4,-14,-3,-18,-7,-18,-1,-21,1,-11,5,1,3,8,3,-19,0,-11,3,-6,5,7,4,7,3,10,1,-4,2,23,1,13,-6,17,-2,16,-2,8,-6;-685,831,27,-1,21,-1,18,-3,0,-2,-24,-5,-25,-2,-9,-2,22,0,-23,-6,-17,-3,-17,-8,-20,-2,-7,-2,-30,-1,14,-1,-7,-2,8,-5,-9,-3,-16,-3,-5,-4,-14,-3,2,-2,17,0,0,-2,-27,-6,-26,3,-29,-2,-15,1,-19,1,-1,5,18,2,-5,7,7,1,26,-5,-13,7,-17,2,8,4,18,2,3,3,-14,4,-4,6,27,-1,8,-1,16,4,-23,1,-35,-1,-18,4,-8,4,-12,3,-2,3,15,2,12,0,19,2,15,4,12,-1,11,-3,8,6,13,1,18,1,30,1,6,-1,29,1,21,0,22,-1;-271,835,63,-8,-19,-4,-38,0,-54,-1,5,-2,35,1,31,-3,19,3,8,-4,-11,-5,26,3,48,4,30,-2,6,-4,-41,-7,-5,-3,-32,-1,23,-1,-12,-7,-8,-6,0,-12,12,-6,-15,-1,-17,-3,19,-5,2,-9,-11,0,13,-9,-22,-1,12,-4,-4,-3,-14,-2,-14,0,13,-7,0,-4,-20,4,-5,-3,14,-2,13,-6,3,-8,-17,-2,-8,4,-12,5,3,-6,-12,-6,27,0,14,-1,-27,-8,-27,-8,-30,-4,-11,0,-10,-4,-14,-10,-22,-7,-6,-1,-14,-2,-14,-2,-9,-7,0,-7,-5,-6,-16,-8,4,-8,-5,-8,-5,-10,-14,-1,-15,9,-20,0,-9,5,-7,10,-17,12,-5,7,-2,9,-14,9,4,7,-7,4,10,12,15,3,4,4,2,8,-11,-3,-6,-2,-9,-1,-12,3,-1,7,4,5,10,0,20,-2,-17,6,-9,3,-10,-1,-8,3,11,9,-6,4,-8,7,-12,10,-13,4,0,4,-27,6,-21,1,-27,-1,-24,0,-12,3,-17,6,26,3,20,1,-42,2,-23,4,1,4,38,5,37,5,4,4,-27,3,9,4,34,7,15,1,-4,5,23,2,31,2,31,0,11,-3,26,5,24,-3,14,-1,21,-3,-24,5,1,4,34,6,35,0,13,3,35,1,80,-1';
  let cache = null;
  /** Returns an array of polylines, each a Float32Array of [lon, lat, lon, lat, …]. */
  R.worldLand = function () {
    if (cache) return cache;
    cache = RAW.split(';').map((s) => {
      const v = s.split(',').map(Number);
      const out = new Float32Array(v.length);
      let x = 0;
      let y = 0;
      for (let i = 0; i < v.length; i += 2) {
        x += v[i];
        y += v[i + 1];
        out[i] = x / 10;
        out[i + 1] = y / 10;
      }
      return out;
    });
    return cache;
  };
})(window.JAQAWorkspace);

/* ---- modules/globe.js ---- */
/*
 * globe.js — dependency-free orthographic globe for the Situation Room.
 *
 * Clean-room implementation (no third-party code). Draws on a <canvas>:
 * sphere, graticule, Natural Earth coastlines (R.worldLand) and evidence
 * markers taken ONLY from records already loaded in this session. It loads no
 * map tiles, no fonts and no remote assets, and makes no network requests.
 *
 * Interaction: drag / arrow keys rotate, wheel / + − zoom, 0 resets, Enter
 * selects the marker nearest the reticle. Auto-rotation and pulses are
 * disabled when the user prefers reduced motion or the tab is hidden.
 * A text alternative (marker table) is rendered by the caller.
 */
(function (R) {
  'use strict';
  const RAD = Math.PI / 180;
  const reduceMotion = () => !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  function cssVar(el, name, fallback) {
    const v = getComputedStyle(el).getPropertyValue(name).trim();
    return v || fallback;
  }

  /**
   * create(host, opts) → controller
   * opts: { view: {lon, lat, zoom, auto}, label, onSelect(point), onView(view), compact }
   */
  function create(host, opts) {
    const o = opts || {};
    const view = o.view || { lon: 10, lat: 20, zoom: 1, auto: true };
    const canvas = document.createElement('canvas');
    canvas.className = 'rq-globe-canvas';
    canvas.setAttribute('role', 'img');
    canvas.setAttribute('tabindex', '0');
    canvas.setAttribute('aria-label', (o.label || 'Evidence globe') + '. Use arrow keys to rotate, plus and minus to zoom, Enter to open the marker nearest the centre. A text list of markers follows.');
    host.appendChild(canvas);
    const tip = document.createElement('div');
    tip.className = 'rq-globe-tip';
    tip.setAttribute('aria-hidden', 'true');
    host.appendChild(tip);

    const ctx = canvas.getContext('2d');
    let W = 0;
    let H = 0;
    let dpr = 1;
    let points = [];
    let hover = null;
    let selected = null;
    let raf = 0;
    let lastT = 0;
    let dragging = null;
    let idleUntil = 0;
    let anim = null;
    let alive = true;

    function resize() {
      const r = host.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = Math.max(200, r.width);
      H = Math.max(200, r.height);
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
      canvas.style.width = W + 'px';
      canvas.style.height = H + 'px';
      draw(performance.now());
    }
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(resize) : null;
    if (ro) ro.observe(host);

    const radius = () => (Math.min(W, H) / 2) * 0.86 * view.zoom;

    /** Orthographic projection. Returns [x, y, visible]. */
    function project(lon, lat) {
      const l = (lon - view.lon) * RAD;
      const p = lat * RAD;
      const p0 = view.lat * RAD;
      const cosc = Math.sin(p0) * Math.sin(p) + Math.cos(p0) * Math.cos(p) * Math.cos(l);
      const r = radius();
      const x = W / 2 + r * Math.cos(p) * Math.sin(l);
      const y = H / 2 - r * (Math.cos(p0) * Math.sin(p) - Math.sin(p0) * Math.cos(p) * Math.cos(l));
      return [x, y, cosc > 0];
    }
    /** Inverse projection for the reticle readout. */
    function invert(x, y) {
      const r = radius();
      const px = (x - W / 2) / r;
      const py = -(y - H / 2) / r;
      const rho = Math.sqrt(px * px + py * py);
      if (rho > 1) return null;
      const c = Math.asin(rho);
      const p0 = view.lat * RAD;
      const lat = rho === 0 ? view.lat : Math.asin(Math.cos(c) * Math.sin(p0) + (py * Math.sin(c) * Math.cos(p0)) / rho) / RAD;
      const lon = view.lon + Math.atan2(px * Math.sin(c), rho * Math.cos(c) * Math.cos(p0) - py * Math.sin(c) * Math.sin(p0)) / RAD;
      return { lat, lon: ((lon + 540) % 360) - 180 };
    }

    function strokePolyline(arr, step) {
      let pen = false;
      for (let i = 0; i < arr.length; i += step) {
        const [x, y, vis] = project(arr[i], arr[i + 1]);
        if (vis) {
          if (pen) ctx.lineTo(x, y);
          else {
            ctx.moveTo(x, y);
            pen = true;
          }
        } else pen = false;
      }
    }

    function draw(t) {
      if (!W) return;
      const col = {
        sea: cssVar(host, '--globe-sea', '#07152a'),
        seaEdge: cssVar(host, '--globe-sea-edge', '#0b2545'),
        grid: cssVar(host, '--globe-grid', 'rgba(45,212,191,0.14)'),
        land: cssVar(host, '--globe-land', 'rgba(94,234,212,0.85)'),
        rim: cssVar(host, '--globe-rim', 'rgba(45,212,191,0.55)'),
        quake: cssVar(host, '--globe-quake', '#fb7185'),
        place: cssVar(host, '--globe-place', '#22d3ee'),
        signal: cssVar(host, '--globe-signal', '#fbbf24'),
        entity: cssVar(host, '--globe-entity', '#a78bfa'),
        text: cssVar(host, '--globe-text', '#d8e6f5')
      };
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      const r = radius();
      const cx = W / 2;
      const cy = H / 2;

      // Atmosphere glow + sphere.
      const glow = ctx.createRadialGradient(cx, cy, r * 0.9, cx, cy, r * 1.18);
      glow.addColorStop(0, col.rim);
      glow.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.globalAlpha = 0.35;
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(cx, cy, r * 1.18, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
      const sea = ctx.createRadialGradient(cx - r * 0.35, cy - r * 0.4, r * 0.1, cx, cy, r);
      sea.addColorStop(0, col.seaEdge);
      sea.addColorStop(1, col.sea);
      ctx.fillStyle = sea;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();

      // Graticule every 15°.
      ctx.strokeStyle = col.grid;
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let lon = -180; lon < 180; lon += 15) {
        const a = [];
        for (let lat = -90; lat <= 90; lat += 3) a.push(lon, lat);
        strokePolyline(a, 2);
      }
      for (let lat = -75; lat <= 75; lat += 15) {
        const a = [];
        for (let lon = -180; lon <= 180; lon += 3) a.push(lon, lat);
        strokePolyline(a, 2);
      }
      ctx.stroke();

      // Coastlines.
      ctx.strokeStyle = col.land;
      ctx.lineWidth = o.compact ? 0.9 : 1.15;
      ctx.beginPath();
      for (const ln of R.worldLand()) strokePolyline(ln, 2);
      ctx.stroke();

      // Rim.
      ctx.strokeStyle = col.rim;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();

      // Markers.
      const phase = reduceMotion() ? 0 : (t / 1000) % 2;
      for (const pt of points) {
        const [x, y, vis] = project(pt.lon, pt.lat);
        pt._x = x;
        pt._y = y;
        pt._vis = vis;
        if (!vis) continue;
        const c = col[pt.kind] || col.place;
        const base = pt.kind === 'quake' ? 2.5 + (pt.weight || 0) * 7 : pt.kind === 'entity' ? 5 : 4;
        if (pt.kind === 'quake' && phase) {
          ctx.strokeStyle = c;
          ctx.globalAlpha = 1 - (phase % 1);
          ctx.beginPath();
          ctx.arc(x, y, base + (phase % 1) * 14, 0, Math.PI * 2);
          ctx.stroke();
          ctx.globalAlpha = 1;
        }
        ctx.fillStyle = c;
        ctx.strokeStyle = 'rgba(0,0,0,0.6)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        if (pt.kind === 'entity') {
          ctx.moveTo(x, y - base);
          ctx.lineTo(x + base, y);
          ctx.lineTo(x, y + base);
          ctx.lineTo(x - base, y);
          ctx.closePath();
        } else if (pt.kind === 'signal') {
          ctx.rect(x - base * 0.8, y - base * 0.8, base * 1.6, base * 1.6);
        } else ctx.arc(x, y, base, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        if (pt === hover || pt === selected) {
          ctx.strokeStyle = col.text;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(x, y, base + 5, 0, Math.PI * 2);
          ctx.stroke();
        }
      }
      if (o.onView) o.onView({ lat: view.lat, lon: view.lon, zoom: view.zoom, visible: points.filter((p) => p._vis).length });
    }

    function needsLoop() {
      if (!alive || document.hidden || reduceMotion()) return false;
      return !!anim || (view.auto && !dragging && performance.now() > idleUntil) || points.some((p) => p.kind === 'quake');
    }
    function loop(t) {
      raf = 0;
      if (!alive) return;
      if (!host.isConnected) return destroy();
      const dt = lastT ? Math.min(64, t - lastT) : 16;
      lastT = t;
      if (anim) {
        const k = Math.min(1, (t - anim.t0) / anim.ms);
        const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
        view.lon = anim.from.lon + anim.dLon * e;
        view.lat = anim.from.lat + (anim.to.lat - anim.from.lat) * e;
        if (k >= 1) anim = null;
      } else if (view.auto && !dragging && t > idleUntil && !reduceMotion()) {
        view.lon = ((view.lon + dt * 0.004 + 540) % 360) - 180;
      }
      draw(t);
      if (needsLoop()) raf = requestAnimationFrame(loop);
    }
    function kick() {
      if (!raf && alive) {
        lastT = 0;
        raf = requestAnimationFrame(loop);
      }
    }
    function redraw() {
      if (needsLoop()) kick();
      else draw(performance.now());
    }
    const onVis = () => redraw();
    document.addEventListener('visibilitychange', onVis);

    function nearest(x, y, maxD) {
      let best = null;
      let bd = maxD;
      for (const p of points) {
        if (!p._vis) continue;
        const d = Math.hypot(p._x - x, p._y - y);
        if (d < bd) {
          bd = d;
          best = p;
        }
      }
      return best;
    }
    function pause() {
      idleUntil = performance.now() + 8000;
    }

    canvas.addEventListener('pointerdown', (e) => {
      dragging = { x: e.clientX, y: e.clientY, lon: view.lon, lat: view.lat, moved: false };
      canvas.setPointerCapture(e.pointerId);
      anim = null;
    });
    canvas.addEventListener('pointermove', (e) => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      if (dragging) {
        const k = 0.35 / view.zoom;
        const dx = e.clientX - dragging.x;
        const dy = e.clientY - dragging.y;
        if (Math.abs(dx) + Math.abs(dy) > 3) dragging.moved = true;
        view.lon = ((dragging.lon - dx * k + 540) % 360) - 180;
        view.lat = Math.max(-85, Math.min(85, dragging.lat + dy * k));
        pause();
        draw(performance.now());
        return;
      }
      const h = nearest(x, y, 12);
      if (h !== hover) {
        hover = h;
        canvas.style.cursor = h ? 'pointer' : 'grab';
        if (h) {
          tip.textContent = h.label;
          tip.style.left = Math.min(W - 220, Math.max(4, x + 12)) + 'px';
          tip.style.top = Math.max(4, y - 10) + 'px';
          tip.classList.add('is-on');
        } else tip.classList.remove('is-on');
        if (!raf) draw(performance.now());
      }
    });
    const endDrag = (e) => {
      if (!dragging) return;
      const wasClick = !dragging.moved;
      dragging = null;
      if (wasClick) {
        const rect = canvas.getBoundingClientRect();
        const p = nearest(e.clientX - rect.left, e.clientY - rect.top, 14);
        if (p) select(p);
      }
      redraw();
    };
    canvas.addEventListener('pointerup', endDrag);
    canvas.addEventListener('pointercancel', () => {
      dragging = null;
      redraw();
    });
    canvas.addEventListener('pointerleave', () => {
      hover = null;
      tip.classList.remove('is-on');
    });
    canvas.addEventListener(
      'wheel',
      (e) => {
        e.preventDefault();
        view.zoom = Math.max(0.7, Math.min(4, view.zoom * (e.deltaY < 0 ? 1.12 : 1 / 1.12)));
        pause();
        redraw();
      },
      { passive: false }
    );
    canvas.addEventListener('keydown', (e) => {
      const step = 6 / view.zoom;
      let handled = true;
      if (e.key === 'ArrowLeft') view.lon -= step;
      else if (e.key === 'ArrowRight') view.lon += step;
      else if (e.key === 'ArrowUp') view.lat = Math.min(85, view.lat + step);
      else if (e.key === 'ArrowDown') view.lat = Math.max(-85, view.lat - step);
      else if (e.key === '+' || e.key === '=') view.zoom = Math.min(4, view.zoom * 1.2);
      else if (e.key === '-' || e.key === '_') view.zoom = Math.max(0.7, view.zoom / 1.2);
      else if (e.key === '0') Object.assign(view, { zoom: 1 });
      else if (e.key === 'Enter') {
        const p = nearest(W / 2, H / 2, Math.min(W, H) / 3);
        if (p) select(p);
      } else handled = false;
      if (handled) {
        e.preventDefault();
        view.lon = ((view.lon + 540) % 360) - 180;
        pause();
        redraw();
      }
    });

    function select(p) {
      selected = p;
      focus(p.lat, p.lon);
      if (o.onSelect) o.onSelect(p);
    }
    function focus(lat, lon) {
      pause();
      const to = { lat: Math.max(-80, Math.min(80, lat)), lon };
      if (reduceMotion()) {
        view.lat = to.lat;
        view.lon = lon;
        return redraw();
      }
      let dLon = lon - view.lon;
      if (dLon > 180) dLon -= 360;
      if (dLon < -180) dLon += 360;
      anim = { from: { lat: view.lat, lon: view.lon }, to, dLon, t0: performance.now(), ms: 900 };
      kick();
    }
    function destroy() {
      alive = false;
      if (raf) cancelAnimationFrame(raf);
      raf = 0;
      if (ro) ro.disconnect();
      document.removeEventListener('visibilitychange', onVis);
    }

    resize();
    redraw();
    return {
      view,
      setPoints(list) {
        points = list || [];
        host.setAttribute('data-points', String(points.length));
        redraw();
      },
      focus,
      redraw,
      setAuto(on) {
        view.auto = !!on;
        redraw();
      },
      destroy,
      invert: () => invert(W / 2, H / 2)
    };
  }

  R.globe = { create, reduceMotion };
})(window.JAQAWorkspace);

/* ---- modules/searchPipeline.js ---- */
/*
 * searchPipeline.js — entity detection, intent routing, query plans and
 * session lifecycle.
 *
 * Pipeline: sanitize → privacy guard → local pattern detection → (optional)
 * live resolution → plan a SMALL initial request budget (≤ 5 Tier A calls)
 * → render Overview progressively → deeper modules lazy-load on open or on
 * explicit user action.
 *
 * Detection never guesses silently: it returns a primary interpretation with
 * a confidence label plus alternative candidates the user can switch to.
 * Cross-module hand-off happens through R.state.session (memory only); the
 * search term is never written to the URL.
 */
(function (R) {
  'use strict';

  /* --------------------------- task factories --------------------------- */
  const norm = (s) => String(s || '').toLowerCase().trim();
  const C = R.clients;
  const T = (R.T = {
    gleifSearch: (q) => ({ key: 'gleif:search:' + norm(q), sourceId: 'gleif', label: 'GLEIF legal entity search', run: () => C.gleif.search(q) }),
    gleifLei: (lei) => ({ key: 'gleif:lei:' + lei, sourceId: 'gleif', label: 'GLEIF LEI record', run: () => C.gleif.byLei(lei) }),
    gleifParent: (lei, which) => ({ key: `gleif:${which}:${lei}`, sourceId: 'gleif', label: which === 'ultimate' ? 'GLEIF ultimate parent' : 'GLEIF direct parent', run: () => C.gleif.parent(lei, which) }),
    gleifChildren: (lei) => ({ key: 'gleif:children:' + lei, sourceId: 'gleif', label: 'GLEIF direct children', run: () => C.gleif.children(lei, 20) }),
    wdSearch: (q) => ({ key: 'wd:search:' + norm(q), sourceId: 'wikidata', label: 'Wikidata background search', run: () => C.wikidata.search(q) }),
    wdIds: (qid) => ({ key: 'wd:ids:' + qid, sourceId: 'wikidata', label: 'Wikidata identifier cross-links', run: () => C.wikidata.identifiers(qid) }),
    wpSummary: (title) => ({ key: 'wp:' + norm(title), sourceId: 'wikipedia', label: 'Wikipedia summary', run: () => C.wikipedia.summary(title) }),
    secSubs: (cik) => ({ key: 'sec:subs:' + C.sec.padCik(cik), sourceId: 'sec', label: 'SEC EDGAR submissions', run: () => C.sec.submissions(cik) }),
    wbCountry: (iso) => ({ key: 'wb:country:' + iso, sourceId: 'worldbank', label: 'World Bank country profile', run: () => C.worldbank.country(iso) }),
    wbInd: (iso, k) => ({ key: `wb:ind:${iso}:${k}`, sourceId: 'worldbank', label: 'World Bank: ' + (C.worldbank.INDICATORS[k] || [k, k])[1], run: () => C.worldbank.indicator(iso, k) }),
    geocode: (name) => ({ key: 'geo:' + norm(name), sourceId: 'openmeteo', label: 'Location resolution (Open-Meteo geocoding)', run: () => C.openmeteo.geocode(name) }),
    quakes: (lat, lon, radius, days) => ({ key: `usgs:${(+lat).toFixed(2)},${(+lon).toFixed(2)}:${radius || 500}:${days || 30}`, sourceId: 'usgs', label: `USGS earthquakes (M4.5+, ${radius || 500} km, ${days || 30} days)`, run: () => C.usgs.near(lat, lon, radius || 500, days || 30, 4.5) }),
    forecast: (lat, lon, label) => ({ key: `om:fc:${(+lat).toFixed(2)},${(+lon).toFixed(2)}`, sourceId: 'openmeteo', label: '7-day forecast (Open-Meteo)', run: () => C.openmeteo.forecast(lat, lon, label) }),
    nws: (lat, lon) => ({ key: `nws:${(+lat).toFixed(2)},${(+lon).toFixed(2)}`, sourceId: 'nws', label: 'NWS active alerts (US only)', run: () => C.nws.alertsAt(lat, lon) }),
    overpass: (lat, lon) => ({ key: `osm:ports:${(+lat).toFixed(2)},${(+lon).toFixed(2)}`, sourceId: 'overpass', label: 'Mapped port features within 15 km (OpenStreetMap)', run: () => C.overpass.portsNear(lat, lon, 15000) }),
    kevCve: (cve) => ({ key: 'kev:cve:' + cve.toUpperCase(), sourceId: 'cisaKev', label: 'CISA KEV lookup', run: () => C.kev.byCve(cve) }),
    kevMentions: (t) => ({ key: 'kev:mentions:' + norm(t), sourceId: 'cisaKev', label: 'CISA KEV vendor/product mentions', run: () => C.kev.mentions(t) }),
    nvdCve: (cve) => ({ key: 'nvd:cve:' + cve.toUpperCase(), sourceId: 'nvd', label: 'NVD CVE record', run: () => C.nvd.cve(cve) }),
    nvdKeyword: (t) => ({ key: 'nvd:kw:' + norm(t), sourceId: 'nvd', label: 'NVD keyword search', run: () => C.nvd.keyword(t) }),
    cpscSearch: (t) => ({ key: 'cpsc:title:' + norm(t), sourceId: 'cpsc', label: 'CPSC recalls (title match)', run: () => C.cpsc.search(t) }),
    cpscNum: (n) => ({ key: 'cpsc:num:' + n, sourceId: 'cpsc', label: 'CPSC recall number', run: () => C.cpsc.byNumber(n) }),
    nhtsaCampaign: (id) => ({ key: 'nhtsa:' + id.toUpperCase(), sourceId: 'nhtsa', label: 'NHTSA recall campaign', run: () => C.nhtsa.campaign(id.toUpperCase()) }),
    usaAwards: (o) => ({ key: `usa:${o.kind || 'contracts'}:${o.recipient ? 'r:' + norm(o.recipient) : 'k:' + norm(o.keyword)}:${o.from || ''}:${o.to || ''}:${o.page || 1}`, sourceId: 'usaspending', label: `USAspending ${o.kind === 'grants' ? 'grants/assistance' : o.kind === 'idvs' ? 'IDVs / frameworks' : 'contract awards'} (${o.recipient ? 'recipient' : 'keyword'})`, run: () => C.usaspending.awards(o) }),
    usaAwardDetail: (id) => ({ key: 'usa:detail:' + id, sourceId: 'usaspending', label: 'USAspending award detail', run: () => C.usaspending.awardDetail(id) }),
    frSearch: (term, o) => ({ key: `fr:${norm(term)}:${JSON.stringify(o || {})}`, sourceId: 'federalRegister', label: 'Federal Register documents' + (o && o.type ? ' (' + o.type + ')' : ''), run: () => C.federalRegister.search(term, o) }),
    frDoc: (n) => ({ key: 'fr:doc:' + n, sourceId: 'federalRegister', label: 'Federal Register document', run: () => C.federalRegister.doc(n) }),
    courts: (q, type) => ({ key: `cl:${type || 'r'}:${norm(q)}`, sourceId: 'courtlistener', label: type === 'o' ? 'CourtListener opinions' : 'CourtListener dockets (RECAP)', run: () => C.courtlistener.search(q, type) }),
    ecb: (ccy) => ({ key: 'ecb:' + ccy, sourceId: 'ecb', label: 'ECB reference rate EUR/' + ccy, run: () => C.ecb.exr(ccy, 30) }),
    gdelt: (q) => ({ key: 'gdelt:' + norm(q), sourceId: 'gdelt', label: 'GDELT media signals (3 months)', run: () => C.gdelt.articles(q) }),
    epa: (name) => ({ key: 'epa:' + norm(name), sourceId: 'epa', label: 'EPA ECHO facilities (name match)', run: () => C.epa.facilities(name) })
  });

  /* ----------------------------- detection ----------------------------- */
  const TYPES = {
    organization: 'Organization', lei: 'Legal entity / LEI', ticker: 'Public company / ticker', cik: 'SEC CIK', registration: 'Registration number',
    insurer: 'Insurer', reinsurer: 'Reinsurer', broker: 'Broker', mga: 'MGA', captive: 'Captive / protected cell / RRG', ils: 'ILS / cat bond entity', tpa: 'TPA / claims administrator', syndicate: 'Lloyd’s syndicate',
    regulator: 'Regulator', ratingAgency: 'Rating agency (link-out)', country: 'Country / sovereign', port: 'Port / logistics node', place: 'Facility / geographic location',
    hs: 'Product / HS code', category: 'Category', cve: 'Cyber vulnerability (CVE)', cwe: 'Weakness (CWE)', tender: 'Tender / procurement notice', award: 'Award / contract', grant: 'Grant / funding opportunity',
    ppp: 'PPP / concession / infrastructure project', recall: 'Recall', regdoc: 'Regulatory document', sanctionsId: 'Sanctions / debarment triage', financeDomain: 'Finance risk domain', riskDomain: 'Global risk domain',
    insuranceLine: 'Insurance / reinsurance line', procurement: 'Procurement concept', standard: 'Standard / certification framework', digitalAsset: 'Digital asset concept', vessel: 'Vessel', aircraft: 'Aircraft', person: 'Person (restricted)', freetext: 'Free-text concept'
  };

  // Curated concept routes for common enterprise phrases (quick pills and typed concepts).
  const CONCEPTS = [
    [/^(ted( tender)?s?|tenders electronic daily)$/i, 'procurement', { focus: 'ted' }],
    [/^(usaspending( award)?s?|federal awards?)$/i, 'award', { focus: 'usaspending' }],
    [/^(sam( exclusions?| opportunit(y|ies))?|sam\.gov.*)$/i, 'sanctionsId', { focus: 'sam' }],
    [/^(ofac( search)?|sdn( list)?|sanctions( list)?( search)?|export control( entity list)?|entity list|debarment( list)?)$/i, 'sanctionsId', {}],
    [/^(cisa kev|kev|known exploited vulnerabilit(y|ies))$/i, 'riskDomain', { domain: 'cyber' }],
    [/^(cpsc recalls?|nhtsa recalls?|product recalls?)$/i, 'recall', { concept: true }],
    [/^(federal register( rules?)?|regulatory change( radar)?)$/i, 'regdoc', { concept: true }],
    [/^(world bank lpi|logistics performance( index)?|lpi)$/i, 'riskDomain', { domain: 'logistics' }],
    [/^(un procurement|ungm|world bank procurement|adb tenders?|afdb procurement|idb procurement|ebrd procurement|isdb procurement|development bank procurement)$/i, 'procurement', { focus: 'devBanks' }],
    [/^(eu funding( and| &) tenders|grants?|funding opportunit(y|ies)|subsid(y|ies))$/i, 'grant', {}],
    [/^(ppp( concession)?|concessions?|infrastructure projects?|public[- ]private partnership)$/i, 'ppp', {}],
    [/^(broker panel( tender)?|insurance claims platform( rfp)?|actuarial services( tender)?|captive management( tender)?)$/i, 'procurement', { insuranceRelated: true }],
    [/^(tenders?|rfps?|rfqs?|itts?|eois?|pqqs?|bids?|framework agreements?|dynamic purchasing system|procurement)$/i, 'procurement', {}],
    [/^(modern slavery( registry| register)?)$/i, 'riskDomain', { domain: 'modern-slavery' }],
    [/^(iso ?\d{4,5}(-\d)?|iso\/iec ?\d{4,5}|nist (csf|ai rmf|ssdf)|oecd due diligence|soc ?2|fidic|nec contracts?|solvency ii|iais icps?|cmmc|wto gpa|uncac|fatf)$/i, 'standard', {}],
    [/^(cat ?bonds?|ils|insurance[- ]linked securities?|captives?|reinsurance|retrocession|mga|tpa)$/i, 'insuranceLine', {}],
    [/^(crypto(currency)?|bitcoin|stablecoins?|digital assets?|virtual assets?)$/i, 'digitalAsset', {}],
    [/^(semiconductors?|battery materials|lithium[- ]ion batter(y|ies)|packaging resins?|plastics?|rare earth magnets?|permanent magnets?|steel|aluminium|aluminum|copper|solar panels?|pharmaceuticals?)$/i, 'category', {}]
  ];

  // HS heading hints for common categories (WCO HS nomenclature headings; verify with the official tariff).
  const CATEGORY_HS = {
    semiconductor: ['8541', '8542'], 'battery materials': ['2836.91', '2825.20', '8507.60'], 'lithium-ion': ['8507.60'], 'packaging resins': ['3901', '3902', '3907', '3923'], plastics: ['3901', '3923'],
    'rare earth magnets': ['8505.11', '2846'], 'permanent magnets': ['8505.11'], steel: ['72', '73'], aluminium: ['76'], aluminum: ['76'], copper: ['74'], 'solar panels': ['8541.43'], pharmaceuticals: ['30']
  };

  function categoryHs(q) {
    const t = q.toLowerCase();
    for (const [k, v] of Object.entries(CATEGORY_HS)) if (t.includes(k)) return v;
    return [];
  }

  const COMPANY_SUFFIX = /\b(inc|incorporated|corp|corporation|co|company|ltd|limited|llc|llp|plc|ag|se|sa|nv|bv|gmbh|kgaa|spa|s\.p\.a\.|srl|oyj|ab|asa|pte|bhd|berhad|kk|pty|holdings?|group|partners|industries|technologies|systems|manufacturing|logistics|bank|capital|trust|fund)\.?$/i;

  function detect(raw) {
    const q = raw.trim();
    const up = q.toUpperCase();
    const cands = [];
    const add = (type, confidence, reason, extra) => cands.push(Object.assign({ type, label: TYPES[type], confidence, reason }, extra || {}));

    // Strong identifier patterns first.
    if (R.privacy.isValidLei(up)) add('lei', 'High', 'Matches ISO 17442 LEI format with valid check digits', { lei: up });
    else if (/^[A-Z0-9]{18}[0-9]{2}$/.test(up)) add('lei', 'Low', 'Looks like an LEI but check digits do not validate', { lei: up });
    let m;
    if ((m = /^CVE-(\d{4})-(\d{4,})$/i.exec(q))) add('cve', 'High', 'CVE identifier pattern', { cve: up });
    if ((m = /^CWE-(\d{1,5})$/i.exec(q))) add('cwe', 'High', 'CWE identifier pattern', { cwe: m[1] });
    if ((m = /^(?:CIK\s*)?(\d{10})$/i.exec(q)) || (m = /^CIK\s*(\d{1,10})$/i.exec(q))) add('cik', /^CIK/i.test(q) ? 'High' : 'Medium', '10-digit number may be an SEC CIK', { cik: m[1] });
    if ((m = /^HS\s*(\d{4}(?:[.\s]?\d{2}){0,3})$/i.exec(q))) add('hs', 'High', 'Explicit HS code', { hs: m[1].replace(/\s/g, '') });
    else if ((m = /^(\d{4}\.\d{2}(?:\.\d{2}){0,2})$/.exec(q))) add('hs', 'Medium', 'Dotted HS-style code', { hs: m[1] });
    else if ((m = /^(\d{4}|\d{6}|\d{8})$/.exec(q))) add('hs', 'Low', 'Digits could be an HS heading/subheading (or UNSPSC/NAICS)', { hs: m[1] });
    if ((m = /^(\d{2}[VETC]\d{6})$/i.exec(q))) add('recall', 'High', 'NHTSA recall campaign number pattern', { nhtsa: up });
    if ((m = /^(?:CPSC\s*)?(\d{2}-?\d{3})$/i.exec(q))) add('recall', /CPSC/i.test(q) ? 'High' : 'Low', 'Could be a CPSC recall number', { cpsc: m[1].replace('-', '') });
    if ((m = /^(\d{4}-\d{5})$/.exec(q))) add('regdoc', 'High', 'Federal Register document number pattern', { frDoc: m[1] });
    if (/^[A-Z]{2,8}(-[A-Z0-9]{1,8}){1,3}-\d{4}-\d{3,5}$/.test(up)) add('regdoc', 'Medium', 'Regulatory docket pattern', { docket: up });
    if ((m = /^(\d{1,8}-\d{4})$/.exec(q))) add('tender', 'High', 'TED notice publication-number pattern', { ted: m[1] });
    if (/^\d{4}\/S \d{3}-\d{6}$/i.test(q)) add('tender', 'High', 'Legacy TED OJ S reference', { ted: q });
    if (/^(CONT_AWD|CONT_IDV|ASST_NON|ASST_AGG)_/i.test(q)) add(/^ASST/i.test(q) ? 'grant' : 'award', 'High', 'USAspending generated award identifier', { generatedId: q });
    else if (/^[A-Z0-9]{4,6}\d{2}[A-Z]\d{4,}$/i.test(q) && /\d/.test(q) && /[A-Z]/i.test(q)) add('award', 'Low', 'Could be a US federal contract PIID', { piid: up });
    if (/^[A-Z0-9]{12}$/.test(up) && /\d/.test(up) && /[A-Z]/.test(up) && !cands.length) add('registration', 'Low', 'Could be a SAM.gov UEI (12 characters)', { uei: up });
    if (/^(SC|NI|OC|SO|NC|R0)?\d{6,8}$/i.test(q) && !cands.some((c) => c.type === 'hs' && c.confidence !== 'Low')) add('registration', 'Low', 'Could be a UK Companies House number', { ukco: up });
    if ((m = /^IMO\s?(\d{7})$/i.exec(q))) add('vessel', 'High', 'IMO ship identification number', { imo: m[1] });
    if (/^([A-Z]{2})\s?([A-Z2-9]{3})$/.test(up) && q === up && q.length >= 5 && R.geo.byIso2(up.slice(0, 2))) add('port', 'Low', 'Could be a UN/LOCODE', { locode: up.replace(/\s/g, '') });
    if (/^N\d{1,5}[A-Z]{0,2}$/.test(up) && q === up) add('aircraft', 'Low', 'Could be a US aircraft N-number');

    const country = R.geo.findCountry(q);
    if (country) add('country', q.length <= 3 ? 'Medium' : 'High', 'Matches a country name or ISO code', { iso2: country.iso2, iso3: country.iso3, countryName: country.name });

    if (/^\$?[A-Z]{1,5}(\.[A-Z])?$/.test(q) && q === up && !/^(CVE|CWE)$/.test(q)) add('ticker', country ? 'Low' : 'Medium', 'Uppercase short symbol could be a stock ticker', { ticker: q.replace('$', '') });
    if ((m = /^(NYSE|NASDAQ|LSE|TSX|ASX|XETRA|EURONEXT)\s*[:\s]\s*([A-Z.]{1,6})$/i.exec(q))) add('ticker', 'High', 'Exchange-qualified ticker', { ticker: m[2].toUpperCase(), exchange: m[1].toUpperCase() });

    // Curated concepts.
    for (const [re, type, extra] of CONCEPTS) if (re.test(q)) add(type, 'High', 'Recognized enterprise concept', Object.assign({ concept: true }, extra));

    // Taxonomy matches.
    const tx = R.taxonomy.matchDomains(q);
    if (tx.finance.length) add('financeDomain', 'High', 'Matches Finance Risk Universe domain', { domains: tx.finance.map((x) => x.id) });
    if (tx.global.length) add('riskDomain', 'High', 'Matches Global Risk Universe domain', { domains: tx.global.map((x) => x.id) });
    const lines = R.taxonomy.matchInsuranceLine(q);
    if (lines.length && /\b(insurance|cover|coverage|liability|d&o|e&o|indemnity|marine|cargo|reinsurance)\b/i.test(q) && !COMPANY_SUFFIX.test(q)) add('insuranceLine', 'High', 'Matches an insurance line', { lines: lines.map((l) => l.id) });

    // Ports and places.
    if (/\b(port of|port|harbou?r|terminal|seaport|airport)\b/i.test(q) && !cands.some((c) => c.type === 'port' && c.confidence !== 'Low')) {
      const place = q.replace(/\b(port of|port|harbou?r|terminal|seaport|airport)\b/gi, '').replace(/\s+/g, ' ').trim();
      if (place.length >= 3) add('port', 'Medium', 'Contains a port/logistics keyword', { placeName: place });
    }

    // Insurance entity types (organization names containing insurance words).
    const insType = R.taxonomy.insuranceEntityTypes.find((t) => t.re.test(q));
    const isConcept = cands.some((c) => c.concept);
    if (insType && !isConcept && q.split(' ').length >= 2) add(insType.id, 'Medium', 'Organization name contains “' + insType.name.toLowerCase() + '” terms', { orgName: q });

    // Generic organization / category / person / free-text.
    const strong = cands.some((c) => c.confidence === 'High');
    if (!strong || COMPANY_SUFFIX.test(q)) {
      if (COMPANY_SUFFIX.test(q)) add('organization', 'High', 'Contains a legal-entity suffix', { orgName: q });
      else if (/^[A-Za-z0-9&.,'’\- ]{2,80}$/.test(q) && !cands.length) add('organization', 'Medium', 'Looks like an organization name', { orgName: q });
      else if (!cands.some((c) => c.type === 'organization')) add('organization', 'Low', 'Could be an organization name', { orgName: q });
    }
    if (cands.some((c) => c.type === 'category')) cands.find((c) => c.type === 'category').hsHints = categoryHs(q);
    if (/^[A-Z][a-z]+ [A-Z][a-z]+$/.test(q) && !COMPANY_SUFFIX.test(q) && !country && !insType) add('person', 'Low', 'Looks like a personal name — person searches are restricted');
    add('freetext', 'Low', 'Treat as a free-text concept', {});

    // De-duplicate by type keeping the highest confidence, then order.
    const rank = { High: 0, Medium: 1, Low: 2 };
    const byType = new Map();
    cands.forEach((c) => {
      const prev = byType.get(c.type);
      if (!prev || rank[c.confidence] < rank[prev.confidence]) byType.set(c.type, Object.assign({}, prev || {}, c));
    });
    const list = [...byType.values()].sort((a, b) => rank[a.confidence] - rank[b.confidence] || (a.type === 'freetext') - (b.type === 'freetext'));
    return { query: q, primary: list[0], candidates: list };
  }

  /* --------------------------- routing & plans --------------------------- */
  const ORG_TYPES = ['organization', 'insurer', 'reinsurer', 'broker', 'mga', 'captive', 'ils', 'tpa', 'syndicate', 'registration'];
  const ROUTE = {
    riskDomain: 'globalRisk', financeDomain: 'financeRisk', insuranceLine: 'insurance', procurement: 'procurement', tender: 'procurement', award: 'awards', grant: 'grants', ppp: 'ppp',
    cve: 'cyber', cwe: 'cyber', regdoc: 'regulatory', standard: 'standards', sanctionsId: 'sanctions', hs: 'trade', category: 'trade', digitalAsset: 'marketMacro', person: 'overview'
  };
  function lensesFor(type) {
    if (ORG_TYPES.includes(type) || ['lei', 'ticker', 'cik'].includes(type)) {
      const base = ['org360', 'fragility', 'sanctions', 'credit', 'supplyChain', 'awards', 'cyber', 'relationships'];
      if (['insurer', 'reinsurer', 'broker', 'mga', 'captive', 'ils', 'tpa', 'syndicate'].includes(type)) base.splice(1, 0, 'insurance', 'insuranceStrength');
      if (['ticker', 'cik'].includes(type)) base.splice(1, 0, 'filings');
      return base;
    }
    const map = {
      country: ['marketMacro', 'climate', 'esg', 'trade', 'sanctions', 'procurement', 'globalRisk'],
      port: ['climate', 'supplyChain', 'trade', 'relationships'],
      place: ['climate', 'supplyChain'],
      hs: ['trade', 'supplyChain', 'regulatory'],
      category: ['trade', 'supplyChain', 'procurement', 'regulatory'],
      cve: ['cyber', 'supplyChain'],
      cwe: ['cyber'],
      recall: ['supplyChain', 'org360'],
      regdoc: ['regulatory'],
      tender: ['procurement', 'awards'],
      award: ['awards', 'procurement', 'org360'],
      grant: ['grants', 'procurement'],
      ppp: ['ppp', 'grants', 'procurement'],
      riskDomain: ['globalRisk', 'regulatory', 'scenario'],
      financeDomain: ['financeRisk', 'fragility', 'marketMacro'],
      insuranceLine: ['insurance', 'insuranceStrength', 'climate', 'procurement'],
      procurement: ['procurement', 'awards', 'grants', 'ppp'],
      standard: ['standards', 'cyber', 'esg'],
      sanctionsId: ['sanctions', 'credit'],
      digitalAsset: ['marketMacro', 'sanctions'],
      vessel: ['supplyChain', 'sanctions'],
      aircraft: ['supplyChain'],
      person: ['session'],
      freetext: ['globalRisk', 'regulatory', 'org360']
    };
    return map[type] || ['globalRisk'];
  }

  /** Initial (Tier A) plan. Keep it small: at most five requests. */
  function initialPlan(c, q) {
    const p = [];
    const t = c.type;
    if (ORG_TYPES.includes(t)) {
      const name = c.orgName || q;
      p.push(T.gleifSearch(name), T.wdSearch(name));
    } else if (t === 'lei') {
      p.push(T.gleifLei(c.lei), T.gleifParent(c.lei, 'direct'), T.gleifParent(c.lei, 'ultimate'));
    } else if (t === 'cik') {
      p.push(T.secSubs(c.cik));
    } else if (t === 'ticker') {
      p.push(T.wdSearch(c.ticker + ' company'), T.gleifSearch(c.ticker));
    } else if (t === 'country') {
      p.push(T.wbCountry(c.iso3), T.wbInd(c.iso3, 'lpi'), T.wbInd(c.iso3, 'inflation'), T.wbInd(c.iso3, 'wgiPV'));
    } else if (t === 'port' || t === 'place') {
      if (c.placeName) p.push(T.geocode(c.placeName));
    } else if (t === 'cve') {
      p.push(T.kevCve(c.cve), T.nvdCve(c.cve));
    } else if (t === 'recall') {
      if (c.nhtsa) p.push(T.nhtsaCampaign(c.nhtsa));
      if (c.cpsc) p.push(T.cpscNum(c.cpsc));
      if (c.concept) p.push(T.frSearch('recall', { perPage: 5, order: 'newest' }));
    } else if (t === 'regdoc') {
      if (c.frDoc) p.push(T.frDoc(c.frDoc));
      else p.push(T.frSearch(c.docket || (c.concept ? 'rule' : q), { perPage: 10, order: 'newest' }));
    } else if (t === 'award') {
      if (c.generatedId) p.push(T.usaAwardDetail(c.generatedId));
      else p.push(T.usaAwards({ keyword: c.piid || (c.concept ? 'services' : q), kind: 'contracts' }));
    } else if (t === 'grant') {
      if (c.generatedId) p.push(T.usaAwardDetail(c.generatedId));
      else p.push(T.usaAwards({ keyword: c.concept ? 'infrastructure' : q, kind: 'grants' }));
    } else if (t === 'riskDomain' || t === 'financeDomain' || t === 'freetext' || t === 'standard') {
      p.push(T.frSearch(q, { perPage: 8 }));
      if (t === 'freetext') p.push(T.gleifSearch(q));
    } else if (t === 'insuranceLine') {
      p.push(T.frSearch(q, { perPage: 8 }), T.usaAwards({ keyword: q.replace(/\binsurance\b/i, '').trim().length > 3 ? q : 'insurance', kind: 'contracts' }));
    } else if (t === 'procurement' || t === 'tender' || t === 'ppp') {
      const kw = c.concept ? (c.insuranceRelated ? q.replace(/\b(tender|rfp)\b/i, '').trim() : t === 'ppp' ? 'public-private partnership' : 'services') : q;
      p.push(T.usaAwards({ keyword: kw, kind: 'contracts' }));
      if (t === 'ppp') p.push(T.frSearch('public-private partnership', { perPage: 5 }));
    } else if (t === 'hs' || t === 'category') {
      p.push(T.frSearch(t === 'hs' ? 'HTS ' + c.hs.slice(0, 4) : q + ' tariff', { perPage: 8, order: 'newest' }));
      if (t === 'category') p.push(T.cpscSearch(q));
    } else if (t === 'sanctionsId') {
      p.push(T.frSearch(c.focus === 'sam' ? 'debarment' : 'sanctions', { perPage: 8, order: 'newest' }));
    } else if (t === 'digitalAsset') {
      p.push(T.frSearch(q, { perPage: 8, order: 'newest' }));
    } else if (t === 'cwe') {
      // Link-out only (MITRE CWE); no live request needed.
    }
    return p.slice(0, 5);
  }

  /* ----------------------------- session ----------------------------- */
  function newSession(query, detection, chosen) {
    if (R.state.session && R.state.session.controller) R.state.session.controller.abort();
    R.state.generation += 1;
    R.net.resetCache();
    R.state.session = {
      id: R.util.uid('s'),
      query,
      detection,
      chosen,
      tasks: new Map(),
      controller: new AbortController(),
      startedAt: new Date(),
      primary: null,
      resolved: {},
      history: [],
      historyIndex: -1
    };
    return R.state.session;
  }

  /** After a place is resolved, fan out to event sources (still within budget). */
  function afterGeocode(task) {
    const s = R.state.session;
    if (!s || !task.records.length) return;
    const top = task.records[0];
    const { lat, lon, country } = top.data;
    s.resolved.lat = lat;
    s.resolved.lon = lon;
    s.resolved.placeLabel = top.title;
    s.resolved.iso2 = s.resolved.iso2 || country;
    const plan = [T.quakes(lat, lon, 500, 30), T.forecast(lat, lon, top.title)];
    if (country === 'US' || country === 'PR') plan.push(T.nws(lat, lon));
    const keys = plan.map((d) => R.tasks.ensure(d).key);
    s.autoKeys.push(...keys);
    R.tasks.runAll(keys);
    R.events.emit('session:resolved');
  }

  /** Organization flow: pick an unambiguous GLEIF/Wikidata match; otherwise ask the user. */
  function afterOrgSearch(task) {
    const s = R.state.session;
    if (!s) return;
    if (task.sourceId === 'gleif' && !s.primary) {
      const exact = task.records.filter((r) => r.prov.confidence === 'Exact');
      if (exact.length === 1) selectPrimary(exact[0], { auto: true });
    }
    if (task.sourceId === 'wikidata' && task.records.length && !s.resolved.qid) {
      const q = s.chosen.orgName || s.chosen.ticker || s.query;
      const top = task.records[0];
      const conf = R.match.matchConfidence(q.replace(/ company$/i, ''), top.data.label);
      if (conf === 'Exact' || conf === 'Likely' || s.chosen.type === 'ticker') {
        s.resolved.qid = top.data.qid;
        const d = T.wdIds(top.data.qid);
        R.tasks.ensure(d);
        s.autoKeys.push(d.key);
        R.tasks.start(d.key);
      }
    }
    if (task.key.startsWith('wd:ids:') && task.records.length) {
      const ids = task.records[0].data;
      if (ids.cik && !s.resolved.cik) {
        s.resolved.cik = ids.cik;
        const d = T.secSubs(ids.cik);
        R.tasks.ensure(d);
        s.autoKeys.push(d.key);
        R.tasks.start(d.key);
      }
      if (ids.lei && !s.resolved.lei && s.chosen.type === 'ticker') {
        const d = T.gleifLei(ids.lei);
        R.tasks.ensure(d);
        s.autoKeys.push(d.key);
        R.tasks.start(d.key).then((t) => t && t.records[0] && !s.primary && selectPrimary(t.records[0], { auto: true, confidence: 'Likely' }));
      }
    }
    if (task.key.startsWith('gleif:lei:') && task.records.length && !s.primary && s.chosen.type === 'lei') selectPrimary(task.records[0], { auto: true });
    if (task.key.startsWith('sec:subs:') && task.records.length) {
      s.resolved.secName = task.records[0].data.name;
      if (!s.primary && s.chosen.type === 'cik') selectPrimary(task.records[0], { auto: true });
    }
    if (task.key.startsWith('wb:country:') && task.records.length) {
      const c = task.records[0].data;
      Object.assign(s.resolved, { iso2: c.iso2, iso3: c.iso3, countryName: c.name, lat: c.lat, lon: c.lon, placeLabel: c.capital ? c.capital + ' (capital, reference point)' : c.name });
      R.events.emit('session:resolved');
    }
  }

  function selectPrimary(record, opts) {
    const s = R.state.session;
    if (!s) return;
    s.primary = record;
    s.primaryConfidence = (opts && opts.confidence) || record.prov.confidence || 'Likely';
    s.primaryAuto = !!(opts && opts.auto);
    if (record.ids.lei) s.resolved.lei = record.ids.lei;
    if (record.ids.cik) s.resolved.cik = record.ids.cik;
    if (record.data && record.data.country && !s.resolved.iso2) s.resolved.iso2 = String(record.data.country).slice(0, 2);
    s.resolved.entityName = record.title;
    R.events.emit('primary:changed', record);
  }

  async function run(rawQuery, forcedType) {
    const check = R.privacy.checkInput(rawQuery);
    if (!check.ok) return { rejected: true, reason: check.reason };
    const detection = detect(check.value);
    let chosen = detection.primary;
    if (forcedType) chosen = detection.candidates.find((c) => c.type === forcedType) || Object.assign({ type: forcedType, label: TYPES[forcedType], confidence: 'Manual', reason: 'Selected by user' }, forcedType === 'organization' ? { orgName: check.value } : forcedType === 'port' || forcedType === 'place' ? { placeName: check.value } : {});
    const s = newSession(check.value, detection, chosen);
    s.autoKeys = [];
    s.lenses = lensesFor(chosen.type);
    if (chosen.type === 'country') Object.assign(s.resolved, { iso2: chosen.iso2, iso3: chosen.iso3, countryName: chosen.countryName });
    if (chosen.type === 'lei') s.resolved.lei = chosen.lei;
    if (chosen.type === 'cik') s.resolved.cik = chosen.cik;
    const plan = initialPlan(chosen, check.value);
    plan.forEach((d) => R.tasks.ensure(d));
    s.autoKeys = plan.map((d) => d.key);
    R.events.emit('session:started', s);
    R.util.announce('Investigating. Results will appear as sources respond.');
    await R.tasks.runAll(s.autoKeys.slice());
    return { session: s, route: ROUTE[chosen.type] || 'overview' };
  }

  // Follow-up hooks (kept here so all orchestration is in one place).
  R.events.on('task:update', (t) => {
    const s = R.state.session;
    if (!s || !(t.status === 'done' || t.status === 'empty')) return;
    if (t.key.startsWith('geo:')) afterGeocode(t);
    if (/^(gleif:search|wd:search|wd:ids|gleif:lei|sec:subs|wb:country)/.test(t.key)) afterOrgSearch(t);
  });

  /** Minimal session for Advanced Query when no search has run (no initial plan). */
  function ensureSession() {
    if (R.state.session) return R.state.session;
    const chosen = { type: 'freetext', label: 'Advanced query', confidence: 'Manual', reason: 'Advanced Query builder' };
    const s = newSession('(advanced query)', { query: '', primary: chosen, candidates: [chosen] }, chosen);
    s.autoKeys = [];
    s.lenses = [];
    return s;
  }

  R.pipeline = { detect, run, ensureSession, selectPrimary, lensesFor, TYPES, ORG_TYPES, ROUTE, categoryHs };
})(window.JAQAWorkspace);

/* ---- modules/renderers.js ---- */
/*
 * renderers.js — shared UI building blocks.
 *
 * All rendering uses R.util.h (textContent only), so strings from APIs can
 * never inject markup. Badges always carry visible text (never colour only).
 * Every record card shows provenance (source, retrieval time, category,
 * confidence) and an official link opened with rel="noopener noreferrer".
 */
(function (R) {
  'use strict';
  const { h, icon, extLink, fmt, clear } = R.util;

  const ui = (R.ui = {});

  ui.badge = (text, tone, title) => h('span', { class: 'rq-badge rq-tone-' + (tone || 'neutral'), title: title || null }, text);

  const CONF_TONE = { Exact: 'ok', Likely: 'org', Possible: 'warn', Unresolved: 'neutral', 'Manual review recommended': 'warn', High: 'ok', Medium: 'warn', Low: 'neutral', Manual: 'org' };
  ui.confidence = (c) => (c ? ui.badge('Match: ' + c, CONF_TONE[c] || 'neutral', 'Match confidence. “Possible” is never treated as “Exact”.') : null);

  const MODE_TONE = { live: 'ok', verify: 'warn', linkout: 'neutral', download: 'neutral', unavailable: 'serious', hidden: 'neutral' };
  const MODE_TEXT = { live: 'Live', verify: 'Verify (link-out)', linkout: 'Link-out only', download: 'Download', unavailable: 'Unavailable', hidden: 'Hidden' };
  ui.modeBadge = (id) => {
    const m = R.runtime.mode(id);
    const s = R.sources.get(id);
    const mode = m === 'linkout' && s && s.status === 'verify' ? 'verify' : m;
    return ui.badge(MODE_TEXT[mode] || mode, MODE_TONE[mode] || 'neutral');
  };

  ui.icon = icon;

  ui.warning = (text, tone, title) => {
    const compact = R.state.prefs.warningsCompact;
    return h(
      'div',
      { class: 'rq-warning rq-warn-' + (tone || 'amber') + (compact ? ' is-compact' : ''), role: 'note' },
      icon(tone === 'info' ? 'info' : 'warn', 'rq-icon-sm'),
      h('div', null, title ? h('strong', null, title + ' ') : null, text)
    );
  };

  ui.section = (title, opts, ...children) => {
    const o = opts || {};
    const id = R.util.uid('sec');
    return h(
      'section',
      { class: 'rq-section' + (o.cls ? ' ' + o.cls : ''), 'aria-labelledby': id },
      h('div', { class: 'rq-section-head' }, h('h3', { id, class: 'rq-h3' }, o.icon ? icon(o.icon, 'rq-icon-sm') : null, title), o.actions ? h('div', { class: 'rq-section-actions' }, o.actions) : null),
      o.desc ? h('p', { class: 'rq-section-desc' }, o.desc) : null,
      ...children
    );
  };

  ui.button = (label, onClick, opts) => {
    const o = opts || {};
    return h('button', { type: 'button', class: 'rq-btn' + (o.variant ? ' rq-btn-' + o.variant : '') + (o.cls ? ' ' + o.cls : ''), onclick: onClick, 'aria-label': o.aria || null, disabled: o.disabled || null, title: o.title || null }, o.icon ? icon(o.icon, 'rq-icon-sm') : null, label ? h('span', null, label) : null);
  };

  ui.skeleton = (n) => h('div', { class: 'rq-skeleton-wrap', 'aria-hidden': 'true' }, Array.from({ length: n || 2 }, () => h('div', { class: 'rq-skeleton' }, h('div', { class: 'rq-sk-line w60' }), h('div', { class: 'rq-sk-line w90' }), h('div', { class: 'rq-sk-line w40' }))));

  ui.kv = (fields, limit) => {
    const dl = h('dl', { class: 'rq-kv' });
    (fields || []).slice(0, limit || fields.length).forEach(([k, v]) => {
      dl.appendChild(h('dt', null, k));
      dl.appendChild(h('dd', null, fmt.val(v)));
    });
    return dl;
  };

  /** Long text with an accessible "Read more" toggle. */
  ui.readMore = (text, n) => {
    const t = String(text || '');
    if (t.length <= (n || 240)) return h('p', { class: 'rq-summary' }, t);
    const p = h('p', { class: 'rq-summary' }, fmt.truncate(t, n || 240));
    let open = false;
    const btn = h('button', { type: 'button', class: 'rq-link-btn', 'aria-expanded': 'false' }, 'Read more');
    btn.addEventListener('click', () => {
      open = !open;
      p.textContent = open ? t : fmt.truncate(t, n || 240);
      btn.textContent = open ? 'Show less' : 'Read more';
      btn.setAttribute('aria-expanded', String(open));
    });
    return h('div', null, p, btn);
  };

  ui.provenance = (prov) =>
    h(
      'div',
      { class: 'rq-prov' },
      icon('doc', 'rq-icon-xs'),
      h('span', null, prov.sourceName),
      h('span', { class: 'rq-dot' }, '·'),
      h('span', null, 'retrieved ' + fmt.time(prov.retrievedAt) + ' (this session)'),
      h('span', { class: 'rq-dot' }, '·'),
      h('span', null, prov.category)
    );

  /** Record card. opts: { onSelect(record) label } */
  ui.recordCard = (r, opts) => {
    const o = opts || {};
    const pinned = R.state.watchlist.some((w) => w.uid === r.uid);
    const title = h('h4', { class: 'rq-card-title', title: r.title }, r.title);
    return h(
      'article',
      { class: 'rq-card', 'data-kind': r.kind },
      h('div', { class: 'rq-card-badges' }, ...r.badges.map((b) => ui.badge(b.text, b.tone)), ui.confidence(r.prov.confidence)),
      title,
      r.subtitle ? h('p', { class: 'rq-card-sub' }, r.subtitle) : null,
      r.summary ? ui.readMore(r.summary, 220) : null,
      ui.kv(r.fields.filter((f) => f[1] !== null && f[1] !== undefined && f[1] !== ''), 5),
      h(
        'div',
        { class: 'rq-card-foot' },
        ui.provenance(r.prov),
        h(
          'div',
          { class: 'rq-card-actions' },
          o.onSelect ? ui.button(o.selectLabel || 'Use this entity', () => o.onSelect(r), { variant: 'primary', cls: 'rq-btn-sm' }) : null,
          ui.button('Details', () => R.shell.openDetail(r), { cls: 'rq-btn-sm', icon: 'list' }),
          ui.button(pinned ? 'Pinned' : 'Pin', (e) => {
            ui.pin(r);
            e.currentTarget.querySelector('span').textContent = 'Pinned';
          }, { cls: 'rq-btn-sm', icon: 'pin', aria: 'Pin to evidence board: ' + r.title }),
          r.prov.url ? extLink(r.prov.url, 'Official source', { cls: 'rq-btn rq-btn-sm rq-btn-ghost' }) : null
        )
      )
    );
  };

  ui.pin = (r) => {
    if (!R.state.watchlist.some((w) => w.uid === r.uid)) {
      R.state.watchlist.push(r);
      R.util.announce('Added to evidence board.');
      R.events.emit('watchlist:update');
    }
  };

  /** Accessible table for records. */
  ui.recordTable = (records, cols) => {
    const columns = cols || [
      ['Record', (r) => r.title],
      ['Type', (r) => r.kind],
      ['Key detail', (r) => (r.fields[1] ? `${r.fields[1][0]}: ${fmt.val(r.fields[1][1])}` : '')],
      ['Source', (r) => r.prov.sourceName],
      ['Match', (r) => r.prov.confidence || '—']
    ];
    const table = h(
      'table',
      { class: 'rq-table' },
      h('thead', null, h('tr', null, ...columns.map(([c]) => h('th', { scope: 'col' }, c)), h('th', { scope: 'col' }, 'Links'))),
      h(
        'tbody',
        null,
        ...records.map((r) =>
          h(
            'tr',
            null,
            ...columns.map(([, fn], i) => (i === 0 ? h('th', { scope: 'row' }, h('button', { type: 'button', class: 'rq-link-btn', onclick: () => R.shell.openDetail(r) }, fmt.truncate(fn(r), 90))) : h('td', null, fmt.truncate(fmt.val(fn(r)), 120)))),
            h('td', null, r.prov.url ? extLink(r.prov.url, 'Source') : '—')
          )
        )
      )
    );
    return h('div', { class: 'rq-table-wrap', tabindex: '0', role: 'region', 'aria-label': 'Results table' }, table);
  };

  ui.records = (records, opts) => {
    if (R.state.prefs.viewMode === 'table' && !(opts && opts.forceCards)) return ui.recordTable(records);
    return h('div', { class: 'rq-cards' }, ...records.map((r) => ui.recordCard(r, opts)));
  };

  /* ------------------------------ task panel ------------------------------ */
  const mounted = new Map(); // key -> Set<{el, render}>
  R.events.on('task:update', (t) => {
    const set = mounted.get(t.key);
    if (!set) return;
    for (const m of [...set]) {
      if (!m.el.isConnected) set.delete(m);
      else m.render();
    }
  });
  R.events.on('net:update', () => {
    for (const set of mounted.values()) for (const m of [...set]) if (!m.el.isConnected) set.delete(m);
  });

  /**
   * Render a live lookup with all states: idle (user-triggered), loading,
   * results, empty (with no-hit ≠ clear warning), error (friendly + link-out),
   * link-out only.
   * opts: { auto, noHitWarning, linkout: {href,label}, onSelect, selectLabel, limit, emptyText, compact }
   */
  ui.taskPanel = (def, opts) => {
    const o = opts || {};
    const t = R.tasks.ensure(def);
    if (t && R.shell) R.shell.visibleTaskKeys.add(def.key);
    const el = h('div', { class: 'rq-task', 'aria-live': 'polite', 'aria-busy': 'false' });
    if (!t) {
      el.appendChild(ui.warning('Start a search to load this evidence.', 'info'));
      return el;
    }
    const src = R.sources.get(def.sourceId);
    const render = () => {
      const task = R.tasks.get(def.key) || t;
      clear(el);
      el.setAttribute('aria-busy', task.status === 'loading' ? 'true' : 'false');
      const head = h(
        'div',
        { class: 'rq-task-head' },
        h('span', { class: 'rq-task-label' }, def.label),
        ui.modeBadge(def.sourceId),
        task.status === 'done' ? ui.badge(task.records.length + (task.meta && task.meta.total > task.records.length ? ' of ' + fmt.num(task.meta.total, 0) : '') + ' record(s)', 'neutral') : null
      );
      el.appendChild(head);
      const linkout = o.linkout || (src ? { href: src.linkoutSearchUrlTemplate && !/\{/.test(src.linkoutSearchUrlTemplate) ? src.linkoutSearchUrlTemplate : src.officialSiteUrl, label: 'Open ' + src.displayName } : null);
      if (task.status === 'idle') {
        if (o.auto) {
          R.tasks.start(def.key);
          el.appendChild(ui.skeleton(1));
        } else if (!R.runtime.isLive(def.sourceId)) {
          task.status = 'linkout';
          render();
        } else {
          el.appendChild(h('div', { class: 'rq-task-idle' }, h('p', { class: 'rq-muted' }, 'Not loaded automatically (keeps request volume low). Loading sends your current query directly from your browser to ' + (src ? src.displayName : 'this provider') + '.'), ui.button('Load from ' + (src ? src.displayName : 'source'), () => R.tasks.start(def.key), { variant: 'primary', icon: 'download' })));
        }
      } else if (task.status === 'loading') {
        el.appendChild(ui.skeleton(o.compact ? 1 : 2));
      } else if (task.status === 'done') {
        const recs = task.records.slice(0, o.limit || 50);
        if (o.render) el.appendChild(o.render(recs, task));
        else el.appendChild(ui.records(recs, { onSelect: o.onSelect, selectLabel: o.selectLabel }));
        if (task.meta && task.meta.note) el.appendChild(ui.warning(task.meta.note, 'info'));
        if (o.after) el.appendChild(o.after(task));
      } else if (task.status === 'empty') {
        el.appendChild(h('p', { class: 'rq-empty' }, (task.meta && task.meta.note) || o.emptyText || 'This query returned no public records from this source.'));
        if (o.noHitWarning !== false) el.appendChild(ui.warning(R.legal.noHitNotClear, 'amber', 'No match does not mean no risk.'));
        if (linkout && linkout.href) el.appendChild(h('p', null, extLink(linkout.href, linkout.label)));
      } else if (task.status === 'linkout') {
        el.appendChild(h('p', { class: 'rq-muted' }, src && src.status === 'verify' ? 'Live request unavailable from this browser (not verified for this origin). Open the source directly.' : R.net.errorText('linkout')));
        if (linkout && linkout.href) el.appendChild(h('p', null, extLink(linkout.href, linkout.label)));
      } else if (task.status === 'error') {
        const msg = R.net.errorText(task.errorKind);
        el.appendChild(h('p', { class: 'rq-error', role: 'status' }, msg));
        if (task.errorKind === 'rate_limited' && task.retryAt) el.appendChild(h('p', { class: 'rq-muted' }, 'You can retry after ' + fmt.time(new Date(task.retryAt)) + '.'));
        const row = h('div', { class: 'rq-row' });
        if (task.errorKind !== 'cors_or_network') row.appendChild(ui.button('Retry', () => {
          task.status = 'idle';
          R.tasks.start(def.key);
        }, { icon: 'refresh' }));
        if (linkout && linkout.href) row.appendChild(extLink(linkout.href, linkout.label));
        el.appendChild(row);
      }
    };
    render();
    if (!mounted.has(def.key)) mounted.set(def.key, new Set());
    mounted.get(def.key).add({ el, render });
    return el;
  };

  /* ------------------------------ link-outs ------------------------------ */
  /** Render a directory of official link-outs. q is optional. */
  ui.linkouts = (entries, q, opts) => {
    const o = opts || {};
    const list = h('ul', { class: 'rq-linklist' + (o.compact ? ' is-compact' : '') });
    entries.forEach((e) => {
      const lo = R.linkout(e, q);
      list.appendChild(
        h(
          'li',
          null,
          extLink(lo.href, e.name),
          e.region ? h('span', { class: 'rq-link-meta' }, e.region) : null,
          e.kind === 'paid' ? ui.badge('Paid / link-out only', 'neutral') : null,
          e.kind === 'rating-agency' ? ui.badge('Rating agency link-out', 'ins') : null,
          e.kind === 'market-report' ? ui.badge('Market-report link-out', 'ins') : null,
          e.translationRisk || (e.lang && e.lang !== 'en') ? ui.badge('Translation risk', 'warn') : null,
          lo.withQuery ? h('span', { class: 'rq-link-meta', title: 'This link carries your query to the provider.' }, 'opens with your query') : null,
          e.note ? h('span', { class: 'rq-link-note' }, e.note) : null
        )
      );
    });
    return h('div', { class: 'rq-linkouts' }, o.title ? h('h4', { class: 'rq-h4' }, o.title) : null, list, h('p', { class: 'rq-fineprint' }, 'Link-outs are opened directly by your browser in a new tab. JAQA does not fetch, scrape or store these pages.'));
  };
  ui.dir = (key, q, opts) => ui.linkouts(R.directories[key] || [], q, opts);

  /* ---------------------------- misc widgets ---------------------------- */
  ui.bars = (rows, opts) => {
    const max = Math.max(1, ...rows.map((r) => r[1]));
    return h(
      'div',
      { class: 'rq-bars', role: 'list', 'aria-label': (opts && opts.label) || 'Distribution' },
      ...rows.map(([label, v, tone]) =>
        h('div', { class: 'rq-bar-row', role: 'listitem' }, h('span', { class: 'rq-bar-label' }, label), h('span', { class: 'rq-bar-track', 'aria-hidden': 'true' }, h('span', { class: 'rq-bar-fill rq-tone-' + (tone || 'org'), style: { width: Math.max(2, (v / max) * 100) + '%' } })), h('span', { class: 'rq-bar-val' }, String(v)))
      )
    );
  };

  ui.emptyModule = (text) =>
    h('div', { class: 'rq-empty-state' }, icon('search', 'rq-icon-lg'), h('p', null, text || 'Start with a company, insurer, reinsurer, broker, country, port, HS code, CVE, tender, award, grant, PPP, regulation, or risk concept.'), ui.button('Focus search', () => R.shell.focusSearch(), { variant: 'primary', icon: 'search' }));

  /** Conflict panel: shows each source side by side; never resolves automatically. */
  ui.conflict = (label, items) =>
    h(
      'div',
      { class: 'rq-conflict', role: 'group', 'aria-label': 'Source discrepancy: ' + label },
      h('div', { class: 'rq-conflict-head' }, ui.badge('Source discrepancy', 'warn'), h('strong', null, label)),
      h('div', { class: 'rq-conflict-grid' }, ...items.map((it) => h('div', { class: 'rq-conflict-cell' }, h('div', { class: 'rq-muted' }, it.source), h('div', null, fmt.val(it.value)), it.url ? extLink(it.url, 'Open ' + it.source) : null))),
      h('p', { class: 'rq-fineprint' }, 'JAQA does not adjudicate legal, compliance, credit, sanctions, insurance, reinsurance, procurement, bid, award, claims, coverage, or financial decisions. Verify with each source.')
    );

  ui.moduleWarnings = (list) => h('div', { class: 'rq-module-warnings' }, ...list.map((w) => ui.warning(w, 'amber')));

  /** Filter/select helper. */
  ui.select = (label, options, value, onChange, opts) => {
    const id = R.util.uid('sel');
    const sel = h('select', { id, class: 'rq-input', 'data-focus-key': (opts && opts.key) || label, onchange: (e) => onChange(e.target.value) }, ...options.map(([v, l]) => h('option', { value: v, selected: v === value ? true : null }, l)));
    return h('label', { class: 'rq-field' + (opts && opts.cls ? ' ' + opts.cls : ''), for: id }, h('span', null, label), sel);
  };
  ui.input = (label, value, onInput, opts) => {
    const o = opts || {};
    const id = R.util.uid('in');
    const inp = h('input', { id, class: 'rq-input', 'data-focus-key': o.key || label, type: o.type || 'text', value: value || '', placeholder: o.placeholder || '', maxlength: o.maxlength || 120, autocomplete: 'off', spellcheck: 'false', oninput: (e) => onInput(e.target.value) });
    return h('label', { class: 'rq-field' + (o.cls ? ' ' + o.cls : ''), for: id }, h('span', null, label), inp);
  };

  /** Module export bar (JSON + CSV of the records visible in the module). */
  ui.exportBar = (jsonName, csvName, domain) =>
    h(
      'div',
      { class: 'rq-row rq-export-bar' },
      ui.button('Export JSON', () => R.exporters.visibleJSON(jsonName, domain), { icon: 'download', cls: 'rq-btn-sm' }),
      ui.button('Export CSV', () => {
        const keys = [...R.shell.visibleTaskKeys];
        const recs = keys.map((k) => R.tasks.get(k)).filter(Boolean).flatMap((t) => t.records || []);
        if (!recs.length) return R.util.announce('No records loaded in this module yet.');
        R.exporters.csv(csvName, recs, domain);
      }, { icon: 'download', cls: 'rq-btn-sm' })
    );

  /** Standard "context required" block when a module needs a session. */
  ui.needSession = (what) => ui.emptyModule(what ? `Run a search to populate ${what}.` : null);
})(window.JAQAWorkspace);

/* ---- modules/exporters.js ---- */
/*
 * exporters.js — browser-side JSON/CSV export, copy helpers and print.
 *
 * - Files are generated in the browser (Blob) and never uploaded or kept.
 * - Filenames are fixed and never contain search terms.
 * - CSV cells are sanitized against formula injection: any cell starting
 *   with =, +, -, @, tab or carriage return is prefixed with a single quote.
 * - JSON exports carry provenance, confidence, freshness, coverage gaps and
 *   the JAQA™ legal metadata block. API keys and secrets are never exported.
 * - When an export would contain the user's search term, the user is warned
 *   and must confirm before download/copy.
 */
(function (R) {
  'use strict';
  const { h } = R.util;

  function csvCell(v) {
    let s = v === null || v === undefined ? '' : String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
    s = s.replace(/"/g, '""');
    return /[",\n\r]/.test(s) || s !== s.trim() ? `"${s}"` : s;
  }
  function toCSV(rows) {
    return rows.map((r) => r.map(csvCell).join(',')).join('\r\n');
  }

  function download(filename, text, mime) {
    const blob = new Blob([text], { type: mime + ';charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = h('a', { href: '#', download: filename });
    a.setAttribute('href', url); // blob: URL set directly (not an external link)
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    R.util.announce('Export ready: ' + filename);
  }

  function recordJSON(r) {
    return {
      title: r.title,
      subtitle: r.subtitle,
      kind: r.kind,
      summary: r.summary || undefined,
      fields: Object.fromEntries(r.fields.map(([k, v]) => [k, v === null || v === undefined || v === '' ? 'Not reported by source' : v])),
      identifiers: r.ids,
      badges: r.badges.map((b) => b.text),
      flags: r.flags,
      provenance: {
        source: r.prov.sourceName,
        sourceId: r.prov.sourceId,
        endpoint: r.prov.endpoint,
        recordId: r.prov.recordId,
        officialUrl: r.prov.url,
        retrievedAt: r.prov.retrievedAt.toISOString(),
        dataCategory: r.prov.category,
        matchConfidence: r.prov.confidence || null,
        attribution: r.prov.attribution
      }
    };
  }

  function coverageSnapshot(sourceIds) {
    const ids = sourceIds || R.sources.list.map((s) => s.id);
    return ids
      .map((id) => R.sources.get(id))
      .filter(Boolean)
      .map((s) => ({
        source: s.displayName,
        id: s.id,
        tier: s.tier,
        defaultMode: s.defaultMode,
        runtimeMode: R.runtime.mode(s.id),
        corsVerified: s.corsVerified,
        coverageGap: s.coverageGapWarning || null,
        falseNegativeRisk: s.falseNegativeRisk,
        mayLagOfficialDb: s.mayLagOfficialDb,
        translationRisk: s.translationRisk,
        deadlineRisk: s.deadlineRisk,
        officialSourceAuthoritative: s.officialSourceAuthoritative,
        legalReviewRequired: s.legalReviewRequired,
        attribution: s.attribution
      }));
  }

  const DOMAIN_WARNINGS = {
    finance: 'No credit score, credit rating, solvency opinion, investment, treasury or hedging advice is generated. Public distress signals do not predict insolvency.',
    insurance: 'No insurance, reinsurance, underwriting, claims, coverage, solvency, capacity or recoverability determination is made. Ratings and market reports are link-out only.',
    sanctions: 'No hit ≠ clear. JAQA is not a sanctions screening system of record or an AML system.',
    procurement: 'Deadlines, timezones, eligibility, lots, amendments and translations must be verified on the official procurement portal. No bid/no-bid advice, award prediction or eligibility determination.',
    globalRisk: 'Coverage is incomplete by region, sector, language and source. The taxonomy is a public-source map, not a risk measurement.'
  };

  function sessionMeta() {
    const s = R.state.session;
    if (!s) return null;
    return {
      interpretedType: s.chosen.label,
      interpretationConfidence: s.chosen.confidence,
      startedAt: s.startedAt.toISOString(),
      resolvedIdentifiers: Object.fromEntries(Object.entries(s.resolved).filter(([k]) => ['lei', 'cik', 'iso2', 'iso3', 'qid'].includes(k))),
      primaryEntity: s.primary ? { title: s.primary.title, confidence: s.primaryConfidence, source: s.primary.prov.sourceName } : null
    };
  }

  /** Warn before exporting content that includes the search term. */
  function confirmTerm(includesTerm, go) {
    if (!includesTerm) return go(false);
    const body = h(
      'div',
      { class: 'rq-prose' },
      h('p', null, 'This export can include your search term. Files are created in your browser and are not uploaded or stored by JAQA, but anyone you share the file with will see it.'),
      h('div', { class: 'rq-row' }, R.ui.button('Include search term', () => { R.shell.closeDialog(); go(true); }, { variant: 'primary' }), R.ui.button('Export without search term', () => { R.shell.closeDialog(); go(false); }), R.ui.button('Cancel', () => R.shell.closeDialog(), { variant: 'ghost' }))
    );
    R.shell.openDialog('Export warning', body, 'modal');
  }

  function jsonExport(filename, records, domain, extra) {
    const s = R.state.session;
    confirmTerm(!!s, (withTerm) => {
      const sources = [...new Set(records.map((r) => r.prov.sourceName))];
      const payload = Object.assign(R.legal.exportBlock(sources), {
        warnings: [R.legal.shortDisclaimer, R.legal.noHitNotClear, DOMAIN_WARNINGS[domain] || DOMAIN_WARNINGS.globalRisk].filter(Boolean),
        session: s ? Object.assign({ query: withTerm ? s.query : '[omitted by user]' }, sessionMeta()) : null,
        records: records.map(recordJSON),
        coverage: coverageSnapshot([...new Set(records.map((r) => r.prov.sourceId))]),
        extra: extra || undefined
      });
      download(filename, JSON.stringify(payload, null, 2), 'application/json');
    });
  }

  function csvExport(filename, records, domain) {
    const header = ['Title', 'Subtitle', 'Kind', 'Key fields', 'Badges', 'Source', 'Data category', 'Match confidence', 'Retrieved at (session)', 'Source record ID', 'Official URL'];
    const rows = [header].concat(
      records.map((r) => [
        r.title,
        r.subtitle,
        r.kind,
        r.fields.filter((f) => f[1] !== null && f[1] !== undefined && f[1] !== '').map(([k, v]) => `${k}: ${v}`).join(' | '),
        r.badges.map((b) => b.text).join(' | '),
        r.prov.sourceName,
        r.prov.category,
        r.prov.confidence || '',
        r.prov.retrievedAt.toISOString(),
        r.prov.recordId,
        r.prov.url
      ])
    );
    rows.push([]);
    rows.push(['Disclaimer', R.legal.shortDisclaimer]);
    rows.push(['No hit ≠ clear', R.legal.noHitNotClear]);
    if (DOMAIN_WARNINGS[domain]) rows.push(['Domain warning', DOMAIN_WARNINGS[domain]]);
    rows.push(['Legal', R.legal.copyright]);
    download(filename, '﻿' + toCSV(rows), 'text/csv');
  }

  function visibleRecords() {
    const keys = R.shell.visibleTaskKeys.size ? [...R.shell.visibleTaskKeys] : R.tasks.all().map((t) => t.key);
    return keys.map((k) => R.tasks.get(k)).filter(Boolean).flatMap((t) => t.records || []);
  }

  async function copyText(text, label, includesTerm) {
    const doCopy = async () => {
      try {
        await navigator.clipboard.writeText(text); // write-only; clipboard is never read
        R.util.announce(label + ' copied.');
      } catch (e) {
        R.util.announce('Copy failed. Your browser blocked clipboard access.');
      }
    };
    if (includesTerm) confirmTerm(true, (ok) => ok && doCopy());
    else doCopy();
  }

  function idList(key) {
    const recs = R.tasks.records().concat(R.state.watchlist);
    return [...new Set(recs.map((r) => r.ids && r.ids[key]).filter(Boolean))];
  }

  R.exporters = {
    csvCell,
    toCSV,
    recordJSON,
    json: jsonExport,
    csv: csvExport,
    sessionJSON() {
      const recs = R.tasks.records();
      jsonExport('JAQA-Workspace-results.json', recs, 'globalRisk', { tasks: R.tasks.all().map((t) => ({ label: t.label, source: t.sourceId, status: t.status, errorKind: t.errorKind || null, records: (t.records || []).length })) });
    },
    visibleCSV() {
      const recs = visibleRecords();
      if (!recs.length) return R.util.announce('No visible records to export.');
      csvExport('JAQA-Workspace-results.csv', recs, 'globalRisk');
    },
    visibleJSON(filename, domain) {
      jsonExport(filename || 'JAQA-Workspace-results.json', visibleRecords(), domain || 'globalRisk');
    },
    evidencePackJSON() {
      const recs = R.state.watchlist.length ? R.state.watchlist : R.tasks.records();
      jsonExport('JAQA-Evidence-Pack.json', recs, 'globalRisk', { evidenceBoardCount: R.state.watchlist.length, note: R.state.watchlist.length ? 'Pinned evidence board records.' : 'No pinned records; all session records included.' });
    },
    evidencePackCSV() {
      const recs = R.state.watchlist.length ? R.state.watchlist : R.tasks.records();
      csvExport('JAQA-Evidence-Pack.csv', recs, 'globalRisk');
    },
    watchlistJSON() {
      jsonExport('JAQA-Watchlist.json', R.state.watchlist, 'globalRisk');
    },
    copyIds(key, label) {
      const ids = idList(key);
      if (!ids.length) return R.util.announce('No ' + label + ' in this session.');
      copyText(ids.join('\n'), label, false);
    },
    copyLinks() {
      const recs = R.tasks.records().concat(R.state.watchlist);
      const links = [...new Set(recs.map((r) => r.prov.url).filter(Boolean))];
      copyText(links.join('\n'), 'Official source links', false);
    },
    copyPrivacy() {
      copyText([R.legal.privacyStatement, '', R.legal.privacyLegalSentence, '', ...R.legal.longDisclaimer].join('\n'), 'Privacy statement', false);
    },
    download,
    DOMAIN_WARNINGS
  };
})(window.JAQAWorkspace);

/* ---- modules/overview.js ---- */
/*
 * overview.js — MODULE 1: Overview / Risk Triage, plus the shared signal and
 * data-gap collectors used by other modules.
 *
 * Signals are source-reported facts only (e.g. "in CISA KEV", "8-K item
 * 1.03 filed", "NWS Severe alert"). Nothing is scored, ranked or cleared.
 */
(function (R) {
  'use strict';
  const { h, icon, fmt, extLink } = R.util;
  const ui = R.ui;

  /* --------------------------- signal collector --------------------------- */
  R.signals = {
    collect() {
      const out = [];
      for (const t of R.tasks.all()) {
        for (const r of t.records || []) {
          r.badges.filter((b) => b.tone === 'serious' || (b.tone === 'warn' && !/Translation|Comment period/.test(b.text))).forEach((b) => out.push({ text: `${b.text} — ${r.title}`, tone: b.tone, record: r }));
          if (r.data && r.data.signals) r.data.signals.slice(0, 8).forEach((sg) => out.push({ text: `${sg.text} (${sg.date})`, tone: 'warn', record: r, url: sg.url }));
          if (r.data && r.data.flags && r.data.flags.length) out.push({ text: `Forecast threshold signal(s): ${r.data.flags.slice(0, 3).join('; ')}`, tone: 'warn', record: r });
        }
      }
      const seen = new Set();
      return out.filter((s) => (seen.has(s.text) ? false : seen.add(s.text)));
    },
    gaps() {
      const s = R.state.session;
      const gaps = [];
      if (!s) return gaps;
      const type = s.chosen.type;
      const org = R.pipeline.ORG_TYPES.includes(type) || ['lei', 'ticker', 'cik'].includes(type);
      const gl = R.tasks.all().find((t) => t.key.startsWith('gleif:search:'));
      if (org && gl && gl.status === 'empty') gaps.push('No LEI record found. Missing LEI does not mean an invalid entity; many private companies and SMEs have no LEI.');
      if (org && gl && gl.status === 'done' && !s.primary) gaps.push('Entity not yet resolved: several candidates match. Select the correct legal entity before relying on downstream evidence.');
      if (org && !s.resolved.cik) gaps.push('No SEC registrant identified. Private companies and most non-US entities have limited public financial data.');
      if (org) gaps.push('Sanctions/debarment status is not checked live. Use official lists and your screening system of record (no hit ≠ clear).');
      if (['insurer', 'reinsurer', 'broker', 'mga', 'captive', 'ils', 'tpa', 'syndicate'].includes(type)) gaps.push('Insurer financial strength ratings, solvency ratios and market reports are paid or regulator-held; link-out only.');
      if (['procurement', 'tender'].includes(type)) gaps.push('TED and most national portals are link-out only (no CORS-enabled public API). Deadlines/eligibility must be verified officially.');
      if (['country', 'port', 'place'].includes(type)) gaps.push('ReliefWeb humanitarian reports are link-out only until an approved API appname is verified.');
      if (type === 'port' && !s.resolved.lat) gaps.push('Location not yet resolved; event proximity checks need verified coordinates.');
      if (['hs', 'category'].includes(type)) gaps.push('UN Comtrade trade flows require a key and are link-out only. No shipment-level data is available.');
      if (type === 'cve') gaps.push('A CVE record does not show which suppliers run the affected product/version. Asset inventories and SBOMs are needed.');
      for (const t of R.tasks.all()) if (t.status === 'error') gaps.push(`${t.label}: ${R.net.errorText(t.errorKind)}`);
      return [...new Set(gaps)];
    },
    /** Conflicts between sources on the same identifier (never auto-resolved). */
    conflicts() {
      const s = R.state.session;
      const out = [];
      if (!s || !s.primary) return out;
      const gleifLei = s.primary.prov.sourceId === 'gleif' ? s.primary.ids.lei : null;
      const wd = R.tasks.all().find((t) => t.key.startsWith('wd:ids:') && t.records.length);
      const sec = R.tasks.all().find((t) => t.key.startsWith('sec:subs:') && t.records.length);
      if (gleifLei && wd && wd.records[0].data.lei && wd.records[0].data.lei !== gleifLei)
        out.push(['LEI for the selected entity', [{ source: 'GLEIF (selected record)', value: gleifLei, url: s.primary.prov.url }, { source: 'Wikidata claim', value: wd.records[0].data.lei, url: wd.records[0].prov.url }]]);
      if (gleifLei && sec && sec.records[0].ids.lei && sec.records[0].ids.lei !== gleifLei)
        out.push(['LEI reported to SEC vs GLEIF', [{ source: 'GLEIF (selected record)', value: gleifLei, url: s.primary.prov.url }, { source: 'SEC EDGAR submissions', value: sec.records[0].ids.lei, url: sec.records[0].prov.url }]]);
      return out;
    }
  };

  /* ------------------------------ first run ------------------------------ */
  function firstRun() {
    const groups = R.modules.GROUPS.map((g) => h('div', { class: 'rq-mod-group' }, h('h4', { class: 'rq-h4' }, g.label), h('ul', null, ...R.modules.all().filter((m) => m.group === g.id).map((m) => h('li', null, h('button', { type: 'button', class: 'rq-link-btn', onclick: () => R.shell.go(m.id, { focus: true }) }, m.title))))));
    const live = R.sources.list.filter((s) => s.corsVerified);
    return h(
      'div',
      { class: 'rq-firstrun' },
      h(
        'div',
        { class: 'rq-hero' },
        h('h3', { class: 'rq-hero-title' }, 'Start with a company, insurer, reinsurer, broker, country, port, HS code, CVE, tender, award, grant, PPP, regulation, or risk concept'),
        h('p', null, 'JAQA assembles public evidence from ', h('strong', null, live.length + ' live public APIs'), ' verified for browser access, and routes everything else to official link-outs — with provenance, confidence and coverage gaps on every result.'),
        h('div', { class: 'rq-row' }, ui.button('Focus search', () => R.shell.focusSearch(), { variant: 'primary', icon: 'search' }), ui.button('How it works', () => R.shell.openHelp(), { icon: 'help' }), ui.button('Coverage Console', () => R.shell.go('coverage', { focus: true }), { icon: 'gauge' }))
      ),
      h(
        'div',
        { class: 'rq-principles' },
        h('div', { class: 'rq-principle' }, icon('lock'), h('h4', { class: 'rq-h4' }, 'Private by design'), h('p', null, 'No accounts, cookies, browser storage or analytics. Refresh or Clear Session wipes everything. Queries go straight from your browser to public providers.')),
        h('div', { class: 'rq-principle' }, icon('globe'), h('h4', { class: 'rq-h4' }, 'Live where verified'), h('p', null, live.map((s) => s.displayName.replace(/ \(.*\)$/, '')).slice(0, 9).join(', ') + ' and more. Unverified sources stay link-out.')),
        h('div', { class: 'rq-principle' }, icon('warn'), h('h4', { class: 'rq-h4' }, 'No hit ≠ clear'), h('p', null, 'Public data is incomplete, delayed and ambiguous. Absence of a record never means cleared, solvent, covered, eligible or low risk.')),
        h('div', { class: 'rq-principle' }, icon('gavel'), h('h4', { class: 'rq-h4' }, 'Evidence, not advice'), h('p', null, 'No insurance, credit, investment, treasury, sanctions, procurement, bid, award, legal or tax advice. Human, qualified review is required.'))
      ),
      R.state.helpDismissed
        ? null
        : h('div', { class: 'rq-help-panel' }, h('div', { class: 'rq-row rq-row-between' }, h('h3', { class: 'rq-h3' }, 'Quick guide'), ui.button('Dismiss for this session', () => {
            R.state.helpDismissed = true;
            R.shell.refresh();
          }, { cls: 'rq-btn-sm rq-btn-ghost' })), R.shell.helpContent(true)),
      ui.section('Modules', { icon: 'layers' }, h('div', { class: 'rq-mod-groups' }, ...groups)),
      ui.warning(R.legal.shortDisclaimer, 'info', 'Legal.')
    );
  }

  /* ------------------------------- overview ------------------------------- */
  const MODULE_ACTIONS = [
    ['org360', 'Open Organization 360'], ['fragility', 'Open Counterparty Financial Fragility'], ['insurance', 'Open Insurance & Reinsurance'], ['sanctions', 'Open Sanctions & Debarment'],
    ['cyber', 'Open Cyber Exposure'], ['climate', 'Open Physical/Climate Disruption'], ['trade', 'Open Trade & Category'], ['procurement', 'Open Procurement Radar'], ['relationships', 'Open Relationship Explorer']
  ];

  function resolutionBlock(ctx) {
    const s = ctx.session;
    const org = R.pipeline.ORG_TYPES.includes(ctx.type) || ctx.type === 'ticker';
    if (s.primary) {
      const p = s.primary;
      return ui.section('Resolved entity', { icon: 'building', actions: [ui.button('Change entity', () => {
        s.primary = null;
        s.resolved.entityName = null;
        R.events.emit('primary:changed', null);
      }, { cls: 'rq-btn-sm' }), ui.button('Add to Watchlist', () => ui.pin(p), { icon: 'pin', cls: 'rq-btn-sm' })] },
        h('div', { class: 'rq-resolved' }, h('div', null, h('div', { class: 'rq-resolved-name' }, p.title), h('div', { class: 'rq-muted' }, p.subtitle)), h('div', { class: 'rq-row' }, ui.confidence(s.primaryConfidence), s.primaryAuto ? ui.badge('Auto-selected (single exact match)', 'neutral') : ui.badge('Selected by you', 'org'), p.ids.lei ? ui.badge('LEI ' + p.ids.lei, 'org') : null)),
        s.primaryConfidence === 'Possible' ? ui.warning('This is a possible match only. Manual review recommended before relying on linked evidence.', 'amber') : null
      );
    }
    if (org) {
      const def = R.T.gleifSearch(s.chosen.orgName || s.query);
      return ui.section('Entity resolution — choose the legal entity', { icon: 'building', desc: 'Candidates from GLEIF, sorted by match confidence. JAQA never silently picks a “Possible” match.' }, ui.taskPanel(def, { auto: true, onSelect: (r) => R.pipeline.selectPrimary(r), selectLabel: 'Use this entity', emptyText: 'No LEI records matched. The entity may be private, unregistered with GLEIF, or known under a different legal name.', linkout: { href: R.linkoutFromTemplate('https://search.gleif.org/#/search/simpleSearch={q}', s.query), label: 'Search GLEIF directly' } }));
    }
    return null;
  }

  function coverageSummary() {
    const tasks = R.tasks.all();
    const by = (st) => tasks.filter((t) => t.status === st).length;
    return ui.bars(
      [
        ['Records returned', by('done'), 'ok'],
        ['No records', by('empty'), 'neutral'],
        ['Loading', by('loading'), 'org'],
        ['Link-out only', by('linkout'), 'neutral'],
        ['Failed', by('error'), 'warn']
      ],
      { label: 'Lookups by status' }
    );
  }

  function overview(ctx) {
    if (!ctx.session) return firstRun();
    const s = ctx.session;
    const sig = R.signals.collect();
    const gaps = R.signals.gaps();
    const conflicts = R.signals.conflicts();
    const lensSet = new Set(s.lenses || []);
    const actions = MODULE_ACTIONS.filter(([id]) => lensSet.has(id) || ['org360', 'sanctions', 'relationships'].includes(id));
    const autoTasks = (s.autoKeys || []).map((k) => R.tasks.get(k)).filter(Boolean);

    return h(
      'div',
      { class: 'rq-overview' },
      h(
        'div',
        { class: 'rq-summary-grid' },
        h('div', { class: 'rq-stat' }, h('div', { class: 'rq-stat-label' }, 'Interpreted as'), h('div', { class: 'rq-stat-value' }, s.chosen.label), h('div', { class: 'rq-muted' }, 'Confidence: ' + s.chosen.confidence)),
        h('div', { class: 'rq-stat' }, h('div', { class: 'rq-stat-label' }, 'Primary subject'), h('div', { class: 'rq-stat-value rq-truncate' }, s.primary ? s.primary.title : s.resolved.countryName || s.resolved.placeLabel || ctx.name), h('div', { class: 'rq-muted' }, s.primary ? 'Match: ' + s.primaryConfidence : 'Not a resolved legal entity')),
        h('div', { class: 'rq-stat' }, h('div', { class: 'rq-stat-label' }, 'Source-reported signals'), h('div', { class: 'rq-stat-value' }, String(sig.length)), h('div', { class: 'rq-muted' }, 'Facts to review — not scores')),
        h('div', { class: 'rq-stat' }, h('div', { class: 'rq-stat-label' }, 'Data gaps'), h('div', { class: 'rq-stat-value' }, String(gaps.length)), h('div', { class: 'rq-muted' }, 'Coverage limits for this query'))
      ),
      h('div', { class: 'rq-row rq-quick-actions', role: 'group', 'aria-label': 'Quick actions' }, ...actions.map(([id, label]) => ui.button(label, () => R.shell.go(id, { focus: true }), { cls: 'rq-btn-sm' })), s.primary ? ui.button('Add to Watchlist', () => ui.pin(s.primary), { icon: 'pin', cls: 'rq-btn-sm' }) : null, ui.button('Export Evidence Pack', () => R.exporters.evidencePackJSON(), { icon: 'download', cls: 'rq-btn-sm', variant: 'primary' })),
      resolutionBlock(ctx),
      conflicts.length ? ui.section('Source discrepancies', { icon: 'warn' }, ...conflicts.map(([l, items]) => ui.conflict(l, items))) : null,
      h(
        'div',
        { class: 'rq-two-col' },
        ui.section('Top source-reported signals', { icon: 'warn', desc: 'Direct facts from sources that merit human review. Not a risk score.' }, sig.length ? h('ul', { class: 'rq-signal-list' }, ...sig.slice(0, 12).map((x) => h('li', { class: 'rq-signal rq-signal-' + x.tone }, ui.badge(x.tone === 'serious' ? 'Serious (source-reported)' : 'Review', x.tone), h('button', { type: 'button', class: 'rq-link-btn', onclick: () => R.shell.openDetail(x.record) }, x.text), h('span', { class: 'rq-muted' }, ' — ' + x.record.prov.sourceName)))) : h('p', { class: 'rq-muted' }, 'No source-reported signals yet. This is not evidence of low risk.')),
        ui.section('Top data gaps', { icon: 'info' }, gaps.length ? h('ul', { class: 'rq-gap-list' }, ...gaps.slice(0, 10).map((g) => h('li', null, g))) : h('p', { class: 'rq-muted' }, 'No specific gaps detected yet. Coverage is still incomplete by design.'))
      ),
      h('div', { class: 'rq-two-col' }, ui.section('Source coverage for this query', { icon: 'chart' }, coverageSummary()), ui.section('Freshness', { icon: 'calendar' }, h('ul', { class: 'rq-fresh-list' }, ...R.tasks.all().filter((t) => t.retrievedAt).map((t) => {
        const src = R.sources.get(t.sourceId);
        return h('li', null, h('strong', null, t.label), ' — retrieved ' + fmt.time(t.retrievedAt) + (src && src.mayLagOfficialDb ? ' · may lag the official database' : ''));
      })), R.tasks.all().some((t) => t.retrievedAt) ? null : h('p', { class: 'rq-muted' }, 'Nothing retrieved yet.'))),
      ui.section('Initial lookups', { icon: 'search', desc: 'A small first request budget. Deeper sources load when you open a module or click Load.' }, ...autoTasks.filter((t) => !(t.key.startsWith('gleif:search:') && !s.primary && (R.pipeline.ORG_TYPES.includes(ctx.type) || ctx.type === 'ticker'))).map((t) => ui.taskPanel(t.def, { auto: true, limit: 6 }))),
      ui.warning('Overview summarizes public records and link-outs. It does not approve, clear, score, rank, insure, cover, fund, award, or certify counterparties, countries, products, or opportunities.', 'info')
    );
  }

  R.modules.register({ id: 'overview', group: 'risk', order: 1, icon: 'gauge', liveRefresh: true, title: 'Overview / Risk Triage', short: 'Overview', description: 'Unified summary of the investigated subject: interpretation, resolution, signals, gaps, coverage and freshness.', render: overview });
})(window.JAQAWorkspace);

/* ---- modules/organization360.js ---- */
/*
 * organization360.js — MODULE 4: Organization 360, MODULE 5: Counterparty
 * Financial Fragility, MODULE 6: Public Filing & Financial Statement Lens,
 * MODULE 7: Credit, Insolvency & Litigation.
 *
 * HOW PUBLIC FILINGS ARE PARSED AND CAVEATED
 *   SEC submissions give form types, dates, accession numbers and 8-K item
 *   codes. JAQA lists specific 8-K items (1.03, 2.04, 4.01, 4.02, …) and
 *   NT (late filing) notices as source-reported filing facts with links.
 *
 * HOW DERIVED METRICS ARE CALCULATED AND LABELED
 *   Only when XBRL company facts are live: each metric shows its formula,
 *   the exact XBRL concepts and periods used, and a comparability caveat.
 *   No credit score, peer ranking, rating or investment conclusion is ever
 *   produced.
 */
(function (R) {
  'use strict';
  const { h, extLink, fmt } = R.util;
  const ui = R.ui;
  const T = R.T;

  const INSURANCE_TYPES = ['insurer', 'reinsurer', 'broker', 'mga', 'captive', 'ils', 'tpa', 'syndicate'];

  /** Returns a resolution panel when the subject is not yet a resolved entity; else null. */
  R.entityGate = function (ctx, purpose) {
    if (!ctx.session) return ui.needSession(purpose);
    if (ctx.primary) return null;
    const org = R.pipeline.ORG_TYPES.includes(ctx.type) || ['ticker', 'lei', 'cik'].includes(ctx.type);
    if (!org) return h('div', null, ui.warning(`The current query was interpreted as “${ctx.chosen.label}”. ${purpose ? 'This module works on organizations; ' : ''}search an organization, LEI, ticker or CIK, or change the interpretation above.`, 'info'), ui.button('Treat query as an organization', () => R.shell.search(ctx.q, 'organization'), { icon: 'building' }));
    if (ctx.type === 'cik') return h('div', null, ui.taskPanel(T.secSubs(ctx.chosen.cik), { auto: true, onSelect: (r) => R.pipeline.selectPrimary(r), selectLabel: 'Use this entity' }));
    if (ctx.type === 'lei') return h('div', null, ui.taskPanel(T.gleifLei(ctx.chosen.lei), { auto: true, onSelect: (r) => R.pipeline.selectPrimary(r), selectLabel: 'Use this entity' }));
    return ui.section('Choose the legal entity first', { icon: 'building', desc: 'Downstream lookups use the selected entity’s legal name and identifiers. Possible matches are never treated as exact.' }, ui.taskPanel(T.gleifSearch(ctx.chosen.orgName || ctx.q), { auto: true, onSelect: (r) => R.pipeline.selectPrimary(r), selectLabel: 'Use this entity' }), h('p', { class: 'rq-muted' }, 'No suitable LEI record? Many private companies have none.'), ui.button('Continue with the query text as a name (Possible match)', () => {
      const r = R.rec('user', 'unresolved-name', { title: ctx.q, subtitle: 'Unresolved name — no legal-entity record selected', category: 'ambiguous', confidence: 'Unresolved', badges: [{ text: 'Unresolved entity', tone: 'warn' }], fields: [['Name as entered', ctx.q]], data: { name: ctx.q } });
      r.prov.sourceName = 'User-entered name (unresolved)';
      r.prov.url = '';
      R.pipeline.selectPrimary(r, { confidence: 'Unresolved' });
    }, { cls: 'rq-btn-sm' }));
  };

  function subjectName(ctx) {
    return (ctx.primary && ctx.primary.data && ctx.primary.data.name) || ctx.primary.title;
  }
  function subjectHeader(ctx) {
    const p = ctx.primary;
    return h('div', { class: 'rq-subject' }, h('div', null, h('div', { class: 'rq-eyebrow' }, 'Subject'), h('div', { class: 'rq-resolved-name' }, p.title)), h('div', { class: 'rq-row' }, ui.confidence(ctx.session.primaryConfidence), p.ids.lei ? ui.badge('LEI ' + p.ids.lei, 'org') : ui.badge('No LEI selected', 'neutral'), ctx.resolved.cik ? ui.badge('CIK ' + ctx.resolved.cik, 'fin') : null));
  }

  const gapsList = (items) => ui.section('Data gaps', { icon: 'info' }, h('ul', { class: 'rq-gap-list' }, ...items.map((g) => h('li', null, g))));

  /* ---------------------------- Organization 360 ---------------------------- */
  R.modules.register({
    id: 'org360',
    group: 'risk',
    order: 2,
    icon: 'building',
    title: 'Organization 360',
    short: 'Organization 360',
    description: 'Legal identity, corporate family, identifiers, filings, awards and public signals for a supplier, buyer, insurer, reinsurer, broker, captive, MGA, TPA or other organization.',
    warnings: ['Corporate family coverage is incomplete. Missing LEI does not mean an invalid entity. Private companies may have limited public data. Confidence and provenance are shown for every record.'],
    render(ctx) {
      const gate = R.entityGate(ctx, 'Organization 360');
      if (gate) return gate;
      const p = ctx.primary;
      const name = subjectName(ctx);
      const lei = p.ids.lei;
      const isIns = INSURANCE_TYPES.includes(ctx.type);
      const qid = ctx.resolved.qid;
      return h(
        'div',
        null,
        subjectHeader(ctx),
        ui.section('Legal identity', { icon: 'building' }, ui.recordCard(p)),
        lei
          ? ui.section('Corporate family (GLEIF Level 2 relationship data)', { icon: 'tree', desc: 'Loaded on module open (up to 3 requests). Parent/child data is only as reported to GLEIF; reporting exceptions are common.' }, h('div', { class: 'rq-three-col' }, ui.taskPanel(T.gleifParent(lei, 'direct'), { auto: true, compact: true, noHitWarning: false }), ui.taskPanel(T.gleifParent(lei, 'ultimate'), { auto: true, compact: true, noHitWarning: false }), ui.taskPanel(T.gleifChildren(lei), { auto: true, compact: true, limit: 8, noHitWarning: false })))
          : ui.warning('No LEI selected, so GLEIF parent/child relationships cannot be loaded.', 'amber'),
        ui.section('Identifier cross-links', { icon: 'link', desc: 'Wikidata claims are community-edited and non-authoritative. Conflicts with official registries are shown, never auto-resolved.' }, qid ? ui.taskPanel(T.wdIds(qid), { auto: true }) : ui.taskPanel(T.wdSearch(name), { auto: false, onSelect: (r) => {
          ctx.session.resolved.qid = r.data.qid;
          R.tasks.ensure(T.wdIds(r.data.qid));
          R.tasks.start(T.wdIds(r.data.qid).key);
          R.shell.refresh();
        }, selectLabel: 'Use for cross-links' })),
        ctx.resolved.cik ? ui.section('SEC filings', { icon: 'doc' }, ui.taskPanel(T.secSubs(ctx.resolved.cik), { auto: true }), ui.button('Open Public Filing lens', () => R.shell.go('filings', { focus: true }), { cls: 'rq-btn-sm' })) : null,
        ui.section('Enrichment (user-triggered)', { icon: 'download', desc: 'Each lookup sends the entity name directly from your browser to the named provider.' },
          h('div', { class: 'rq-two-col' },
            ui.taskPanel(T.usaAwards({ recipient: name, kind: 'contracts' }), { limit: 5, emptyText: 'No US federal contract awards matched this recipient name.' }),
            ui.taskPanel(T.cpscSearch(name), { limit: 5, emptyText: 'No CPSC recalls matched this name in recall titles.' }),
            ui.taskPanel(T.kevMentions(name.split(/\s+/)[0]), { limit: 5, emptyText: 'No CISA KEV entries name this vendor/product text.' }),
            ui.taskPanel(T.courts(name, 'r'), { limit: 5 }),
            ui.taskPanel(T.epa(name), { limit: 5 }),
            ui.taskPanel(T.wpSummary(name), { limit: 1, noHitWarning: false })
          )
        ),
        isIns ? ui.section('Insurance regulator & rating link-outs', { icon: 'umbrella' }, ui.dir('insuranceRegulators', null, { compact: true }), ui.dir('ratingAgencies', null, { compact: true })) : null,
        ui.section('Sanctions & debarment (link-out only)', { icon: 'shield' }, ui.warning(R.legal.noHitNotClear + ' JAQA is not a sanctions screening system of record.', 'amber'), ui.dir('sanctions', null, { compact: true })),
        ui.section('Registries & official sources', { icon: 'link' }, ui.dir('entity', name, { compact: true })),
        gapsList([
          lei ? 'GLEIF data is self-reported by the entity via LOUs and corroborated to varying levels.' : 'No LEI selected.',
          ctx.resolved.cik ? 'SEC data covers US-registered filers only.' : 'No SEC registrant identified — financial filings may be unavailable or held by non-US registries.',
          'Name-based lookups (awards, recalls, KEV, courts, EPA) can match unrelated entities with similar names. Verify identifiers.',
          'Website, officers, beneficial owners and internal data are not collected.'
        ]),
        ui.exportBar('JAQA-Counterparty-Evidence-Pack.json', 'JAQA-Counterparty-Evidence-Pack.csv', 'globalRisk')
      );
    }
  });

  /* ---------------------- Counterparty Financial Fragility ---------------------- */
  function secSignalsView(recs, task) {
    const sigs = (task.meta && task.meta.signals) || [];
    return h(
      'div',
      null,
      ui.recordCard(recs[0]),
      h('h4', { class: 'rq-h4' }, 'Source-reported filing events (most recent first)'),
      sigs.length
        ? h('ul', { class: 'rq-signal-list' }, ...sigs.slice(0, 20).map((s) => h('li', { class: 'rq-signal rq-signal-warn' }, ui.badge('Filing event', 'warn'), h('span', null, `${s.date} — ${s.text} `), extLink(s.url, 'Open filing'))))
        : h('p', { class: 'rq-muted' }, 'No late-filing notices or listed 8-K stress items in the recent filings index. This does not indicate financial health.')
    );
  }
  R.secSignalsView = secSignalsView;

  R.modules.register({
    id: 'fragility',
    group: 'finance',
    order: 21,
    icon: 'gauge',
    title: 'Counterparty Financial Fragility',
    short: 'Counterparty Fragility',
    description: 'Public evidence of financial stress: filing events, late filings, restructuring and insolvency records, liens, litigation and enforcement link-outs.',
    warnings: ['Public distress signals do not predict insolvency. Credit, legal, treasury, and compliance review required.', 'No credit score. No approval/rejection. No “safe” or “distressed” conclusion. No confidential lender data.'],
    render(ctx) {
      const gate = R.entityGate(ctx, 'Counterparty Financial Fragility');
      if (gate) return gate;
      const name = subjectName(ctx);
      return h(
        'div',
        null,
        subjectHeader(ctx),
        ui.kv([
          ['Legal name', ctx.primary.title],
          ['LEI', ctx.primary.ids.lei],
          ['Jurisdiction', ctx.primary.data && ctx.primary.data.jurisdiction],
          ['Entity status (GLEIF)', ctx.primary.data && ctx.primary.data.status],
          ['Public company status', ctx.resolved.cik ? 'SEC registrant (CIK ' + ctx.resolved.cik + ')' : 'No SEC registrant identified'],
          ['Match confidence', ctx.session.primaryConfidence]
        ]),
        ctx.resolved.cik
          ? ui.section('Public filing events', { icon: 'doc', desc: '8-K items 1.03, 1.05, 2.04, 2.05, 2.06, 3.01, 4.01, 4.02, 5.02 and NT late-filing notices, as listed in the SEC filing index.' }, ui.taskPanel(T.secSubs(ctx.resolved.cik), { auto: true, render: secSignalsView }))
          : ui.warning('Private-company coverage limitation: no public filings identified. Request financial statements directly from the counterparty and use licensed credit data where appropriate.', 'amber'),
        ui.section('Insolvency, restructuring & court records', { icon: 'gavel', desc: 'User-triggered. CourtListener covers part of the US federal record (RECAP); PACER is fee-based and not bypassed.' }, ui.taskPanel(T.courts(name, 'r'), { limit: 8 }), ui.dir('insolvency', name, { compact: true })),
        ui.section('Liens, charges & judgments (link-out)', { icon: 'link' }, ui.warning('Lien/UCC/judgment registries are jurisdiction-specific, often delayed, and name matching is ambiguous.', 'amber'), ui.dir('lien', name, { compact: true })),
        ui.section('Sanctions, debarment & enforcement (link-out)', { icon: 'shield' }, ui.dir('sanctions', null, { compact: true }), ui.dir('enforcement', null, { compact: true })),
        ui.section('Rating agencies & market data (link-out only)', { icon: 'chart' }, ui.dir('ratingAgencies', null, { compact: true }), ui.warning('Ratings are licensed; JAQA never scrapes, reproduces or derives them.', 'info')),
        ui.warning('Parent/subsidiary ambiguity: stress at a subsidiary, parent or sister entity may be reported under a different legal name. Check the corporate family in Organization 360.', 'amber'),
        ui.exportBar('JAQA-Counterparty-Evidence-Pack.json', 'JAQA-Counterparty-Evidence-Pack.csv', 'finance')
      );
    }
  });

  /* ------------------------- Public Filing & XBRL lens ------------------------- */
  const XBRL = {
    Revenues: ['Revenues', 'RevenueFromContractWithCustomerExcludingAssessedTax', 'SalesRevenueNet'],
    NetIncome: ['NetIncomeLoss'],
    OperatingCashFlow: ['NetCashProvidedByUsedInOperatingActivities'],
    Cash: ['CashAndCashEquivalentsAtCarryingValue'],
    AssetsCurrent: ['AssetsCurrent'],
    LiabilitiesCurrent: ['LiabilitiesCurrent'],
    LongTermDebt: ['LongTermDebtNoncurrent', 'LongTermDebt'],
    Equity: ['StockholdersEquity', 'StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest'],
    InterestExpense: ['InterestExpense', 'InterestExpenseNonoperating'],
    OperatingIncome: ['OperatingIncomeLoss']
  };
  function latestFact(facts, names) {
    const g = facts && facts['us-gaap'];
    if (!g) return null;
    for (const n of names) {
      const units = g[n] && g[n].units && (g[n].units.USD || Object.values(g[n].units)[0]);
      if (!units) continue;
      const annual = units.filter((u) => /^(10-K|20-F|40-F)/.test(u.form || '') && u.fp === 'FY');
      const pick = (annual.length ? annual : units).slice().sort((a, b) => String(b.end).localeCompare(String(a.end)) || String(b.filed).localeCompare(String(a.filed)))[0];
      if (pick) return { concept: n, val: pick.val, end: pick.end, form: pick.form, fy: pick.fy, filed: pick.filed, accn: pick.accn };
    }
    return null;
  }
  R.clients.secXbrl = {
    async facts(cik) {
      const padded = R.clients.sec.padCik(cik);
      const res = await R.net.request('secXbrl', `https://data.sec.gov/api/xbrl/companyfacts/CIK${padded}.json`, { validate: (j) => j && typeof j.facts === 'object' });
      if (!res.ok) return { error: res.errorKind };
      const facts = res.data.facts;
      const got = Object.fromEntries(Object.entries(XBRL).map(([k, names]) => [k, latestFact(facts, names)]));
      const metric = (label, formula, a, b, caveat) => {
        const x = got[a];
        const y = got[b];
        if (!x || !y || !y.val) return [label, 'Not computable: required XBRL facts not reported'];
        return [label, `${fmt.num(x.val / y.val, 2)} — ${formula}; ${x.concept} (${x.end}) ÷ ${y.concept} (${y.end}). ${caveat}`];
      };
      const fields = [
        ...Object.entries(got).map(([k, v]) => [k + ' (latest, as reported)', v ? `${fmt.money(v.val)} · ${v.concept} · period end ${v.end} · ${v.form} filed ${v.filed}` : null]),
        metric('Current ratio (derived by JAQA)', 'AssetsCurrent ÷ LiabilitiesCurrent', 'AssetsCurrent', 'LiabilitiesCurrent', 'Periods may differ; not a credit metric.'),
        metric('Debt to equity (derived by JAQA)', 'LongTermDebt ÷ StockholdersEquity', 'LongTermDebt', 'Equity', 'Excludes short-term debt and leases; accounting policies differ.'),
        metric('Interest coverage (derived by JAQA)', 'OperatingIncomeLoss ÷ InterestExpense', 'OperatingIncome', 'InterestExpense', 'Operating income is not EBIT/EBITDA; periods may differ.')
      ];
      return {
        records: [
          R.rec('secXbrl', 'xbrl-financial-fact', {
            title: (res.data.entityName || 'Registrant') + ' — XBRL company facts',
            subtitle: 'Latest annual facts where available',
            recordId: padded,
            url: `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=${padded}&type=10-K&owner=exclude`,
            endpoint: 'api/xbrl/companyfacts',
            category: 'derived-financial-metric',
            badges: [{ text: 'Derived by JAQA from public filing data', tone: 'fin' }, { text: 'Not a credit rating', tone: 'neutral' }],
            fields
          })
        ]
      };
    }
  };

  R.modules.register({
    id: 'filings',
    group: 'finance',
    order: 22,
    icon: 'doc',
    title: 'Public Filing & Financial Statement Lens',
    short: 'Public Filings',
    description: 'Filing index, filing events and (where live) XBRL financial facts with transparent derived metrics.',
    warnings: ['Derived by JAQA from public filing data. Not a credit rating. Accounting standards, fiscal periods, and restatements may limit comparability.'],
    render(ctx) {
      const gate = R.entityGate(ctx, 'the Public Filing lens');
      if (gate) return gate;
      const cik = ctx.resolved.cik;
      if (!cik)
        return h('div', null, subjectHeader(ctx), ui.warning('No SEC registrant identified for this entity (no CIK from the selection or Wikidata cross-links). Non-US and private companies file with other registries or not at all.', 'amber'), ui.dir('entity', subjectName(ctx), { title: 'Registry link-outs', compact: true }));
      const filingsTable = (recs, task) => {
        const fl = ((task.meta && task.meta.filings) || []).filter((f) => /^(10-K|10-Q|8-K|20-F|40-F|6-K|NT |S-1|424B|DEF 14A)/.test(f.form)).slice(0, 30);
        return h(
          'div',
          null,
          ui.recordCard(recs[0]),
          h('div', { class: 'rq-table-wrap', tabindex: '0', role: 'region', 'aria-label': 'Recent filings' }, h('table', { class: 'rq-table' }, h('thead', null, h('tr', null, ...['Form', 'Filed', 'Period', '8-K items', 'Accession', 'Document'].map((c) => h('th', { scope: 'col' }, c)))), h('tbody', null, ...fl.map((f) => h('tr', null, h('th', { scope: 'row' }, f.form), h('td', null, f.date), h('td', null, f.report || '—'), h('td', null, f.items || '—'), h('td', null, f.accession), h('td', null, extLink(f.url, 'Open')))))))
        );
      };
      return h(
        'div',
        null,
        subjectHeader(ctx),
        ui.section('Filing index (SEC EDGAR submissions)', { icon: 'doc' }, ui.taskPanel(T.secSubs(cik), { auto: true, render: filingsTable })),
        ui.section('XBRL financial facts & derived metrics', { icon: 'chart', desc: 'Formula, source concepts, periods and caveats shown for every derived value. No credit score, peer ranking or investment conclusion.' }, ui.taskPanel({ key: 'secxbrl:' + cik, sourceId: 'secXbrl', label: 'SEC XBRL company facts', run: () => R.clients.secXbrl.facts(cik) }, { linkout: { href: `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=${cik}&type=10-K&owner=exclude`, label: 'Open 10-K filings on EDGAR' } })),
        ui.section('Going-concern, restatement and auditor-change disclosures', { icon: 'warn' }, h('p', null, 'Listed 8-K items 4.01 (auditor change) and 4.02 (non-reliance/restatement) appear in Counterparty Financial Fragility. Going-concern language must be read in the filings themselves:'), extLink('https://www.sec.gov/edgar/search/#/q=%22going%20concern%22&ciks=' + cik, 'EDGAR full-text search: “going concern” for this CIK')),
        ui.exportBar('JAQA-Finance-Risk-results.json', 'JAQA-Finance-Risk-results.csv', 'finance')
      );
    }
  });

  /* ------------------------ Credit, Insolvency & Litigation ------------------------ */
  R.modules.register({
    id: 'credit',
    group: 'finance',
    order: 23,
    icon: 'gavel',
    title: 'Credit, Insolvency & Litigation',
    short: 'Credit, Insolvency & Litigation',
    description: 'Public court, bankruptcy, lien, judgment, debarment and enforcement signals with jurisdictional link-outs.',
    warnings: ['No public record does not mean no distress. Private-company coverage may be limited. Court and lien registries are jurisdiction-specific and delayed. Legal and credit review required.', 'No credit score, payment recommendation, collateral valuation, lender-priority determination or personal-data aggregation.'],
    render(ctx) {
      if (!ctx.session) return h('div', null, ui.needSession('court and insolvency records'), ui.dir('insolvency', null, { title: 'Insolvency registries' }), ui.dir('lien', null, { title: 'Lien & judgment registries' }));
      const name = ctx.primary ? subjectName(ctx) : ctx.q;
      return h(
        'div',
        null,
        ctx.primary ? subjectHeader(ctx) : ui.warning('No resolved entity; lookups use the query text and may match unrelated parties.', 'amber'),
        ui.section('US federal court dockets (RECAP) — includes bankruptcy courts where indexed', { icon: 'gavel' }, ui.taskPanel(T.courts(name, 'r'), { limit: 10 })),
        ui.section('Court opinions', { icon: 'doc' }, ui.taskPanel(T.courts(name, 'o'), { limit: 10 })),
        ctx.resolved.cik ? ui.section('Bankruptcy / acceleration filing items (SEC 8-K)', { icon: 'warn' }, ui.taskPanel(T.secSubs(ctx.resolved.cik), { auto: true, render: secSignalsView })) : null,
        ui.section('Insolvency registries', { icon: 'link' }, ui.dir('insolvency', name, { compact: true })),
        ui.section('Liens, UCC, charges, tax liens & judgments', { icon: 'link' }, ui.dir('lien', name, { compact: true }), h('p', { class: 'rq-muted' }, 'Tax liens are recorded with county/state recorders (US) and equivalent offices elsewhere; many are fee-based or not searchable online.')),
        ui.section('Debarment, exclusions & enforcement', { icon: 'shield' }, ui.linkouts(R.directories.sanctions.filter((e) => e.kind === 'debarment'), null, { compact: true }), ui.dir('enforcement', null, { compact: true })),
        ui.exportBar('JAQA-Finance-Risk-results.json', 'JAQA-Finance-Risk-results.csv', 'finance')
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/globalRiskUniverse.js ---- */
/*
 * globalRiskUniverse.js — MODULE 2: Global Risk Universe, and the shared
 * taxonomy view reused by the Finance Risk Universe.
 *
 * The coverage matrix is computed at runtime from the Source Capability
 * Registry: a domain shows "Evidence available now" only if at least one of
 * its mapped sources is live in this browser session. Nothing here measures
 * risk; it maps where public evidence exists and where it does not.
 */
(function (R) {
  'use strict';
  const { h, extLink } = R.util;
  const ui = R.ui;

  const DIR_LABEL = {
    entity: 'Entity registries', sanctions: 'Sanctions, debarment & export control', enforcement: 'Enforcement', insolvency: 'Insolvency registries', lien: 'Lien & judgment registries',
    insuranceRegulators: 'Insurance regulators', ratingAgencies: 'Rating agencies', marketReports: 'Market reports', procurement: 'Procurement portals', devBanks: 'Development banks', ppp: 'PPP resources',
    macro: 'Macro & central banks', trade: 'Trade & customs', cyber: 'Cyber & data', climate: 'Climate & catastrophe', esg: 'ESG & human rights', regulatory: 'Regulatory', standards: 'Standards', digitalAssets: 'Digital assets', logistics: 'Logistics'
  };
  R.DIR_LABEL = DIR_LABEL;

  function liveSources(d) {
    return (d.src || []).filter((id) => R.runtime.isLive(id));
  }

  /**
   * Shared taxonomy view.
   * cfg: { list, state, kind: 'global'|'finance', notAdvice, matchKey, jsonName, csvName, domain }
   */
  R.taxonomyView = function (cfg, ctx) {
    const st = cfg.state;
    const matched = ctx.session && ctx.chosen && ctx.chosen.domains ? ctx.chosen.domains : [];
    if (!st.selected && matched.length) st.selected = matched[0];
    const groups = cfg.kind === 'global' ? Object.entries(R.taxonomy.groups).map(([k, g]) => [k, g.label]) : [];
    const regions = [...new Set(cfg.list.flatMap((d) => d.regions || []))];
    const sectors = [...new Set(cfg.list.flatMap((d) => d.sectors || []))];

    const filtered = cfg.list.filter((d) => {
      if (st.group && d.group !== st.group) return false;
      if (st.region && !(d.regions || []).includes(st.region)) return false;
      if (st.sector && !(d.sectors || []).includes(st.sector)) return false;
      const live = liveSources(d).length;
      if (st.mode === 'live' && !live) return false;
      if (st.mode === 'linkout' && live) return false;
      if (st.text) {
        const t = st.text.toLowerCase();
        if (![d.name, d.def, ...(d.sub || []), ...(d.aliases || [])].join(' ').toLowerCase().includes(t)) return false;
      }
      return true;
    });

    const rerender = () => R.shell.refresh();
    const filters = h(
      'div',
      { class: 'rq-filters' },
      groups.length ? ui.select('Risk group', [['', 'All groups'], ...groups], st.group || '', (v) => ((st.group = v), rerender())) : null,
      ui.select('Region', [['', 'All regions'], ...regions.map((r) => [r, r])], st.region || '', (v) => ((st.region = v), rerender())),
      ui.select('Sector', [['', 'All sectors'], ...sectors.map((r) => [r, r])], st.sector || '', (v) => ((st.sector = v), rerender())),
      ui.select('Source mode', [['', 'All'], ['live', 'Evidence available now (live)'], ['linkout', 'Link-out only']], st.mode || '', (v) => ((st.mode = v), rerender())),
      ui.input('Filter text', st.text || '', (v) => {
        st.text = v;
        clearTimeout(st.t);
        st.t = setTimeout(rerender, 350);
      }, { placeholder: 'e.g. flood, sanctions, liquidity' })
    );

    const withLive = filtered.filter((d) => liveSources(d).length).length;
    const summary = ui.bars(
      [
        ['Domains shown', filtered.length, 'org'],
        ['At least one live source mapped', withLive, 'ok'],
        ['Link-out only', filtered.length - withLive, 'neutral']
      ],
      { label: 'Coverage summary' }
    );

    const table = h(
      'div',
      { class: 'rq-table-wrap', tabindex: '0', role: 'region', 'aria-label': 'Coverage matrix' },
      h(
        'table',
        { class: 'rq-table rq-matrix' },
        h('caption', { class: 'rq-sr' }, 'Coverage matrix: public-source availability by domain'),
        h('thead', null, h('tr', null, h('th', { scope: 'col' }, 'Domain'), cfg.kind === 'global' ? h('th', { scope: 'col' }, 'Group') : null, h('th', { scope: 'col' }, 'Evidence now'), h('th', { scope: 'col' }, 'Live sources'), h('th', { scope: 'col' }, 'Link-out directories'), h('th', { scope: 'col' }, 'Main data gap'))),
        h(
          'tbody',
          null,
          ...filtered.map((d) => {
            const live = liveSources(d);
            const isMatch = matched.includes(d.id);
            return h(
              'tr',
              { class: (isMatch ? 'is-match ' : '') + (st.selected === d.id ? 'is-selected' : '') },
              h('th', { scope: 'row' }, h('button', { type: 'button', class: 'rq-link-btn', 'aria-pressed': st.selected === d.id ? 'true' : 'false', onclick: () => {
                st.selected = d.id;
                rerender();
                setTimeout(() => {
                  const el = document.getElementById('rq-tax-detail');
                  if (el) el.focus();
                }, 30);
              } }, d.name), isMatch ? ui.badge('Matches query', 'org') : null),
              cfg.kind === 'global' ? h('td', null, d.groupLabel) : null,
              h('td', null, live.length ? ui.badge('Live evidence', 'ok') : ui.badge('Link-out only', 'neutral')),
              h('td', null, live.length ? live.map((id) => R.sources.get(id).displayName.replace(/ \(.*\)$/, '')).join(', ') : '—'),
              h('td', null, (d.dirs || []).map((k) => DIR_LABEL[k] || k).join(', ')),
              h('td', { class: R.state.prefs.highlightGaps ? 'rq-gap-cell' : '' }, d.gaps)
            );
          })
        )
      )
    );

    const sel = cfg.list.find((d) => d.id === st.selected);
    return h(
      'div',
      null,
      ui.warning(cfg.notAdvice, 'info'),
      filters,
      h('div', { class: 'rq-two-col' }, ui.section('Coverage summary', { icon: 'chart' }, summary), ui.section('Export', { icon: 'download' }, h('div', { class: 'rq-row' }, ui.button('Coverage matrix JSON', () => exportMatrix(cfg, filtered, 'json'), { icon: 'download', cls: 'rq-btn-sm' }), ui.button('Coverage matrix CSV', () => exportMatrix(cfg, filtered, 'csv'), { icon: 'download', cls: 'rq-btn-sm' })), h('p', { class: 'rq-fineprint' }, 'Exports include coverage-gap warnings and JAQA™ legal metadata.'))),
      sel ? domainDetail(sel, cfg, ctx) : null,
      ui.section('Coverage matrix', { icon: 'grid', desc: `${filtered.length} of ${cfg.list.length} domains. Select a domain for definitions, mappings, live lookups and official links.` }, table)
    );
  };

  function domainDetail(d, cfg, ctx) {
    const live = liveSources(d);
    const term = d.name.replace(/\s*risk$/i, '').replace(/\s*\(.*\)$/, '').split(' / ')[0];
    const lines = cfg.kind === 'global' ? R.taxonomy.insuranceLines.filter((l) => l.risks.includes(d.id)) : [];
    return h(
      'section',
      { class: 'rq-tax-detail', id: 'rq-tax-detail', tabindex: '-1', 'aria-label': d.name + ' details' },
      h('div', { class: 'rq-row rq-row-between' }, h('h3', { class: 'rq-h3' }, d.name), h('div', { class: 'rq-row' }, live.length ? ui.badge('Evidence available now', 'ok') : ui.badge('Link-out only', 'neutral'), cfg.kind === 'global' ? ui.badge(d.groupLabel, 'risk') : ui.badge('Finance risk domain', 'fin'))),
      h('p', { class: 'rq-lead' }, d.def),
      ui.kv([
        ['Why it matters (risk, procurement, insurance, finance)', d.why || d.rel],
        ['Sub-risks', (d.sub || []).join('; ') || null],
        ['Typical evidence types', (d.ev || []).join('; ') || null],
        ['Common data gaps', d.gaps],
        ['Regions covered', (d.regions || []).join('; ')],
        ['Sectors', (d.sectors || []).join('; ')],
        ['Languages', 'English source metadata; official link-outs may be multilingual (translation risk)'],
        ['Related regulators', (d.reg || []).join('; ') || null],
        ['Related standards / frameworks', (d.std || []).join('; ') || null]
      ]),
      h(
        'div',
        { class: 'rq-two-col' },
        ui.section('Risk-to-Insurance mapping', { icon: 'umbrella', desc: 'Possible related lines to discuss with qualified brokers/insurers. Not a coverage determination.' }, h('div', { class: 'rq-row' }, ...[...new Set([...(d.ins || []), ...lines.map((l) => l.name)])].map((x) => ui.badge(x, 'ins'))), (d.ins || []).length || lines.length ? null : h('p', { class: 'rq-muted' }, 'No specific line mapped.'), ui.button('Open Insurance & Reinsurance', () => R.shell.go('insurance', { focus: true }), { cls: 'rq-btn-sm' })),
        ui.section('Risk-to-Procurement mapping', { icon: 'doc', desc: 'Relevant public procurement categories. Not bid/no-bid advice.' }, h('div', { class: 'rq-row' }, ...((d.proc && d.proc.length ? d.proc : ['General goods & services'])).map((x) => ui.badge(x, 'proc'))), ui.button('Open Procurement & Bid Radar', () => R.shell.go('procurement', { focus: true }), { cls: 'rq-btn-sm' }))
      ),
      ctx.session
        ? ui.section('Live lookup: recent US regulatory documents mentioning this domain', { icon: 'search', desc: 'User-triggered. Sends the domain term (not your original query) to the Federal Register.' }, ui.taskPanel(R.T.frSearch(term, { perPage: 5, order: 'newest' }), { limit: 5 }))
        : h('p', { class: 'rq-muted' }, 'Run a search to enable live lookups for this domain.'),
      ui.section('Official link-outs', { icon: 'link' }, ...(d.dirs || []).map((k) => ui.dir(k, null, { title: DIR_LABEL[k] || k, compact: true }))),
      ui.warning('Not advice. ' + cfg.notAdvice, 'amber')
    );
  }

  function exportMatrix(cfg, list, fmtType) {
    const rows = list.map((d) => ({
      domain: d.name,
      group: d.groupLabel || 'Finance',
      definition: d.def,
      evidenceAvailableNow: liveSources(d).length > 0,
      liveSources: liveSources(d).map((id) => R.sources.get(id).displayName),
      linkoutDirectories: (d.dirs || []).map((k) => DIR_LABEL[k] || k),
      dataGaps: d.gaps,
      insuranceLines: d.ins || [],
      procurementCategories: d.proc || [],
      regulators: d.reg || [],
      standards: d.std || []
    }));
    if (fmtType === 'json') {
      const payload = Object.assign(R.legal.exportBlock(['JAQA Source Capability Registry']), { warnings: [cfg.notAdvice, R.exporters.DOMAIN_WARNINGS.globalRisk], coverageMatrix: rows });
      R.exporters.download(cfg.jsonName, JSON.stringify(payload, null, 2), 'application/json');
    } else {
      const head = ['Domain', 'Group', 'Evidence available now', 'Live sources', 'Link-out directories', 'Data gaps', 'Insurance lines', 'Procurement categories', 'Regulators', 'Standards'];
      const data = rows.map((r) => [r.domain, r.group, r.evidenceAvailableNow ? 'yes' : 'no', r.liveSources.join('; '), r.linkoutDirectories.join('; '), r.dataGaps, r.insuranceLines.join('; '), r.procurementCategories.join('; '), r.regulators.join('; '), r.standards.join('; ')]);
      data.push([], ['Warning', cfg.notAdvice], ['Legal', R.legal.copyright]);
      R.exporters.download(cfg.csvName, '﻿' + R.exporters.toCSV([head, ...data]), 'text/csv');
    }
  }

  const state = {};
  R.events.on('session:cleared', () => Object.keys(state).forEach((k) => delete state[k]));
  R.events.on('session:started', () => delete state.selected);

  R.modules.register({
    id: 'globalRisk',
    group: 'risk',
    order: 3,
    icon: 'globe',
    title: 'Global Risk Universe',
    short: 'Global Risk Universe',
    description: `${R.taxonomy.global.length} risk domains mapped to live public sources, official link-outs, regulators, standards, insurance lines and procurement categories.`,
    warnings: ['Global Risk Universe is a public-source map, not a risk measurement system. JAQA organizes public evidence about each risk; it does not measure it.'],
    render: (ctx) => R.taxonomyView({ list: R.taxonomy.global, state, kind: 'global', notAdvice: 'Coverage is incomplete by region, sector, language and source. No output here states that anything is safe, clear, covered, insured, approved or low/high risk.', jsonName: 'JAQA-Global-Risk-results.json', csvName: 'JAQA-Global-Risk-results.csv' }, ctx)
  });
})(window.JAQAWorkspace);

/* ---- modules/financeRiskUniverse.js ---- */
/*
 * financeRiskUniverse.js — MODULE 3: Finance Risk Universe,
 * MODULE 9: Market, Macro & Sovereign Risk, MODULE 10: FX, Interest Rate &
 * Commodity Context.
 *
 * No credit score, sovereign rating, default prediction, investment advice,
 * hedging advice or exposure calculation is produced. Indicators are shown
 * with source, period, frequency and latency warnings.
 */
(function (R) {
  'use strict';
  const { h, extLink } = R.util;
  const ui = R.ui;

  const state = {};
  const macro = { iso3: null, more: false };
  const fx = { ccy: null };
  R.events.on('session:cleared', () => {
    Object.keys(state).forEach((k) => delete state[k]);
    macro.iso3 = null;
    macro.more = false;
    fx.ccy = null;
  });
  R.events.on('session:started', () => {
    delete state.selected;
    macro.iso3 = null;
    fx.ccy = null;
  });

  R.modules.register({
    id: 'financeRisk',
    group: 'finance',
    order: 20,
    icon: 'coin',
    title: 'Finance Risk Universe',
    short: 'Finance Risk Universe',
    description: `${R.taxonomy.finance.length} finance-risk domains mapped to public filings, macro indicators, registries, regulators and official link-outs.`,
    warnings: ['Finance Risk Universe is a public-source map, not a financial risk measurement system. No credit score, rating, solvency opinion, investment or treasury advice is produced.'],
    render: (ctx) => R.taxonomyView({ list: R.taxonomy.finance, state, kind: 'finance', notAdvice: 'Not credit, investment, treasury, insurance, legal, tax, AML or sanctions advice. Public records may be delayed, restated or incomplete.', jsonName: 'JAQA-Finance-Risk-results.json', csvName: 'JAQA-Finance-Risk-results.csv' }, ctx)
  });

  /* ---------------------- country resolution helper ---------------------- */
  function countryFromCtx(ctx) {
    const r = ctx.resolved || {};
    if (r.iso3) return r.iso3;
    const iso2 = r.iso2 || (ctx.primary && ctx.primary.ids && ctx.primary.ids.country);
    const c = iso2 ? R.geo.byIso2(iso2) : null;
    return c ? c.iso3 : null;
  }
  R.countryFromCtx = countryFromCtx;

  function countryPicker(current, onPick) {
    return ui.select('Country / sovereign', [['', 'Select a country…'], ...R.geo.countries.map((c) => [c.iso3, `${c.name} (${c.iso3})`])], current || '', onPick, { key: 'country-picker' });
  }
  R.countryPicker = countryPicker;

  function indicatorGrid(iso3, keys, auto) {
    return h('div', { class: 'rq-indicator-grid' }, ...keys.map((k) => ui.taskPanel(R.T.wbInd(iso3, k), { auto, compact: true, emptyText: 'Not reported by source for recent years.' })));
  }

  /* ---------------------- Market, Macro & Sovereign ---------------------- */
  R.modules.register({
    id: 'marketMacro',
    group: 'finance',
    order: 25,
    icon: 'chart',
    title: 'Market, Macro & Sovereign Risk',
    short: 'Market, Macro & Sovereign',
    description: 'Public macro-financial and sovereign context: growth, inflation, debt, external position, banking and governance indicators.',
    warnings: ['Market data may be delayed. Reference rates are not tradable prices. JAQA does not provide investment or hedging advice and produces no sovereign rating or default prediction.'],
    render(ctx) {
      if (!ctx.session) return h('div', null, ui.needSession('macro and sovereign indicators'), ui.dir('macro', null, { title: 'Official macro & central bank sources' }));
      const iso3 = macro.iso3 || countryFromCtx(ctx);
      const c = iso3 ? R.geo.countries.find((x) => x.iso3 === iso3) : null;
      const picker = countryPicker(iso3, (v) => {
        macro.iso3 = v || null;
        R.shell.refresh();
      });
      if (ctx.type === 'digitalAsset')
        return h('div', null, ui.warning('Digital-asset markets are highly volatile and differently regulated across jurisdictions. Link-out only; no investment advice, no price data, no wallet or address screening.', 'amber', 'Digital asset context.'), ui.dir('digitalAssets', null, { title: 'Official digital-asset resources' }), ui.dir('sanctions', null, { title: 'Sanctions resources (address listings appear in official lists only)', compact: true }));
      if (!c) return h('div', null, h('div', { class: 'rq-filters' }, picker), ui.warning('Select a country, or search a country/entity with a known jurisdiction, to load sovereign context.', 'info'), ui.dir('macro', null, { title: 'Official macro & central bank sources' }));
      return h(
        'div',
        null,
        h('div', { class: 'rq-filters' }, picker, h('div', { class: 'rq-field' }, h('span', null, 'Official link-outs'), h('div', { class: 'rq-row' }, extLink('https://www.imf.org/en/Countries/' + c.iso3, 'IMF country page'), extLink('https://data.worldbank.org/country/' + c.iso2, 'World Bank country data')))),
        ui.section('Growth, prices & fiscal position — ' + c.name, { icon: 'chart', desc: 'World Bank WDI, annual. Loaded on module open (4 requests).' }, indicatorGrid(c.iso3, ['gdpGrowth', 'inflation', 'govDebt', 'currentAccount'], true)),
        macro.more
          ? h(
              'div',
              null,
              ui.section('External position, rates & banking', { icon: 'coin' }, indicatorGrid(c.iso3, ['reserves', 'extDebt', 'lending', 'realRate', 'npl', 'bankCapital', 'privCredit'], true)),
              ui.section('Governance (Worldwide Governance Indicators)', { icon: 'gavel', desc: 'Estimates range approximately −2.5 to +2.5 and carry margins of error. Not a rating.' }, indicatorGrid(c.iso3, ['wgiPV', 'wgiGE', 'wgiRQ', 'wgiRL', 'wgiCC', 'wgiVA'], true))
            )
          : ui.button('Load external, banking & governance indicators (13 more requests)', () => {
              macro.more = true;
              R.shell.refresh();
            }, { icon: 'download' }),
        ui.section('Sovereign, subnational & market link-outs', { icon: 'link' }, ui.dir('macro', null, { compact: true }), h('p', { class: 'rq-muted' }, 'Sovereign credit ratings, CDS spreads and equity index data are licensed; JAQA links to providers and never reproduces them.'), ui.dir('ratingAgencies', null, { compact: true })),
        ui.exportBar('JAQA-Market-Macro-indicators.json', 'JAQA-Market-Macro-indicators.csv', 'finance')
      );
    }
  });

  /* ------------------------- FX, Rate & Commodity ------------------------- */
  R.modules.register({
    id: 'fx',
    group: 'finance',
    order: 26,
    icon: 'coin',
    title: 'FX, Interest Rate & Commodity Context',
    short: 'FX, Rates & Commodities',
    description: 'Reference rates, rate indicators, commodity benchmarks and currency-control/sanctions context for treasury, procurement and category teams.',
    warnings: [
      'Actual exposure requires internal contracts, debt schedules, payables/receivables and hedge data. JAQA does not calculate exposure from public data alone and never accepts internal positions.',
      'No hedging advice. No treasury execution advice. No trade execution.'
    ],
    render(ctx) {
      const iso3 = countryFromCtx(ctx);
      const c = iso3 ? R.geo.countries.find((x) => x.iso3 === iso3) : null;
      const defCcy = fx.ccy || (c && R.geo.currencyFor(c.iso2) !== 'EUR' ? R.geo.currencyFor(c.iso2) : null) || 'USD';
      const picker = ui.select('Currency vs EUR (ECB reference rates)', R.geo.ECB_CCY.map((x) => [x, x]), defCcy, (v) => {
        fx.ccy = v;
        R.shell.refresh();
      }, { key: 'fx-ccy' });
      return h(
        'div',
        null,
        h('div', { class: 'rq-filters' }, picker),
        ctx.session
          ? ui.section('Euro foreign exchange reference rate', { icon: 'coin', desc: 'ECB Data Portal, last 30 observations. Loaded on module open (1 request).' }, ui.taskPanel(R.T.ecb(defCcy), { auto: true }))
          : ui.needSession('FX reference rates'),
        c && ctx.session ? ui.section('Country rate & FX indicators — ' + c.name, { icon: 'chart', desc: 'User-triggered (World Bank, annual).' }, indicatorGrid(c.iso3, ['fx', 'lending', 'realRate'], false)) : null,
        ui.section('Commodity benchmarks & currency controls (link-outs)', { icon: 'link' }, ui.linkouts(R.directories.macro.filter((e) => /commodity|AREAER|Treasury|FRED|ECB/i.test(e.name)), null, { compact: true })),
        ui.section('Sanctions & payment restrictions (link-outs)', { icon: 'shield' }, ui.linkouts(R.directories.sanctions.slice(0, 6), null, { compact: true }), ui.warning(R.legal.noHitNotClear, 'amber')),
        ui.section('Trade & category exposure', { icon: 'ship' }, h('p', null, 'Public trade data is aggregated and lagging; it cannot reveal your organization’s exposure.'), ui.button('Open Trade, Customs & Category Exposure', () => R.shell.go('trade', { focus: true }), { cls: 'rq-btn-sm' })),
        ui.exportBar('JAQA-Market-Macro-indicators.json', 'JAQA-Market-Macro-indicators.csv', 'finance')
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/sanctionsEnforcement.js ---- */
/*
 * sanctionsEnforcement.js — MODULE 8: Financial Crime, Sanctions &
 * Enforcement.
 *
 * HOW "NO HIT ≠ CLEAR" IS ENFORCED
 *   Sanctions and debarment sources are link-out only; JAQA never queries
 *   them automatically, never bulk-screens, and never renders words such as
 *   "cleared" or "no match — safe". Every sanctions panel carries the no-hit
 *   warning, and exports repeat it (R.exporters.DOMAIN_WARNINGS.sanctions).
 */
(function (R) {
  'use strict';
  const { h } = R.util;
  const ui = R.ui;

  R.modules.register({
    id: 'sanctions',
    group: 'finance',
    order: 24,
    icon: 'shield',
    title: 'Financial Crime, Sanctions & Enforcement',
    short: 'Sanctions & Enforcement',
    description: 'Official sanctions, debarment, export-control and enforcement sources (link-out), plus live regulatory notices and court records where verified.',
    warnings: [
      'No public match found does not mean cleared. JAQA is not an AML system and not a sanctions clearance tool. JAQA does not determine suspicion, intent, or liability.',
      'No SAR/CTR access, no transaction monitoring, no KYC document processing. JAQA does not assist sanctions or export-control evasion.'
    ],
    render(ctx) {
      const name = ctx.session ? (ctx.primary ? (ctx.primary.data && ctx.primary.data.name) || ctx.primary.title : ctx.q) : null;
      const isList = ctx.session && ['sanctionsId'].includes(ctx.type);
      return h(
        'div',
        null,
        ctx.session && ctx.type === 'person' ? ui.warning('Person searches are restricted. Use your organization’s screening system of record; JAQA does not aggregate personal data.', 'red') : null,
        ui.section('Sanctions lists (official, link-out)', { icon: 'shield', desc: 'Screen names in the official tools. Name matching requires fuzzy logic, identifiers and human adjudication.' }, ui.warning(R.legal.noHitNotClear, 'red', 'No hit ≠ clear.'), ui.linkouts(R.directories.sanctions.filter((e) => e.kind === 'sanctions'), null)),
        ui.section('Export control & forced-labour entity lists (link-out)', { icon: 'ship' }, ui.linkouts(R.directories.sanctions.filter((e) => e.kind === 'export-control'), null)),
        ui.section('Debarment & exclusions (link-out)', { icon: 'gavel' }, ui.linkouts(R.directories.sanctions.filter((e) => e.kind === 'debarment'), null)),
        ui.section('Enforcement & financial-crime sources (link-out)', { icon: 'doc' }, ui.dir('enforcement', null)),
        ctx.session
          ? ui.section('Recent US sanctions & export-control rules (Federal Register, live)', { icon: 'search', desc: isList ? 'Loaded automatically for sanctions concept searches.' : 'User-triggered.' }, ui.taskPanel(R.T.frSearch(isList && ctx.chosen.focus === 'sam' ? 'debarment' : 'sanctions', { perPage: 8, order: 'newest' }), { auto: isList, limit: 8 }))
          : null,
        name && !isList && ctx.type !== 'person'
          ? ui.section('Court records mentioning the subject (live, user-triggered)', { icon: 'gavel', desc: 'Text match only; may include unrelated parties. Not an adverse-media or enforcement determination.' }, ui.taskPanel(R.T.courts(name, 'o'), { limit: 8 }))
          : null,
        ui.section('Adverse media (link-out only)', { icon: 'globe' }, ui.warning('Media signals are noisy and unverified. JAQA does not perform adverse-media screening.', 'amber'), name && ctx.type !== 'person' ? ui.taskPanel(R.T.gdelt(name), { limit: 10 }) : null),
        ui.exportBar('JAQA-Sanctions-Enforcement-triage.json', 'JAQA-Sanctions-Enforcement-triage.csv', 'sanctions')
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/insuranceReinsurance.js ---- */
/*
 * insuranceReinsurance.js — MODULE 11: Insurance & Reinsurance Intelligence,
 * MODULE 12: Insurance & Reinsurance Financial Strength.
 *
 * HOW INSURANCE SOURCES ARE LINK-OUT-FIRST
 *   Insurance regulators, rating agencies, market reports, Lloyd’s, captive
 *   and ILS resources have no verified public browser APIs. They are official
 *   link-outs only. Rating reports and market reports are never scraped,
 *   reproduced or derived. Live evidence comes only from verified sources
 *   (GLEIF, SEC, Federal Register, USGS, USAspending, CourtListener).
 *
 * HOW NO INSURANCE ADVICE IS GENERATED
 *   Outputs are records and links. No coverage, capacity, solvency,
 *   recoverability, broker-suitability or premium statement is ever rendered.
 */
(function (R) {
  'use strict';
  const { h, extLink } = R.util;
  const ui = R.ui;
  const T = R.T;

  const INS_WARN = 'JAQA does not provide insurance, reinsurance, underwriting, claims, coverage, broker-selection, or capacity advice. Insurance and reinsurance decisions require qualified brokers, insurers, reinsurers, actuaries, legal counsel, regulators, and risk professionals as appropriate.';
  const RE_WARN = 'Reinsurance capacity, treaty terms, recoverables, retrocession chains, and collateral arrangements are often confidential. JAQA only organizes public-source signals and official link-outs.';
  const ILS_WARN = 'Catastrophe bonds and insurance-linked securities involve complex legal, credit, market, and trigger risks. Public records do not constitute investment advice or risk transfer confirmation.';
  const NOHIT = 'No public record found does not mean an insurer, reinsurer, broker, captive, or ILS vehicle is clear, solvent, authorized, or suitable.';

  const ENTITY_TYPES = ['insurer', 'reinsurer', 'broker', 'mga', 'captive', 'ils', 'tpa', 'syndicate'];

  function linesView(ctx) {
    const matched = ctx.chosen && ctx.chosen.lines ? ctx.chosen.lines : [];
    return h(
      'div',
      { class: 'rq-lines' },
      ...R.taxonomy.insuranceLines.map((l) =>
        h('div', { class: 'rq-line' + (matched.includes(l.id) ? ' is-match' : '') }, h('strong', null, l.name), l.risks.length ? h('div', { class: 'rq-muted' }, 'Related risk domains: ' + l.risks.map((id) => (R.taxonomy.global.find((d) => d.id === id) || {}).name).filter(Boolean).join(', ')) : null, matched.includes(l.id) ? ui.badge('Matches query', 'org') : null)
      )
    );
  }

  function catContext(ctx) {
    const r = ctx.resolved || {};
    if (r.lat && r.lon)
      return h('div', null, h('p', { class: 'rq-muted' }, 'Reference point: ' + (r.placeLabel || 'resolved location') + '. Geographic event context only — not exposure by policy, not insured loss.'), h('div', { class: 'rq-two-col' }, ui.taskPanel(T.quakes(r.lat, r.lon, 500, 30), { compact: true }), ui.taskPanel(T.forecast(r.lat, r.lon, r.placeLabel), { compact: true })));
    return h('p', { class: 'rq-muted' }, 'Search a country, port or place to add catastrophe-event context by geography. Event data does not confirm insured loss or claims liability.');
  }

  R.modules.register({
    id: 'insurance',
    group: 'insurance',
    order: 30,
    icon: 'umbrella',
    title: 'Insurance & Reinsurance Intelligence',
    short: 'Insurance & Reinsurance',
    description: 'Public evidence on insurers, reinsurers, brokers, MGAs, captives, Lloyd’s syndicates, ILS/cat bond vehicles and TPAs — regulators, filings, lines, catastrophe context and insurance-related procurement.',
    warnings: [INS_WARN, 'JAQA does not determine coverage, capacity, solvency, claims outcome, broker suitability, reinsurance recoverability, or insurance market conditions.', NOHIT],
    render(ctx) {
      const isEntity = ctx.session && ENTITY_TYPES.includes(ctx.type);
      const name = ctx.primary ? (ctx.primary.data && ctx.primary.data.name) || ctx.primary.title : ctx.q;
      const q = ctx.session ? ctx.q : '';
      return h(
        'div',
        null,
        ui.section('1. Counterparty overview', { icon: 'building' }, ctx.session ? (isEntity || ctx.primary ? (ctx.primary ? h('div', null, ui.recordCard(ctx.primary), ui.button('Open Organization 360', () => R.shell.go('org360', { focus: true }), { cls: 'rq-btn-sm' })) : R.entityGate(ctx, 'insurance counterparty evidence')) : h('p', { class: 'rq-muted' }, 'The current query is not an insurance entity. Search an insurer, reinsurer, broker, MGA, captive, syndicate, ILS vehicle or TPA to resolve a counterparty.')) : ui.needSession('insurance counterparty evidence')),
        ui.section('2. Regulatory coverage (official registers, link-out)', { icon: 'gavel', desc: 'Authorization and licensing status is authoritative only in the regulator’s own register.' }, ui.dir('insuranceRegulators', null, { compact: true })),
        ui.section('3. Financial strength & credit signals', { icon: 'chart' }, h('p', null, 'See the Financial Strength lens for filings, regulator returns and rating link-outs.'), ui.button('Open Insurance & Reinsurance Financial Strength', () => R.shell.go('insuranceStrength', { focus: true }), { cls: 'rq-btn-sm' })),
        ui.section('4. Insurance lines & product context', { icon: 'layers', desc: 'Context for discussion with qualified professionals. Not a coverage determination.' }, linesView(ctx)),
        ui.section('5. Catastrophe / event exposure context (by geography, not by policy)', { icon: 'cloud' }, ctx.session ? catContext(ctx) : ui.needSession('catastrophe context'), ui.linkouts(R.directories.marketReports.filter((e) => /Munich|Swiss/.test(e.name)), null, { compact: true })),
        ui.section('6. Reinsurance / retrocession context', { icon: 'tree' }, ui.warning(RE_WARN, 'amber'), ui.dir('marketReports', null, { compact: true }), ui.warning(ILS_WARN, 'amber', 'ILS / cat bonds.')),
        ui.section('7. Broker / MGA / TPA context', { icon: 'link', desc: 'Intermediaries and delegated-authority holders are authorized via regulator registers (e.g. FCA register, NAIC/state DOIs).' }, ui.linkouts(R.directories.insuranceRegulators.filter((e) => /FCA|NAIC|Lloyd|EIOPA/.test(e.name)), null, { compact: true })),
        ui.section('8. Procurement intersection', { icon: 'doc', desc: 'Publicly tendered broker panels, claims platforms, actuarial services and captive management. US federal awards are live; other portals are link-out.' }, ctx.session ? ui.taskPanel(T.usaAwards({ keyword: isEntity ? name : /insur|broker|claims|actuar|captive|reinsur/i.test(q) ? q : 'insurance brokerage', kind: 'contracts' }), { limit: 6, auto: ctx.type === 'insuranceLine' }) : null, ui.button('Open Procurement & Bid Radar', () => R.shell.go('procurement', { focus: true }), { cls: 'rq-btn-sm' })),
        ctx.session ? ui.section('Regulatory documents (Federal Register, live)', { icon: 'search' }, ui.taskPanel(T.frSearch(ctx.type === 'insuranceLine' ? q : 'insurance', { perPage: 6 }), { auto: ctx.type === 'insuranceLine', limit: 6 })) : null,
        ui.exportBar('JAQA-Insurance-Reinsurance-evidence.json', 'JAQA-Insurance-Reinsurance-evidence.csv', 'insurance')
      );
    }
  });

  R.modules.register({
    id: 'insuranceStrength',
    group: 'insurance',
    order: 31,
    icon: 'shield',
    title: 'Insurance & Reinsurance Financial Strength',
    short: 'Financial Strength',
    description: 'Public filings, solvency disclosures, regulator links and rating-agency link-outs for insurers, reinsurers, brokers, captives, MGAs, TPAs and ILS entities.',
    warnings: ['JAQA does not determine solvency, capacity, recoverability, or financial strength. Rating agencies and regulators are authoritative sources.', NOHIT, 'No coverage determination, claims advice, underwriting advice, capacity estimate, recoverable estimate or paid rating reproduction.'],
    render(ctx) {
      const gate = ctx.session && !ctx.primary ? R.entityGate(ctx, 'financial strength evidence') : null;
      const cik = ctx.resolved && ctx.resolved.cik;
      const name = ctx.primary ? (ctx.primary.data && ctx.primary.data.name) || ctx.primary.title : ctx.q;
      return h(
        'div',
        null,
        !ctx.session ? ui.needSession('insurer financial strength evidence') : gate || h('div', null, ui.recordCard(ctx.primary)),
        ctx.session ? ui.kv([
          ['Entity type (as interpreted)', ctx.chosen ? ctx.chosen.label : null],
          ['Match confidence', ctx.session.primaryConfidence || 'Unresolved'],
          ['Listed / SEC filer', cik ? 'Yes — CIK ' + cik : 'No SEC registrant identified']
        ]) : null,
        cik ? ui.section('Public filings for listed insurers/reinsurers', { icon: 'doc' }, ui.taskPanel(T.secSubs(cik), { auto: true, render: R.secSignalsView })) : null,
        ui.section('Solvency & capital disclosures (regulator link-outs)', { icon: 'gavel', desc: 'Solvency II SFCRs are published by EEA insurers; NAIC/state DOIs, PRA/FCA, BaFin, APRA, OSFI, NFRA and IRDAI hold local returns.' }, ui.dir('insuranceRegulators', null, { compact: true })),
        ui.section('Rating agencies (link-out only)', { icon: 'chart' }, ui.warning('Financial strength ratings are licensed. JAQA never scrapes, reproduces or derives a rating.', 'info'), ui.dir('ratingAgencies', null, { compact: true })),
        ctx.session && ctx.type !== 'insuranceLine' ? ui.section('Litigation signals (live, user-triggered)', { icon: 'gavel' }, ui.taskPanel(T.courts(name, 'o'), { limit: 6 })) : null,
        ui.section('Sanctions & debarment (link-out)', { icon: 'shield' }, ui.linkouts(R.directories.sanctions.slice(0, 7), null, { compact: true })),
        ui.section('ILS / cat bond & captive public resources (link-out)', { icon: 'layers' }, ui.warning(ILS_WARN, 'amber'), ui.linkouts(R.directories.insuranceRegulators.filter((e) => /Bermuda|Cayman|Guernsey|Vermont/.test(e.name)).concat(R.directories.marketReports.filter((e) => /Artemis|Lloyd/.test(e.name))), null, { compact: true }), h('p', { class: 'rq-muted' }, 'Captive cell/member data and ILS investor data are confidential and never requested.')),
        ui.exportBar('JAQA-Insurance-Financial-Strength-evidence.json', 'JAQA-Insurance-Financial-Strength-evidence.csv', 'insurance')
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/cyber.js ---- */
/*
 * cyber.js — MODULE 13: Cyber, Technology, AI & Software Supply-Chain Risk.
 *
 * Uses CISA KEV (official cisagov mirror) and NVD. No scanning of any kind:
 * Shodan/Censys/VirusTotal/urlscan are link-out only and never called.
 * A vulnerability record is never presented as confirmed supplier exposure.
 */
(function (R) {
  'use strict';
  const { h, extLink } = R.util;
  const ui = R.ui;
  const T = R.T;

  T.kevRecent = () => ({ key: 'kev:recent', sourceId: 'cisaKev', label: 'CISA KEV — most recent additions', run: () => R.clients.kev.recent(15) });

  R.modules.register({
    id: 'cyber',
    group: 'risk',
    order: 10,
    icon: 'bug',
    title: 'Cyber, Technology, AI & Software Supply Chain',
    short: 'Cyber & Software Supply Chain',
    description: 'Known exploited vulnerabilities, CVE records, cyber-incident filing items and official advisories relevant to vendors, platforms and supply chains.',
    warnings: [
      'CVE records do not prove that a supplier, insurer, broker, or procurement platform uses the affected software or firmware version.',
      'Cyber supply-chain triage requires asset inventory, SBOMs where available, vendor attestations, and incident response review. No live scanning; no confidential asset inventory upload.'
    ],
    render(ctx) {
      if (!ctx.session)
        return h('div', null, ui.needSession('cyber evidence'), ui.dir('cyber', null, { title: 'Official cyber sources' }));
      const c = ctx.chosen;
      const name = ctx.primary ? (ctx.primary.data && ctx.primary.data.name) || ctx.primary.title : ctx.q;
      const parts = [];
      if (c.type === 'cve') {
        parts.push(
          ui.section('Known exploitation (CISA KEV)', { icon: 'warn' }, ui.taskPanel(T.kevCve(c.cve), { auto: true, emptyText: 'This CVE is not in the CISA KEV catalog. Absence from KEV does not mean it is not exploited.', noHitWarning: false })),
          ui.section('CVE record (NVD)', { icon: 'doc' }, ui.taskPanel(T.nvdCve(c.cve), { auto: true })),
          h('div', { class: 'rq-row' }, extLink('https://www.cve.org/CVERecord?id=' + c.cve, 'CVE.org record'), extLink('https://nvd.nist.gov/vuln/detail/' + c.cve, 'NVD record'), extLink('https://github.com/advisories?query=' + encodeURIComponent(c.cve), 'GitHub Advisory Database'))
        );
      } else if (c.type === 'cwe') {
        parts.push(ui.section('Weakness reference', { icon: 'doc' }, extLink('https://cwe.mitre.org/data/definitions/' + c.cwe + '.html', 'MITRE CWE-' + c.cwe), h('p', { class: 'rq-muted' }, 'CWE is a weakness taxonomy; it does not identify affected products.')));
      } else if (R.pipeline.ORG_TYPES.includes(c.type) || ctx.primary || c.type === 'freetext' || c.type === 'category') {
        const term = name.split(/\s+/)[0];
        parts.push(
          ui.section('Vendor/product mentions in CISA KEV', { icon: 'warn', desc: `Matches the text “${term}” against KEV vendor/product fields. A match is about a product, not about any organization’s deployment.` }, ui.taskPanel(T.kevMentions(term), { limit: 10, emptyText: 'No KEV entries mention this vendor/product text.' })),
          ui.section('NVD keyword search', { icon: 'search' }, ui.taskPanel(T.nvdKeyword(name), { limit: 10 }))
        );
      } else {
        parts.push(ui.section('Recent CISA KEV additions', { icon: 'warn', desc: 'Downloads the KEV catalog once per session (user-triggered).' }, ui.taskPanel(T.kevRecent(), { limit: 15, auto: c.domain === 'cyber' })));
      }
      if (ctx.resolved.cik) parts.push(ui.section('Cybersecurity incident disclosures (SEC 8-K item 1.05)', { icon: 'doc' }, ui.taskPanel(T.secSubs(ctx.resolved.cik), { auto: true, render: R.secSignalsView })));
      parts.push(
        ui.section('Advisories & software supply-chain references', { icon: 'link' }, ui.dir('cyber', null, { compact: true })),
        ui.section('Scanners & exposure search engines (link-out only)', { icon: 'shield', desc: 'JAQA never scans, probes, fingerprints or enumerates any system. Use these only under your organization’s authorization and policies.' }, ui.dir('scannersLinkOutOnly', null, { compact: true })),
        ui.exportBar('JAQA-Cyber-results.json', 'JAQA-Cyber-results.csv', 'globalRisk')
      );
      return h('div', null, ...parts);
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/situationRoom.js ---- */
/*
 * situationRoom.js — Situation Room: the command-center landing view.
 *
 * DESIGN PROVENANCE: the layout language (dense multi-panel intelligence
 * grid, live wire/ticker, status strip) and the HUD language (reticle,
 * corner brackets, telemetry readouts, optic modes) are INSPIRED BY the
 * public WorldMonitor and God's Eye View projects. No code, assets, styles
 * or data were copied into this module; it is a clean-room implementation
 * built on JAQA's own verified sources. (God's Eye View's MIT code ships
 * separately as JAQA Eye View at /globe/; see THIRD_PARTY_NOTICES.md.)
 *
 * PRIVACY: feeds use fixed, non-personal queries (no search terms), stay on
 * STANDBY until the user activates them, and are wiped by Clear Session.
 * The globe plots only records already loaded in this session.
 */
(function (R) {
  'use strict';
  const { h, icon, fmt, clear, extLink } = R.util;
  const ui = R.ui;
  const C = R.clients;

  const REG_TOPICS = [
    ['sanctions', 'Sanctions'],
    ['export controls', 'Export controls'],
    ['tariff', 'Tariffs & trade remedies'],
    ['insurance', 'Insurance'],
    ['cybersecurity', 'Cybersecurity'],
    ['procurement', 'Procurement'],
    ['climate disclosure', 'Climate disclosure']
  ];
  const st = { topic: 'sanctions', mode: 'std', layers: { quake: true, place: true, entity: true, signal: true } };
  R.events.on('session:cleared', () => Object.assign(st, { topic: 'sanctions', mode: 'std', layers: { quake: true, place: true, entity: true, signal: true } }));

  const FEEDS = {
    quakes: () => ({ key: 'feed:usgs:global7d', sourceId: 'usgs', label: 'Global seismic · USGS M4.5+ · 7 days', run: () => C.usgs.global(7, 4.5, { persistent: true }) }),
    kev: () => ({ key: 'feed:kev:recent', sourceId: 'cisaKev', label: 'Exploited vulnerabilities · CISA KEV · newest', run: () => C.kev.recent(12, { persistent: true }) }),
    reg: (topic) => ({ key: 'feed:fr:' + topic, sourceId: 'federalRegister', label: 'US regulatory wire · ' + topic, run: () => C.federalRegister.search(topic, { perPage: 10, order: 'newest', persistent: true }) }),
    fx: () => ({ key: 'feed:ecb:USD', sourceId: 'ecb', label: 'EUR/USD reference · ECB', run: () => C.ecb.exr('USD', 30, { persistent: true }) })
  };
  const feedDefs = () => [FEEDS.quakes(), FEEDS.kev(), FEEDS.reg(st.topic), FEEDS.fx()];

  function activateFeeds() {
    const keys = feedDefs().map((d) => R.tasks.ensure(d).key);
    R.util.announce('Activating public feeds. Fixed queries only; no search terms are sent.');
    R.tasks.runAll(keys);
    R.shell.refresh();
  }
  const feedsActive = () => feedDefs().some((d) => {
    const t = R.tasks.get(d.key);
    return t && t.status !== 'idle';
  });

  /* ------------------------------ markers ------------------------------ */
  function collectPoints() {
    const pts = [];
    const add = (p) => st.layers[p.kind] && isFinite(p.lat) && isFinite(p.lon) && pts.push(p);
    const tasks = [...R.tasks.feeds(), ...R.tasks.all()];
    for (const t of tasks) {
      for (const r of t.records || []) {
        const d = r.data || {};
        if (r.kind === 'earthquake' && isFinite(d.lat)) add({ kind: 'quake', lat: d.lat, lon: d.lon, weight: Math.max(0, Math.min(1, ((d.mag || 4.5) - 4.5) / 3)), label: r.title, record: r });
        else if (r.kind === 'place') add({ kind: 'place', lat: d.lat, lon: d.lon, label: 'Place · ' + r.title, record: r });
        else if (r.kind === 'country' && isFinite(d.lat)) add({ kind: 'place', lat: d.lat, lon: d.lon, label: 'Country reference · ' + r.title + (d.capital ? ' (' + d.capital + ')' : ''), record: r });
        else if (r.kind === 'forecast' && d.flags && d.flags.length) add({ kind: 'signal', lat: d.lat, lon: d.lon, label: 'Forecast threshold signal · ' + d.flags[0], record: r });
        else if (r.kind === 'monitor' && isFinite(d.lat)) add({ kind: 'signal', lat: d.lat, lon: d.lon, label: 'Global Monitor · ' + r.title, record: r });
      }
    }
    const s = R.state.session;
    if (s && s.resolved && isFinite(s.resolved.lat) && s.resolved.lat !== null) {
      const name = s.primary ? s.primary.title : s.resolved.placeLabel || s.query;
      add({ kind: 'entity', lat: s.resolved.lat, lon: s.resolved.lon, label: 'Subject reference · ' + name, record: s.primary || null });
    }
    return pts;
  }

  let globe = null;
  let markerList = null;
  let hud = null;
  function refreshLive() {
    if (globe && hud && hud.isConnected) globe.setPoints(collectPoints());
    if (markerList && markerList.isConnected) renderMarkerList();
  }
  R.events.on('task:update', (t) => {
    if (t.status !== 'loading') refreshLive();
  });

  function renderMarkerList() {
    const pts = collectPoints().slice(0, 40);
    clear(markerList);
    if (!pts.length) {
      markerList.appendChild(h('p', { class: 'rq-muted rq-mono' }, 'NO MARKERS. Activate public feeds or run a search with a location, port or country.'));
      return;
    }
    markerList.appendChild(
      h(
        'table',
        { class: 'rq-table rq-table-dense' },
        h('caption', { class: 'rq-sr' }, 'Globe markers (text alternative)'),
        h('thead', null, h('tr', null, ...['Layer', 'Marker', 'Lat', 'Lon', ''].map((c) => h('th', { scope: 'col' }, c)))),
        h(
          'tbody',
          null,
          ...pts.map((p) =>
            h(
              'tr',
              null,
              h('td', null, h('span', { class: 'rq-layer-chip rq-layer-' + p.kind }, p.kind === 'quake' ? 'SEISMIC' : p.kind === 'entity' ? 'SUBJECT' : p.kind === 'signal' ? 'SIGNAL' : 'PLACE')),
              h('th', { scope: 'row' }, h('button', { type: 'button', class: 'rq-link-btn', onclick: () => (p.record ? R.shell.openDetail(p.record) : null) }, fmt.truncate(p.label, 90))),
              h('td', { class: 'rq-mono' }, Number(p.lat).toFixed(2)),
              h('td', { class: 'rq-mono' }, Number(p.lon).toFixed(2)),
              h('td', null, ui.button('Locate', () => globe && globe.focus(p.lat, p.lon), { cls: 'rq-btn-xs', aria: 'Rotate globe to ' + p.label }))
            )
          )
        )
      )
    );
  }

  /* ------------------------------ panels ------------------------------ */
  function panel(title, opts, ...children) {
    const o = opts || {};
    return h(
      'section',
      { class: 'rq-panel' + (o.cls ? ' ' + o.cls : ''), 'aria-label': title },
      h('header', { class: 'rq-panel-head' }, h('span', { class: 'rq-panel-title' }, o.live ? h('span', { class: 'rq-live-dot', 'aria-hidden': 'true' }) : null, title), o.meta ? h('span', { class: 'rq-panel-meta' }, o.meta) : null, o.actions || null),
      h('div', { class: 'rq-panel-body' }, ...children)
    );
  }

  /** Dense wire-style list for feed panels. */
  function wireList(recs, kind) {
    return h(
      'ol',
      { class: 'rq-wire' },
      ...recs.map((r) => {
        const d = r.data || {};
        const tag = kind === 'quake' ? 'M' + fmt.num(d.mag, 1) : kind === 'kev' ? (r.fields.find((f) => f[0] === 'Date added to KEV') || [])[1] || 'KEV' : kind === 'reg' ? (r.fields.find((f) => f[0] === 'Publication date') || [])[1] || 'FR' : '';
        const time = kind === 'quake' && d.time ? new Date(d.time).toISOString().slice(5, 16).replace('T', ' ') + 'Z' : '';
        return h(
          'li',
          { class: 'rq-wire-row' + (kind === 'quake' && d.mag >= 6 ? ' is-hot' : '') },
          h('span', { class: 'rq-wire-tag rq-mono' }, tag),
          h('button', { type: 'button', class: 'rq-wire-title', onclick: () => R.shell.openDetail(r) }, kind === 'quake' ? r.title.replace(/^M[\d.]+ — /, '') : r.title),
          time ? h('span', { class: 'rq-wire-time rq-mono' }, time) : null,
          kind === 'quake' && isFinite(d.lat) ? h('button', { type: 'button', class: 'rq-wire-locate', 'aria-label': 'Locate on globe: ' + r.title, onclick: () => globe && globe.focus(d.lat, d.lon) }, icon('globe', 'rq-icon-xs')) : null
        );
      })
    );
  }

  function feedPanel(def, kind, auto) {
    return ui.taskPanel(def, { auto, compact: true, noHitWarning: kind !== 'reg', render: (recs) => wireList(recs.slice(0, kind === 'quake' ? 40 : 12), kind) });
  }

  function tickerItems() {
    const items = [];
    const q = R.tasks.get('feed:usgs:global7d');
    if (q && q.records) q.records.filter((r) => r.data.mag >= 5.5).slice(0, 6).forEach((r) => items.push(['SEISMIC', r.title]));
    const k = R.tasks.get('feed:kev:recent');
    if (k && k.records) k.records.slice(0, 5).forEach((r) => items.push(['KEV', r.title]));
    const f = R.tasks.get(FEEDS.reg(st.topic).key);
    if (f && f.records) f.records.slice(0, 5).forEach((r) => items.push(['REG', r.title]));
    R.signals.collect().slice(0, 6).forEach((sg) => items.push(['SESSION', sg.text]));
    return items;
  }

  function ticker() {
    const items = tickerItems();
    const wrap = h('div', { class: 'rq-ticker', role: 'region', 'aria-label': 'Latest items wire' });
    if (!items.length) {
      wrap.appendChild(h('div', { class: 'rq-ticker-static rq-mono' }, h('span', { class: 'rq-ticker-tag' }, 'WIRE'), 'FEEDS ON STANDBY — activate public feeds or run a search to populate the wire. No hit ≠ clear.'));
      return wrap;
    }
    const line = () => items.map(([tag, text]) => h('span', { class: 'rq-ticker-item' }, h('span', { class: 'rq-ticker-tag' }, tag), fmt.truncate(text, 110)));
    wrap.appendChild(h('div', { class: 'rq-ticker-track', 'aria-hidden': 'true' }, h('div', { class: 'rq-ticker-run' }, line(), line())));
    wrap.appendChild(h('ul', { class: 'rq-sr' }, ...items.map(([tag, text]) => h('li', null, tag + ': ' + text))));
    return wrap;
  }

  /* ------------------------------ globe panel ------------------------------ */
  const MODES = [['std', 'STD'], ['nvg', 'NVG'], ['flir', 'FLIR'], ['crt', 'CRT']];
  function globePanel(ctx) {
    const view = R.state.globeView || (R.state.globeView = { lon: 20, lat: 18, zoom: 1, auto: true });
    const host = h('div', { class: 'rq-globe-host' });
    const readout = h('span', { class: 'rq-hud-readout rq-mono' }, 'CTR —');
    const vis = h('span', { class: 'rq-hud-readout rq-mono' }, 'MARKERS 0');
    hud = h(
      'div',
      { class: 'rq-hud rq-optic-' + st.mode },
      host,
      h('div', { class: 'rq-hud-reticle', 'aria-hidden': 'true' }),
      h('div', { class: 'rq-hud-scan', 'aria-hidden': 'true' }),
      h('span', { class: 'rq-hud-corner tl', 'aria-hidden': 'true' }),
      h('span', { class: 'rq-hud-corner tr', 'aria-hidden': 'true' }),
      h('span', { class: 'rq-hud-corner bl', 'aria-hidden': 'true' }),
      h('span', { class: 'rq-hud-corner br', 'aria-hidden': 'true' }),
      h('div', { class: 'rq-hud-top rq-mono', 'aria-hidden': 'true' }, h('span', null, 'OPTIC ' + (MODES.find((m) => m[0] === st.mode) || MODES[0])[1]), h('span', { class: 'rq-utc' }, R.shell.utcNow())),
      h('div', { class: 'rq-hud-bottom', 'aria-live': 'off' }, readout, vis)
    );
    // Link into JAQA Eye View (/globe/), kept in step with this view.
    const alt3d = (z) => Math.round(Math.max(150000, 14000000 / Math.max(1, z)));
    const link3d = R.globe3d ? R.globe3d.link('Open in 3D globe', { lat: view.lat, lon: ((view.lon + 540) % 360) - 180, alt: alt3d(view.zoom), style: st.mode }) : null;
    if (globe) globe.destroy();
    globe = R.globe.create(host, {
      view,
      label: 'Situation Room evidence globe',
      onSelect: (p) => (p.record ? R.shell.openDetail(p.record) : R.util.announce(p.label)),
      onView: (v) => {
        readout.textContent = `CTR ${Math.abs(v.lat).toFixed(1)}°${v.lat >= 0 ? 'N' : 'S'} ${Math.abs(((v.lon + 540) % 360) - 180).toFixed(1)}°${((v.lon + 540) % 360) - 180 >= 0 ? 'E' : 'W'} · ZOOM ${v.zoom.toFixed(1)}×`;
        vis.textContent = `MARKERS ${v.visible}`;
        if (link3d) link3d.setAttribute('href', R.util.safeUrl(R.globe3d.url({ lat: v.lat, lon: ((v.lon + 540) % 360) - 180, alt: alt3d(v.zoom), style: st.mode })) || R.globe3d.base);
      }
    });
    globe.setPoints(collectPoints());
    const s = ctx.session;
    if (s && s.resolved && isFinite(s.resolved.lat) && s.resolved.lat !== null && st.focusedFor !== s.id) {
      st.focusedFor = s.id;
      setTimeout(() => globe && globe.focus(s.resolved.lat, s.resolved.lon), 60);
    }
    const layerToggle = (k, label) => {
      const id = R.util.uid('ly');
      return h('label', { class: 'rq-chip-toggle', for: id }, h('input', { id, type: 'checkbox', checked: st.layers[k] ? true : null, onchange: (e) => {
        st.layers[k] = e.target.checked;
        refreshLive();
      } }), h('span', { class: 'rq-layer-chip rq-layer-' + k }, label));
    };
    const controls = h(
      'div',
      { class: 'rq-globe-controls' },
      h('div', { class: 'rq-seg', role: 'group', 'aria-label': 'Optic mode' }, ...MODES.map(([k, l]) => h('button', { type: 'button', class: 'rq-seg-btn' + (st.mode === k ? ' is-on' : ''), 'aria-pressed': st.mode === k ? 'true' : 'false', onclick: () => {
        st.mode = k;
        R.shell.refresh();
      } }, l))),
      h('div', { class: 'rq-row rq-row-tight', role: 'group', 'aria-label': 'Layers' }, layerToggle('quake', 'SEISMIC'), layerToggle('place', 'PLACES'), layerToggle('entity', 'SUBJECT'), layerToggle('signal', 'SIGNALS')),
      h(
        'div',
        { class: 'rq-row rq-row-tight' },
        ui.button(view.auto ? 'Auto-rotate on' : 'Auto-rotate off', (e) => {
          globe.setAuto(!view.auto);
          e.currentTarget.querySelector('span').textContent = view.auto ? 'Auto-rotate on' : 'Auto-rotate off';
        }, { cls: 'rq-btn-xs', icon: 'refresh' }),
        s && s.resolved && s.resolved.lat !== undefined && s.resolved.lat !== null ? ui.button('Recenter on subject', () => globe.focus(s.resolved.lat, s.resolved.lon), { cls: 'rq-btn-xs', icon: 'globe' }) : null
      )
    );
    const open3d = h('div', { class: 'rq-row rq-row-tight' }, link3d, link3d ? h('span', { class: 'rq-fineprint' }, 'Photorealistic JAQA Eye View globe at this view (coordinates only).') : null);
    return panel('Evidence globe', { cls: 'rq-panel-globe', live: feedsActive(), meta: 'Natural Earth outlines · no tiles' }, hud, controls, open3d, h('p', { class: 'rq-fineprint' }, 'Drag or use arrow keys to rotate · wheel or +/− to zoom · Enter opens the marker nearest the reticle. Markers come only from records loaded in this session. Event positions are not facility, loss or exposure data.'));
  }

  /** Compact globe for other modules (e.g. Climate & Catastrophe). */
  R.situation = {
    mountGlobe(host, points, center) {
      const g = R.globe.create(host, { view: { lon: center ? center.lon : 0, lat: center ? center.lat : 20, zoom: 1.6, auto: false }, compact: true, label: 'Local event globe', onSelect: (p) => p.record && R.shell.openDetail(p.record) });
      g.setPoints(points);
      return g;
    },
    collectPoints,
    activateFeeds
  };

  /* ------------------------------ module ------------------------------ */
  R.modules.register({
    id: 'situation',
    group: 'risk',
    order: 0,
    icon: 'globe',
    title: 'Situation Room',
    short: 'Situation Room',
    description: 'Command-center view: evidence globe, live public wires and your session’s signals in one screen.',
    warnings: ['Situational awareness from public sources only — not a real-time control tower, not a risk score, and no hit ≠ clear.'],
    render(ctx) {
      const s = ctx.session;
      const active = feedsActive();
      const live = R.sources.list.filter((x) => R.runtime.mode(x.id) === 'live').length;
      const sig = R.signals.collect();
      const strip = h(
        'div',
        { class: 'rq-strip', role: 'group', 'aria-label': 'Situation status' },
        h('span', { class: 'rq-strip-item rq-mono' }, h('span', { class: 'rq-strip-k' }, 'UTC'), h('span', { class: 'rq-utc' }, R.shell.utcNow())),
        h('span', { class: 'rq-strip-item rq-mono' }, h('span', { class: 'rq-strip-k' }, 'FEEDS'), h('span', { class: active ? 'rq-ok' : 'rq-warn-t' }, active ? 'ACTIVE' : 'STANDBY')),
        h('span', { class: 'rq-strip-item rq-mono' }, h('span', { class: 'rq-strip-k' }, 'LIVE SOURCES'), String(live)),
        h('span', { class: 'rq-strip-item rq-mono' }, h('span', { class: 'rq-strip-k' }, 'SUBJECT'), s ? fmt.truncate(s.primary ? s.primary.title : s.resolved.countryName || s.resolved.placeLabel || s.query, 40) : 'NONE'),
        h('span', { class: 'rq-strip-item rq-mono' }, h('span', { class: 'rq-strip-k' }, 'SESSION SIGNALS'), String(sig.length)),
        h('span', { class: 'rq-strip-spacer' }),
        active
          ? ui.button('Refresh feeds', () => {
              feedDefs().forEach((d) => {
                const t = R.tasks.get(d.key);
                if (t && t.status !== 'loading') t.status = 'idle';
              });
              activateFeeds();
            }, { icon: 'refresh', cls: 'rq-btn-sm' })
          : ui.button('Activate public feeds', () => activateFeeds(), { icon: 'download', variant: 'primary', cls: 'rq-btn-sm' })
      );
      markerList = h('div', { class: 'rq-marker-list', 'aria-live': 'polite' });
      const regSelect = ui.select('Topic', REG_TOPICS, st.topic, (v) => {
        st.topic = v;
        if (feedsActive()) {
          const d = FEEDS.reg(v);
          R.tasks.ensure(d);
          R.tasks.start(d.key);
        }
        R.shell.refresh();
      }, { key: 'sr-topic', cls: 'rq-field-inline' });
      const standbyNote = active ? null : h('p', { class: 'rq-standby rq-mono' }, 'STANDBY · Activating sends fixed, non-personal queries (never your search terms) directly from your browser to USGS, CISA (GitHub), the Federal Register and the ECB.');
      const subjectPanel = s
        ? panel('Current subject', { live: true, meta: s.chosen.label }, h('div', { class: 'rq-subject-hud' }, h('div', { class: 'rq-subject-name' }, s.primary ? s.primary.title : s.resolved.countryName || s.resolved.placeLabel || s.query), h('div', { class: 'rq-row rq-row-tight' }, ui.badge('Interpretation: ' + s.chosen.confidence, 'org'), s.primary ? ui.confidence(s.primaryConfidence) : null)), sig.length ? h('ul', { class: 'rq-signal-list rq-compact-list' }, ...sig.slice(0, 6).map((x) => h('li', { class: 'rq-signal' }, ui.badge(x.tone === 'serious' ? 'Serious' : 'Review', x.tone), h('button', { type: 'button', class: 'rq-link-btn', onclick: () => R.shell.openDetail(x.record) }, fmt.truncate(x.text, 100))))) : h('p', { class: 'rq-muted' }, 'No source-reported signals yet. This is not evidence of low risk.'), h('div', { class: 'rq-row rq-row-tight' }, ui.button('Overview', () => R.shell.go('overview', { focus: true }), { cls: 'rq-btn-xs' }), ui.button('Relationships', () => R.shell.go('relationships', { focus: true }), { cls: 'rq-btn-xs' }), ui.button('Evidence pack', () => R.exporters.evidencePackJSON(), { cls: 'rq-btn-xs', icon: 'download' })))
        : panel('Current subject', { meta: 'none' }, h('p', { class: 'rq-muted' }, 'No active investigation. Search a company, insurer, port, country, CVE, tender or risk concept above — results are plotted here when they carry coordinates.'), h('div', { class: 'rq-row rq-row-tight' }, ...['Port of Rotterdam', 'Malaysia', 'Allianz SE', 'CVE-2024-3094'].map((q) => ui.button(q, () => R.shell.search(q), { cls: 'rq-btn-xs' }))));
      const statusPanel = panel('Source status', { meta: live + ' live' }, ui.bars([['Live (verified)', live, 'ok'], ['Link-out / verify', R.sources.list.length - live, 'neutral'], ['Unavailable this session', R.sources.list.filter((x) => R.runtime.get(x.id).mode === 'unavailable').length, 'warn']], { label: 'Source modes' }), ui.button('Open Coverage Console', () => R.shell.go('coverage', { focus: true }), { cls: 'rq-btn-xs', icon: 'gauge' }));
      const grid = h(
        'div',
        { class: 'rq-sr-grid' },
        globePanel(ctx),
        panel('Global seismic wire', { cls: 'rq-panel-tall', live: active, meta: 'USGS · M4.5+ · 7d' }, active ? feedPanel(FEEDS.quakes(), 'quake', true) : standbyNote || null, h('p', { class: 'rq-fineprint' }, 'Seismic events do not confirm facility damage, insured loss or supplier disruption.')),
        subjectPanel,
        panel('Exploited vulnerabilities', { live: active, meta: 'CISA KEV' }, active ? feedPanel(FEEDS.kev(), 'kev', true) : h('p', { class: 'rq-muted rq-mono' }, 'STANDBY'), h('p', { class: 'rq-fineprint' }, 'A KEV entry does not show which suppliers run the affected product.')),
        panel('US regulatory wire', { live: active, meta: 'Federal Register', actions: regSelect }, active ? feedPanel(FEEDS.reg(st.topic), 'reg', true) : h('p', { class: 'rq-muted rq-mono' }, 'STANDBY'), h('p', { class: 'rq-fineprint' }, 'Not legal advice. Verify applicability and dates with counsel.')),
        panel('FX reference', { live: active, meta: 'ECB · EUR/USD' }, active ? ui.taskPanel(FEEDS.fx(), { auto: true, compact: true, render: (recs) => h('div', { class: 'rq-fx' }, h('div', { class: 'rq-fx-val rq-mono' }, (recs[0].fields[0] || [])[1] || '—'), h('div', { class: 'rq-muted rq-mono' }, (recs[0].fields[1] || [])[1] || ''), h('div', { class: 'rq-muted' }, 'Reference rate, not a tradable price.'), h('button', { type: 'button', class: 'rq-link-btn', onclick: () => R.shell.openDetail(recs[0]) }, 'Details')) }) : h('p', { class: 'rq-muted rq-mono' }, 'STANDBY')),
        panel('Markers (text alternative)', { cls: 'rq-panel-wide', meta: 'from loaded records' }, markerList),
        statusPanel
      );
      const out = h('div', { class: 'rq-situation' }, strip, ticker(), grid, h('p', { class: 'rq-fineprint' }, 'Signals come from the public records loaded in this session. Open-source licences: ', h('a', { href: '/licenses/' }, 'Licences'), '.'));
      setTimeout(renderMarkerList, 0);
      return out;
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/cesiumView.js ---- */
/*
 * cesiumView.js — the 3D evidence globe inside the JAQA workspace.
 *
 * Built on CesiumJS (Apache-2.0; notice on /licenses/), served by the JAQA
 * server from /globe/cesium/ (the same self-hosted build JAQA Eye View uses).
 * It is loaded only when this view is opened.
 *
 * Privacy: imagery is the Natural Earth II set bundled with CesiumJS, so the
 * view makes no request to any third party (no Cesium ion, no tile servers).
 * CSP: uses CesiumWidget + primitives only (no Knockout-based Viewer widgets),
 * so it runs under script-src 'self' without 'unsafe-eval'.
 * JAQA™ is a trademark of JAQA. © JAQA™. All rights reserved.
 */
(function (R) {
  'use strict';
  const { h } = R.util;
  const BASE = '/globe/cesium/';
  let loading = null;

  /** Load the self-hosted CesiumJS build once. Rejects on static-only hosting. */
  function load() {
    if (window.Cesium) return Promise.resolve(window.Cesium);
    if (loading) return loading;
    loading = new Promise((resolve, reject) => {
      window.CESIUM_BASE_URL = BASE;
      // CesiumJS's single-file build installs its workers as one inline string
      // (globalThis.CESIUM_WORKERS) and runs them from blob: scripts, which the
      // strict CSP blocks. With CESIUM_WORKERS undefined, CesiumJS uses its
      // standard same-origin ES-module workers (/globe/cesium/Workers/*.js);
      // the setter discards the inline copy.
      if (!Object.getOwnPropertyDescriptor(window, 'CESIUM_WORKERS')) {
        Object.defineProperty(window, 'CESIUM_WORKERS', { configurable: true, get: () => undefined, set: () => {} });
      }
      const css = document.createElement('link');
      css.rel = 'stylesheet';
      css.href = BASE + 'Widgets/CesiumWidget/CesiumWidget.css';
      document.head.appendChild(css);
      const s = document.createElement('script');
      s.src = BASE + 'Cesium.js';
      s.async = true;
      const timer = setTimeout(() => reject(new Error('timeout')), 30000);
      s.onload = () => {
        clearTimeout(timer);
        window.Cesium ? resolve(window.Cesium) : reject(new Error('missing'));
      };
      s.onerror = () => {
        clearTimeout(timer);
        reject(new Error('unavailable'));
      };
      document.head.appendChild(s);
    }).catch((e) => {
      loading = null; // allow a retry
      throw e;
    });
    return loading;
  }

  const COLORS = { quake: '#f97316', place: '#2dd4bf', entity: '#22d3ee', signal: '#fbbf24' };
  const reduceMotion = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let current = null;

  /**
   * Mount a CesiumJS globe in host. points: [{kind, lat, lon, label, record}].
   * Returns a controller, or throws if CesiumJS is not available.
   */
  async function mount(host, points, opts) {
    const o = opts || {};
    const Cesium = await load();
    if (!host.isConnected) return null;
    if (current) current.destroy();
    const canvasBox = h('div', { class: 'rq-cesium-canvas', role: 'img', 'aria-label': '3D globe with evidence markers' });
    const credits = h('div', { class: 'rq-cesium-credits' });
    // No Cesium logo: this view uses no Cesium ion content (bundled imagery
    // only); the CesiumJS licence notice is on /licenses/.
    Cesium.CreditDisplay.cesiumCredit = undefined;
    host.replaceChildren(canvasBox, credits);
    const widget = new Cesium.CesiumWidget(canvasBox, {
      baseLayer: Cesium.ImageryLayer.fromProviderAsync(Cesium.TileMapServiceImageryProvider.fromUrl(Cesium.buildModuleUrl('Assets/Textures/NaturalEarthII'))),
      terrainProvider: new Cesium.EllipsoidTerrainProvider(),
      creditContainer: credits,
      scene3DOnly: true,
      requestRenderMode: true,
      maximumRenderTimeChange: Infinity
    });
    const scene = widget.scene;
    scene.globe.enableLighting = false;
    const dots = scene.primitives.add(new Cesium.PointPrimitiveCollection());

    function setPoints(list) {
      dots.removeAll();
      for (const p of list || []) {
        if (!Number.isFinite(p.lat) || !Number.isFinite(p.lon)) continue;
        dots.add({
          position: Cesium.Cartesian3.fromDegrees(p.lon, p.lat),
          pixelSize: p.kind === 'entity' ? 14 : p.kind === 'quake' ? 8 + Math.round((p.weight || 0) * 8) : 9,
          color: Cesium.Color.fromCssColorString(COLORS[p.kind] || '#e2e8f0'),
          outlineColor: Cesium.Color.fromCssColorString('#020617'),
          outlineWidth: 2,
          id: p
        });
      }
      if (o.onCount) o.onCount(dots.length);
      scene.requestRender();
    }
    function flyTo(lat, lon, height) {
      widget.camera.flyTo({ destination: Cesium.Cartesian3.fromDegrees(lon, lat, height || 2500000), duration: reduceMotion() ? 0 : 1.6 });
    }
    function zoom(factor) {
      const height = widget.camera.positionCartographic.height;
      factor > 1 ? widget.camera.zoomIn(height * (factor - 1)) : widget.camera.zoomOut(height * (1 / factor - 1));
      scene.requestRender();
    }

    const handler = new Cesium.ScreenSpaceEventHandler(scene.canvas);
    handler.setInputAction((e) => {
      const picked = scene.pick(e.position);
      const p = picked && picked.id;
      if (!p || !p.label) return;
      if (p.record && R.shell) R.shell.openDetail(p.record);
      else R.util.announce(p.label);
    }, Cesium.ScreenSpaceEventType.LEFT_CLICK);
    handler.setInputAction((e) => {
      const picked = scene.pick(e.endPosition);
      canvasBox.title = picked && picked.id && picked.id.label ? picked.id.label : '';
    }, Cesium.ScreenSpaceEventType.MOUSE_MOVE);

    setPoints(points);
    if (o.center && Number.isFinite(o.center.lat)) flyTo(o.center.lat, o.center.lon, o.center.height);
    else widget.camera.setView({ destination: Cesium.Cartesian3.fromDegrees(10, 20, 20000000) });

    const api = {
      setPoints,
      flyTo,
      zoom,
      reset: () => flyTo(20, 10, 20000000),
      destroy() {
        handler.destroy();
        if (!widget.isDestroyed()) widget.destroy();
        if (current === api) current = null;
      },
      isConnected: () => host.isConnected
    };
    current = api;
    return api;
  }

  // Keep the open view in step with new evidence (searches, feeds, monitor).
  R.events.on('task:update', () => {
    if (!current) return;
    if (!current.isConnected()) return current.destroy();
    if (R.situation) current.setPoints(R.situation.collectPoints());
  });
  R.events.on('session:cleared', () => current && current.isConnected() && current.setPoints(R.situation ? R.situation.collectPoints() : []));

  R.cesium3d = { load, mount, current: () => current, base: BASE };
})(window.JAQAWorkspace);

/* ---- modules/globe3d.js ---- */
/*
 * globe3d.js — 3D Globe: launcher for JAQA Eye View (apps/globe), served by
 * the JAQA server at /globe/. Open-source licences: /licenses/.
 *
 * JAQA only builds a link: JAQA Eye View reads its camera from the URL hash
 * (#lat=…&lon=…&alt=…&style=…; see apps/globe/src/sharelink.js). Only
 * coordinates and a style are placed in it — never a search term.
 * JAQA™ is a trademark of JAQA. © JAQA™. All rights reserved.
 */
(function (R) {
  'use strict';
  const { h } = R.util;
  const ui = R.ui;

  // JAQA optic modes → JAQA Eye View style names (sharelink.js URL values).
  const STYLE = { std: 'normal', nvg: 'nvg', flir: 'flir', crt: 'crt' };
  const num = (v, d) => (Number.isFinite(v) ? Number(v.toFixed(d)) : null);

  R.globe3d = {
    base: '/globe/',
    /** Link into the 3D globe at a location. alt in metres above the ground. */
    url(o) {
      const p = o || {};
      const lat = num(p.lat, 4);
      const lon = num(p.lon, 4);
      if (lat === null || lon === null || Math.abs(lat) > 90 || Math.abs(lon) > 180) return this.base;
      const alt = Math.max(300, Math.min(20000000, Math.round(p.alt || 250000)));
      const parts = ['lat=' + lat, 'lon=' + lon, 'alt=' + alt, 'pitch=' + (alt > 2000000 ? -90 : -45)];
      if (p.style && STYLE[p.style]) parts.push('style=' + STYLE[p.style]);
      return this.base + '#' + parts.join('&');
    },
    link(label, o, cls) {
      return h('a', { class: cls || 'rq-btn rq-btn-sm', href: this.url(o) }, R.util.icon('globe', 'rq-icon-sm'), h('span', null, label));
    }
  };

  // Facts from apps/globe/README.md, not marketing claims.
  const FEATURES = [
    ['Photorealistic 3D globe', 'CesiumJS with Esri satellite imagery and OpenStreetMap keyless; Google Photorealistic 3D Tiles with a Google Maps key or Cesium ion token.'],
    ['Live contacts', 'Aircraft, ships and satellites near a target, with click-to-track, trails and a 250 km contacts roster.'],
    ['Sensor looks', 'CRT, NVG, FLIR/thermal, Noir and Snow shader styles, a detection overlay and a tactical HUD.'],
    ['Environment', 'Earthquakes, wildfires (NASA FIRMS), weather radar, wind, clouds, lightning and NHC/CPHC cyclone tracks.'],
    ['Space', 'Satellite orbits (SGP4), pass predictions and a rolling 30 days of launches.'],
    ['Cameras & infrastructure', 'Public CCTV cameras, mapped ALPR camera locations, datacenters, dams, submarine cables and military installations.'],
    ['Scene director', 'Cinematic camera tours, shareable scenes and share links.'],
    ['Voice agent', 'Hands-free control through the OpenAI Realtime API (needs a server-side OpenAI key).']
  ];

  /** 3D evidence globe (src/modules/cesiumView.js), mounted on render. */
  function cesiumSection(here) {
    const host = h('div', { class: 'rq-cesium' }, h('p', { class: 'rq-muted rq-cesium-status' }, 'Loading the 3D globe…'));
    const count = h('span', { class: 'rq-mono rq-muted' }, '');
    let ctl = null;
    const btn = (label, icon, fn) => ui.button(label, () => ctl && fn(ctl), { icon, cls: 'rq-btn-sm' });
    const controls = h(
      'div',
      { class: 'rq-row rq-row-tight' },
      btn('Zoom in', 'search', (c) => c.zoom(2)),
      btn('Zoom out', 'search', (c) => c.zoom(0.5)),
      btn('Reset view', 'globe', (c) => c.reset()),
      here ? btn('Fly to ' + here.label, 'pin', (c) => c.flyTo(here.lat, here.lon, 1500000)) : null,
      count
    );
    setTimeout(() => {
      if (!host.isConnected || !R.cesium3d) return;
      const pts = R.situation ? R.situation.collectPoints() : [];
      R.cesium3d
        .mount(host, pts, { center: here ? { lat: here.lat, lon: here.lon, height: 3000000 } : null, onCount: (n) => (count.textContent = n + ' marker(s)') })
        .then((c) => (ctl = c))
        .catch(() => {
          host.replaceChildren(ui.warning('The 3D evidence globe needs the JAQA server. It is not available on this static-only deployment; the Situation Room globe still works.', 'info'));
          controls.remove();
        });
    }, 0);
    return ui.section(
      '3D evidence globe',
      { icon: 'globe', desc: 'Your session’s evidence on a real 3D Earth: seismic events, places, the current subject and Global Monitor events. Imagery is the Natural Earth II set served by the JAQA server, so this view makes no third-party requests. Drag to rotate, scroll to zoom, click a marker for details.' },
      host,
      controls,
      h('p', { class: 'rq-fineprint' }, 'Marker positions come from the loaded public records; they are not facility, loss or exposure data.')
    );
  }

  R.modules.register({
    id: 'globe3d',
    group: 'risk',
    order: 1,
    icon: 'globe',
    title: '3D Globe (JAQA Eye View)',
    short: '3D Globe',
    description: 'Open JAQA Eye View, the photorealistic 3D globe with live aircraft, ships, satellites, hazards and cameras.',
    warnings: [
      'Opens JAQA Eye View at /globe/. It is a separate app with its own layers and requests: its data comes from public providers through the JAQA server, and its voice agent sends audio to OpenAI only if the server has an OpenAI key.',
      'Live positions, camera feeds and public registries can be delayed, incomplete or wrong. Nothing on the globe is a determination of risk, ownership, intent or exposure.'
    ],
    liveRefresh: false,
    render(ctx) {
      const s = ctx.session;
      const r = s && s.resolved;
      const here = r && Number.isFinite(r.lat) && r.lat !== null ? { lat: r.lat, lon: r.lon, label: (s.primary ? s.primary.title : r.placeLabel || r.countryName || 'current subject') } : null;
      const styles = [['std', 'Normal'], ['nvg', 'NVG'], ['flir', 'FLIR'], ['crt', 'CRT']];
      return h(
        'div',
        { class: 'rq-stack' },
        cesiumSection(here),
        h(
          'div',
          { class: 'rq-hero' },
          h('h3', { class: 'rq-hero-title' }, 'Launch JAQA Eye View'),
          h('p', null, 'JAQA Eye View opens in this tab. Use your browser’s Back button to return to the JAQA workspace.'),
          h('div', { class: 'rq-row' }, R.globe3d.link('Open 3D globe', { lat: 20, lon: 10, alt: 18000000 }, 'rq-btn rq-btn-primary'), here ? R.globe3d.link('Fly to ' + here.label, { lat: here.lat, lon: here.lon, alt: 60000 }) : null),
          h('p', { class: 'rq-fineprint' }, 'Only coordinates and a visual style go into the link, never your search terms.')
        ),
        ui.section('Open in a sensor style', { icon: 'layers', desc: here ? 'At ' + here.label + '.' : 'Whole-Earth view. Run a search first to open at a place.' }, h('div', { class: 'rq-row' }, ...styles.map(([k, l]) => R.globe3d.link(l, here ? { lat: here.lat, lon: here.lon, alt: 60000, style: k } : { lat: 20, lon: 10, alt: 18000000, style: k })))),
        ui.section('What JAQA Eye View includes', { icon: 'list' }, h('ul', { class: 'rq-list' }, ...FEATURES.map(([t, d]) => h('li', null, h('strong', null, t + ': '), d)))),
        h('p', { class: 'rq-fineprint' }, 'Map data and imagery credits are under “Data attribution” on the globe. Open-source licences: ', h('a', { href: '/licenses/' }, 'Licences'), '.')
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/globalMonitor.js ---- */
/*
 * globalMonitor.js — Global Monitor: a live dashboard of official public
 * feeds (headlines + links), an event map, "countries in the headlines" and an
 * FX reference board. Feature set inspired by WorldMonitor's news/intel
 * dashboard; clean-room JAQA code (no WorldMonitor code, AGPL respected).
 *
 * Feeds are fetched by the JAQA server from an allowlist of official
 * publishers and verified by scripts/verify-monitor.mjs; the browser only calls
 * the same-origin /api/jaqa/monitor endpoint with a fixed feed id. Loading is
 * user-initiated; feed tasks survive new searches and Clear Session wipes them.
 * JAQA™ is a trademark of JAQA. © JAQA™. All rights reserved.
 */
(function (R) {
  'use strict';
  const { h, extLink, fmt } = R.util;
  const ui = R.ui;
  const C = R.clients;

  const cfg = () => R.config.monitor || { feeds: [], categories: [] };
  const st = { category: 'all', active: false };
  R.events.on('session:cleared', () => {
    st.active = false;
    st.category = 'all';
  });

  const FX = ['USD', 'GBP', 'JPY', 'CHF', 'CNY', 'INR'];
  const feedDef = (f) => ({ key: 'feed:monitor:' + f.id, sourceId: 'jaqaMonitor', label: f.name + ' · ' + f.publisher, run: () => C.monitor.feed(f, { persistent: true }) });
  const fxDef = (ccy) => ({ key: 'feed:ecb:' + ccy, sourceId: 'ecb', label: 'EUR/' + ccy + ' reference · ECB', run: () => C.ecb.exr(ccy, 30, { persistent: true }) });
  const visibleFeeds = () => cfg().feeds.filter((f) => st.category === 'all' || f.category === st.category);

  function activate() {
    st.active = true;
    const keys = visibleFeeds().map((f) => R.tasks.ensure(feedDef(f)).key).concat(FX.map((c) => R.tasks.ensure(fxDef(c)).key));
    R.util.announce('Loading official feeds through the JAQA server. Fixed feeds only; no search terms are sent.');
    R.tasks.runAll(keys);
    R.shell.go('monitor');
  }

  /** All loaded monitor headline records (any category). */
  function loaded() {
    const out = [];
    for (const f of cfg().feeds) {
      const t = R.tasks.get('feed:monitor:' + f.id);
      if (t && t.records) out.push(...t.records);
    }
    return out;
  }

  // Countries named in loaded headlines. A mention count, not a risk score.
  let countryRx = null;
  function hotspots(records) {
    if (!countryRx) countryRx = R.geo.countries.filter((c) => c.name.length > 3).map((c) => [c, new RegExp('\\b' + c.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'i')]);
    const counts = new Map();
    for (const r of records) for (const [c, rx] of countryRx) if (rx.test(r.title)) counts.set(c, (counts.get(c) || 0) + 1);
    return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 15);
  }

  function headlineList(recs) {
    return h(
      'ul',
      { class: 'rq-wire' },
      ...recs.slice(0, 12).map((r) =>
        h(
          'li',
          { class: 'rq-wire-row rq-mon-row' },
          h('span', { class: 'rq-wire-time rq-mono', title: 'Published (UTC)' }, r.data.published ? r.data.published.slice(5, 16).replace('T', ' ') : '—'),
          h('span', { class: 'rq-mon-title' }, extLink(r.links[0].href, r.title)),
          Number.isFinite(r.data.lat) ? h('a', { class: 'rq-wire-locate', href: R.globe3d.url({ lat: r.data.lat, lon: r.data.lon, alt: 400000 }), title: 'Open this location in the 3D globe', 'aria-label': 'Open in 3D globe: ' + r.title }, R.util.icon('globe', 'rq-icon-xs')) : h('span')
        )
      )
    );
  }

  let mapGlobe = null;
  function eventMap(records) {
    const pts = records.filter((r) => Number.isFinite(r.data.lat)).map((r) => ({ kind: 'signal', lat: r.data.lat, lon: r.data.lon, label: r.title, record: r }));
    const host = h('div', { class: 'rq-local-globe' });
    setTimeout(() => {
      if (!host.isConnected) return;
      if (mapGlobe) mapGlobe.destroy();
      mapGlobe = R.situation.mountGlobe(host, pts, pts[0] ? { lat: pts[0].lat, lon: pts[0].lon } : { lat: 20, lon: 10 });
    }, 0);
    return h('div', null, host, h('p', { class: 'rq-fineprint' }, pts.length + ' event(s) with publisher-supplied coordinates. Select a marker for details, or ', R.globe3d.link('open the 3D globe', { lat: 20, lon: 10, alt: 18000000 }, 'rq-link-inline'), '.'));
  }

  R.modules.register({
    id: 'monitor',
    group: 'risk',
    order: 2,
    icon: 'chart',
    title: 'Global Monitor',
    short: 'Global Monitor',
    description: 'Live headlines from official publishers (UN, WHO, GDACS, NASA, NOAA, CISA, central banks, travel advisories), an event map, the countries named in the news and an FX board.',
    warnings: [
      'Headlines from official publishers, shown as published: not verified, ranked or summarized by JAQA. Read the source before relying on anything. No hit ≠ clear.',
      '“Countries in the headlines” counts name mentions only. It is not a risk, stability or exposure score.'
    ],
    liveRefresh: true,
    render() {
      const c = cfg();
      if (!c.feeds.length) {
        return h(
          'div',
          null,
          ui.warning('No monitor feed has been verified for this deployment yet, so nothing is loaded live. The official publishers are linked below.', 'info'),
          ui.section('Official publishers', { icon: 'link', desc: 'A feed is served only after scripts/verify-monitor.mjs has fetched and parsed it successfully.' }, h('ul', { class: 'rq-list' }, ...(c.candidates || []).map((f) => h('li', null, extLink(f.home, f.publisher + ' — ' + f.name)))))
        );
      }
      const live = R.runtime.isLive('jaqaMonitor');
      const cats = [['all', 'All categories'], ...c.categories.filter(([id]) => c.feeds.some((f) => f.category === id))];
      const head = h(
        'div',
        { class: 'rq-strip', role: 'group', 'aria-label': 'Monitor status' },
        h('span', { class: 'rq-strip-item rq-mono' }, h('span', { class: 'rq-strip-k' }, 'FEEDS'), String(c.feeds.length)),
        h('span', { class: 'rq-strip-item rq-mono' }, h('span', { class: 'rq-strip-k' }, 'VERIFIED'), (c.verifiedAt || '').slice(0, 10) || '—'),
        h('span', { class: 'rq-strip-item rq-mono' }, h('span', { class: 'rq-strip-k' }, 'STATUS'), h('span', { class: st.active ? 'rq-ok' : 'rq-warn-t' }, st.active ? 'ACTIVE' : 'STANDBY')),
        h('span', { class: 'rq-strip-spacer' }),
        ui.select('Category', cats, st.category, (v) => {
          st.category = v;
          if (st.active) activate();
          else R.shell.go('monitor');
        }, { key: 'monitor-category', cls: 'rq-field-inline' }),
        ui.button(st.active ? 'Refresh' : 'Load monitor feeds', activate, { variant: 'primary', icon: st.active ? 'refresh' : 'download', cls: 'rq-btn-sm' })
      );
      if (!live) {
        return h('div', null, head, ui.warning('The JAQA server is not available here (static-only hosting), so feeds cannot load. Open the publishers directly:', 'amber'), h('ul', { class: 'rq-list' }, ...c.feeds.map((f) => h('li', null, extLink(f.home, f.publisher + ' — ' + f.name)))));
      }
      if (!st.active) {
        return h('div', null, head, h('div', { class: 'rq-hero' }, h('h3', { class: 'rq-hero-title' }, 'Monitor on standby'), h('p', null, 'Loading asks the JAQA server for the latest headlines from ' + visibleFeeds().length + ' official feed(s). Your searches are never sent. The server caches each feed for 10 minutes.'), ui.button('Load monitor feeds', activate, { variant: 'primary', icon: 'download' })));
      }
      const recs = loaded();
      const hs = hotspots(recs);
      const feedsPanels = visibleFeeds().map((f) =>
        h('section', { class: 'rq-panel', 'aria-label': f.name }, h('div', { class: 'rq-panel-head' }, h('span', { class: 'rq-panel-title' }, f.name), h('span', { class: 'rq-panel-meta' }, f.publisher)), h('div', { class: 'rq-panel-body' }, ui.taskPanel(feedDef(f), { auto: true, compact: true, noHitWarning: false, render: headlineList, linkout: { href: f.home, label: 'Open ' + f.publisher } })))
      );
      return h(
        'div',
        { class: 'rq-stack' },
        head,
        h(
          'div',
          { class: 'rq-mon-grid' },
          h('section', { class: 'rq-panel rq-mon-map', 'aria-label': 'Event map' }, h('div', { class: 'rq-panel-head' }, h('span', { class: 'rq-panel-title' }, 'Event map'), h('span', { class: 'rq-panel-meta' }, 'publisher coordinates')), h('div', { class: 'rq-panel-body' }, eventMap(recs))),
          h(
            'section',
            { class: 'rq-panel', 'aria-label': 'Countries in the headlines' },
            h('div', { class: 'rq-panel-head' }, h('span', { class: 'rq-panel-title' }, 'Countries in the headlines'), h('span', { class: 'rq-panel-meta' }, 'mentions, not a score')),
            h(
              'div',
              { class: 'rq-panel-body' },
              hs.length
                ? h('ol', { class: 'rq-mon-hot' }, ...hs.map(([co, n]) => h('li', null, h('button', { type: 'button', class: 'rq-link-btn', onclick: () => R.shell.search(co.name), title: 'Investigate ' + co.name + ' in JAQA' }, co.name), h('span', { class: 'rq-mono rq-muted' }, ' ' + n))))
                : h('p', { class: 'rq-muted' }, 'No country names found in the loaded headlines yet.'),
              h('p', { class: 'rq-fineprint' }, 'Exact country-name matches in headline text only; abbreviations and demonyms are missed.')
            )
          ),
          h(
            'section',
            { class: 'rq-panel', 'aria-label': 'FX reference board' },
            h('div', { class: 'rq-panel-head' }, h('span', { class: 'rq-panel-title' }, 'FX reference board'), h('span', { class: 'rq-panel-meta' }, 'ECB · EUR base')),
            h(
              'div',
              { class: 'rq-panel-body rq-mon-fx' },
              ...FX.map((ccy) => ui.taskPanel(fxDef(ccy), { auto: true, compact: true, render: (rs) => h('div', { class: 'rq-fx' }, h('div', { class: 'rq-mono rq-muted' }, 'EUR/' + ccy), h('div', { class: 'rq-fx-val rq-mono' }, (rs[0].fields[0] || [])[1] || '—'), h('button', { type: 'button', class: 'rq-link-btn', onclick: () => R.shell.openDetail(rs[0]) }, 'Details')) })),
              h('p', { class: 'rq-fineprint' }, 'Reference rates, not tradable prices. Equity, commodity and crypto prices are not included: no keyless official source has been verified.')
            )
          ),
          ...feedsPanels
        )
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/climateCatastrophe.js ---- */
/*
 * climateCatastrophe.js — MODULE 14: Physical, Climate & Catastrophe
 * Disruption.
 *
 * Event context is anchored to a reference point (a resolved place, port or
 * a country capital). No map tiles are loaded. Proximity is computed by JAQA
 * (haversine) and labeled as derived.
 */
(function (R) {
  'use strict';
  const { h, extLink } = R.util;
  const ui = R.ui;
  const T = R.T;

  const local = { place: '' };
  R.events.on('session:cleared', () => (local.place = ''));

  // Local event globe (shares the Situation Room globe engine).
  let localGlobe = null;
  function localPoints(r) {
    const pts = [{ kind: 'entity', lat: r.lat, lon: r.lon, label: 'Reference point · ' + (r.placeLabel || 'resolved location') }];
    const q = R.tasks.get(T.quakes(r.lat, r.lon, 500, 30).key);
    (q && q.records ? q.records : []).forEach((x) => isFinite(x.data.lat) && pts.push({ kind: 'quake', lat: x.data.lat, lon: x.data.lon, weight: Math.max(0, Math.min(1, ((x.data.mag || 4.5) - 4.5) / 3)), label: x.title, record: x }));
    const f = R.tasks.get(T.forecast(r.lat, r.lon, r.placeLabel).key);
    if (f && f.records && f.records[0] && f.records[0].data.flags.length) pts.push({ kind: 'signal', lat: r.lat + 0.6, lon: r.lon + 0.6, label: 'Forecast threshold signal · ' + f.records[0].data.flags[0], record: f.records[0] });
    return pts;
  }
  R.events.on('task:update', (t) => {
    const s = R.state.session;
    if (!localGlobe || !s || !/^(usgs:|om:fc:)/.test(t.key) || s.resolved.lat === undefined || s.resolved.lat === null) return;
    localGlobe.setPoints(localPoints(s.resolved));
  });

  function placePicker(ctx) {
    const s = ctx.session;
    let val = local.place;
    const form = h(
      'form',
      { class: 'rq-inline-form', onsubmit: (e) => {
        e.preventDefault();
        const chk = R.privacy.checkInput(val);
        if (!chk.ok) return R.util.announce(chk.reason);
        local.place = chk.value;
        R.shell.refresh();
      } },
      ui.input('Reference place (city, port or region — never a private address)', val, (v) => (val = v), { placeholder: 'e.g. Kaohsiung, Rotterdam, Houston', key: 'climate-place' }),
      h('button', { type: 'submit', class: 'rq-btn rq-btn-primary' }, 'Resolve place')
    );
    const panel = local.place
      ? ui.taskPanel(T.geocode(local.place), { auto: true, limit: 5, noHitWarning: false, onSelect: (r) => {
          Object.assign(s.resolved, { lat: r.data.lat, lon: r.data.lon, placeLabel: r.title, iso2: s.resolved.iso2 || r.data.country });
          R.shell.refresh();
        }, selectLabel: 'Use as reference point' })
      : null;
    return h('div', null, form, panel);
  }

  R.modules.register({
    id: 'climate',
    group: 'risk',
    order: 11,
    icon: 'cloud',
    title: 'Physical, Climate & Catastrophe Disruption',
    short: 'Climate & Catastrophe',
    description: 'Earthquakes, weather forecasts and official alerts near a reference point, plus climate-vulnerability and catastrophe-loss link-outs.',
    warnings: ['Public event data does not confirm insured loss, supplier disruption, contract force majeure, or claims liability.', 'Facility proximity requires verified addresses and may be incomplete. No map tiles are loaded.'],
    liveRefresh: false,
    render(ctx) {
      if (!ctx.session) return h('div', null, ui.needSession('event signals'), ui.dir('climate', null, { title: 'Official climate & catastrophe sources' }));
      const r = ctx.resolved;
      const hasPoint = r.lat !== undefined && r.lat !== null && r.lon !== undefined && r.lon !== null;
      const isUS = r.iso2 === 'US' || r.iso2 === 'PR';
      const iso3 = R.countryFromCtx(ctx);
      return h(
        'div',
        null,
        ui.section('Reference point', { icon: 'globe' }, hasPoint ? h('p', null, ui.badge('Reference point', 'neutral'), ' ', r.placeLabel || `${r.lat}, ${r.lon}`, h('span', { class: 'rq-muted' }, ` (${Number(r.lat).toFixed(3)}, ${Number(r.lon).toFixed(3)})`)) : ui.warning('No reference point yet. Search a port, place or country, or resolve a place below.', 'info'), !hasPoint && iso3 ? ui.button('Use jurisdiction capital (' + iso3 + ') as approximate reference point', () => {
          const d = T.wbCountry(iso3);
          R.tasks.ensure(d);
          R.tasks.start(d.key);
        }, { icon: 'globe', cls: 'rq-btn-sm' }) : null, placePicker(ctx)),
        hasPoint
          ? h(
              'div',
              null,
              ui.section('Local event globe', { icon: 'globe', desc: 'Reference point, nearby M4.5+ events and forecast signals. Drag to rotate; select a marker for details. Positions are not facility or loss data.' }, (() => {
                const host = h('div', { class: 'rq-local-globe' });
                setTimeout(() => {
                  if (!host.isConnected) return;
                  if (localGlobe) localGlobe.destroy();
                  localGlobe = R.situation.mountGlobe(host, localPoints(r), { lat: r.lat, lon: r.lon });
                }, 0);
                return host;
              })()),
              ui.section('Seismic events (USGS, M4.5+, 500 km, 30 days)', { icon: 'warn' }, ui.taskPanel(T.quakes(r.lat, r.lon, 500, 30), { auto: true, limit: 10, emptyText: 'No M4.5+ earthquakes within 500 km in the last 30 days.', noHitWarning: false })),
              ui.section('Weather forecast & threshold signals (Open-Meteo)', { icon: 'cloud' }, ui.taskPanel(T.forecast(r.lat, r.lon, r.placeLabel), { auto: true })),
              isUS ? ui.section('Official NWS alerts', { icon: 'warn' }, ui.taskPanel(T.nws(r.lat, r.lon), { auto: true, emptyText: 'No active NWS alerts for this point.', noHitWarning: false })) : ui.warning('Official NWS alerts cover the US only. Use national meteorological services (via WMO) elsewhere.', 'info'),
              ui.section('Mapped port & harbour features nearby (OpenStreetMap)', { icon: 'ship', desc: 'User-triggered, small query. Community-mapped; not a facility register.' }, ui.taskPanel(T.overpass(r.lat, r.lon), { limit: 10, noHitWarning: false, linkout: { href: `https://www.openstreetmap.org/#map=12/${r.lat}/${r.lon}`, label: 'Open OpenStreetMap at this point' } }))
            )
          : null,
        ui.section('Humanitarian & disaster reports (link-out)', { icon: 'link', desc: 'ReliefWeb API requires an approved appname; link-out until verified.' }, iso3 ? extLink('https://reliefweb.int/country/' + iso3.toLowerCase(), 'ReliefWeb country page') : null),
        ui.section('Climate vulnerability & catastrophe resources (link-out)', { icon: 'link' }, ui.dir('climate', null, { compact: true })),
        ui.exportBar('JAQA-Climate-Catastrophe-signals.json', 'JAQA-Climate-Catastrophe-signals.csv', 'globalRisk')
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/lenses.js ---- */
/*
 * lenses.js — MODULE 15: ESG, Conduct, Human Rights & Nature; MODULE 16:
 * Trade, Customs & Category Exposure; MODULE 17: Supply Chain & Third-Party
 * Risk; MODULE 18: Regulatory Change Radar; MODULE 23: Standards,
 * Certifications & Frameworks Link-Outs.
 */
(function (R) {
  'use strict';
  const { h, extLink } = R.util;
  const ui = R.ui;
  const T = R.T;

  const subject = (ctx) => (ctx.primary ? (ctx.primary.data && ctx.primary.data.name) || ctx.primary.title : ctx.q);

  /* ------------------------------ ESG & conduct ------------------------------ */
  R.modules.register({
    id: 'esg',
    group: 'risk',
    order: 12,
    icon: 'leaf',
    title: 'ESG, Conduct, Human Rights & Nature',
    short: 'ESG & Human Rights',
    description: 'Environmental compliance records, governance indicators and official due-diligence resources for human rights, modern slavery, conflict minerals and nature.',
    warnings: ['ESG signals are not certifications. Public records do not prove or disprove forced labour, environmental misconduct, governance failures, or human-rights abuses.', 'JAQA does not rank suppliers, insurers, countries, or projects as ethical/unethical, and never scrapes paid ESG ratings.'],
    render(ctx) {
      if (!ctx.session) return h('div', null, ui.needSession('ESG evidence'), ui.dir('esg', null, { title: 'Official ESG & human-rights resources' }));
      const iso3 = R.countryFromCtx(ctx);
      const org = R.pipeline.ORG_TYPES.includes(ctx.type) || !!ctx.primary;
      return h(
        'div',
        null,
        org ? ui.section('US environmental compliance (EPA ECHO, facility-name match)', { icon: 'leaf', desc: 'User-triggered. Facility names are not legal entities; verify addresses and registry IDs.' }, ui.taskPanel(T.epa(subject(ctx)), { limit: 10 })) : null,
        iso3 ? ui.section('Governance context — ' + (R.geo.countries.find((c) => c.iso3 === iso3) || {}).name, { icon: 'gavel', desc: 'Worldwide Governance Indicators (estimates with margins of error; not a rating).' }, h('div', { class: 'rq-indicator-grid' }, ...['wgiCC', 'wgiRL', 'wgiVA'].map((k) => ui.taskPanel(T.wbInd(iso3, k), { compact: true })))) : null,
        ui.section('Modern slavery, forced labour & human rights (link-out)', { icon: 'link' }, ui.linkouts(R.directories.esg.filter((e) => /slavery|forced|child|Guiding|OECD Due|withhold/i.test(e.name)), null, { compact: true }), ui.linkouts(R.directories.sanctions.filter((e) => /UFLPA/.test(e.name)), null, { compact: true })),
        ui.section('Conflict minerals, nature & biodiversity (link-out)', { icon: 'leaf' }, ui.linkouts(R.directories.esg.filter((e) => /minerals|Minerals|TNFD/.test(e.name)), null, { compact: true })),
        ui.section('Integrity & governance indexes (link-out)', { icon: 'chart' }, ui.linkouts(R.directories.esg.filter((e) => /Governance|Transparency/.test(e.name)), null, { compact: true })),
        ui.section('Regulatory & litigation cross-links', { icon: 'gavel' }, ui.button('Open Regulatory Change Radar', () => R.shell.go('regulatory', { focus: true }), { cls: 'rq-btn-sm' }), ui.button('Open Credit, Insolvency & Litigation', () => R.shell.go('credit', { focus: true }), { cls: 'rq-btn-sm' })),
        ui.exportBar('JAQA-ESG-results.json', 'JAQA-ESG-results.csv', 'globalRisk')
      );
    }
  });

  /* --------------------------- Trade & category --------------------------- */
  R.modules.register({
    id: 'trade',
    group: 'risk',
    order: 13,
    icon: 'ship',
    title: 'Trade, Customs & Category Exposure',
    short: 'Trade & Category',
    description: 'HS code and category context, tariff and trade-remedy notices, country trade indicators, and customs/export-control link-outs.',
    warnings: ['Trade data is aggregated and may lag. Public trade data does not reveal confidential customer-supplier relationships. No shipment-level visibility.', 'HS classification shown here is not customs legal advice. Verify with the official tariff and customs rulings.'],
    render(ctx) {
      if (!ctx.session) return h('div', null, ui.needSession('trade and category context'), ui.dir('trade', null, { title: 'Official trade & customs sources' }));
      const c = ctx.chosen;
      const hs = c.type === 'hs' ? c.hs : null;
      const hints = c.type === 'category' ? c.hsHints || [] : [];
      const iso3 = R.countryFromCtx(ctx);
      const hs4 = hs ? hs.replace(/\D/g, '').slice(0, 4) : null;
      return h(
        'div',
        null,
        hs
          ? ui.section('HS code ' + hs, { icon: 'doc', desc: 'Harmonized System code as entered. Chapter/heading descriptions are authoritative only in the official tariff.' }, ui.kv([['HS chapter', hs.replace(/\D/g, '').slice(0, 2)], ['HS heading', hs4], ['HS subheading (6-digit)', hs.replace(/\D/g, '').slice(0, 6) || null], ['National tariff lines', 'Digits beyond 6 are country-specific (e.g. US HTS, EU CN/TARIC)']]), h('div', { class: 'rq-row' }, extLink('https://hts.usitc.gov/search?query=' + encodeURIComponent(hs4), 'USITC HTS: heading ' + hs4), extLink('https://www.trade-tariff.service.gov.uk/search?q=' + encodeURIComponent(hs4), 'UK Trade Tariff: ' + hs4), extLink('https://ec.europa.eu/taxation_customs/dds2/taric/taric_consultation.jsp', 'EU TARIC consultation')))
          : null,
        hints.length ? ui.section('Category → HS heading hints', { icon: 'layers', desc: 'Indicative WCO HS headings commonly associated with this category. Verify classification with customs specialists.' }, h('div', { class: 'rq-row' }, ...hints.map((x) => ui.button('HS ' + x, () => R.shell.search('HS ' + x), { cls: 'rq-btn-sm' })))) : null,
        ui.section('Tariff, trade-remedy & customs notices (Federal Register, live)', { icon: 'search' }, ui.taskPanel(T.frSearch(hs ? 'HTS ' + hs4 : (c.type === 'category' ? ctx.q + ' tariff' : 'tariff ' + ctx.q), { perPage: 8, order: 'newest' }), { auto: c.type === 'hs' || c.type === 'category', limit: 8 })),
        iso3 ? ui.section('Country trade indicators', { icon: 'chart' }, h('div', { class: 'rq-indicator-grid' }, ...['trade', 'hightech', 'lpi'].map((k) => ui.taskPanel(T.wbInd(iso3, k), { compact: true })))) : null,
        c.type === 'category' ? ui.section('Product-safety signals for this category (CPSC, live)', { icon: 'warn' }, ui.taskPanel(T.cpscSearch(ctx.q), { auto: true, limit: 6 })) : null,
        ui.section('Trade flows & tariffs (link-out)', { icon: 'link', desc: 'UN Comtrade requires an API key and is link-out only.' }, ui.dir('trade', null, { compact: true })),
        ui.section('Export controls & payment restrictions (link-out)', { icon: 'shield' }, ui.linkouts(R.directories.sanctions.filter((e) => e.kind === 'export-control' || /OFAC/.test(e.name)), null, { compact: true })),
        ui.exportBar('JAQA-Trade-Category-results.json', 'JAQA-Trade-Category-results.csv', 'globalRisk')
      );
    }
  });

  /* -------------------------- Supply chain & TPRM -------------------------- */
  R.modules.register({
    id: 'supplyChain',
    group: 'risk',
    order: 14,
    icon: 'layers',
    title: 'Supply Chain & Third-Party Risk',
    short: 'Supply Chain & Third Party',
    description: 'One place to assemble public evidence for suppliers, vendors, logistics providers, manufacturers, distributors and service providers.',
    warnings: ['Public-source triage does not replace supplier questionnaires, audits, site visits, contracts, insurance certificates, or internal vendor master data.', 'No public record found does not mean no risk.'],
    render(ctx) {
      if (!ctx.session) return ui.needSession('third-party evidence');
      const name = subject(ctx);
      const iso3 = R.countryFromCtx(ctx);
      const rows = [
        ['Organization resolution', ctx.primary ? `${ctx.primary.title} (${ctx.session.primaryConfidence})` : 'Not resolved', 'org360'],
        ['Parent/subsidiary', ctx.primary && ctx.primary.ids.lei ? 'GLEIF relationships available in Organization 360' : 'Unknown — no LEI selected', 'org360'],
        ['Country context', iso3 ? iso3 : 'No jurisdiction resolved', 'marketMacro'],
        ['Port / route / facility events', ctx.resolved.lat ? 'Reference point set' : 'No reference point', 'climate'],
        ['Trade & category exposure', ctx.type === 'hs' || ctx.type === 'category' ? 'Category query' : 'Open lens', 'trade'],
        ['Sanctions / debarment', 'Link-out only (no hit ≠ clear)', 'sanctions'],
        ['Litigation / liens / insolvency', 'User-triggered', 'credit'],
        ['Financial fragility', ctx.resolved.cik ? 'SEC filer' : 'Limited public financials', 'fragility'],
        ['Cyber signals', 'KEV/NVD (product-level only)', 'cyber'],
        ['ESG / conduct', 'Link-outs + EPA ECHO', 'esg'],
        ['Procurement award history', 'USAspending (US federal)', 'awards']
      ];
      return h(
        'div',
        null,
        ui.section('Evidence checklist', { icon: 'list', desc: 'Where each type of evidence lives in JAQA. Status reflects this session only.' }, h('div', { class: 'rq-table-wrap', tabindex: '0', role: 'region', 'aria-label': 'Evidence checklist' }, h('table', { class: 'rq-table' }, h('thead', null, h('tr', null, h('th', { scope: 'col' }, 'Evidence area'), h('th', { scope: 'col' }, 'Session status'), h('th', { scope: 'col' }, 'Open'))), h('tbody', null, ...rows.map(([a, st, m]) => h('tr', null, h('th', { scope: 'row' }, a), h('td', null, st), h('td', null, ui.button('Open', () => R.shell.go(m, { focus: true }), { cls: 'rq-btn-xs' })))))))),
        ui.section('Quick public checks (user-triggered)', { icon: 'download' }, h('div', { class: 'rq-two-col' }, ui.taskPanel(T.cpscSearch(name), { limit: 5 }), ui.taskPanel(T.kevMentions(name.split(/\s+/)[0]), { limit: 5 }), ui.taskPanel(T.usaAwards({ recipient: name, kind: 'contracts' }), { limit: 5 }), iso3 ? ui.taskPanel(T.wbInd(iso3, 'lpi'), { compact: true }) : null)),
        ui.warning('Parent/subsidiary ambiguity: signals may belong to a related entity with a similar name. Confirm legal entity identifiers before acting.', 'amber'),
        ui.exportBar('JAQA-Counterparty-Evidence-Pack.json', 'JAQA-Counterparty-Evidence-Pack.csv', 'globalRisk')
      );
    }
  });

  /* ------------------------- Regulatory Change Radar ------------------------- */
  const reg = { term: '', type: '', from: '', to: '', run: 0 };
  R.events.on('session:cleared', () => Object.assign(reg, { term: '', type: '', from: '', to: '', run: 0 }));
  R.events.on('session:started', () => Object.assign(reg, { term: '', run: 0 }));
  R.modules.register({
    id: 'regulatory',
    group: 'risk',
    order: 15,
    icon: 'gavel',
    title: 'Regulatory Change Radar',
    short: 'Regulatory Change Radar',
    description: 'US regulatory documents (live) with agency, action type, publication, comment and effective dates, plus EU/UK and sector-regulator link-outs.',
    warnings: ['Regulatory documents are not legal advice. Jurisdiction and effective dates must be verified with counsel/compliance.'],
    render(ctx) {
      if (!ctx.session) return h('div', null, ui.needSession('regulatory documents'), ui.dir('regulatory', null, { title: 'Official regulatory sources' }));
      const term = reg.term || (ctx.chosen.frDoc ? '' : ctx.chosen.concept ? 'rule' : ctx.q);
      let draft = { term, type: reg.type, from: reg.from, to: reg.to };
      const form = h(
        'form',
        { class: 'rq-filters', onsubmit: (e) => {
          e.preventDefault();
          const chk = R.privacy.checkInput(draft.term || 'rule');
          if (!chk.ok) return R.util.announce(chk.reason);
          Object.assign(reg, draft, { term: chk.value, run: reg.run + 1 });
          R.shell.refresh();
        } },
        ui.input('Topic / keyword', term, (v) => (draft.term = v), { key: 'reg-term' }),
        ui.select('Action type', [['', 'All types'], ['RULE', 'Final rule'], ['PRORULE', 'Proposed rule'], ['NOTICE', 'Notice'], ['PRESDOCU', 'Presidential document']], reg.type, (v) => (draft.type = v), { key: 'reg-type' }),
        ui.input('Published from', reg.from, (v) => (draft.from = v), { type: 'date', key: 'reg-from' }),
        ui.input('Published to', reg.to, (v) => (draft.to = v), { type: 'date', key: 'reg-to' }),
        h('button', { type: 'submit', class: 'rq-btn rq-btn-primary' }, 'Search')
      );
      const def = ctx.chosen.frDoc && !reg.run ? T.frDoc(ctx.chosen.frDoc) : T.frSearch(term, { perPage: 15, order: 'newest', type: reg.type || undefined, from: reg.from || undefined, to: reg.to || undefined });
      return h(
        'div',
        null,
        form,
        ui.section('US Federal Register', { icon: 'doc', desc: 'Comment deadlines and effective dates as published; verify on the official document.' }, ui.taskPanel(def, { auto: true, limit: 15 })),
        ui.section('EU, UK and other jurisdictions (link-out)', { icon: 'link' }, ui.dir('regulatory', ctx.q, { compact: true })),
        ui.section('Sector regulators (link-out)', { icon: 'umbrella' }, ui.linkouts(R.directories.insuranceRegulators.slice(0, 8), null, { compact: true }), ui.linkouts(R.directories.cyber.filter((e) => /EDPB|ICO/.test(e.name)), null, { compact: true })),
        ui.exportBar('JAQA-Regulatory-Radar.json', 'JAQA-Regulatory-Radar.csv', 'globalRisk')
      );
    }
  });

  /* ---------------------- Standards & frameworks ---------------------- */
  R.modules.register({
    id: 'standards',
    group: 'risk',
    order: 16,
    icon: 'doc',
    title: 'Standards, Certifications & Frameworks Link-Outs',
    short: 'Standards & Frameworks',
    description: 'Official references for risk, continuity, security, AI, due diligence, procurement, insurance-supervision and anti-corruption frameworks.',
    warnings: ['Standards link-outs are references, not certifications. JAQA does not verify certification status unless an official public register/API is verified. Certification status is never implied.'],
    render(ctx) {
      const q = ctx.session ? ctx.q.toLowerCase().replace(/[^a-z0-9 ]/g, ' ') : '';
      const list = R.directories.standards;
      const isMatch = (e) => q && q.split(' ').filter((t) => t.length >= 3).some((t) => e.name.toLowerCase().includes(t));
      const sorted = list.slice().sort((a, b) => isMatch(b) - isMatch(a));
      return h(
        'div',
        { class: 'rq-table-wrap', tabindex: '0', role: 'region', 'aria-label': 'Standards and frameworks' },
        h(
          'table',
          { class: 'rq-table' },
          h('thead', null, h('tr', null, ...['Standard / framework', 'Publisher', 'Relevance', 'Coverage note', 'Official link'].map((c) => h('th', { scope: 'col' }, c)))),
          h(
            'tbody',
            null,
            ...sorted.map((e) =>
              h(
                'tr',
                { class: isMatch(e) ? 'is-match' : '' },
                h('th', { scope: 'row' }, e.name, isMatch(e) ? ui.badge('Matches query', 'org') : null),
                h('td', null, e.publisher || '—'),
                h('td', null, /ISO 31000|Risk/.test(e.name) ? 'Enterprise risk' : /22301|27031|continuity/i.test(e.name) ? 'Continuity / resilience' : /27001|27035|SOC|NIST|CMMC/.test(e.name) ? 'Security & cyber' : /AI/.test(e.name) ? 'AI governance' : /OECD|Guiding|ILO/.test(e.name) ? 'Due diligence / human rights' : /FIDIC|NEC|Procurement|GPA/.test(e.name) ? 'Procurement & contracts' : /IAIS|Solvency/.test(e.name) ? 'Insurance supervision' : /UNCAC|FATF/.test(e.name) ? 'Integrity / AML' : 'Certification register'),
                h('td', null, e.kind === 'certification-register' ? 'Register for verifying certificates (link-out)' : 'Standard text may be paid; JAQA does not reproduce it. Certification status not implied.'),
                h('td', null, extLink(e.url, 'Open'))
              )
            )
          )
        )
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/procurementBids.js ---- */
/*
 * procurementBids.js — MODULE 19: Procurement & Bid Radar, MODULE 20:
 * Awards, Contracts & Past Performance, MODULE 21: Grants, Development &
 * Public Funding, MODULE 22: PPP, Concessions & Infrastructure Projects.
 *
 * HOW PROCUREMENT PORTALS ARE LINK-OUT-FIRST AND NEVER SCRAPED
 *   Verification showed TED’s search API does not return CORS headers for
 *   browser POSTs, and SAM.gov/national portals require keys or logins. They
 *   are therefore official link-outs. Live data comes from USAspending (US
 *   federal awards/assistance), which publishes past awards — not open
 *   opportunities. The UI says so plainly.
 *
 * HOW NO BID/NO-BID OR AWARD ADVICE IS GENERATED
 *   No ranking, eligibility, win probability or bid recommendation is
 *   computed anywhere. Deadlines are shown only as published, with timezone
 *   and amendment warnings.
 */
(function (R) {
  'use strict';
  const { h, extLink, fmt } = R.util;
  const ui = R.ui;
  const T = R.T;

  const PROC_WARN = 'JAQA organizes public procurement notices, awards, grants, and related evidence. It does not provide bid/no-bid advice, procurement legal advice, eligibility determinations, award predictions, or contract management advice. Always verify deadlines, eligibility, language, thresholds, lots, amendments, and official source requirements.';
  const DEADLINE_WARN = 'Tender deadlines may be jurisdiction-specific, timezone-specific, subject to amendment, translation-dependent, and controlled by official procurement portals. JAQA displays published metadata only and does not guarantee timeliness or eligibility.';
  const COLLUSION_WARN = 'JAQA must not be used to coordinate bids, share confidential pricing, allocate markets, manipulate procurement, evade sanctions, evade export controls, or engage in corrupt or anti-competitive conduct.';

  const st = { keyword: '', region: '', sort: 'amount', view: 'cards', page: 1, kind: 'contracts', run: 0, from: '', to: '' };
  R.events.on('session:cleared', () => Object.assign(st, { keyword: '', region: '', sort: 'amount', view: 'cards', page: 1, kind: 'contracts', run: 0, from: '', to: '' }));
  R.events.on('session:started', () => Object.assign(st, { keyword: '', page: 1, run: 0 }));

  const REGION_OF = (e) => {
    const r = e.region || '';
    if (/European Union|Norway|Denmark|Finland|Switzerland|United Kingdom|Europe/.test(r)) return 'Europe';
    if (/United States|Canada|Mexico|Brazil|Latin/.test(r)) return 'Americas';
    if (/Australia|New Zealand|Singapore|India|Japan|Korea|China|Asia/.test(r)) return 'Asia-Pacific';
    if (/Africa/.test(r)) return 'Africa';
    return 'Global / multilateral';
  };

  function portalTable(entries, q) {
    const groups = {};
    entries.forEach((e) => (groups[REGION_OF(e)] = groups[REGION_OF(e)] || []).push(e));
    return h(
      'div',
      { class: 'rq-table-wrap', tabindex: '0', role: 'region', 'aria-label': 'Procurement portals by region' },
      h(
        'table',
        { class: 'rq-table' },
        h('caption', { class: 'rq-sr' }, 'Map-free geographic table of official procurement portals'),
        h('thead', null, h('tr', null, ...['Region', 'Portal', 'Jurisdiction', 'Language', 'Mode'].map((c) => h('th', { scope: 'col' }, c)))),
        h(
          'tbody',
          null,
          ...Object.entries(groups).flatMap(([g, list]) =>
            list.map((e, i) => {
              const lo = R.linkout(e, q);
              return h('tr', null, i === 0 ? h('th', { scope: 'rowgroup', rowspan: String(list.length) }, g) : null, h('td', null, extLink(lo.href, e.name), lo.withQuery ? h('span', { class: 'rq-link-meta' }, ' opens with your query') : null), h('td', null, e.region || '—'), h('td', null, e.lang ? ui.badge('Translation risk (' + e.lang + ')', 'warn') : 'en'), h('td', null, ui.badge('Official link-out', 'proc')));
            })
          )
        )
      )
    );
  }

  function sortRecords(recs) {
    const r = recs.slice();
    if (st.sort === 'amount') r.sort((a, b) => (b.data.amount || 0) - (a.data.amount || 0));
    if (st.sort === 'start') r.sort((a, b) => String(b.data.start || '').localeCompare(String(a.data.start || '')));
    if (st.sort === 'end') r.sort((a, b) => String(a.data.end || '').localeCompare(String(b.data.end || '')));
    if (st.sort === 'recipient') r.sort((a, b) => String(a.fields[1][1] || '').localeCompare(String(b.fields[1][1] || '')));
    return r;
  }

  function timelineView(recs) {
    const by = {};
    recs.forEach((r) => {
      const d = (r.data.end || r.data.start || 'Undated').slice(0, 7);
      (by[d] = by[d] || []).push(r);
    });
    return h('div', { class: 'rq-timeline' }, ...Object.keys(by).sort().map((m) => h('div', { class: 'rq-timeline-month' }, h('h4', { class: 'rq-h4' }, m === 'Undated' ? m : m + ' (period-of-performance end)'), h('ul', null, ...by[m].map((r) => h('li', null, h('button', { type: 'button', class: 'rq-link-btn', onclick: () => R.shell.openDetail(r) }, r.title), ' — ', fmt.money(r.data.amount)))))));
  }

  function awardsResults(recs, task) {
    const sorted = sortRecords(recs);
    const body = st.view === 'timeline' ? timelineView(sorted) : st.view === 'table' ? ui.recordTable(sorted, [['Award', (r) => r.title], ['Agency', (r) => r.subtitle], ['Period', (r) => r.fields[5][1]], ['Amount (as reported)', (r) => fmt.money(r.data.amount)], ['Match', (r) => r.prov.confidence || '—']]) : ui.records(sorted, { forceCards: true });
    return h(
      'div',
      null,
      h('div', { class: 'rq-filters' }, ui.select('Sort', [['amount', 'Amount (as reported)'], ['start', 'Start date (newest)'], ['end', 'End date (soonest)'], ['recipient', 'Recipient A–Z']], st.sort, (v) => ((st.sort = v), R.shell.refresh()), { key: 'proc-sort' }), ui.select('View', [['cards', 'Cards'], ['table', 'Table'], ['timeline', 'Timeline (in-memory)']], st.view, (v) => ((st.view = v), R.shell.refresh()), { key: 'proc-view' })),
      body,
      h('div', { class: 'rq-row' }, st.page > 1 ? ui.button('Previous page', () => ((st.page -= 1), R.shell.refresh()), { cls: 'rq-btn-sm' }) : null, h('span', { class: 'rq-muted' }, 'Page ' + st.page), task.meta && task.meta.hasNext ? ui.button('Next page', () => ((st.page += 1), R.shell.refresh()), { cls: 'rq-btn-sm' }) : null)
    );
  }
  R.awardsResults = awardsResults;

  function searchForm(ctx, defaults, kinds) {
    const draft = { keyword: st.keyword || defaults.keyword, from: st.from, to: st.to, kind: st.kind };
    return h(
      'form',
      { class: 'rq-filters', onsubmit: (e) => {
        e.preventDefault();
        const chk = R.privacy.checkInput(draft.keyword);
        if (!chk.ok) return R.util.announce(chk.reason);
        if (chk.value.length < 3) return R.util.announce('USAspending keyword search needs at least 3 characters.');
        Object.assign(st, draft, { keyword: chk.value, page: 1, run: st.run + 1 });
        R.shell.refresh();
      } },
      ui.input('Keyword (buyer, category, CPV/NAICS term, supplier)', draft.keyword, (v) => (draft.keyword = v), { key: 'proc-kw' }),
      kinds ? ui.select('Award type', [['contracts', 'Contracts'], ['idvs', 'IDVs / frameworks'], ['grants', 'Grants / assistance']], draft.kind, (v) => (draft.kind = v), { key: 'proc-kind' }) : null,
      ui.input('Action date from', draft.from, (v) => (draft.from = v), { type: 'date', key: 'proc-from' }),
      ui.input('Action date to', draft.to, (v) => (draft.to = v), { type: 'date', key: 'proc-to' }),
      h('button', { type: 'submit', class: 'rq-btn rq-btn-primary' }, 'Search')
    );
  }

  function defaultKeyword(ctx) {
    const c = ctx.chosen;
    if (!c) return '';
    if (c.concept) return c.insuranceRelated ? ctx.q.replace(/\b(tender|rfp)\b/gi, '').trim() : c.type === 'ppp' ? 'public-private partnership' : 'services';
    if (ctx.primary) return (ctx.primary.data && ctx.primary.data.name) || ctx.primary.title;
    return ctx.q;
  }

  /* --------------------------- Procurement & Bid Radar --------------------------- */
  R.modules.register({
    id: 'procurement',
    group: 'procurement',
    order: 40,
    icon: 'doc',
    title: 'Procurement & Bid Radar',
    short: 'Procurement & Bid Radar',
    description: 'Discover public tenders, RFPs, RFQs, frameworks, awards, grants, PPPs and concessions across official portals and development banks.',
    warnings: [PROC_WARN, DEADLINE_WARN, COLLUSION_WARN],
    render(ctx) {
      const kw = st.keyword || defaultKeyword(ctx);
      const entries = [...R.directories.procurement, ...R.directories.devBanks];
      const regions = ['Europe', 'Americas', 'Asia-Pacific', 'Africa', 'Global / multilateral'];
      const filtered = st.region ? entries.filter((e) => REGION_OF(e) === st.region) : entries;
      const tedId = ctx.chosen && ctx.chosen.type === 'tender' && ctx.chosen.ted;
      return h(
        'div',
        null,
        tedId ? ui.section('TED notice ' + tedId, { icon: 'doc' }, ui.kv([['Publication number', tedId], ['Source', 'TED (Publications Office of the EU)'], ['Mode', 'Official link-out (TED API has no browser CORS)']]), extLink('https://ted.europa.eu/en/notice/-/detail/' + encodeURIComponent(tedId), 'Open notice on TED', { cls: 'rq-btn rq-btn-primary' }), ui.warning(DEADLINE_WARN, 'amber')) : null,
        ui.section('Open opportunities', { icon: 'search', desc: 'Open notices (TED, SAM.gov, national and development-bank portals) have no verified browser API and are official link-outs. Enter your query on the portal.' }, h('div', { class: 'rq-filters' }, ui.select('Region', [['', 'All regions'], ...regions.map((r) => [r, r])], st.region, (v) => ((st.region = v), R.shell.refresh()), { key: 'proc-region' })), portalTable(filtered, kw)),
        ctx.session
          ? ui.section('US federal awards (live, USAspending)', { icon: 'chart', desc: 'Past awards — useful for buyer, category and incumbent context. Not open opportunities and not a prediction of future awards.' }, searchForm(ctx, { keyword: kw }, true), kw.length >= 3 ? ui.taskPanel(T.usaAwards({ keyword: kw, kind: st.kind, from: st.from || undefined, to: st.to || undefined, page: st.page }), { auto: st.run > 0 || ['procurement', 'tender'].includes(ctx.type), render: awardsResults }) : ui.warning('Enter at least 3 characters to search awards.', 'info'))
          : ui.needSession('award search'),
        ui.section('Procurement types & categories', { icon: 'layers' }, h('div', { class: 'rq-row' }, ...R.taxonomy.procurementTypes.map((t) => ui.badge(t, 'proc'))), h('div', { class: 'rq-row' }, ...R.taxonomy.procurementCategories.map((c) => ui.badge(c.name, 'neutral')))),
        ui.section('Deadline radar (in-memory)', { icon: 'calendar' }, h('p', { class: 'rq-muted' }, 'Deadline tracking populates only from sources that publish submission deadlines through a verified API. None do today, so deadlines must be read on the official notice. JAQA never stores alerts.'), ui.warning(DEADLINE_WARN, 'amber')),
        ui.exportBar('JAQA-Procurement-Bids-results.json', 'JAQA-Procurement-Bids-results.csv', 'procurement')
      );
    }
  });

  /* ---------------------- Awards, Contracts & Past Performance ---------------------- */
  R.modules.register({
    id: 'awards',
    group: 'procurement',
    order: 41,
    icon: 'chart',
    title: 'Awards, Contracts & Past Performance',
    short: 'Awards & Past Performance',
    description: 'Public award history: recipients, buyers, values, periods of performance, parent awards and competition data where published.',
    warnings: ['Public award history does not guarantee future performance.', 'Recipient name matching may be ambiguous; verify legal entity (UEI) and contract number.'],
    render(ctx) {
      if (!ctx.session) return h('div', null, ui.needSession('award history'), ui.dir('procurement', null, { compact: true }));
      const c = ctx.chosen;
      const byRecipient = !!ctx.primary || R.pipeline.ORG_TYPES.includes(c.type);
      const name = ctx.primary ? (ctx.primary.data && ctx.primary.data.name) || ctx.primary.title : c.orgName || ctx.q;
      const detailAfter = (task) => h('p', { class: 'rq-muted' }, 'Open a record’s official USAspending page for transactions, modifications and subawards.');
      return h(
        'div',
        null,
        c.generatedId ? ui.section('Award detail', { icon: 'doc' }, ui.taskPanel(T.usaAwardDetail(c.generatedId), { auto: true })) : null,
        ui.section(byRecipient ? 'Awards to this recipient (name match)' : 'Awards matching the query', { icon: 'chart', desc: byRecipient ? 'Recipient-name search. Includes affiliates with similar names — verify UEI.' : 'Keyword search across award descriptions.' }, ui.taskPanel(byRecipient ? T.usaAwards({ recipient: name, kind: 'contracts', page: st.page }) : T.usaAwards({ keyword: c.piid || (c.concept ? 'services' : ctx.q), kind: 'contracts', page: st.page }), { auto: true, render: awardsResults, after: detailAfter, emptyText: 'No US federal contract awards matched.' })),
        ui.section('EU and other award notices (link-out)', { icon: 'link' }, ui.linkouts(R.directories.procurement.filter((e) => /TED|Contracts Finder|Find a Tender|AusTender|CanadaBuys/.test(e.name)), null, { compact: true })),
        ui.section('Related checks', { icon: 'shield' }, h('div', { class: 'rq-row' }, ui.button('Sanctions & debarment', () => R.shell.go('sanctions', { focus: true }), { cls: 'rq-btn-sm' }), ui.button('Litigation', () => R.shell.go('credit', { focus: true }), { cls: 'rq-btn-sm' }), ui.button('Financial filings', () => R.shell.go('filings', { focus: true }), { cls: 'rq-btn-sm' }), ui.button('Recalls & cyber', () => R.shell.go('supplyChain', { focus: true }), { cls: 'rq-btn-sm' }))),
        ui.exportBar('JAQA-Awards-Past-Performance.json', 'JAQA-Awards-Past-Performance.csv', 'procurement')
      );
    }
  });

  /* ---------------------- Grants, Development & Public Funding ---------------------- */
  R.modules.register({
    id: 'grants',
    group: 'procurement',
    order: 42,
    icon: 'coin',
    title: 'Grants, Development & Public Funding',
    short: 'Grants & Public Funding',
    description: 'US federal assistance awards (live) and official development-finance, EU and national funding portals (link-out).',
    warnings: ['Grant eligibility and funding decisions are controlled by official funders. JAQA does not provide grant application advice.'],
    render(ctx) {
      const kw = ctx.session ? (ctx.chosen.concept ? 'infrastructure' : ctx.primary ? (ctx.primary.data && ctx.primary.data.name) || ctx.primary.title : ctx.q) : '';
      const byRecipient = ctx.session && !!ctx.primary;
      return h(
        'div',
        null,
        ctx.session ? ui.section('US federal grants & assistance (live, USAspending)', { icon: 'chart', desc: 'Past assistance awards; call deadlines are published by funders, not here.' }, ui.taskPanel(T.usaAwards(byRecipient ? { recipient: kw, kind: 'grants' } : { keyword: kw, kind: 'grants' }), { auto: ctx.type === 'grant', render: awardsResults })) : ui.needSession('grant records'),
        ui.section('EU, development-bank & bilateral funding (link-out)', { icon: 'globe' }, ui.linkouts([...R.directories.procurement.filter((e) => e.grant), ...R.directories.devBanks.filter((e) => e.grant)], null, { compact: true })),
        ui.exportBar('JAQA-Grants-PPP-results.json', 'JAQA-Grants-PPP-results.csv', 'procurement')
      );
    }
  });

  /* ---------------------- PPP, Concessions & Infrastructure ---------------------- */
  R.modules.register({
    id: 'ppp',
    group: 'procurement',
    order: 43,
    icon: 'building',
    title: 'PPP, Concessions & Infrastructure Projects',
    short: 'PPP & Concessions',
    description: 'Public PPP, concession and infrastructure-project resources with the risk domains typically allocated in these structures.',
    warnings: ['PPP/concession structures are legally complex. JAQA does not advise on project bankability, concession terms, or risk allocation.'],
    render(ctx) {
      const domains = ['construction', 'political', 'regulatory', 'infrastructure', 'catastrophe', 'esg', 'currency-control', 'expropriation'].map((id) => R.taxonomy.global.find((d) => d.id === id)).filter(Boolean);
      return h(
        'div',
        null,
        ui.section('PPP & infrastructure databases (link-out)', { icon: 'link' }, ui.dir('ppp', null, { compact: true }), ui.linkouts(R.directories.devBanks.slice(0, 7), null, { compact: true })),
        ui.section('Risk domains commonly allocated in PPPs', { icon: 'layers', desc: 'Construction, political, regulatory, availability, demand, force majeure and ESG risks. Opens the Global Risk Universe for public evidence.' }, h('div', { class: 'rq-row' }, ...domains.map((d) => ui.button(d.name, () => R.shell.search(d.name), { cls: 'rq-btn-sm' })))),
        ctx.session ? ui.section('US regulatory documents on PPPs (live)', { icon: 'search' }, ui.taskPanel(T.frSearch('public-private partnership', { perPage: 6 }), { auto: ctx.type === 'ppp', limit: 6 })) : null,
        ctx.session ? ui.section('US federal awards mentioning concessions/PPPs (live)', { icon: 'chart' }, ui.taskPanel(T.usaAwards({ keyword: ctx.type === 'ppp' && ctx.chosen.concept ? 'public-private partnership' : ctx.q, kind: 'contracts' }), { auto: ctx.type === 'ppp', render: awardsResults })) : null,
        ui.exportBar('JAQA-Grants-PPP-results.json', 'JAQA-Grants-PPP-results.csv', 'procurement')
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/relationshipExplorer.js ---- */
/*
 * relationshipExplorer.js — MODULE 24: Relationship Explorer.
 *
 * A lazy, accessible tree (no graph library). Each edge carries provenance
 * and a confidence label. Edges reported directly by an authoritative source
 * (e.g. GLEIF Level 2) are "reported"; name-based links are "derived"
 * (dashed) and never shown as Exact. Navigation history (breadcrumbs,
 * back/forward) lives in memory only.
 */
(function (R) {
  'use strict';
  const { h, icon, extLink } = R.util;
  const ui = R.ui;
  const T = R.T;

  const ex = { root: null, history: [], index: -1, open: new Set() };
  R.events.on('session:cleared', () => Object.assign(ex, { root: null, history: [], index: -1, open: new Set() }));
  R.events.on('session:started', () => Object.assign(ex, { root: null, history: [], index: -1, open: new Set() }));

  R.explorer = {
    focus(record) {
      ex.history = ex.history.slice(0, ex.index + 1);
      ex.history.push(record);
      ex.index = ex.history.length - 1;
      ex.root = record;
      ex.open = new Set();
    }
  };

  /** Edge groups for a record: [{ id, relation, def, confidence, derived, linkout }] */
  function edgesFor(r) {
    const out = [];
    const name = (r.data && r.data.name) || r.title;
    if (r.kind === 'legal-entity' && r.ids.lei) {
      out.push({ id: 'dp', relation: 'Direct parent', def: T.gleifParent(r.ids.lei, 'direct'), confidence: 'Exact', note: 'Reported to GLEIF (Level 2)' });
      out.push({ id: 'up', relation: 'Ultimate parent', def: T.gleifParent(r.ids.lei, 'ultimate'), confidence: 'Exact', note: 'Reported to GLEIF (Level 2)' });
      out.push({ id: 'ch', relation: 'Direct children', def: T.gleifChildren(r.ids.lei), confidence: 'Exact', note: 'Reported to GLEIF (Level 2)' });
    }
    const iso2 = r.ids.country || (r.data && r.data.country);
    const c = iso2 ? R.geo.byIso2(String(iso2).slice(0, 2)) : null;
    if (c) out.push({ id: 'cty', relation: 'Jurisdiction → country context', def: T.wbCountry(c.iso3), confidence: 'Likely', derived: true, note: 'Derived from the entity’s jurisdiction/address' });
    if (r.kind === 'legal-entity' || r.kind === 'filer' || r.kind === 'unresolved-name') {
      if (r.ids.cik || (R.state.session && R.state.session.resolved.cik)) out.push({ id: 'sec', relation: 'SEC filer & filing events', def: T.secSubs(r.ids.cik || R.state.session.resolved.cik), confidence: 'Likely', derived: !r.ids.cik, note: 'Via Wikidata CIK claim or direct CIK' });
      out.push({ id: 'aw', relation: 'US federal awards (recipient name)', def: T.usaAwards({ recipient: name, kind: 'contracts' }), confidence: 'Possible', derived: true, note: 'Name match — verify UEI' });
      out.push({ id: 'rc', relation: 'Product recalls (title match)', def: T.cpscSearch(name), confidence: 'Possible', derived: true, note: 'Name match in recall titles' });
      out.push({ id: 'kv', relation: 'KEV vendor/product mentions', def: T.kevMentions(name.split(/\s+/)[0]), confidence: 'Possible', derived: true, note: 'Product-level; not deployment' });
      out.push({ id: 'ct', relation: 'Court records (name match)', def: T.courts(name, 'r'), confidence: 'Possible', derived: true, note: 'Text match — manual review' });
      out.push({ id: 'sa', relation: 'Sanctions & debarment', linkout: 'sanctions', confidence: 'Unresolved', note: 'Link-out only — no hit ≠ clear' });
      out.push({ id: 'ir', relation: 'Insurance regulators & ratings', linkout: 'insuranceRegulators', confidence: 'Unresolved', note: 'Link-out only' });
    }
    if (r.kind === 'country') {
      const iso3 = r.ids.iso3;
      out.push({ id: 'lpi', relation: 'Logistics performance', def: T.wbInd(iso3, 'lpi'), confidence: 'Exact' });
      out.push({ id: 'wgi', relation: 'Political stability (WGI)', def: T.wbInd(iso3, 'wgiPV'), confidence: 'Exact' });
      if (r.data.lat) out.push({ id: 'eq', relation: 'Earthquakes near capital', def: T.quakes(r.data.lat, r.data.lon, 500, 30), confidence: 'Likely', derived: true, note: 'Capital used as reference point' });
      out.push({ id: 'pp', relation: 'Procurement portals', linkout: 'procurement', confidence: 'Unresolved' });
    }
    if (r.kind === 'vulnerability' && r.data && r.data.vendor) out.push({ id: 'vp', relation: 'Other KEV entries for vendor', def: T.kevMentions(r.data.vendor), confidence: 'Likely', derived: true });
    return out;
  }

  function subjectRecord(ctx) {
    if (ex.root) return ex.root;
    if (ctx.primary) return ctx.primary;
    const s = ctx.session;
    if (s && s.chosen.type === 'country') {
      const t = R.tasks.get(T.wbCountry(s.chosen.iso3).key);
      if (t && t.records.length) return t.records[0];
    }
    if (s && s.chosen.type === 'cve') {
      const t = R.tasks.get(T.kevCve(s.chosen.cve).key);
      if (t && t.records.length) return t.records[0];
    }
    return null;
  }

  function nodeView(e, parentRec, depth) {
    const key = (parentRec.uid || parentRec.title) + ':' + e.id;
    const open = ex.open.has(key);
    const toggle = h('button', { type: 'button', class: 'rq-tree-toggle', 'aria-expanded': String(open), onclick: () => {
      if (open) ex.open.delete(key);
      else {
        ex.open.add(key);
        if (e.def) {
          R.tasks.ensure(e.def);
          R.tasks.start(e.def.key);
        }
      }
      R.shell.refresh();
    } }, icon('chevron', 'rq-icon-xs' + (open ? ' is-open' : '')), h('span', null, e.relation));
    const meta = h('span', { class: 'rq-tree-meta' }, ui.confidence(e.confidence), e.derived ? ui.badge('Derived link', 'neutral') : e.linkout ? ui.badge('Link-out', 'neutral') : ui.badge('Reported by source', 'ok'), e.note ? h('span', { class: 'rq-muted' }, e.note) : null);
    const li = h('li', { class: 'rq-tree-node' + (e.derived ? ' is-derived' : ''), role: 'treeitem', 'aria-expanded': String(open), 'aria-level': String(depth) }, h('div', { class: 'rq-tree-row' }, toggle, meta));
    if (open) {
      if (e.linkout) li.appendChild(ui.dir(e.linkout, null, { compact: true }));
      else if (e.def) {
        const t = R.tasks.get(e.def.key);
        if (!t || t.status === 'loading' || t.status === 'idle') li.appendChild(h('p', { class: 'rq-muted' }, 'Loading…'));
        else if (t.status === 'done')
          li.appendChild(
            h('ul', { role: 'group' }, ...t.records.slice(0, 12).map((r) =>
              h('li', { class: 'rq-tree-leaf', role: 'treeitem', 'aria-level': String(depth + 1) }, h('span', { class: 'rq-tree-leaf-title' }, r.title), ui.confidence(e.derived ? e.confidence : r.prov.confidence || e.confidence), h('span', { class: 'rq-muted' }, r.prov.sourceName), h('span', { class: 'rq-row rq-row-tight' }, ui.button('Details', () => R.shell.openDetail(r), { cls: 'rq-btn-xs' }), r.kind === 'legal-entity' || r.kind === 'country' ? ui.button('Explore from here', () => {
                R.explorer.focus(r);
                R.shell.refresh();
              }, { cls: 'rq-btn-xs', icon: 'tree' }) : null, r.prov.url ? extLink(r.prov.url, 'Source') : null))
            ))
          );
        else if (t.status === 'empty') li.appendChild(h('p', { class: 'rq-muted' }, (t.meta && t.meta.note) || 'No records reported by source.'));
        else if (t.status === 'linkout') li.appendChild(h('p', { class: 'rq-muted' }, R.net.errorText('linkout')));
        else li.appendChild(h('p', { class: 'rq-error' }, R.net.errorText(t.errorKind)));
      }
    }
    return li;
  }

  const FLOWS = [
    ['Insurance flow', ['Insurer', 'Regulator', 'Financial filings', 'Rating link-out', 'Insurance lines', 'Catastrophe exposure context', 'Reinsurer link-out', 'Broker link-out', 'Captive/ILS vehicle', 'Claims/product signals', 'Procurement opportunities'], ['org360', 'insurance', 'filings', 'insuranceStrength', 'insurance', 'climate', 'insuranceStrength', 'insurance', 'insuranceStrength', 'supplyChain', 'procurement']],
    ['Reinsurance flow', ['Reinsurer', 'Retrocessionaire link-out', 'Treaty/facultative public context', 'Cat bond/ILS link-out', 'Rating link-out', 'Regulatory link-out', 'Event losses link-out', 'Capacity market report link-out'], ['org360', 'insurance', 'insurance', 'insuranceStrength', 'insuranceStrength', 'insurance', 'climate', 'insurance']],
    ['Procurement flow', ['Tender', 'Buyer', 'CPV/UNSPSC/NAICS', 'Supplier', 'Award', 'Contract modification', 'Subcontract (where public)', 'Sanctions', 'Litigation', 'Financial filings', 'Recalls', 'Cyber', 'Country risk', 'Port/route risk', 'Insurance-related procurement'], ['procurement', 'procurement', 'procurement', 'org360', 'awards', 'awards', 'awards', 'sanctions', 'credit', 'filings', 'supplyChain', 'cyber', 'marketMacro', 'climate', 'insurance']],
    ['Finance flow', ['Counterparty', 'LEI/registry', 'Filings', 'Insolvency/liens/litigation', 'Sanctions/enforcement', 'Ratings link-out', 'Market/macro context', 'Trade exposure', 'Procurement awards', 'Insurance counterparty links'], ['org360', 'org360', 'filings', 'credit', 'sanctions', 'fragility', 'marketMacro', 'trade', 'awards', 'insuranceStrength']]
  ];

  R.modules.register({
    id: 'relationships',
    group: 'evidence',
    order: 50,
    icon: 'tree',
    title: 'Relationship Explorer',
    short: 'Relationship Explorer',
    description: 'Move through corporate families, jurisdictions, filings, awards, recalls, vulnerabilities, court records and link-outs as an expandable tree. Every node carries provenance and confidence.',
    warnings: ['Derived links (dashed) are name- or context-based and require manual review. “Possible” is never shown as “Exact”.'],
    liveRefresh: true,
    render(ctx) {
      const root = subjectRecord(ctx);
      const flows = ui.section('Canonical evidence flows', { icon: 'layers', desc: 'Each step opens the module where that evidence lives.' }, ...FLOWS.map(([name, steps, mods]) => h('div', { class: 'rq-flow-steps' }, h('h4', { class: 'rq-h4' }, name), h('ol', null, ...steps.map((s, i) => h('li', null, h('button', { type: 'button', class: 'rq-link-btn', onclick: () => R.shell.go(mods[i], { focus: true }) }, s)))))));
      if (!root) return h('div', null, ctx.session ? R.entityGate(ctx, 'relationships') || ui.warning('No explorable subject yet. Resolve an entity, country or CVE first.', 'info') : ui.needSession('relationships'), flows);
      if (!ex.history.length) R.explorer.focus(root);
      const edges = edgesFor(root);
      const crumbs = h('nav', { class: 'rq-crumbs', 'aria-label': 'Exploration trail' }, h('ol', null, ...ex.history.map((r, i) => h('li', null, i === ex.index ? h('span', { 'aria-current': 'location' }, r.title) : h('button', { type: 'button', class: 'rq-link-btn', onclick: () => {
        ex.index = i;
        ex.root = ex.history[i];
        R.shell.refresh();
      } }, r.title)))));
      const nav = h('div', { class: 'rq-row' }, ui.button('Back', () => {
        if (ex.index > 0) {
          ex.index -= 1;
          ex.root = ex.history[ex.index];
          R.shell.refresh();
        }
      }, { cls: 'rq-btn-sm', disabled: ex.index <= 0 }), ui.button('Forward', () => {
        if (ex.index < ex.history.length - 1) {
          ex.index += 1;
          ex.root = ex.history[ex.index];
          R.shell.refresh();
        }
      }, { cls: 'rq-btn-sm', disabled: ex.index >= ex.history.length - 1 }));
      const edgeRows = [];
      edges.forEach((e) => {
        const t = e.def && R.tasks.get(e.def.key);
        (t && t.records ? t.records.slice(0, 12) : []).forEach((r) => edgeRows.push([root.title, e.relation, r.title, e.derived ? e.confidence : r.prov.confidence || e.confidence, e.derived ? 'Derived' : 'Reported', r.prov.sourceName]));
      });
      return h(
        'div',
        null,
        crumbs,
        nav,
        ui.section('Tree', { icon: 'tree', desc: 'Expand a relation to load it (lazy, user-triggered).' }, h('div', { class: 'rq-tree-root' }, h('div', { class: 'rq-tree-rootnode' }, icon('building', 'rq-icon-sm'), h('strong', null, root.title), ui.confidence(root.prov.confidence), ui.button('Details', () => R.shell.openDetail(root), { cls: 'rq-btn-xs' })), h('ul', { class: 'rq-tree', role: 'tree', 'aria-label': 'Relationships of ' + root.title }, ...edges.map((e) => nodeView(e, root, 1))))),
        ui.section('Relationship table', { icon: 'list', desc: 'Loaded relations only. Text alternative to the tree.' }, edgeRows.length ? h('div', { class: 'rq-table-wrap', tabindex: '0', role: 'region', 'aria-label': 'Relationship table' }, h('table', { class: 'rq-table' }, h('thead', null, h('tr', null, ...['From', 'Relation', 'To', 'Confidence', 'Link type', 'Source'].map((c) => h('th', { scope: 'col' }, c)))), h('tbody', null, ...edgeRows.map((row) => h('tr', null, h('th', { scope: 'row' }, row[0]), ...row.slice(1).map((c) => h('td', null, c))))))) : h('p', { class: 'rq-muted' }, 'Expand relations above to populate this table.')),
        flows
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/scenarioLab.js ---- */
/*
 * scenarioLab.js — MODULE 25: Scenario Stress Lab (qualitative).
 *
 * The exposure band is a transparent count of public-signal checks, with the
 * rules printed next to the result:
 *   fewer than 2 checks loaded → Unknown
 *   0 checks with a source-reported signal → Low
 *   1 → Medium, 2 or more → High
 * No loss, premium, capital, claim, award-probability, financial-loss or
 * hedge-effectiveness figure is ever computed. No internal data is accepted.
 */
(function (R) {
  'use strict';
  const { h } = R.util;
  const ui = R.ui;
  const T = R.T;

  const st = { role: 'supplier', disruption: 'earthquake', duration: '7-30' };
  R.events.on('session:cleared', () => Object.assign(st, { role: 'supplier', disruption: 'earthquake', duration: '7-30' }));

  const DISRUPTIONS = {
    earthquake: 'Earthquake', storm: 'Storm / flood', heat: 'Extreme heat', cyber: 'Cyber (exploited vulnerability)', sanctions: 'Sanctions / export-control change',
    financial: 'Counterparty financial stress', recall: 'Product recall', political: 'Political instability / conflict', logistics: 'Logistics / port disruption', regulatory: 'Regulatory change'
  };
  const ACTIONS = {
    earthquake: ['Confirm facility addresses and seismic exposure with the counterparty', 'Request business continuity and alternate-site plans', 'Discuss property/BI programme questions with your broker (no coverage view here)'],
    storm: ['Verify official warnings with national meteorological services', 'Request site flood/wind resilience information', 'Review logistics contingency with carriers'],
    heat: ['Check worker-safety procedures and cooling resilience', 'Review energy supply contingencies'],
    cyber: ['Request confirmation of affected product/version and patch status from the vendor', 'Review SBOM/attestations and incident-response contacts', 'Check contract security obligations with counsel'],
    sanctions: ['Screen in your sanctions system of record', 'Refer matches to compliance for adjudication', 'Review export classification with trade-compliance specialists'],
    financial: ['Request recent financial statements from the counterparty', 'Consult licensed credit data and your credit team', 'Review payment terms, guarantees and step-in rights with counsel'],
    recall: ['Confirm affected SKUs/lots with the supplier', 'Coordinate with quality/regulatory teams', 'Discuss recall/product-liability questions with your broker'],
    political: ['Review country-risk policy and escalation thresholds', 'Assess alternative sourcing options', 'Discuss political-risk insurance questions with a qualified broker'],
    logistics: ['Confirm routing alternatives with logistics providers', 'Check port authority notices', 'Review inventory buffers'],
    regulatory: ['Have counsel/compliance confirm applicability and effective dates', 'Map affected contracts and specifications']
  };

  function checksFor(ctx) {
    const r = ctx.resolved || {};
    const name = ctx.primary ? (ctx.primary.data && ctx.primary.data.name) || ctx.primary.title : ctx.q;
    const iso3 = R.countryFromCtx(ctx);
    const pt = r.lat !== undefined && r.lat !== null;
    const list = [];
    const add = (label, def, test, rule) => list.push({ label, def, test, rule });
    const d = st.disruption;
    if (d === 'earthquake' && pt) add('M6+ earthquake within 300 km (30 days)', T.quakes(r.lat, r.lon, 500, 30), (recs) => recs.some((x) => x.data.mag >= 6 && x.data.dist !== null && x.data.dist <= 300), 'USGS magnitude ≥ 6.0 and distance ≤ 300 km');
    if ((d === 'storm' || d === 'heat' || d === 'logistics') && pt) add('Forecast threshold signal (7 days)', T.forecast(r.lat, r.lon, r.placeLabel), (recs) => recs.some((x) => (x.data.flags || []).some((f) => (d === 'heat' ? /temperature/ : /gust|precip/).test(f))), 'Open-Meteo thresholds shown on the forecast record');
    if ((d === 'storm' || d === 'heat') && pt && (r.iso2 === 'US' || r.iso2 === 'PR')) add('Severe/Extreme NWS alert', T.nws(r.lat, r.lon), (recs) => recs.some((x) => ['Severe', 'Extreme'].includes(x.data.severity)), 'NWS severity Severe or Extreme');
    if (d === 'cyber') add('Vendor/product text appears in CISA KEV', T.kevMentions(name.split(/\s+/)[0]), (recs) => recs.length > 0, 'At least one KEV entry matches the vendor/product text');
    if (d === 'cyber' && r.cik) add('SEC 8-K item 1.05 (cyber incident) filed', T.secSubs(r.cik), (recs) => ((recs[0] && recs[0].data.signals) || []).some((s) => s.item === '1.05'), '8-K item 1.05 present in recent filings');
    if (d === 'financial' && r.cik) add('SEC stress filing items (1.03, 2.04, 4.02) or NT filings', T.secSubs(r.cik), (recs) => ((recs[0] && recs[0].data.signals) || []).some((s) => ['1.03', '2.04', '4.02'].includes(s.item) || /^NT /.test(s.form)), 'Listed 8-K items or NT late-filing notice present');
    if (d === 'financial') add('Bankruptcy-chapter docket (name match)', T.courts(name, 'r'), (recs) => recs.some((x) => x.fields.some((f) => f[0] === 'Bankruptcy chapter' && f[1])), 'CourtListener docket with a bankruptcy chapter (Possible match)');
    if (d === 'recall') add('CPSC recall (title match)', T.cpscSearch(name), (recs) => recs.length > 0, 'At least one CPSC recall title matches');
    if ((d === 'political' || d === 'sanctions') && iso3) add('WGI Political Stability estimate below −1.0', T.wbInd(iso3, 'wgiPV'), (recs) => recs.some((x) => x.data.value < -1), 'World Bank WGI PV.EST < −1.0 (latest year)');
    if (d === 'logistics' && iso3) add('LPI overall score below 3.0', T.wbInd(iso3, 'lpi'), (recs) => recs.some((x) => x.data.value < 3), 'World Bank LPI < 3.0 (latest edition)');
    if (d === 'sanctions' || d === 'regulatory') {
      const since = new Date(Date.now() - 180 * 86400000).toISOString().slice(0, 10);
      add('US regulatory activity in last 180 days', T.frSearch(d === 'sanctions' ? 'sanctions ' + (iso3 ? (R.geo.countries.find((c) => c.iso3 === iso3) || {}).name : '') : ctx.q, { perPage: 10, order: 'newest', from: since }), (recs) => recs.length > 0, 'At least one Federal Register document in the window');
    }
    return list;
  }

  R.modules.register({
    id: 'scenario',
    group: 'evidence',
    order: 51,
    icon: 'flask',
    title: 'Scenario Stress Lab',
    short: 'Scenario Stress Lab',
    description: 'Qualitative, public-signal scenario exploration with a transparent exposure band, missing-data list and review actions.',
    warnings: [
      'Scenario output is qualitative and based on public-source signals only.',
      'It does not calculate insured loss, premium, capital impact, claim liability, bid win probability, contract award outcome, financial loss, or hedge effectiveness. No internal data upload.'
    ],
    liveRefresh: true,
    render(ctx) {
      if (!ctx.session) return ui.needSession('a scenario');
      const inputs = h(
        'div',
        { class: 'rq-filters' },
        ui.select('Subject role', [['supplier', 'Supplier'], ['buyer', 'Buyer'], ['insurer', 'Insurer'], ['reinsurer', 'Reinsurer'], ['broker', 'Broker'], ['captive', 'Captive'], ['ils', 'ILS / cat bond entity'], ['country', 'Country'], ['port', 'Port'], ['category', 'Category / HS code'], ['project', 'Project / PPP']], st.role, (v) => ((st.role = v), R.shell.refresh()), { key: 'sc-role' }),
        ui.select('Disruption type', Object.entries(DISRUPTIONS), st.disruption, (v) => ((st.disruption = v), R.shell.refresh()), { key: 'sc-dis' }),
        ui.select('Duration', [['lt7', 'Under 7 days'], ['7-30', '7–30 days'], ['30-90', '30–90 days'], ['gt90', 'Over 90 days']], st.duration, (v) => ((st.duration = v), R.shell.refresh()), { key: 'sc-dur' })
      );
      const checks = checksFor(ctx);
      let loaded = 0;
      let signals = 0;
      const rows = checks.map((c) => {
        const t = R.tasks.ensure(c.def);
        const done = t && (t.status === 'done' || t.status === 'empty');
        let res = 'Not loaded';
        if (done) {
          loaded++;
          const hit = c.test(t.records || []);
          if (hit) signals++;
          res = hit ? 'Signal (source-reported)' : 'No signal in loaded data';
        } else if (t && t.status === 'error') res = 'Unavailable: ' + R.net.errorText(t.errorKind);
        else if (t && t.status === 'linkout') res = 'Link-out only';
        return { c, t, res };
      });
      const band = loaded < 2 ? 'Unknown' : signals === 0 ? 'Low' : signals === 1 ? 'Medium' : 'High';
      const tone = { Unknown: 'neutral', Low: 'ok', Medium: 'warn', High: 'serious' }[band];
      const subject = ctx.primary ? ctx.primary.title : ctx.resolved.countryName || ctx.resolved.placeLabel || ctx.q;
      return h(
        'div',
        null,
        inputs,
        h('div', { class: 'rq-band' }, h('div', null, h('div', { class: 'rq-stat-label' }, 'Qualitative exposure band'), h('div', { class: 'rq-band-value rq-tone-' + tone }, band)), h('div', null, h('p', null, `${DISRUPTIONS[st.disruption]} · ${st.role} · ${subject}`), h('p', { class: 'rq-muted' }, `${signals} signal(s) across ${loaded} loaded check(s) of ${checks.length}. Rule: fewer than 2 checks loaded → Unknown; 0 signals → Low; 1 → Medium; 2+ → High. Duration does not change the band; it informs review priority.`))),
        !(ctx.resolved.lat !== undefined && ctx.resolved.lat !== null) && R.countryFromCtx(ctx)
          ? ui.warning('No geographic reference point. You can use the capital of the resolved jurisdiction (' + R.countryFromCtx(ctx) + ') as an approximate reference point — facility locations may differ.', 'info')
          : null,
        !(ctx.resolved.lat !== undefined && ctx.resolved.lat !== null) && R.countryFromCtx(ctx)
          ? ui.button('Use jurisdiction capital as reference point', () => {
              const d = T.wbCountry(R.countryFromCtx(ctx));
              R.tasks.ensure(d);
              R.tasks.start(d.key);
            }, { icon: 'globe', cls: 'rq-btn-sm' })
          : null,
        ui.section('Public evidence checks', { icon: 'list' }, checks.length ? h('div', { class: 'rq-table-wrap', tabindex: '0', role: 'region', 'aria-label': 'Evidence checks' }, h('table', { class: 'rq-table' }, h('thead', null, h('tr', null, ...['Check', 'Rule', 'Result', 'Action'].map((c) => h('th', { scope: 'col' }, c)))), h('tbody', null, ...rows.map(({ c, t, res }) => h('tr', null, h('th', { scope: 'row' }, c.label), h('td', null, c.rule), h('td', null, res), h('td', null, t && (t.status === 'idle' || (t.status === 'error' && t.errorKind !== 'cors_or_network')) && R.runtime.isLive(c.def.sourceId) ? ui.button('Load', () => {
          t.status = 'idle';
          R.tasks.start(c.def.key);
        }, { cls: 'rq-btn-xs', icon: 'download' }) : t && t.status === 'loading' ? 'Loading…' : '—')))))) : ui.warning('No public checks apply to this combination yet. Resolve a place/country or an entity to enable checks.', 'info')),
        ui.section('Missing data', { icon: 'info' }, h('ul', { class: 'rq-gap-list' }, ...rows.filter((x) => x.res === 'Not loaded' || /Unavailable|Link-out/.test(x.res)).map((x) => h('li', null, x.c.label + ' — ' + x.res)), h('li', null, 'Internal data (contracts, sites, inventory, policies, exposures) is never accepted here.'), !ctx.resolved.lat ? h('li', null, 'No geographic reference point (search a port/place/country or set one in Climate & Catastrophe).') : null)),
        ui.section('Recommended review actions', { icon: 'check', desc: 'Generic human-review steps. Not advice.' }, h('ul', null, ...(ACTIONS[st.disruption] || []).map((a) => h('li', null, a)))),
        ui.warning('No fake precision, no automatic supplier ranking, no guaranteed disruption prediction, no insurance coverage determination, no credit score, no investment advice.', 'amber')
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/watchlist.js ---- */
/*
 * watchlist.js — MODULE 26: Watchlist / Evidence Board.
 *
 * Holds only records derived from public sources (pinned from result cards).
 * There is deliberately no free-text notes field. Memory only: refresh or
 * Clear Session empties it.
 */
(function (R) {
  'use strict';
  const { h } = R.util;
  const ui = R.ui;

  R.modules.register({
    id: 'watchlist',
    group: 'evidence',
    order: 52,
    icon: 'pin',
    title: 'Watchlist / Evidence Board',
    short: 'Evidence Board',
    description: 'A temporary, in-memory board of pinned public-source records, exportable as an evidence pack with provenance and legal metadata.',
    warnings: ['The watchlist is temporary and is not stored by JAQA. Do not add confidential bid, pricing, underwriting, claims, contract, personal, health, bank, payment, internal risk rating, or protected commercial information.'],
    render() {
      const list = R.state.watchlist;
      const bySource = {};
      list.forEach((r) => (bySource[r.prov.sourceName] = (bySource[r.prov.sourceName] || 0) + 1));
      return h(
        'div',
        null,
        h(
          'div',
          { class: 'rq-row' },
          ui.button('Export evidence pack (JSON)', () => R.exporters.evidencePackJSON(), { icon: 'download', variant: 'primary', cls: 'rq-btn-sm' }),
          ui.button('Export evidence pack (CSV)', () => R.exporters.evidencePackCSV(), { icon: 'download', cls: 'rq-btn-sm' }),
          ui.button('Export watchlist (JSON)', () => R.exporters.watchlistJSON(), { icon: 'download', cls: 'rq-btn-sm' }),
          ui.button('Copy official source links', () => R.exporters.copyLinks(), { icon: 'copy', cls: 'rq-btn-sm' }),
          ui.button('Copy LEI list', () => R.exporters.copyIds('lei', 'LEI list'), { icon: 'copy', cls: 'rq-btn-sm' }),
          ui.button('Copy ticker list', () => R.exporters.copyIds('ticker', 'Ticker list'), { icon: 'copy', cls: 'rq-btn-sm' }),
          ui.button('Copy CIK list', () => R.exporters.copyIds('cik', 'CIK list'), { icon: 'copy', cls: 'rq-btn-sm' }),
          ui.button('Copy CVE list', () => R.exporters.copyIds('cve', 'CVE list'), { icon: 'copy', cls: 'rq-btn-sm' }),
          ui.button('Copy award ID list', () => R.exporters.copyIds('award', 'Award ID list'), { icon: 'copy', cls: 'rq-btn-sm' }),
          ui.button('Copy recall ID list', () => R.exporters.copyIds('recall', 'Recall ID list'), { icon: 'copy', cls: 'rq-btn-sm' }),
          ui.button('Copy regulatory document numbers', () => R.exporters.copyIds('frDoc', 'Regulatory document number list'), { icon: 'copy', cls: 'rq-btn-sm' }),
          list.length ? ui.button('Clear board', () => {
            R.state.watchlist = [];
            R.events.emit('watchlist:update');
          }, { icon: 'trash', variant: 'danger', cls: 'rq-btn-sm' }) : null
        ),
        list.length
          ? h('div', null, ui.bars(Object.entries(bySource).map(([k, v]) => [k, v, 'org']), { label: 'Pinned records by source' }), h('div', { class: 'rq-cards' }, ...list.map((r) => h('div', { class: 'rq-pin-wrap' }, ui.recordCard(r), ui.button('Remove', () => {
              R.state.watchlist = R.state.watchlist.filter((x) => x.uid !== r.uid);
              R.events.emit('watchlist:update');
            }, { icon: 'trash', cls: 'rq-btn-xs', aria: 'Remove from board: ' + r.title })))))
          : h('div', { class: 'rq-empty-state' }, R.util.icon('pin', 'rq-icon-lg'), h('p', null, 'No pinned records yet. Use “Pin” on any result card to build an evidence board for this session.'))
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/advancedQuery.js ---- */
/*
 * advancedQuery.js — MODULE 27: Advanced Query.
 *
 * Builds a request (live, verified sources) or an official link-out URL from
 * structured fields. Nothing is sent until the user clicks “Run Query”. The
 * raw request is previewed in a collapsible Technical Details panel. No
 * secrets are ever included.
 */
(function (R) {
  'use strict';
  const { h, extLink } = R.util;
  const ui = R.ui;
  const C = R.clients;

  const RESOURCES = {
    gleif: { label: 'Legal entities (GLEIF)', source: 'gleif', fields: [['name', 'Legal name or keyword'], ['lei', 'LEI (optional, overrides name)']], build: (v) => (v.lei ? { url: `https://api.gleif.org/api/v1/lei-records/${encodeURIComponent(v.lei)}`, run: () => C.gleif.byLei(v.lei) } : { url: `https://api.gleif.org/api/v1/lei-records?filter[fulltext]=${encodeURIComponent(v.name)}&page[size]=10`, run: () => C.gleif.search(v.name) }), need: (v) => v.name || v.lei },
    fr: { label: 'Regulatory documents (Federal Register)', source: 'federalRegister', fields: [['term', 'Keyword / topic'], ['type', 'Type (RULE, PRORULE, NOTICE, PRESDOCU)'], ['agency', 'Agency slug (e.g. treasury-department)'], ['from', 'Published from (YYYY-MM-DD)'], ['to', 'Published to (YYYY-MM-DD)']], build: (v) => ({ url: `https://www.federalregister.gov/api/v1/documents.json?conditions[term]=${encodeURIComponent(v.term)}${v.type ? '&conditions[type][]=' + v.type : ''}${v.agency ? '&conditions[agencies][]=' + v.agency : ''}${v.from ? '&conditions[publication_date][gte]=' + v.from : ''}${v.to ? '&conditions[publication_date][lte]=' + v.to : ''}&per_page=20&order=newest`, run: () => C.federalRegister.search(v.term, { perPage: 20, order: 'newest', type: v.type, agency: v.agency, from: v.from, to: v.to }) }), need: (v) => v.term },
    usa: { label: 'US federal awards (USAspending)', source: 'usaspending', fields: [['keyword', 'Keyword (≥3 chars)'], ['recipient', 'Recipient name (optional)'], ['kind', 'Type: contracts | idvs | grants'], ['from', 'Action date from (YYYY-MM-DD)'], ['to', 'Action date to (YYYY-MM-DD)']], build: (v) => ({ url: 'POST https://api.usaspending.gov/api/v2/search/spending_by_award/', body: { filters: { keywords: v.keyword ? [v.keyword] : undefined, recipient_search_text: v.recipient ? [v.recipient] : undefined }, limit: 20 }, run: () => C.usaspending.awards({ keyword: v.keyword || undefined, recipient: v.recipient || undefined, kind: v.kind || 'contracts', from: v.from || undefined, to: v.to || undefined, limit: 20 }) }), need: (v) => (v.keyword && v.keyword.length >= 3) || v.recipient },
    kev: { label: 'Known exploited vulnerabilities (CISA KEV)', source: 'cisaKev', fields: [['cve', 'CVE ID (optional)'], ['vendor', 'Vendor / product text']], build: (v) => ({ url: 'https://raw.githubusercontent.com/cisagov/kev-data/develop/known_exploited_vulnerabilities.json (filtered in your browser)', run: () => (v.cve ? C.kev.byCve(v.cve) : C.kev.mentions(v.vendor)) }), need: (v) => v.cve || (v.vendor && v.vendor.length >= 3) },
    nvd: { label: 'CVE records (NVD)', source: 'nvd', fields: [['cve', 'CVE ID'], ['keyword', 'Keyword (if no CVE)']], build: (v) => ({ url: v.cve ? `https://services.nvd.nist.gov/rest/json/cves/2.0?cveId=${v.cve}` : `https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch=${encodeURIComponent(v.keyword)}&resultsPerPage=10`, run: () => (v.cve ? C.nvd.cve(v.cve) : C.nvd.keyword(v.keyword)) }), need: (v) => v.cve || v.keyword },
    usgs: { label: 'Earthquakes (USGS)', source: 'usgs', fields: [['lat', 'Latitude'], ['lon', 'Longitude'], ['radius', 'Radius km (≤ 2000)'], ['days', 'Days back (≤ 365)']], build: (v) => ({ url: `https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&latitude=${v.lat}&longitude=${v.lon}&maxradiuskm=${v.radius || 500}&minmagnitude=4.5`, run: () => C.usgs.near(+v.lat, +v.lon, Math.min(+v.radius || 500, 2000), Math.min(+v.days || 30, 365), 4.5) }), need: (v) => isFinite(+v.lat) && isFinite(+v.lon) && v.lat !== '' && v.lon !== '' && Math.abs(+v.lat) <= 90 && Math.abs(+v.lon) <= 180 },
    wb: { label: 'Country indicator (World Bank)', source: 'worldbank', fields: [['iso3', 'Country ISO3'], ['indicator', 'Indicator key: ' + Object.keys(C.worldbank.INDICATORS).join(', ')]], build: (v) => ({ url: `https://api.worldbank.org/v2/country/${v.iso3}/indicator/${(C.worldbank.INDICATORS[v.indicator] || [v.indicator])[0]}?format=json&mrv=6`, run: () => C.worldbank.indicator(v.iso3.toUpperCase(), v.indicator) }), need: (v) => /^[A-Za-z]{3}$/.test(v.iso3 || '') && v.indicator },
    recall: { label: 'Recalls (CPSC / NHTSA)', source: 'cpsc', fields: [['title', 'CPSC recall title keyword'], ['campaign', 'NHTSA campaign number (overrides)']], build: (v) => (v.campaign ? { url: `https://api.nhtsa.gov/recalls/campaignNumber?campaignNumber=${v.campaign}`, run: () => C.nhtsa.campaign(v.campaign), source: 'nhtsa' } : { url: `https://www.saferproducts.gov/RestWebServices/Recall?format=json&RecallTitle=${encodeURIComponent(v.title)}`, run: () => C.cpsc.search(v.title) }), need: (v) => v.title || v.campaign },
    courts: { label: 'Court records (CourtListener)', source: 'courtlistener', fields: [['q', 'Party / keyword'], ['type', 'r = dockets, o = opinions']], build: (v) => ({ url: `https://www.courtlistener.com/api/rest/v4/search/?q="${encodeURIComponent(v.q)}"&type=${v.type === 'o' ? 'o' : 'r'}`, run: () => C.courtlistener.search(v.q, v.type) }), need: (v) => v.q },
    ecb: { label: 'FX reference rate (ECB)', source: 'ecb', fields: [['ccy', 'Currency (' + R.geo.ECB_CCY.join(', ') + ')']], build: (v) => ({ url: `https://data-api.ecb.europa.eu/service/data/EXR/D.${(v.ccy || '').toUpperCase()}.EUR.SP00.A?format=jsondata&lastNObservations=30`, run: () => C.ecb.exr((v.ccy || '').toUpperCase(), 30) }), need: (v) => R.geo.ECB_CCY.includes((v.ccy || '').toUpperCase()) },
    sec: { label: 'SEC filings index (EDGAR submissions)', source: 'sec', fields: [['cik', 'CIK (digits)']], build: (v) => ({ url: `https://data.sec.gov/submissions/CIK${C.sec.padCik(v.cik || '')}.json`, run: () => C.sec.submissions(v.cik) }), need: (v) => /^\d{1,10}$/.test(v.cik || '') },
    ted: { label: 'EU tenders (TED) — link-out', linkout: true, fields: [['kw', 'Keyword'], ['notice', 'Notice publication number (e.g. 123456-2025)']], build: (v) => ({ url: v.notice ? 'https://ted.europa.eu/en/notice/-/detail/' + encodeURIComponent(v.notice) : R.linkoutFromTemplate('https://ted.europa.eu/en/search/result?FT={q}', v.kw, 'https://ted.europa.eu/') }), need: (v) => v.kw || v.notice },
    sam: { label: 'SAM.gov opportunities/exclusions — link-out', linkout: true, fields: [['index', 'opp (opportunities) or ex (exclusions)']], build: (v) => ({ url: 'https://sam.gov/search/?index=' + (v.index === 'ex' ? 'ex' : 'opp') }), need: () => true },
    comtrade: { label: 'Trade flows (UN Comtrade) — link-out', linkout: true, fields: [['hs', 'HS code']], build: () => ({ url: 'https://comtradeplus.un.org/' }), need: () => true }
  };

  const st = { res: 'gleif', values: {}, run: 0, result: null };
  R.events.on('session:cleared', () => Object.assign(st, { res: 'gleif', values: {}, run: 0, result: null }));

  R.modules.register({
    id: 'advanced',
    group: 'evidence',
    order: 53,
    icon: 'sliders',
    title: 'Advanced Query',
    short: 'Advanced Query',
    description: 'Power-user query builder for verified live APIs and official link-outs, with a raw request preview.',
    warnings: ['Nothing is sent until you click Run Query. Do not enter PHI, personal data or confidential financial, bid, underwriting or claims data. Protected portals are never scraped and paywalls are never bypassed.'],
    render(ctx) {
      const def = RESOURCES[st.res];
      const v = st.values[st.res] || (st.values[st.res] = {});
      const built = def.need(v) ? def.build(v) : null;
      const sourceId = built && built.source ? built.source : def.source;
      const form = h(
        'form',
        { class: 'rq-adv', onsubmit: (e) => {
          e.preventDefault();
          if (!built) return R.util.announce('Please complete the required fields.');
          for (const val of Object.values(v)) {
            if (val && !R.privacy.checkInput(String(val)).ok) return R.util.announce(R.privacy.GENERIC_REJECT);
          }
          if (def.linkout) {
            R.shell.openExternal(built.url);
            return;
          }
          R.pipeline.ensureSession();
          st.run += 1;
          st.result = { key: 'adv:' + st.run, sourceId, label: def.label + ' (advanced query)', run: built.run };
          R.shell.refresh();
        } },
        h('div', { class: 'rq-filters' }, ui.select('Resource type', Object.entries(RESOURCES).map(([k, r]) => [k, r.label]), st.res, (val) => ((st.res = val), (st.result = null), R.shell.refresh()), { key: 'adv-res' }), ...def.fields.map(([k, label]) => ui.input(label, v[k] || '', (val) => {
          v[k] = val.trim();
        }, { key: 'adv-' + st.res + '-' + k }))),
        h('div', { class: 'rq-row' }, ui.button('Update preview', () => R.shell.refresh(), { cls: 'rq-btn-sm' }), h('button', { type: 'submit', class: 'rq-btn rq-btn-primary' }, def.linkout ? 'Open official source' : 'Run Query'), def.linkout ? null : ui.modeBadge(sourceId))
      );
      const tech = h('details', { class: 'rq-tech' }, h('summary', null, 'Technical details (request preview)'), built ? h('pre', { class: 'rq-pre' }, (built.url || '') + (built.body ? '\n\nBody:\n' + JSON.stringify(built.body, null, 2) : '')) : h('p', { class: 'rq-muted' }, 'Complete the required fields and press “Update preview”.'), h('p', { class: 'rq-fineprint' }, 'Headers: Accept: application/json · credentials: omit · cache: no-store · referrer: none. No API keys are used.'));
      if (built && !def.linkout && !R.runtime.isLive(sourceId)) tech.appendChild(ui.warning('This source is not live in this browser session; running will show the official link-out instead.', 'amber'));
      return h('div', null, form, tech, st.result && R.state.session ? ui.section('Results', { icon: 'list' }, ui.taskPanel(st.result, { auto: true })) : null);
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/coverageConsole.js ---- */
/*
 * coverageConsole.js — MODULE 28: Coverage Console.
 *
 * Transparent, in-memory view of every source: tier, default mode, runtime
 * mode, CORS verification, counters and policy flags. Availability checks
 * are user-triggered only (never on page load), sequential, and use fixed
 * probe URLs that contain no user data.
 */
(function (R) {
  'use strict';
  const { h, fmt, extLink } = R.util;
  const ui = R.ui;

  const FLAGS = [
    ['mayLagOfficialDb', 'May lag official DB'], ['publicDataOnly', 'Public data only'], ['controlledAccessProhibited', 'Controlled access prohibited'], ['paidSourceLinkOutOnly', 'Paid source: link-out only'],
    ['regulatorLinkOutOnly', 'Regulator link-out only'], ['ratingAgencyLinkOutOnly', 'Rating-agency link-out only'], ['marketReportLinkOutOnly', 'Market-report link-out only'], ['procurementPortalLinkOutOnly', 'Procurement-portal link-out only'],
    ['insolvencyRegistryLinkOutOnly', 'Insolvency-registry link-out only'], ['lienRegistryLinkOutOnly', 'Lien-registry link-out only'], ['sanctionsLinkOutOnly', 'Sanctions link-out only'], ['guidelineLinkOutOnly', 'Guideline link-out only'],
    ['translationRisk', 'Translation risk'], ['deadlineRisk', 'Deadline risk'], ['officialSourceAuthoritative', 'Official source authoritative'], ['falseNegativeRisk', 'False-negative risk'], ['legalReviewRequired', 'Legal review required']
  ];

  let checking = false;
  async function checkAll() {
    if (checking) return;
    checking = true;
    R.shell.refresh();
    const ids = R.sources.list.filter((s) => s.probe).map((s) => s.id);
    // Sequential, max one in flight: polite to providers.
    for (const id of ids) {
      await R.probeSource(id);
      R.shell.refresh();
    }
    checking = false;
    R.shell.refresh();
    R.util.announce('Availability check complete.');
  }

  R.modules.register({
    id: 'coverage',
    group: 'evidence',
    order: 54,
    icon: 'gauge',
    title: 'Coverage Console',
    short: 'Coverage Console',
    description: 'Every source JAQA knows about: live, verify, link-out or unavailable — with verification notes, counters, rate-limit events and policy flags.',
    warnings: ['Console data remains in memory only and is not sent anywhere. Availability checks run only when you click them.'],
    render() {
      const cfg = R.config.corsVerification || {};
      const devOpen = { v: false };
      const rows = R.sources.list.map((s) => {
        const rt = R.runtime.get(s.id);
        const mode = R.runtime.mode(s.id);
        return h(
          'tr',
          null,
          h('th', { scope: 'row' }, h('div', null, s.displayName), h('div', { class: 'rq-muted' }, s.region + ' · Tier ' + s.tier)),
          h('td', null, ui.modeBadge(s.id), h('div', { class: 'rq-muted' }, 'Default: ' + s.defaultMode + (s.status === 'verify' ? ' (verify)' : ''))),
          h('td', null, s.corsVerified ? ui.badge('CORS verified', 'ok') : s.liveCapable ? ui.badge('Not verified', 'warn') : ui.badge('N/A (link-out)', 'neutral'), rt.sessionVerified ? ui.badge('Confirmed this session', 'ok') : null),
          h('td', null, `OK ${rt.ok} · Fail ${rt.fail} · 429 ${rt.rateLimited} · Skipped ${rt.skipped}`, h('div', { class: 'rq-muted' }, 'Last: ' + (rt.lastStatus || '—') + (rt.lastFetch ? ' at ' + fmt.time(rt.lastFetch) : ''))),
          h('td', { class: 'rq-flags' }, ...FLAGS.filter(([k]) => s[k]).map(([, l]) => ui.badge(l, 'neutral'))),
          h('td', null, h('div', { class: 'rq-fineprint' }, s.lastVerifiedNote), s.coverageGapWarning ? h('div', { class: 'rq-fineprint rq-gap-cell' }, s.coverageGapWarning) : null, rt.reason ? h('div', { class: 'rq-fineprint' }, rt.reason) : null),
          h('td', null, s.probe ? ui.button('Check availability', async () => {
            await R.probeSource(s.id);
            R.shell.refresh();
          }, { cls: 'rq-btn-xs', disabled: checking }) : null, s.officialSiteUrl ? extLink(s.officialSiteUrl, 'Official site') : null, s.officialDocsUrl ? extLink(s.officialDocsUrl, 'Docs') : null)
        );
      });
      const counts = { live: 0, verify: 0, linkout: 0, unavailable: 0 };
      R.sources.list.forEach((s) => {
        const m = R.runtime.mode(s.id);
        const k = m === 'linkout' && s.status === 'verify' ? 'verify' : m;
        counts[k] = (counts[k] || 0) + 1;
      });
      const tasks = R.tasks.all();
      return h(
        'div',
        null,
        h('div', { class: 'rq-two-col' },
          ui.section('Source modes (this session)', { icon: 'chart' }, ui.bars([['Live', counts.live, 'ok'], ['Verify (link-out until verified)', counts.verify || 0, 'warn'], ['Link-out only', counts.linkout, 'neutral'], ['Unavailable', counts.unavailable || 0, 'serious']], { label: 'Source modes' })),
          ui.section('Build-time verification', { icon: 'check' }, ui.kv([['Origin tested', cfg.origin || 'Not verified'], ['Verified at', cfg.verifiedAt || '—'], ['Runner', cfg.runner || '—'], ['Method', cfg.method || '—']]), h('p', { class: 'rq-fineprint' }, 'Only verified hosts are allowed by the production Content-Security-Policy. Re-run scripts/verify-cors.mjs to promote a source.'))
        ),
        h('div', { class: 'rq-row' }, ui.button(checking ? 'Checking…' : 'Check availability of all live-capable sources', () => checkAll(), { icon: 'refresh', variant: 'primary', disabled: checking }), ui.button('Retry failed requests', () => R.tasks.retryFailed(), { icon: 'refresh' }), ui.button('Copy session JSON', () => {
          const payload = Object.assign(R.legal.exportBlock([]), { coverage: R.sources.list.map((s) => ({ id: s.id, mode: R.runtime.mode(s.id), stats: Object.assign({}, R.runtime.get(s.id), { rateLimitedUntil: undefined }) })) });
          navigator.clipboard && navigator.clipboard.writeText(JSON.stringify(payload, null, 2)).then(() => R.util.announce('Coverage JSON copied.'), () => R.util.announce('Copy failed.'));
        }, { icon: 'copy' }), ui.button('Export visible results', () => R.exporters.visibleCSV(), { icon: 'download' })),
        h('div', { class: 'rq-table-wrap', tabindex: '0', role: 'region', 'aria-label': 'Source capability registry' }, h('table', { class: 'rq-table rq-console' }, h('thead', null, h('tr', null, ...['Source', 'Mode', 'CORS', 'Counters', 'Flags', 'Notes', 'Actions'].map((c) => h('th', { scope: 'col' }, c)))), h('tbody', null, ...rows))),
        h('details', { class: 'rq-tech' }, h('summary', null, 'Developer panel (technical, no payloads)'), h('pre', { class: 'rq-pre' }, JSON.stringify({ queue: R.net.stats(), tasks: tasks.map((t) => ({ source: t.sourceId, status: t.status, errorKind: t.errorKind || undefined, records: (t.records || []).length })) }, null, 2))),
        ui.section('Third-party projects & platforms (reference / link-out only)', { icon: 'link', desc: 'Not integrated. No iframes, no runtime code, no API calls. No affiliation; nothing here is a clearance or authoritative determination.' }, h('ul', { class: 'rq-linklist' }, ...R.directories.thirdPartyRepos.map((e) => h('li', null, extLink(e.url, e.name), ui.badge(e.mode, 'neutral'), h('span', { class: 'rq-link-meta' }, 'Licence: ' + e.license), h('span', { class: 'rq-link-note' }, e.note))))),
        ui.section('Paid / commercial providers (link-out only)', { icon: 'coin' }, ui.dir('paid', null, { compact: true })),
        ui.section('Internal systems', { icon: 'lock' }, h('p', null, 'ERP, vendor master, spend cube, contracts, purchase orders, invoices, questionnaires, credit bureau reports, internal risk scores, audit findings, bid documents, underwriting and claims files, policy administration, treasury, hedging, payments and KYC repositories are unavailable by design. JAQA never accepts internal data.'))
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- modules/sessionPrivacy.js ---- */
/*
 * sessionPrivacy.js — MODULE 29: Session & Privacy (plus display
 * preferences). Preferences live in memory only and reset on refresh or
 * Clear Session.
 */
(function (R) {
  'use strict';
  const { h, extLink } = R.util;
  const ui = R.ui;

  function toggle(label, checked, onChange) {
    const id = R.util.uid('tg');
    return h('label', { class: 'rq-toggle', for: id }, h('input', { id, type: 'checkbox', checked: checked ? true : null, onchange: (e) => onChange(e.target.checked), 'data-focus-key': label }), h('span', null, label));
  }

  R.modules.register({
    id: 'session',
    group: 'evidence',
    order: 55,
    icon: 'lock',
    title: 'Session & Privacy',
    short: 'Session & Privacy',
    description: 'How JAQA handles your data, provider attributions, display preferences, exports and the legal notice.',
    render() {
      const p = R.state.prefs;
      const refresh = () => {
        R.shell.applyTheme();
        R.shell.renderRail();
        R.shell.refresh();
      };
      const s = R.state.session;
      return h(
        'div',
        null,
        ui.section('Your session', { icon: 'lock' }, ui.kv([
          ['Active query', s ? 'Yes — held in memory only (not shown here)' : 'None'],
          ['Lookups in memory', String(R.tasks.all().length)],
          ['Pinned records', String(R.state.watchlist.length)],
          ['API keys in memory', 'None (this release uses no keys)'],
          ['Persistence', 'None. Refresh or Clear Session wipes everything.']
        ]), h('div', { class: 'rq-row' }, ui.button('Clear Session', () => R.shell.clearSession(), { icon: 'trash', variant: 'danger' }), ui.button('Export session JSON', () => R.exporters.sessionJSON(), { icon: 'download' }), ui.button('Export evidence pack JSON', () => R.exporters.evidencePackJSON(), { icon: 'download' }), ui.button('Copy privacy statement', () => R.exporters.copyPrivacy(), { icon: 'copy' }), ui.button('Print current view', () => window.print(), { icon: 'print' }))),
        ui.section('Privacy', { icon: 'shield' }, R.shell.privacyContent()),
        ui.section('Display preferences (memory only)', { icon: 'sliders' },
          h('div', { class: 'rq-filters' },
            ui.select('Theme', [['ops', 'Situation room (HUD)'], ['dark', 'Dark'], ['light', 'Light'], ['system', 'Follow system (light/dark)']], p.theme, (v) => ((p.theme = v), refresh()), { key: 'pref-theme' }),
            ui.select('Density', [['comfortable', 'Comfortable'], ['compact', 'Compact']], p.density, (v) => ((p.density = v), refresh()), { key: 'pref-density' }),
            ui.select('Result view', [['cards', 'Cards'], ['table', 'Table']], p.viewMode, (v) => ((p.viewMode = v), refresh()), { key: 'pref-view' })
          ),
          h('div', { class: 'rq-toggles' },
            toggle('Compact warnings', p.warningsCompact, (v) => ((p.warningsCompact = v), refresh())),
            toggle('Compact market indicators', p.marketCompact, (v) => ((p.marketCompact = v), refresh())),
            toggle('Highlight coverage gaps', p.highlightGaps, (v) => ((p.highlightGaps = v), refresh())),
            toggle('Official-link-only mode (link-outs never carry your query)', p.officialLinkOnly, (v) => ((p.officialLinkOnly = v), refresh())),
            ...R.modules.GROUPS.map((g) => toggle('Show ' + g.label + ' modules', !p.hiddenGroups.has(g.id), (v) => {
              if (v) p.hiddenGroups.delete(g.id);
              else p.hiddenGroups.add(g.id);
              refresh();
            }))
          ),
          h('h4', { class: 'rq-h4' }, 'Source visibility'),
          h('div', { class: 'rq-toggles rq-toggles-grid' }, ...R.sources.list.filter((x) => x.corsVerified).map((x) => toggle(x.displayName, !p.hiddenSources.has(x.id), (v) => {
            if (v) p.hiddenSources.delete(x.id);
            else p.hiddenSources.add(x.id);
            R.events.emit('net:update');
            refresh();
          })))
        ),
        ui.section('Provider attributions', { icon: 'doc' }, h('ul', null, ...R.sources.list.filter((x) => x.attribution).map((x) => h('li', null, x.attribution, x.officialSiteUrl ? [' ', extLink(x.officialSiteUrl, 'site')] : null)))),
        ui.section('Legal notice', { icon: 'gavel' }, h('ul', null, ...R.legal.longDisclaimer.map((l) => h('li', null, l))), h('p', null, R.legal.trademarkNotice))
      );
    }
  });
})(window.JAQAWorkspace);

/* ---- assets/jaqa-workspace.js ---- */
/*
 * jaqa-workspace.js — application shell: header, universal search, module
 * rail, detail drawer, modals, command palette, status bar and boot.
 *
 * EMBEDDING: the whole app renders inside <main id="jaqa-workspace"
 * class="jaqa-workspace">. All CSS is scoped to .jaqa-workspace, so the
 * shell can be pasted into a CMS/intranet page without touching host styles.
 * To adopt JAQA global CSS, override the --rq-* custom properties.
 */
(function (R) {
  'use strict';
  const { h, clear, icon, extLink, fmt, announce } = R.util;
  const ui = R.ui;

  let root, contentEl, railEl, statusEl, searchInput, detectEl, modalLayer;
  let lastFocus = null;
  const shell = (R.shell = { visibleTaskKeys: new Set() });

  /* ------------------------------- theme ------------------------------- */
  const mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  // Themes: 'ops' (situation-room HUD, default), 'dark', 'light', 'system'.
  function applyTheme() {
    const p = R.state.prefs.theme;
    const resolved = p === 'system' ? (mq && mq.matches ? 'dark' : 'light') : p;
    root.setAttribute('data-theme', resolved);
    root.setAttribute('data-density', R.state.prefs.density);
  }
  const THEME_CYCLE = { ops: 'dark', dark: 'light', light: 'ops', system: 'ops' };
  const THEME_LABEL = { ops: 'Situation-room theme', dark: 'Dark theme', light: 'Light theme' };
  shell.cycleTheme = function () {
    const cur = root.getAttribute('data-theme');
    R.state.prefs.theme = THEME_CYCLE[cur] || 'ops';
    applyTheme();
    announce(THEME_LABEL[root.getAttribute('data-theme')] + ' (this session only).');
  };
  shell.utcNow = () => new Date().toISOString().slice(11, 19) + 'Z';
  shell.applyTheme = applyTheme;
  if (mq && mq.addEventListener) mq.addEventListener('change', () => root && applyTheme());

  /* ------------------------------ modals ------------------------------ */
  function trapFocus(container, e) {
    const f = [...container.querySelectorAll('a[href],button:not([disabled]),input,select,textarea,[tabindex]:not([tabindex="-1"])')].filter((x) => x.offsetParent !== null || x === document.activeElement);
    if (!f.length) return;
    const first = f[0];
    const last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }
  /**
   * Open an accessible dialog. kind: 'modal' | 'drawer' | 'palette'.
   * Focus is trapped while open and returned to the trigger on close.
   */
  shell.openDialog = function (title, body, kind, opts) {
    shell.closeDialog();
    lastFocus = document.activeElement;
    const id = R.util.uid('dlg');
    const closeBtn = h('button', { type: 'button', class: 'rq-icon-btn', 'aria-label': 'Close dialog', onclick: () => shell.closeDialog() }, icon('close'));
    const panel = h(
      'div',
      { class: 'rq-dialog rq-dialog-' + (kind || 'modal'), role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': id, tabindex: '-1' },
      h('div', { class: 'rq-dialog-head' }, h('h2', { id, class: 'rq-h2' }, title), closeBtn),
      h('div', { class: 'rq-dialog-body' }, body)
    );
    const backdrop = h('div', { class: 'rq-backdrop', onclick: (e) => e.target === backdrop && shell.closeDialog() }, panel);
    panel.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        shell.closeDialog();
      } else if (e.key === 'Tab') trapFocus(panel, e);
    });
    modalLayer.appendChild(backdrop);
    root.classList.add('rq-has-dialog');
    setTimeout(() => {
      const target = (opts && opts.focus && panel.querySelector(opts.focus)) || closeBtn;
      target.focus();
    }, 20);
    return panel;
  };
  shell.closeDialog = function () {
    if (!modalLayer || !modalLayer.firstChild) return;
    clear(modalLayer);
    root.classList.remove('rq-has-dialog');
    if (lastFocus && lastFocus.isConnected) lastFocus.focus();
    lastFocus = null;
  };

  /** Open an official link-out from a command (same rel/target policy as extLink). */
  shell.openExternal = function (url) {
    const a = extLink(url, 'external');
    a.style.display = 'none';
    root.appendChild(a);
    a.click();
    a.remove();
  };

  /** Detail drawer for any record. */
  shell.openDetail = function (r) {
    const body = h(
      'div',
      { class: 'rq-detail' },
      h('div', { class: 'rq-card-badges' }, ...r.badges.map((b) => ui.badge(b.text, b.tone)), ui.confidence(r.prov.confidence)),
      r.subtitle ? h('p', { class: 'rq-card-sub' }, r.subtitle) : null,
      r.summary ? ui.readMore(r.summary, 600) : null,
      ui.kv(r.fields),
      r.links && r.links.length ? h('div', { class: 'rq-row' }, ...r.links.map((l) => extLink(l.href, l.label))) : null,
      h('h3', { class: 'rq-h3' }, 'Provenance'),
      ui.kv([
        ['Source', r.prov.sourceName],
        ['Endpoint / record type', r.prov.endpoint],
        ['Source record ID', r.prov.recordId || 'Not reported by source'],
        ['Retrieved at (this session only)', r.prov.retrievedAt.toISOString()],
        ['Data category', r.prov.category],
        ['Match confidence', r.prov.confidence || 'Not applicable'],
        ['Attribution', r.prov.attribution]
      ]),
      h(
        'div',
        { class: 'rq-row' },
        r.prov.url ? extLink(r.prov.url, 'Open official source', { cls: 'rq-btn rq-btn-primary' }) : null,
        ui.button('Pin to evidence board', () => ui.pin(r), { icon: 'pin' }),
        r.kind === 'legal-entity' || r.kind === 'filer' ? ui.button('Explore relationships', () => {
          shell.closeDialog();
          R.explorer && R.explorer.focus(r);
          shell.go('relationships');
        }, { icon: 'tree' }) : null
      ),
      ui.warning(R.legal.determinations, 'info')
    );
    shell.openDialog(r.title, body, 'drawer');
  };

  /* ------------------------------ header ------------------------------ */
  function logo() {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 32 32');
    svg.setAttribute('class', 'rq-logo-mark');
    svg.setAttribute('aria-hidden', 'true');
    const paths = [
      ['rect', { x: 2, y: 2, width: 28, height: 28, rx: 7, fill: 'var(--rq-navy)' }],
      ['path', { d: 'M17.2 8h3.2v10.6c0 3.5-2.2 5.6-5.6 5.6-3 0-5.1-1.8-5.5-4.8l3.1-.6c.2 1.5 1.1 2.4 2.4 2.4 1.5 0 2.4-1 2.4-2.8V8z', fill: '#fff' }],
      ['circle', { cx: 23.5, cy: 23.5, r: 2.5, fill: 'var(--rq-teal)' }]
    ];
    paths.forEach(([t, a]) => {
      const el = document.createElementNS('http://www.w3.org/2000/svg', t);
      Object.entries(a).forEach(([k, v]) => el.setAttribute(k, v));
      svg.appendChild(el);
    });
    return svg;
  }

  const PILLS = [
    'Acme Supplier', 'Acme Reinsurer', 'Port of Rotterdam', 'Port of Singapore', 'Malaysia', 'HS 8542.31', 'CVE-2024-3094', 'CISA KEV', 'CPSC recall', 'NHTSA recall', 'TED tender', 'USAspending award',
    'Federal Register rule', 'OFAC search', 'SAM exclusion', 'World Bank LPI', 'semiconductor', 'battery materials', 'packaging resins', 'rare earth magnets', 'cyber insurance', 'marine cargo', 'D&O insurance',
    'professional indemnity', 'property insurance', 'casualty insurance', 'reinsurance', 'cat bond', 'captive', 'broker panel tender', 'insurance claims platform RFP', 'UN procurement', 'World Bank procurement',
    'ADB tender', 'AfDB procurement', 'IDB procurement', 'EBRD procurement', 'EU funding and tenders', 'PPP concession', 'infrastructure project', 'modern slavery registry', 'ISO 27001', 'NIST CSF',
    'OECD due diligence', 'sanctions list search', 'export control entity list', 'counterparty financial fragility', 'public filing stress', 'insolvency registry', 'lien judgment', 'FX risk', 'interest rate risk',
    'commodity risk', 'sovereign risk', 'insurance financial strength', 'reinsurance counterparty risk', 'trade finance exposure', 'project finance risk'
  ];

  function buildHeader() {
    const privacyBadge = h('button', { type: 'button', class: 'rq-privacy-badge', onclick: () => shell.openPrivacy(), 'aria-label': 'JAQA Privacy: open privacy details' }, icon('lock', 'rq-icon-sm'), h('span', null, R.legal.privacyBadge));
    const themeBtn = h('button', { type: 'button', class: 'rq-icon-btn', 'aria-label': 'Switch theme: situation room, dark, light (not saved)', title: 'Theme', onclick: () => shell.cycleTheme() }, icon('moon'));
    return h(
      'header',
      { class: 'rq-header' },
      h(
        'div',
        { class: 'rq-brand' },
        logo(),
        h('div', null, h('div', { class: 'rq-wordmark' }, 'JAQA'), h('h1', { class: 'rq-title' }, 'JAQA Global Risk, Finance, Insurance & Procurement Intelligence Workspace'), h('p', { class: 'rq-tagline' }, 'Public-source triage for global risk, finance, insurance/reinsurance counterparties, procurement, bids, awards, regulations, events, and supply-chain exposure.'))
      ),
      h(
        'div',
        { class: 'rq-header-actions' },
        h('div', { class: 'rq-cmd-status', role: 'group', 'aria-label': 'Workspace status' }, h('span', { class: 'rq-cmd-chip rq-mono' }, h('span', { class: 'rq-live-dot', 'aria-hidden': 'true' }), 'UTC ', h('span', { class: 'rq-utc' }, shell.utcNow())), h('span', { class: 'rq-cmd-chip rq-mono' }, 'LIVE SOURCES ' + R.sources.list.filter((x) => x.corsVerified).length), h('span', { class: 'rq-cmd-chip rq-mono' }, 'ZERO RETENTION')),
        privacyBadge,
        h(
          'div',
          { class: 'rq-row rq-row-tight' },
          ui.button('Help', () => shell.openHelp(), { icon: 'help', cls: 'rq-btn-sm' }),
          ui.button('Privacy', () => shell.openPrivacy(), { icon: 'shield', cls: 'rq-btn-sm' }),
          ui.button('Legal', () => shell.openLegal(), { icon: 'doc', cls: 'rq-btn-sm' }),
          h('button', { type: 'button', class: 'rq-btn rq-btn-sm', 'aria-label': 'Open command palette (Ctrl or Command + K)', onclick: () => shell.openPalette() }, icon('command', 'rq-icon-sm'), h('span', null, 'Commands'), h('kbd', { class: 'rq-kbd' }, 'Ctrl K')),
          themeBtn,
          ui.button('Clear Session', () => shell.clearSession(), { icon: 'trash', variant: 'danger', cls: 'rq-btn-sm' })
        )
      )
    );
  }

  function buildSearch() {
    searchInput = h('input', {
      id: 'rq-search',
      class: 'rq-search-input',
      type: 'search',
      maxlength: '140',
      autocomplete: 'off',
      autocapitalize: 'off',
      spellcheck: 'false',
      'aria-describedby': 'rq-search-help rq-confidential',
      placeholder: 'Search companies, insurers, reinsurers, brokers, captives, LEIs, tickers, CIKs, countries, ports, HS codes, CVEs, tenders, bids, awards, grants, PPPs, recalls, regulations, finance risk types, or procurement concepts...'
    });
    const form = h(
      'form',
      { class: 'rq-search', role: 'search', 'aria-label': 'Universal search', onsubmit: (e) => {
        e.preventDefault();
        shell.search(searchInput.value);
      } },
      h('label', { for: 'rq-search', class: 'rq-sr' }, 'Universal search'),
      h('div', { class: 'rq-search-field' }, icon('search', 'rq-search-icon'), searchInput),
      h('button', { type: 'submit', class: 'rq-btn rq-btn-primary rq-btn-lg' }, 'Investigate')
    );
    const pills = h('div', { class: 'rq-pills', role: 'list', 'aria-label': 'Example searches' }, ...PILLS.map((p) => h('button', { type: 'button', class: 'rq-pill', role: 'listitem', onclick: () => {
      searchInput.value = p;
      shell.search(p);
    } }, p)));
    let expanded = false;
    const more = h('button', { type: 'button', class: 'rq-link-btn', 'aria-expanded': 'false', onclick: () => {
      expanded = !expanded;
      pills.classList.toggle('is-expanded', expanded);
      more.textContent = expanded ? 'Fewer examples' : 'More examples';
      more.setAttribute('aria-expanded', String(expanded));
    } }, 'More examples');
    detectEl = h('div', { class: 'rq-detect', 'aria-live': 'polite' });
    return h(
      'div',
      { class: 'rq-search-wrap' },
      form,
      h('p', { id: 'rq-search-help', class: 'rq-helper' }, 'Try an insurer, reinsurer, broker, supplier, LEI, ticker, CIK, country, port, HS code, CVE, tender, award, grant, PPP, recall, regulation, finance risk type, or procurement concept.'),
      h('p', { id: 'rq-confidential', class: 'rq-confidential' }, icon('warn', 'rq-icon-xs'), R.legal.sensitiveWarning),
      h('div', { class: 'rq-pills-wrap' }, pills, more),
      detectEl
    );
  }

  /* -------------------------- detection banner -------------------------- */
  function renderDetection() {
    clear(detectEl);
    const s = R.state.session;
    if (!s) return;
    const c = s.chosen;
    const alts = s.detection.candidates.filter((x) => x.type !== c.type).slice(0, 6);
    const wrong = h('details', { class: 'rq-wrong' }, h('summary', null, 'Was this wrong? Choose another interpretation'), h('div', { class: 'rq-row' }, ...alts.map((a) => ui.button(`${a.label} (${a.confidence})`, () => shell.search(s.query, a.type), { cls: 'rq-btn-sm' })), ...['organization', 'country', 'port', 'riskDomain', 'procurement'].filter((t) => t !== c.type && !alts.some((a) => a.type === t)).map((t) => ui.button(R.pipeline.TYPES[t], () => shell.search(s.query, t), { cls: 'rq-btn-sm rq-btn-ghost' }))));
    detectEl.appendChild(
      h(
        'div',
        { class: 'rq-detect-card' },
        h('span', { class: 'rq-muted' }, 'Interpreted as'),
        ui.badge(c.label, 'org'),
        ui.badge('Confidence: ' + c.confidence, c.confidence === 'High' ? 'ok' : c.confidence === 'Medium' ? 'warn' : 'neutral'),
        h('span', { class: 'rq-muted rq-detect-reason' }, c.reason),
        wrong
      )
    );
    if (c.type === 'person') detectEl.appendChild(ui.warning('JAQA does not support searches about private individuals and does not aggregate personal data. For compliance screening of named persons, use official sanctions lists and your organization’s screening system of record.', 'red', 'Person search restricted.'));
  }

  /* ------------------------------- rail ------------------------------- */
  function buildRail() {
    railEl = h('nav', { class: 'rq-rail', 'aria-label': 'Workspace modules' });
    renderRail();
    railEl.addEventListener('keydown', (e) => {
      if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(e.key)) return;
      const btns = [...railEl.querySelectorAll('.rq-rail-item')];
      const i = btns.indexOf(document.activeElement);
      if (i < 0) return;
      e.preventDefault();
      const n = e.key === 'Home' ? 0 : e.key === 'End' ? btns.length - 1 : (i + (e.key === 'ArrowDown' ? 1 : -1) + btns.length) % btns.length;
      btns[n].focus();
    });
    return railEl;
  }
  function renderRail() {
    clear(railEl);
    const toggle = h('button', { type: 'button', class: 'rq-rail-toggle rq-btn rq-btn-sm', 'aria-expanded': 'false', onclick: () => {
      const open = !railEl.classList.contains('is-open');
      railEl.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', String(open));
    } }, icon('menu', 'rq-icon-sm'), h('span', null, 'Modules'));
    railEl.appendChild(toggle);
    const s = R.state.session;
    const lenses = s ? new Set(s.lenses || []) : new Set();
    R.modules.GROUPS.forEach((g) => {
      if (R.state.prefs.hiddenGroups.has(g.id)) return;
      const mods = R.modules.all().filter((m) => m.group === g.id);
      if (!mods.length) return;
      const gid = R.util.uid('grp');
      railEl.appendChild(
        h(
          'div',
          { class: 'rq-rail-group' },
          h('h2', { id: gid, class: 'rq-rail-heading' }, g.label),
          h(
            'ul',
            { 'aria-labelledby': gid },
            ...mods.map((m) =>
              h(
                'li',
                null,
                h(
                  'button',
                  { type: 'button', class: 'rq-rail-item' + (R.state.currentModule === m.id ? ' is-active' : ''), 'aria-current': R.state.currentModule === m.id ? 'page' : null, onclick: () => shell.go(m.id, { focus: true }) },
                  icon(m.icon || 'info', 'rq-icon-sm'),
                  h('span', null, m.short || m.title),
                  lenses.has(m.id) ? h('span', { class: 'rq-rail-dot', title: 'Relevant to current query' }, h('span', { class: 'rq-sr' }, ' (relevant to current query)')) : null
                )
              )
            )
          )
        )
      );
    });
  }
  shell.renderRail = renderRail;

  /* ----------------------------- navigation ----------------------------- */
  shell.go = function (id, opts) {
    const m = R.modules.get(id) || R.modules.get('overview');
    R.state.currentModule = m.id;
    renderRail();
    renderModule(opts && opts.focus);
    if (railEl.classList.contains('is-open')) railEl.classList.remove('is-open');
  };
  function ctx() {
    const s = R.state.session;
    return {
      session: s,
      q: s ? s.query : '',
      type: s ? s.chosen.type : null,
      chosen: s ? s.chosen : null,
      primary: s ? s.primary : null,
      resolved: s ? s.resolved : {},
      name: s ? (s.primary && s.primary.data && s.primary.data.name) || s.resolved.entityName || s.chosen.orgName || s.query : ''
    };
  }
  shell.ctx = ctx;
  function renderModule(focus) {
    const m = R.modules.get(R.state.currentModule);
    // Preserve focus/caret for filter inputs across in-place re-renders.
    const ae = document.activeElement;
    const focusKey = ae && contentEl.contains(ae) && ae.dataset ? ae.dataset.focusKey : null;
    const caret = focusKey && typeof ae.selectionStart === 'number' ? ae.selectionStart : null;
    const scrollY = window.scrollY;
    clear(contentEl);
    shell.visibleTaskKeys = new Set();
    const hid = R.util.uid('mh');
    const head = h(
      'div',
      { class: 'rq-module-head' },
      h('div', null, h('p', { class: 'rq-eyebrow' }, (R.modules.GROUPS.find((g) => g.id === m.group) || {}).label || ''), h('h2', { id: hid, class: 'rq-h2', tabindex: '-1' }, icon(m.icon || 'info', 'rq-icon'), m.title), m.description ? h('p', { class: 'rq-module-desc' }, m.description) : null),
      h('div', { class: 'rq-row rq-row-tight' }, ui.button(R.state.prefs.viewMode === 'table' ? 'Card view' : 'Table view', () => {
        R.state.prefs.viewMode = R.state.prefs.viewMode === 'table' ? 'cards' : 'table';
        renderModule();
      }, { icon: R.state.prefs.viewMode === 'table' ? 'grid' : 'list', cls: 'rq-btn-sm' }), ui.button('Print view', () => window.print(), { icon: 'print', cls: 'rq-btn-sm' }))
    );
    const wrap = h('section', { class: 'rq-module', 'aria-labelledby': hid, 'data-module': m.id }, head);
    if (m.warnings && m.warnings.length) wrap.appendChild(ui.moduleWarnings(m.warnings));
    let body;
    try {
      body = m.render(ctx());
    } catch (e) {
      console.error('[JAQA] module render failed:', m.id);
      body = ui.warning('This module could not be displayed. Other modules are unaffected.', 'red');
    }
    wrap.appendChild(body);
    contentEl.appendChild(wrap);
    if (focus) {
      const hd = contentEl.querySelector('#' + hid);
      if (hd) hd.focus();
    } else {
      if (focusKey) {
        const el = [...contentEl.querySelectorAll('[data-focus-key]')].find((x) => x.dataset.focusKey === focusKey);
        if (el) {
          el.focus({ preventScroll: true });
          if (caret !== null && el.setSelectionRange) el.setSelectionRange(caret, caret);
        }
      }
      window.scrollTo(0, scrollY);
    }
  }
  shell.refresh = () => renderModule(false);

  // Modules flagged liveRefresh re-render as lookups finish, unless the user
  // is interacting inside the module (then refresh on focus-out).
  let refreshTimer = null;
  let refreshPending = false;
  function scheduleRefresh() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => {
      const ae = document.activeElement;
      if (ae && ae !== contentEl && contentEl.contains(ae) && !ae.dataset.focusKey) {
        refreshPending = true;
        return;
      }
      refreshPending = false;
      renderModule(false);
    }, 300);
  }
  shell.scheduleRefresh = scheduleRefresh;

  /* ------------------------------ search ------------------------------ */
  shell.focusSearch = () => {
    searchInput.focus();
    searchInput.select();
  };
  shell.search = async function (value, forcedType) {
    const check = R.privacy.checkInput(value);
    if (!check.ok) {
      // Rejected input is neither stored nor logged; the field is cleared.
      clear(detectEl);
      detectEl.appendChild(ui.warning(check.reason, 'red', 'Input not accepted.'));
      announce(check.reason);
      searchInput.value = '';
      return;
    }
    const res = R.pipeline.run(check.value, forcedType); // session is created synchronously
    renderDetection();
    const s = R.state.session;
    if (!s) return;
    const route = (s.chosen.domain === 'cyber' && 'cyber') || R.pipeline.ROUTE[s.chosen.type] || 'overview';
    shell.go(route);
    await res;
  };

  shell.clearSession = function () {
    R.state.reset();
    searchInput.value = '';
    clear(detectEl);
    applyTheme();
    shell.go(shell.initialModule || 'situation');
    announce('Session cleared. All in-memory searches, results, watchlist items, keys and preferences were wiped.');
  };

  /* ---------------------------- status bar ---------------------------- */
  function renderStatus() {
    if (!statusEl) return;
    clear(statusEl);
    const t = R.runtime.totals();
    const tasks = R.tasks.all();
    const loading = tasks.filter((x) => x.status === 'loading').length;
    const failed = tasks.filter((x) => x.status === 'error').length;
    const live = R.sources.list.filter((s) => R.runtime.mode(s.id) === 'live').length;
    const unavailable = R.sources.list.filter((s) => R.runtime.get(s.id).mode === 'unavailable').length;
    R.util.append(statusEl, [
      h('span', { class: 'rq-status-item' }, icon('gauge', 'rq-icon-xs'), `${live} live source(s)` + (unavailable ? `, ${unavailable} unavailable this session` : '')),
      h('span', { class: 'rq-status-item' }, 'Last fetch: ' + (t.last ? fmt.time(t.last) : '—')),
      h('span', { class: 'rq-status-item' }, `OK ${t.ok} · Failed ${t.fail}` + (t.rateLimited ? ` · Rate-limited ${t.rateLimited}` : '')),
      loading ? h('span', { class: 'rq-status-item' }, ui.badge(loading + ' loading', 'org')) : null,
      failed ? h('span', { class: 'rq-status-item' }, ui.badge('Partial results', 'warn'), ' Some results could not be loaded. Other sources are still shown.') : null,
      h(
        'span',
        { class: 'rq-status-actions' },
        failed ? ui.button('Retry failed', () => R.tasks.retryFailed(), { icon: 'refresh', cls: 'rq-btn-xs' }) : null,
        ui.button('Export Session JSON', () => R.exporters.sessionJSON(), { icon: 'download', cls: 'rq-btn-xs' }),
        ui.button('Export Visible CSV', () => R.exporters.visibleCSV(), { icon: 'download', cls: 'rq-btn-xs' }),
        ui.button('Coverage Console', () => shell.go('coverage', { focus: true }), { icon: 'gauge', cls: 'rq-btn-xs' }),
        ui.button('Privacy Info', () => shell.openPrivacy(), { icon: 'lock', cls: 'rq-btn-xs' }),
        ui.button('Clear Session', () => shell.clearSession(), { icon: 'trash', cls: 'rq-btn-xs', variant: 'danger' })
      )
    ]);
  }
  let statusQueued = false;
  function queueStatus() {
    if (statusQueued) return;
    statusQueued = true;
    requestAnimationFrame(() => {
      statusQueued = false;
      renderStatus();
    });
  }

  /* --------------------------- privacy / help --------------------------- */
  function dataFlowSvg() {
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 640 150');
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-labelledby', 'rq-flow-title rq-flow-desc');
    svg.setAttribute('class', 'rq-flow');
    const add = (tag, attrs, text) => {
      const e = document.createElementNS(NS, tag);
      Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v));
      if (text) e.textContent = text;
      svg.appendChild(e);
      return e;
    };
    add('title', { id: 'rq-flow-title' }, 'Data flow');
    add('desc', { id: 'rq-flow-desc' }, 'Your browser sends a request directly to a selected public API, which responds directly to your browser. There is no JAQA server in the middle.');
    const box = (x, label, sub) => {
      add('rect', { x, y: 30, width: 170, height: 70, rx: 12, fill: 'var(--rq-surface-2)', stroke: 'var(--rq-border-strong)' });
      add('text', { x: x + 85, y: 62, 'text-anchor': 'middle', fill: 'var(--rq-text)', 'font-size': 15, 'font-weight': 600 }, label);
      add('text', { x: x + 85, y: 84, 'text-anchor': 'middle', fill: 'var(--rq-muted)', 'font-size': 12 }, sub);
    };
    box(10, 'Your browser', 'query stays in memory');
    box(460, 'Selected public API', 'e.g. GLEIF, USGS');
    add('line', { x1: 185, y1: 55, x2: 450, y2: 55, stroke: 'var(--rq-teal)', 'stroke-width': 3 });
    add('polygon', { points: '450,49 460,55 450,61', fill: 'var(--rq-teal)' });
    add('line', { x1: 455, y1: 78, x2: 190, y2: 78, stroke: 'var(--rq-navy-ink)', 'stroke-width': 3 });
    add('polygon', { points: '190,72 180,78 190,84', fill: 'var(--rq-navy-ink)' });
    add('text', { x: 320, y: 46, 'text-anchor': 'middle', fill: 'var(--rq-muted)', 'font-size': 12 }, 'request (HTTPS, no cookies)');
    add('text', { x: 320, y: 98, 'text-anchor': 'middle', fill: 'var(--rq-muted)', 'font-size': 12 }, 'public response');
    add('text', { x: 320, y: 132, 'text-anchor': 'middle', fill: 'var(--rq-text)', 'font-size': 13, 'font-weight': 600 }, 'No JAQA server in the middle');
    return svg;
  }
  shell.dataFlowSvg = dataFlowSvg;

  shell.privacyContent = function () {
    const providers = R.sources.list.filter((s) => s.kind === 'api');
    return h(
      'div',
      { class: 'rq-prose' },
      h('p', { class: 'rq-lead' }, R.legal.privacyStatement),
      dataFlowSvg(),
      h('ul', null,
        h('li', null, 'JAQA does not collect search terms. No account is required.'),
        h('li', null, 'Nothing is saved after refresh: no cookies, no browser storage, no service workers, no analytics, no tracking pixels, no JAQA server logs of searches.'),
        h('li', null, 'Searches go directly from your browser to selected public providers. Each provider may log requests according to its own policy.'),
        h('li', null, 'Link-out sources are opened directly by your browser in a new tab, with no referrer.'),
        h('li', null, 'Search terms are never placed in the page URL, so the hosting provider’s access logs do not contain them. The hosting provider may keep standard access logs (IP address, user agent, requested static file, time, status).'),
        h('li', null, 'JAQA does not scrape paid, confidential, login-protected, or subscription sources, and does not reproduce paid rating agency reports, paid market reports, paid credit reports, paid ESG ratings, or paywalled news.'),
        h('li', null, 'JAQA is not a system of record, not a sanctions clearance tool, not a credit rating agency, not an insurance broker, underwriter, actuary, claims adjuster, or coverage interpreter, not a procurement advisor, bid manager, contract evaluator, or award authority, and not a real-time supply chain control tower.')
      ),
      ui.warning(R.legal.commercialWarning, 'red', 'Commercial confidentiality.'),
      ui.warning(R.legal.sensitiveWarning, 'amber', 'Personal, financial and health data.'),
      h('h3', { class: 'rq-h3' }, 'Providers this browser may contact'),
      h('ul', { class: 'rq-provider-list' }, ...providers.map((s) => h('li', null, h('strong', null, s.displayName), ' — ', ui.modeBadge(s.id), ' ', h('span', { class: 'rq-muted' }, s.attribution)))),
      h('h3', { class: 'rq-h3' }, 'Legal notice'),
      h('p', null, R.legal.privacyLegalSentence),
      h('p', null, R.legal.copyright)
    );
  };
  shell.openPrivacy = () => shell.openDialog('JAQA Privacy', shell.privacyContent(), 'modal');
  shell.openLegal = () => shell.openDialog('Legal disclaimer', h('div', { class: 'rq-prose' }, h('ul', null, ...R.legal.longDisclaimer.map((l) => h('li', null, l))), h('p', null, R.legal.trademarkNotice)), 'modal');

  shell.helpContent = function (compact) {
    return h(
      'div',
      { class: 'rq-prose' },
      h('p', { class: 'rq-lead' }, 'JAQA is a public-source triage workspace. It organizes public evidence about organizations, insurers and reinsurers, countries, ports, products, vulnerabilities, tenders, awards, grants, PPPs, regulations and risk concepts — and shows exactly where evidence is missing.'),
      h('div', { class: 'rq-help-grid' },
        h('div', null, h('h3', { class: 'rq-h4' }, 'How it works'), h('ul', null,
          h('li', null, 'Searches are not stored by JAQA. Results come live from selected public providers verified for browser access.'),
          h('li', null, 'Other sources are link-out only and open in a new tab.'),
          h('li', null, 'Coverage is not global or complete. No hit ≠ clear.'),
          h('li', null, 'Deadlines, timezones and translations must be verified on official portals.'))),
        h('div', null, h('h3', { class: 'rq-h4' }, 'What it is not'), h('ul', null,
          h('li', null, 'Not insurance, underwriting, claims or coverage advice.'),
          h('li', null, 'Not procurement bid/no-bid advice or award decision support.'),
          h('li', null, 'Not sanctions clearance, a credit rating, investment or treasury advice.'),
          h('li', null, 'Not a system of record. It does not scrape paid or confidential sources.'))),
        h('div', null, h('h3', { class: 'rq-h4' }, 'How to use it'), h('ul', null,
          h('li', null, 'Type a query and press Investigate (press / to focus search).'),
          h('li', null, 'Check the interpretation banner — correct it if it is wrong.'),
          h('li', null, 'Open modules from the left rail; deeper sources load on demand.'),
          h('li', null, 'Pin records to the Evidence Board and export an evidence pack (JSON/CSV).'),
          h('li', null, 'Press Clear Session to wipe everything immediately.')))
      ),
      compact ? null : ui.warning(R.legal.commercialWarning, 'red', 'Do not enter confidential data.'),
      compact ? null : h('p', { class: 'rq-fineprint' }, 'Keyboard: / search · Ctrl/⌘+K commands · Esc close dialogs · ↑/↓ move through the module rail.')
    );
  };
  shell.openHelp = () => shell.openDialog('Using the JAQA Workspace', shell.helpContent(false), 'modal');

  /* -------------------------- command palette -------------------------- */
  shell.openPalette = function () {
    const cmds = [
      ...R.modules.all().map((m) => ({ label: 'Go to ' + m.title, run: () => shell.go(m.id, { focus: true }) })),
      { label: 'Focus search', run: () => shell.focusSearch() },
      { label: 'Clear session', run: () => shell.clearSession() },
      { label: 'Export current view (CSV)', run: () => R.exporters.visibleCSV() },
      { label: 'Export session (JSON)', run: () => R.exporters.sessionJSON() },
      { label: 'Export evidence pack (JSON)', run: () => R.exporters.evidencePackJSON() },
      { label: 'Open privacy', run: () => shell.openPrivacy() },
      { label: 'Open coverage console', run: () => shell.go('coverage', { focus: true }) },
      { label: 'Switch theme (situation room / dark / light)', run: () => shell.cycleTheme() },
      { label: 'Open Situation Room', run: () => shell.go('situation', { focus: true }) },
      { label: 'Activate Situation Room public feeds', run: () => { shell.go('situation'); R.situation.activateFeeds(); } },
      { label: 'Toggle table/card view', run: () => { R.state.prefs.viewMode = R.state.prefs.viewMode === 'table' ? 'cards' : 'table'; renderModule(); } },
      { label: 'Run advanced query', run: () => shell.go('advanced', { focus: true }) },
      { label: 'Open insurance regulator directory (IAIS members)', run: () => shell.openExternal('https://www.iaisweb.org/about-the-iais/iais-members/') },
      { label: 'Open procurement portal directory', run: () => shell.go('procurement', { focus: true }) },
      { label: 'Open OFAC sanctions search (link-out)', run: () => shell.openExternal('https://sanctionssearch.ofac.treas.gov/') },
      { label: 'Open SEC EDGAR full-text search (link-out)', run: () => shell.openExternal('https://www.sec.gov/edgar/search/') },
      { label: 'Open CISA KEV catalog (link-out)', run: () => shell.openExternal('https://www.cisa.gov/known-exploited-vulnerabilities-catalog') },
      { label: 'Open USGS earthquake map (link-out)', run: () => shell.openExternal('https://earthquake.usgs.gov/earthquakes/map/') },
      { label: 'Add primary entity to watchlist', run: () => R.state.session && R.state.session.primary && ui.pin(R.state.session.primary) }
    ];
    const input = h('input', { class: 'rq-input rq-palette-input', type: 'text', 'aria-label': 'Type a command', placeholder: 'Type a command, or a query and press Enter to investigate…', maxlength: '140', autocomplete: 'off' });
    const list = h('ul', { class: 'rq-palette-list', role: 'listbox', 'aria-label': 'Commands' });
    let items = [];
    let sel = 0;
    const draw = () => {
      clear(list);
      const q = input.value.toLowerCase().trim();
      items = cmds.filter((c) => !q || c.label.toLowerCase().includes(q)).slice(0, 12);
      if (q && !items.length) items = [{ label: 'Investigate this query', run: () => { searchInput.value = input.value; shell.search(input.value); } }];
      sel = Math.min(sel, items.length - 1);
      items.forEach((c, i) => list.appendChild(h('li', { role: 'option', 'aria-selected': i === sel ? 'true' : 'false', class: 'rq-palette-item' + (i === sel ? ' is-sel' : ''), onclick: () => exec(i) }, c.label)));
    };
    const exec = (i) => {
      const c = items[i];
      shell.closeDialog();
      if (c) c.run();
    };
    input.addEventListener('input', () => {
      sel = 0;
      draw();
    });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        sel = (sel + 1) % Math.max(1, items.length);
        draw();
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        sel = (sel - 1 + items.length) % Math.max(1, items.length);
        draw();
      } else if (e.key === 'Enter') {
        e.preventDefault();
        exec(sel);
      }
    });
    draw();
    shell.openDialog('Command palette', h('div', null, input, list, h('p', { class: 'rq-fineprint' }, 'Commands are not recorded. Do not type confidential information.')), 'palette', { focus: '.rq-palette-input' });
  };

  /* -------------------------------- boot -------------------------------- */
  function boot() {
    root = document.getElementById('jaqa-workspace');
    if (!root) return;
    const initialModule = root.getAttribute('data-initial-module') || 'situation';
    shell.initialModule = initialModule;
    clear(root);
    root.classList.add('jaqa-workspace');
    modalLayer = h('div', { class: 'rq-modal-layer' });
    contentEl = h('div', { id: 'rq-content', class: 'rq-content', tabindex: '-1' });
    statusEl = h('div', { class: 'rq-statusbar', role: 'status', 'aria-label': 'Provider and session status' });
    root.append(
      h('a', { class: 'rq-skip', href: '#rq-content' }, 'Skip to workspace'),
      buildHeader(),
      buildSearch(),
      h('div', { class: 'rq-body' }, buildRail(), contentEl),
      statusEl,
      h(
        'footer',
        { class: 'rq-footer' },
        h('p', null, R.legal.shortDisclaimer),
        h('p', null, R.legal.copyright + ' ' + R.legal.trademarkNotice + ' JAQA™ is an independent interface and is not affiliated with or endorsed by data providers unless expressly stated.'),
        h('p', { class: 'rq-footer-links' }, h('button', { type: 'button', class: 'rq-link-btn', onclick: () => shell.openLegal() }, 'Legal disclaimer'), ' · ', h('button', { type: 'button', class: 'rq-link-btn', onclick: () => shell.openPrivacy() }, 'Privacy'), ' · ', h('button', { type: 'button', class: 'rq-link-btn', onclick: () => shell.go('coverage', { focus: true }) }, 'Coverage'), ' · ', h('button', { type: 'button', class: 'rq-link-btn', onclick: () => shell.openHelp() }, 'Support & help'))
      ),
      h('div', { id: 'rq-live', class: 'rq-sr', 'aria-live': 'polite', 'aria-atomic': 'true' }),
      modalLayer
    );
    applyTheme();
    shell.go(R.modules.get(initialModule) ? initialModule : 'overview');
    renderStatus();

    // One clock for every UTC readout (header, strip, HUD). Text only; no data is sent.
    setInterval(() => {
      const t = shell.utcNow();
      root.querySelectorAll('.rq-utc').forEach((el) => (el.textContent = t));
    }, 1000);

    R.events.on('net:update', queueStatus);
    R.events.on('task:update', queueStatus);
    const rerender = () => renderModule(false);
    ['session:started', 'primary:changed', 'session:resolved', 'watchlist:update', 'session:cleared'].forEach((ev) => R.events.on(ev, rerender));
    R.events.on('session:started', () => renderRail());
    R.events.on('task:update', (t) => {
      const m = R.modules.get(R.state.currentModule);
      if (m && m.liveRefresh && t.status !== 'loading') scheduleRefresh();
    });
    contentEl.addEventListener('focusout', () => refreshPending && scheduleRefresh());

    // Fully started: remove the startup/diagnostics screen (see src/assets/jaqa-boot.js).
    const bootScreen = document.getElementById('jaqa-boot');
    if (bootScreen) bootScreen.remove();

    document.addEventListener('keydown', (e) => {
      const tag = (e.target && e.target.tagName) || '';
      const typing = /INPUT|TEXTAREA|SELECT/.test(tag) || (e.target && e.target.isContentEditable);
      if (e.key === '/' && !typing && !root.classList.contains('rq-has-dialog')) {
        e.preventDefault();
        shell.focusSearch();
      } else if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        shell.openPalette();
      } else if (e.key === 'Escape' && root.classList.contains('rq-has-dialog')) {
        shell.closeDialog();
      }
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})(window.JAQAWorkspace);
